"""Per-recording summary features from SPARC articulatory kinematics (EMA).

The source file stores, for every recording, a (time, 12) float16 matrix at
50 Hz giving the X/Y position of six speech articulators in a speaker-normalised
model space (roughly z-scored, |value| <~ 3):

    TDX TDY  tongue dorsum        TBX TBY  tongue body
    TTX TTY  tongue tip           LIX LIY  lower incisor (jaw)
    ULX ULY  upper lip            LLX LLY  lower lip

Articulatory undershoot (small working space), slowed transitions (low
tangential speed) and degraded inter-articulator timing are the core motor
speech signature of Parkinson's disease, ALS, cognitive impairment and
dysarthria generally, so the feature set below is organised around those three
axes plus articulatory rhythm.

Every feature is computed from a single recording in isolation -- no
per-participant or per-task pooling -- so nothing here can leak across a
cross-validation split.  120 feature columns, all float32, all prefixed `ema_`.

Run:  .venv/Scripts/python.exe src/extract_ema.py [--test]
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import DATA, PARQUET                                    # noqa: E402
from parquet_stream import (as_2d, band_power, delta_stats,         # noqa: E402
                            extract, robust_stats)

warnings.filterwarnings("ignore", category=RuntimeWarning)

NAME = "ema"
FS = 50.0                       # SPARC EMA frame rate
N_CH = 12

# ---------------------------------------------------------------- layout
CHANNELS = ["tdx", "tdy", "tbx", "tby", "ttx", "tty",
            "lix", "liy", "ulx", "uly", "llx", "lly"]
CH = {c: i for i, c in enumerate(CHANNELS)}

# (name, x-column, y-column) for the six physical articulators
ARTICULATORS = [("td", 0, 1),    # tongue dorsum
                ("tb", 2, 3),    # tongue body
                ("tt", 4, 5),    # tongue tip
                ("li", 6, 7),    # lower incisor / jaw
                ("ul", 8, 9),    # upper lip
                ("ll", 10, 11)]  # lower lip

# Channel pairs whose coupling carries clinical meaning.
CORR_PAIRS = [("tty", "lly"),    # tongue tip / lower lip
              ("tdy", "tby"),    # tongue dorsum / body (tongue rigidity)
              ("uly", "lly"),    # lip aperture coupling
              ("liy", "lly")]    # jaw / lower lip

BANDS = {"2_4": (2.0, 4.0), "4_7": (4.0, 7.0), "7_12": (7.0, 12.0)}

# robust_stats keys we keep for the derived signals.  `cv` is dropped: lip
# aperture and jaw-normalised tongue height both cross zero, so a mean-scaled
# coefficient of variation is unstable and uninterpretable for them.
ROBUST_KEEP = ["mean", "std", "p5", "p25", "p50", "p75", "p95",
               "iqr", "range9", "skew", "kurt"]
DELTA_KEEP = ["vel_absmean", "vel_p95", "acc_absmean", "jerk"]
BAND_KEEP = ["bp_2_4", "bp_4_7", "bp_7_12", "peak_freq"]

DERIVED = ["lipap", "tngh"]


def _feature_names() -> list[str]:
    n: list[str] = []
    for c in CHANNELS:                                   # 24  position extent
        n += [f"{NAME}_{c}_range", f"{NAME}_{c}_iqr"]
    for a, _, _ in ARTICULATORS:                         # 30  kinematics
        n += [f"{NAME}_{a}_spd_mean", f"{NAME}_{a}_spd_p95", f"{NAME}_{a}_spd_std",
              f"{NAME}_{a}_acc_mean", f"{NAME}_{a}_jerk_mean"]
    for a, _, _ in ARTICULATORS:                         # 18  working space
        n += [f"{NAME}_{a}_hull_area", f"{NAME}_{a}_pca_ev1", f"{NAME}_{a}_pca_elong"]
    for p, q in CORR_PAIRS:                              #  4  coordination
        n.append(f"{NAME}_corr_{p}_{q}")
    for d in DERIVED:                                    # 30  derived signals
        n += [f"{NAME}_{d}_{k}" for k in ROBUST_KEEP]
        n += [f"{NAME}_{d}_{k}" for k in DELTA_KEEP]
    n += [f"{NAME}_lipap_{k}" for k in BAND_KEEP]        #  8  rhythm spectra
    n += [f"{NAME}_spd_{k}" for k in BAND_KEEP]
    n += [f"{NAME}_stroke_rate_hz", f"{NAME}_stroke_pv_ratio",   # 3 stroke shape
          f"{NAME}_stroke_amp_mean"]
    n += [f"{NAME}_spd_mean_all", f"{NAME}_hull_area_mean", f"{NAME}_dur_s"]  # 3
    return n


FEATURES = _feature_names()
TEMPLATE = {k: np.nan for k in FEATURES}


# ---------------------------------------------------------------- primitives
def _extent(x: np.ndarray) -> tuple[float, float]:
    """Full range and interquartile range of a position channel."""
    if x.size < 3:
        return np.nan, np.nan
    q25, q75 = np.percentile(x, [25, 75])
    return float(x.max() - x.min()), float(q75 - q25)


def _kinematics(x: np.ndarray, y: np.ndarray) -> dict:
    """Tangential speed / acceleration / jerk of one articulator.

    Speed is sqrt(dx^2 + dy^2) * fs so it is a true 2-D articulator speed
    rather than a per-axis derivative; slowed articulator transitions are the
    single most replicated kinematic marker of hypokinetic dysarthria.
    """
    out = {"spd_mean": np.nan, "spd_p95": np.nan, "spd_std": np.nan,
           "acc_mean": np.nan, "jerk_mean": np.nan, "speed": None}
    if x.size < 3:
        return out
    vx, vy = np.diff(x) * FS, np.diff(y) * FS
    spd = np.hypot(vx, vy)
    out["speed"] = spd
    out["spd_mean"] = float(spd.mean())
    out["spd_p95"] = float(np.percentile(spd, 95))
    out["spd_std"] = float(spd.std())
    if x.size >= 4:
        ax, ay = np.diff(vx) * FS, np.diff(vy) * FS
        out["acc_mean"] = float(np.hypot(ax, ay).mean())
        if x.size >= 5:
            jx, jy = np.diff(ax) * FS, np.diff(ay) * FS
            out["jerk_mean"] = float(np.hypot(jx, jy).mean())
    return out


def _working_space(x: np.ndarray, y: np.ndarray) -> dict:
    """Convex-hull area and PCA shape of an articulator's 2-D trajectory."""
    out = {"hull_area": np.nan, "pca_ev1": np.nan, "pca_elong": np.nan}
    if x.size < 3:
        return out
    pts = np.column_stack([x, y]).astype(np.float64)

    try:
        from scipy.spatial import ConvexHull
        if np.unique(pts, axis=0).shape[0] >= 3:
            # In 2-D qhull reports the enclosed area as `.volume`.
            out["hull_area"] = float(ConvexHull(pts).volume)
    except Exception:
        out["hull_area"] = np.nan          # degenerate / collinear trajectory

    try:
        cov = np.cov(pts, rowvar=False)
        if np.all(np.isfinite(cov)):
            ev = np.linalg.eigvalsh(cov)   # ascending
            ev2, ev1 = float(ev[0]), float(ev[1])
            ev2 = max(ev2, 0.0)
            out["pca_ev1"] = ev1
            out["pca_elong"] = ev1 / ev2 if ev2 > 1e-12 else np.nan
    except Exception:
        pass
    return out


def _corr(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 5 or x.std() < 1e-9 or y.std() < 1e-9:
        return np.nan
    c = float(np.corrcoef(x, y)[0, 1])
    return c if np.isfinite(c) else np.nan


SMOOTH_TAPS = 7          # 140 ms Hann ~ 7 Hz cutoff = articulatory bandwidth


def _stroke_shape(spd: np.ndarray) -> dict:
    """Peak-rate and peak-speed/amplitude ratio of articulatory strokes.

    Peaks in the mean tangential speed mark individual articulatory gestures:
    their rate is a stroke-rate proxy, and peak-speed divided by the distance
    travelled within the stroke is the classic stiffness / undershoot ratio
    (higher = faster but smaller movements).

    The speed signal is low-passed first.  Un-smoothed 50 Hz EMA speed is
    dominated by frame-level tracking noise, and peak-picking it returns ~7.5
    strokes/s for every task including quiet breathing; after smoothing the
    rate orders correctly (prolonged vowel 2.0 < breathing 2.7 < read passage
    3.0 < diadochokinesis 3.2-3.7 Hz).
    """
    out = {"stroke_rate_hz": np.nan, "stroke_pv_ratio": np.nan,
           "stroke_amp_mean": np.nan}
    if spd.size < 20 or spd.std() < 1e-9:
        return out
    if spd.size > SMOOTH_TAPS:
        w = np.hanning(SMOOTH_TAPS + 2)[1:-1]
        spd = np.convolve(spd, w / w.sum(), mode="same")
    if spd.std() < 1e-9:
        return out
    try:
        from scipy.signal import find_peaks
        pk, _ = find_peaks(spd, prominence=0.5 * spd.std(),
                           distance=max(1, int(round(FS / 8.0))))
    except Exception:
        return out

    dur = spd.size / FS
    out["stroke_rate_hz"] = float(pk.size / dur) if dur > 0 else np.nan
    if pk.size == 0:
        return out

    # Segment each stroke between the troughs flanking its speed peak.
    bounds = np.concatenate([[0], (pk[:-1] + pk[1:]) // 2, [spd.size]])
    amps, ratios = [], []
    for i, p in enumerate(pk):
        lo, hi = int(bounds[i]), int(bounds[i + 1])
        seg = spd[lo:hi]
        if seg.size < 2:
            continue
        lmin = lo + int(np.argmin(spd[lo:p + 1])) if p > lo else lo
        rmin = p + int(np.argmin(spd[p:hi])) if hi > p + 1 else hi
        if rmin <= lmin:
            continue
        amp = float(spd[lmin:rmin].sum() / FS)   # path length of the stroke
        if amp > 1e-9:
            amps.append(amp)
            ratios.append(float(spd[p]) / amp)
    if amps:
        out["stroke_amp_mean"] = float(np.mean(amps))
        out["stroke_pv_ratio"] = float(np.mean(ratios))
    return out


def _sub(d: dict, prefix: str, keep: list[str]) -> dict:
    """Pull the wanted keys out of a helper's output, NaN-filling the rest."""
    return {f"{prefix}_{k}": float(d.get(f"{prefix}_{k}", np.nan)) for k in keep}


# ---------------------------------------------------------------- summarise
def summarise(rec: dict) -> dict:
    out = dict(TEMPLATE)
    a = as_2d(rec["value"], expect_channels=N_CH)
    if a.ndim != 2 or a.shape[1] != N_CH or a.shape[0] == 0:
        return out

    good = np.isfinite(a).all(axis=1)
    if not good.all():
        a = a[good]
    n = a.shape[0]
    out[f"{NAME}_dur_s"] = float(n / FS)
    if n < 3:
        return out
    a = a.astype(np.float64)

    # --- per-channel position extent -----------------------------------
    for c, j in CH.items():
        rng, iqr = _extent(a[:, j])
        out[f"{NAME}_{c}_range"] = rng
        out[f"{NAME}_{c}_iqr"] = iqr

    # --- per-articulator kinematics + working space ---------------------
    speeds, spd_means, hulls = [], [], []
    for art, jx, jy in ARTICULATORS:
        x, y = a[:, jx], a[:, jy]
        k = _kinematics(x, y)
        for key in ("spd_mean", "spd_p95", "spd_std", "acc_mean", "jerk_mean"):
            out[f"{NAME}_{art}_{key}"] = k[key]
        if k["speed"] is not None:
            speeds.append(k["speed"])
        spd_means.append(k["spd_mean"])

        w = _working_space(x, y)
        for key, v in w.items():
            out[f"{NAME}_{art}_{key}"] = v
        hulls.append(w["hull_area"])

    if np.any(np.isfinite(spd_means)):
        out[f"{NAME}_spd_mean_all"] = float(np.nanmean(spd_means))
    if np.any(np.isfinite(hulls)):
        out[f"{NAME}_hull_area_mean"] = float(np.nanmean(hulls))

    # --- inter-articulator coordination ---------------------------------
    for p, q in CORR_PAIRS:
        out[f"{NAME}_corr_{p}_{q}"] = _corr(a[:, CH[p]], a[:, CH[q]])

    # --- derived functional signals -------------------------------------
    sig = {"lipap": a[:, CH["uly"]] - a[:, CH["lly"]],   # lip aperture
           "tngh": a[:, CH["tty"]] - a[:, CH["liy"]]}    # jaw-normalised tongue height
    for d in DERIVED:
        s = sig[d].astype(np.float32)
        pre = f"{NAME}_{d}"
        out.update(_sub(robust_stats(s, pre), pre, ROBUST_KEEP))
        out.update(_sub(delta_stats(s, pre, FS), pre, DELTA_KEEP))

    # --- articulatory rhythm --------------------------------------------
    lip = sig["lipap"].astype(np.float32)
    out.update(_sub(band_power(lip, FS, BANDS, f"{NAME}_lipap"),
                    f"{NAME}_lipap", BAND_KEEP))

    if speeds:
        mspd = np.mean(np.vstack(speeds), axis=0)
        out.update(_sub(band_power(mspd.astype(np.float32), FS, BANDS, f"{NAME}_spd"),
                        f"{NAME}_spd", BAND_KEEP))
        for k, v in _stroke_shape(mspd).items():
            out[f"{NAME}_{k}"] = v

    return {k: out[k] for k in FEATURES}


# ---------------------------------------------------------------- main
def main() -> None:
    test = "--test" in sys.argv
    src = PARQUET["sparc_ema"]
    dst = DATA / (f"dyn_{NAME}_TEST.parquet" if test else f"dyn_{NAME}.parquet")
    print(f"{len(FEATURES)} feature columns -> {dst}", flush=True)
    df = extract(src, "ema", summarise, dst,
                 limit_groups=1 if test else None,
                 progress_every=1 if test else 1)
    if test:
        import pandas as pd
        pd.set_option("display.width", 200, "display.max_columns", 12)
        print(df.head(4).iloc[:, :10])
        nan = df[FEATURES].isna().mean()
        print(f"\nNaN fraction: min {nan.min():.4f}  max {nan.max():.4f}")
        print(nan.sort_values(ascending=False).head(12))


if __name__ == "__main__":
    main()
