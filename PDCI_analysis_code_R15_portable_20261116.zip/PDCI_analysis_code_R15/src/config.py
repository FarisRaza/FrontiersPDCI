"""Shared configuration: paths, target definitions, task taxonomy, leakage blocklists.

Everything downstream imports from here so that label definitions and the
leakage policy live in exactly one place.
"""
from __future__ import annotations

import re
import os
from pathlib import Path

# ---------------------------------------------------------------- paths
ROOT = Path(os.environ.get("PDCI_DATA_ROOT", str(Path(__file__).resolve().parents[2]))).resolve()
ANALYSIS = Path(os.environ.get("PDCI_ANALYSIS_ROOT", str(ROOT / "analysis"))).resolve()
DATA = ANALYSIS / "data"
MODELS = ANALYSIS / "models"
RESULTS = ANALYSIS / "results"
FIGURES = ANALYSIS / "figures"
LOGS = ANALYSIS / "logs"
for _p in (DATA, MODELS, RESULTS, FIGURES, LOGS):
    _p.mkdir(parents=True, exist_ok=True)

PHENO = ROOT / "phenotype"
FEATS = ROOT / "features"
STATIC_TSV = FEATS / "static_features.tsv"

# The three big torchaudio files arrived with numeric suffixes from the
# download manager; torchaudio_pitch.parquet is truncated and unreadable.
PARQUET = {
    "sparc_ema": FEATS / "sparc_ema.parquet",
    "sparc_pitch": FEATS / "sparc_pitch.parquet",
    "sparc_periodicity": FEATS / "sparc_periodicity.parquet",
    "sparc_loudness": FEATS / "sparc_loudness.parquet",
    "ppgs": FEATS / "ppgs.parquet",
    "mfcc": FEATS / "torchaudio_mfcc-004.parquet",
    "mel": FEATS / "torchaudio_mel_spectrogram-001.parquet",
    "spectrogram": FEATS / "torchaudio_spectrogram-002.parquet",
}

# Accept official release names without duplicating or renaming raw data.
for _key, _official in {"mfcc": "torchaudio_mfcc.parquet",
                       "mel": "torchaudio_mel_spectrogram.parquet",
                       "spectrogram": "torchaudio_spectrogram.parquet"}.items():
    if not PARQUET[_key].exists() and (FEATS / _official).exists():
        PARQUET[_key] = FEATS / _official

RANDOM_STATE = 20260725

# ---------------------------------------------------------------- targets
# label_kind:
#   "membership"  -> appearing in the diagnosis TSV *is* the site-assigned
#                    clinical diagnosis (these modules have clinician-rated
#                    severity fields and zero control overlap).
#   "field"       -> membership is not enough; a specific field must say Yes.
#   "screener"    -> the TSV is a symptom questionnaire administered to
#                    controls as well; the label must be *scored*, not
#                    inferred from membership.
TARGETS = {
    "airway_stenosis": dict(file="airway_stenosis", kind="membership", category="respiratory"),
    "parkinsons_disease": dict(file="parkinsons_disease", kind="membership", category="neuro"),
    "laryngeal_dystonia": dict(file="laryngeal_dystonia", kind="membership", category="voice"),
    "cognitive_impairment": dict(file="cognitive_impairment", kind="membership", category="neuro"),
    "unilateral_vocal_fold_paralysis": dict(file="unilateral_vocal_fold_paralysis", kind="membership", category="voice"),
    "benign_lesions": dict(file="benign_lesions", kind="membership", category="voice"),
    "muscle_tension_dysphonia": dict(file="muscle_tension_dysphonia", kind="membership", category="voice"),
    "unexplained_chronic_cough": dict(file="unexplained_chronic_cough", kind="membership", category="respiratory"),
    "depression": dict(file="depression", kind="field", field="dmdd_diagnosed_dd",
                       positive={"Yes"}, category="mood_psych"),
    "psychiatric_history": dict(file="psychiatric_history", kind="membership", category="mood_psych"),
    "adhd_screen_positive": dict(file="adhd_adult", kind="screener", scorer="asrs", category="mood_psych"),
    "ptsd_screen_positive": dict(file="ptsd_adult", kind="screener", scorer="pcl5", category="mood_psych"),
}

# Composite category targets (a participant is positive if positive on any
# member disease).  Built from the *clinical* targets only -- screener-derived
# labels are deliberately excluded so the composites stay diagnosis-based.
CATEGORY_TARGETS = {
    "CAT_voice": ["laryngeal_dystonia", "unilateral_vocal_fold_paralysis",
                  "benign_lesions", "muscle_tension_dysphonia"],
    "CAT_neuro": ["parkinsons_disease", "cognitive_impairment"],
    "CAT_respiratory": ["airway_stenosis", "unexplained_chronic_cough"],
    "CAT_mood_psych": ["depression", "psychiatric_history"],
}

# Rare diagnoses -- never modelled, but needed to define "single category"
# cohorts and to build the any-disease indicator honestly.
RARE_DIAGNOSES = {
    "anxiety": "mood_psych",
    "precancerous_lesions": "voice",
    "bipolar_disorder": "mood_psych",
    "copd_and_asthma": "respiratory",
    "glottic_insufficiency": "voice",
    "laryngitis": "voice",
    "laryngeal_cancer": "voice",
    "amyotrophic_lateral_sclerosis": "neuro",
}

# ---------------------------------------------------------------- ASRS / PCL-5
ASRS_LIKERT = {"Never": 0, "Rarely": 1, "Sometimes": 2, "Often": 3, "Very Often": 4}

# ASRS v1.1 Part A: the six screener items.  Items 1-3 (inattention) score
# positive at "Sometimes" or above; items 4-6 (hyperactivity) at "Often" or
# above.  4+ positives = screen positive.
ASRS_PART_A = {
    "wrapping_up": 2,            # trouble wrapping up final details
    "things_in_order": 2,        # difficulty getting things in order
    "remembering_appt": 2,       # problems remembering appointments
    "avoidance": 3,              # avoid/delay tasks requiring thought
    "fidget": 3,                 # fidget or squirm when seated long
    "overly_active": 3,          # overly active / compelled to do things
}
ASRS_PART_B = ["careless", "difficulty_attention", "difficulty_concentrating",
               "difficulty_unwinding", "difficulty_waiting", "distracted",
               "finish_other_sent", "interrupt_others", "misplace",
               "remain_seated", "restless", "talking_too_much"]

# PCL-5 abbreviated (8 items, 0-4 each).  Standard abbreviated-form cut point
# scaled from the 20-item cut of 33 -> 8/20 * 33 ~= 13.
PCL5_ITEMS = ["avoiding_reminders", "emotionally_upset", "feeling_jumpy", "flashbacks",
              "irritable", "losing_interest", "neg_emotional_state", "super_alert",
              "thinking_stressful_event"]
PCL5_CUTOFF = 13

# ---------------------------------------------------------------- task taxonomy
# 21 canonical task groups, matching the convention the team already uses in
# its per-task significance tables.
TASK_GROUP_RULES = [
    (r"^animal-fluency", "animal_fluency"),
    (r"^breath-sounds", "breath_sounds"),
    (r"^cape-v-sentences", "cape_v_sentences"),
    (r"^caterpillar-passage", "caterpillar_passage"),
    (r"^cinderella-story", "cinderella_story"),
    (r"^diadochokinesis", "diadochokinesis"),
    (r"^free-speech", "free_speech"),
    (r"^glides-|^high-to-low", "glides"),
    (r"^harvard-sentences", "harvard_sentences"),
    (r"^loudness", "loudness"),
    (r"^maximum-phonation-time", "maximum_phonation_time"),
    (r"^open-response-questions", "open_response_questions"),
    (r"^picture-description", "picture_description"),
    (r"^productive-vocabulary", "productive_vocabulary"),
    (r"^prolonged-vowel", "prolonged_vowel"),
    (r"^rainbow-?passage", "rainbow_passage"),
    (r"^random-item-generation", "random_item_generation"),
    (r"^respiration-and-cough-.*cough", "cough_respiration"),
    (r"^respiration-and-cough", "breathing"),
    (r"^story-recall", "story_recall"),
    (r"^voluntary-cough", "voluntary_cough"),
    (r"^word-color-stroop", "word_color_stroop"),
]

# Tasks completed by essentially the whole cohort (>= 780 of 833
# participants).  These get individual per-task features; everything else is
# only used inside the cross-task average.
CORE_TASKS = [
    "prolonged_vowel", "glides", "maximum_phonation_time", "free_speech",
    "diadochokinesis", "loudness", "breathing", "cough_respiration",
    "rainbow_passage", "story_recall", "picture_description",
]

# Finer-grained motor-speech contrasts worth keeping separately: alternating
# vs sequential motion rate carries different clinical information.
DDK_FINE = {
    "diadochokinesis-pa": "ddk_pa", "diadochokinesis-ta": "ddk_ta",
    "diadochokinesis-ka": "ddk_ka", "diadochokinesis-pataka": "ddk_pataka",
    "diadochokinesis-buttercup": "ddk_buttercup",
    "diadochokinesis-v2-puh": "ddk_pa", "diadochokinesis-v2-tuh": "ddk_ta",
    "diadochokinesis-v2-kuh": "ddk_ka", "diadochokinesis-v2-puhtuhkuh": "ddk_pataka",
    "diadochokinesis-v2-buttercup": "ddk_buttercup",
}
GLIDE_FINE = {"glides-low-to-high": "glide_up", "glides-high-to-low": "glide_down",
              "high-to-low": "glide_down"}

_TASK_RE = [(re.compile(p), g) for p, g in TASK_GROUP_RULES]


def task_group(name: str) -> str:
    """Map a raw task_name to one of the 21 canonical groups."""
    if not isinstance(name, str):
        return "other"
    for rx, grp in _TASK_RE:
        if rx.match(name):
            return grp
    return "other"


def task_fine(name: str) -> str | None:
    """Sub-task label for the motor-speech contrasts we keep separately."""
    if not isinstance(name, str):
        return None
    base = re.sub(r"-\d+$", "", name)
    if base in DDK_FINE:
        return DDK_FINE[base]
    if base in GLIDE_FINE:
        return GLIDE_FINE[base]
    return None


# ---------------------------------------------------------------- leakage policy
# confounders.tsv carries self-reported medical history and treatment history
# that restates the diagnosis outright.  Any confounder column matching one of
# these patterns is dropped for that target.  Patterns are matched as
# substrings against the lowercased column name.
TARGET_LEAK_PATTERNS = {
    "airway_stenosis": ["airway_stenosis", "tracheostomy", "prolonged_intubation",
                        "airway_surgery_reconstruction", "vfp_bilateral",
                        "cordotomy_arytenoidectomy", "throat_surgical", "throat_med_history"],
    "parkinsons_disease": ["parkinsons", "deep_brain_stimulator", "neurological_history",
                           "medication_med_history_neuro", "other_neurological",
                           "neuro_modulators", "dysarthria", "ataxia"],
    "laryngeal_dystonia": ["botox_injections", "laryngospasm", "throat_surgical",
                           "throat_med_history", "speech_voice_swallowing_therapy",
                           "other_throat_condition", "non_surgical_treatment_enmt"],
    "cognitive_impairment": ["brain_cancer", "brain_tumor", "confusion", "stroke",
                             "traumatic_brain_injury", "neurological_history",
                             "medication_med_history_neuro", "other_neurological", "cognition"],
    "unilateral_vocal_fold_paralysis": ["vfp_unilateral", "vfp_bilateral",
                                        "injection_implant_to_vocal_folds", "chest_surgery",
                                        "throat_surgical", "throat_med_history",
                                        "cordotomy_arytenoidectomy", "radiation_to_head_neck",
                                        "thyroid_cancer", "speech_voice_swallowing_therapy"],
    "benign_lesions": ["lesions_vocal_cord", "vocal_fold_hemorrhage", "throat_surgical",
                       "throat_med_history", "speech_voice_swallowing_therapy",
                       "other_throat_condition", "non_surgical_treatment_enmt"],
    "muscle_tension_dysphonia": ["muscle_tension_dysphonia", "throat_med_history",
                                 "throat_surgical", "speech_voice_swallowing_therapy",
                                 "other_throat_condition", "non_surgical_treatment_enmt"],
    "unexplained_chronic_cough": ["chronic_cough", "coughing_clearing_throat",
                                  "throat_med_history", "vocal_cord_dysfunction",
                                  "acid_reflux", "reflux_medications", "resp_medical_history",
                                  "respiratory_conditions"],
    "depression": ["depression_major_depressive", "antidepressants",
                   "medication_med_history_psychological", "talk_therapy",
                   "psychological_condition_other", "other_treatment_psychological",
                   "psychotropic_antipsychotic"],
    "psychiatric_history": ["_med_hist_psychological", "psychological_condition",
                            "medication_med_history_psychological", "talk_therapy",
                            "antidepressants", "anti_anxiety_medication", "sedatives",
                            "psychotropic_antipsychotic", "other_treatment_psychological",
                            "anxiety_disorder", "bipolar_disorder", "panic_disorder",
                            "eating_disorder", "obsessive_compulsive",
                            "depression_major_depressive", "alcohol_substance_use_disorder",
                            "stimulants_medications"],
    "adhd_screen_positive": ["adhd", "stimulants", "_med_hist_psychological",
                             "medication_med_history_psychological", "talk_therapy",
                             "psychological_condition"],
    "ptsd_screen_positive": ["ptsd", "_med_hist_psychological", "talk_therapy",
                             "medication_med_history_psychological", "psychological_condition",
                             "anxiety_disorder", "panic_disorder"],
}
for _cat, _members in CATEGORY_TARGETS.items():
    pats: list[str] = []
    for _m in _members:
        pats += TARGET_LEAK_PATTERNS.get(_m, [])
    TARGET_LEAK_PATTERNS[_cat] = sorted(set(pats))

# Symptom scales that are near-tautological for a given target.  These are not
# dropped outright -- they are their own feature block, so a model that uses
# them is always reported separately from a purely acoustic model.
SURVEY_CIRCULAR = {
    "depression": ["phq9"],
    "psychiatric_history": ["phq9", "gad7", "dsm5"],
    "adhd_screen_positive": ["dsm5"],
    "ptsd_screen_positive": ["dsm5", "gad7"],
    "unexplained_chronic_cough": ["lcq"],
    "airway_stenosis": ["dyspnea"],
    "laryngeal_dystonia": ["vhi10"],
    "unilateral_vocal_fold_paralysis": ["vhi10"],
    "benign_lesions": ["vhi10"],
    "muscle_tension_dysphonia": ["vhi10"],
}

# Recording-quality metrics live in static_features.  They are legitimate
# nuisance covariates but can also encode *site*, which is confounded with
# diagnosis.  Kept behind a flag.
QUALITY_FEATURES = ["si_sdr", "pesq", "stoi"]

MIN_POSITIVES = 30
