"""F11-CAL: aggregate-only diagnostics from unchanged canonical OOF scores."""
from __future__ import annotations
import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import numpy as np
import pandas as pd
import scipy
from scipy.special import expit, logit
from scipy.optimize import brentq
import sklearn
from sklearn.metrics import roc_auc_score

MODELS = ('primary', 'agesexcountry')
TARGETS = ('screen', 'stage2', 'threeclass')
SEEDS = dict(screen=20261107, stage2=20261108, threeclass=20261109)
NBOOT = 5000

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n', encoding='utf-8')

def validate(y, p, multiclass=False):
    y, p = np.asarray(y), np.asarray(p, dtype=float)
    if y.ndim != 1 or len(y) == 0 or p.shape != ((len(y), 3) if multiclass else (len(y),)):
        raise ValueError('Invalid outcome/probability shape')
    if not np.isfinite(p).all() or not np.isfinite(y).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('Nonfinite or out-of-range data')
    if not np.isin(y, [0, 1, 2] if multiclass else [0, 1]).all():
        raise ValueError('Invalid outcomes')
    if multiclass and not np.allclose(p.sum(1), 1, atol=1e-12, rtol=0):
        raise ValueError('Multiclass probabilities do not sum to one')

def losses(y, p, multiclass=False):
    validate(y, p, multiclass)
    y = np.asarray(y, dtype=int)
    p = np.asarray(p, dtype=float)
    if multiclass:
        brier = np.square(p - np.eye(3)[y]).sum(1)
        clipped = np.clip(p, 1e-15, 1)
        ll = -np.log(clipped[np.arange(len(y)), y])
    else:
        brier = np.square(p - y)
        clipped = np.clip(p, 1e-15, 1 - 1e-15)
        ll = -(y * np.log(clipped) + (1 - y) * np.log1p(-clipped))
    return np.column_stack((brier, ll)), int(np.count_nonzero(clipped != p))

def calibration(y, p, weights=None):
    """Offset-intercept, free slope, free intercept: unpenalized MLE."""
    validate(y, p)
    y, p = np.asarray(y, dtype=float), np.asarray(p, dtype=float)
    w = np.ones(len(y), dtype=float) if weights is None else np.asarray(weights, dtype=float)
    if w.shape != y.shape or not np.isfinite(w).all() or np.any(w < 0) or w.sum() <= 0:
        raise ValueError('Invalid calibration weights')
    w = w / w.sum()
    prevalence = float(w @ y)
    if not 0 < prevalence < 1:
        raise ValueError('Single outcome class')
    x = logit(np.clip(p, 1e-6, 1 - 1e-6))
    if float(w @ np.square(x - w @ x)) < 1e-14:
        raise ValueError('Calibration slope unidentified: constant predictor')
    # In one-dimensional logistic calibration, disjoint ordered supports imply
    # complete or quasi separation and no finite unpenalized slope MLE.
    zero_support = x[(y == 0) & (w > 0)]
    one_support = x[(y == 1) & (w > 0)]
    if zero_support.max() <= one_support.min() or one_support.max() <= zero_support.min():
        raise ValueError('Complete or quasi separation: finite slope MLE does not exist')
    offset = brentq(lambda a: float(w @ (expit(a + x) - y)), -60, 60,
                    xtol=1e-12, rtol=1e-14)
    design = np.column_stack((np.ones(len(y)), x))
    beta = np.array([logit(prevalence), 0.0])
    converged = False
    for _ in range(100):
        eta = design @ beta
        pred = expit(eta)
        gradient = design.T @ (w * (pred - y))
        info = (design.T * (w * pred * (1 - pred))) @ design
        if not np.isfinite(info).all() or np.linalg.eigvalsh(info)[0] <= 1e-12:
            raise ValueError('Singular information/separation')
        if np.max(np.abs(gradient)) < 1e-10:
            converged = True
            break
        step = np.linalg.solve(info, gradient)
        oldloss = float(w @ (np.logaddexp(0, eta) - y * eta))
        accepted = False
        for power in range(30):
            trial = beta - step * (0.5 ** power)
            trial_eta = design @ trial
            newloss = float(w @ (np.logaddexp(0, trial_eta) - y * trial_eta))
            if newloss <= oldloss + 1e-15:
                beta, accepted = trial, True
                break
        if not accepted or not np.isfinite(beta).all() or np.max(np.abs(beta)) > 1e4:
            raise ValueError('Calibration optimizer failed')
    gradient = design.T @ (w * (expit(design @ beta) - y))
    if not converged and np.max(np.abs(gradient)) >= 1e-8:
        raise ValueError('Calibration did not converge')
    if abs(float(w @ (expit(offset + x) - y))) >= 1e-8:
        raise ValueError('Offset calibration did not converge')
    return np.array([offset, beta[1], beta[0]], dtype=float)

def synthetic_tests():
    y = np.array([0, 1, 0, 1])
    assert np.allclose(losses(y, y)[0], 0, atol=1e-14)
    assert np.allclose(losses(y, np.full(4, .5))[0], [.25, np.log(2)])
    yy = np.array([0, 1, 2])
    assert np.allclose(losses(yy, np.eye(3), True)[0], 0, atol=1e-14)
    assert np.allclose(losses(yy, np.full((3, 3), 1 / 3), True)[0], [2 / 3, np.log(3)])
    p = np.array([.1, .3, .7, .9])
    assert np.allclose(losses(y, p)[0], losses(1 - y, 1 - p)[0])
    assert np.array_equal(losses(y, p)[0] - losses(y, p)[0], np.zeros((4, 2)))
    y2 = np.r_[np.zeros(8), np.ones(2), np.zeros(2), np.ones(8)]
    p2 = np.repeat([.2, .8], 10)
    assert np.allclose(calibration(y2, p2), [0, 1, 0], atol=1e-8)
    assert np.allclose(calibration(y2, expit(logit(p2) + .7)), [-.7, 1, -.7], atol=1e-8)
    invalid = [(y, [np.nan, .2, .3, .4]), (y, [-.1, .2, .3, .4]), (y, [.1, .2])]
    for yy, pp in invalid:
        try:
            losses(yy, pp)
            raise AssertionError('Invalid input accepted')
        except ValueError:
            pass
    try:
        calibration(np.zeros(4), p)
        raise AssertionError('Single class accepted')
    except ValueError:
        pass
    for separated in [np.array([.1, .2, .8, .9]), np.array([.1, .2, .2, .9]), np.array([.9, .8, .2, .1])]:
        try:
            calibration(np.array([0, 0, 1, 1]), separated)
            raise AssertionError('Separated diagnostic accepted')
        except ValueError as exc:
            assert 'separation' in str(exc).lower()
    try:
        calibration(np.array([0, 0, 1, 1, 0, 1]), np.array([.1, .2, .8, .9, .85, .15]), np.array([1, 1, 1, 1, 0, 0]))
        raise AssertionError('Separated weighted active support accepted')
    except ValueError as exc:
        assert 'separation' in str(exc).lower()
    return dict(status='PASS', tests=15)

def load_and_gate(canonical, out):
    participant = pd.read_parquet(canonical / 'local_only/participant_oof_predictions.parquet')
    folds = pd.read_parquet(canonical / 'local_only/all_fold_predictions.parquet')
    receipts = pd.read_csv(canonical / 'auc_intervals.csv')
    checks = {}
    checks['cohort'] = len(participant) == 750 and participant.y_true.value_counts().to_dict() == {0: 598, 1: 90, 2: 62}
    checks['unique_participant_index'] = participant.index.is_unique
    checks['fold_rows'] = len(folds) == 2250
    checks['folds'] = len(folds[['repeat', 'fold']].drop_duplicates()) == 15 and folds['repeat'].nunique() == 3
    checks['once_per_repeat'] = not folds.duplicated(['participant_id', 'repeat']).any() and (folds.groupby('participant_id').size() == 3).all()
    checks['labels'] = (folds.groupby('participant_id').y_true.nunique() == 1).all()
    regroup = folds.groupby('participant_id').mean(numeric_only=True).reindex(participant.index)
    checks['identity_alignment'] = set(folds.participant_id) == set(participant.index) and np.array_equal(regroup.y_true, participant.y_true)
    probability_cols = [f'{m}_{suffix}' for m in MODELS for suffix in ('screen', 'q', 'p0', 'p1', 'p2')]
    diff = float(np.max(np.abs(regroup[probability_cols].to_numpy() - participant[probability_cols].to_numpy())))
    checks['participant_means'] = diff <= 1e-12
    auc_rows = []
    y = participant.y_true.to_numpy()
    for m in MODELS:
        for df in [participant, folds]:
            for suffix in ['screen', 'q']:
                validate((df.y_true.to_numpy() > 0).astype(int), df[f'{m}_{suffix}'].to_numpy())
            validate(df.y_true.to_numpy(), df[[f'{m}_p{k}' for k in range(3)]].to_numpy(), True)
        estimates = dict(screen=roc_auc_score(y > 0, participant[f'{m}_screen']),
                         stage2=roc_auc_score(y[y > 0] == 1, participant.loc[y > 0, f'{m}_q']),
                         macro=roc_auc_score(y, participant[[f'{m}_p{k}' for k in range(3)]], multi_class='ovr', average='macro'))
        for endpoint, value in estimates.items():
            expected = float(receipts.loc[(receipts.model == m) & (receipts.endpoint == endpoint), 'auc'].iloc[0])
            auc_rows.append(dict(model=m, endpoint=endpoint, reproduced=float(value), canonical=expected, difference=float(value - expected)))
    checks['six_auc'] = max(abs(r['difference']) for r in auc_rows) <= 1e-9
    checks = {k: bool(v) for k, v in checks.items()}
    passed = all(checks.values())
    write_json(out / 'GATE.json', dict(status='PASS' if passed else 'FAIL', time=now(), checks=checks,
                                      participant_mean_max_difference=diff, auc=auc_rows,
                                      note='Saved-score canonical gate; R13 already executed and reproduced all nested estimator fits.'))
    if not passed:
        raise RuntimeError('Canonical gate failed; no new diagnostic results produced')
    return participant, folds

def target_arrays(frame, target):
    labels = frame.y_true.to_numpy()
    mask = labels > 0 if target == 'stage2' else np.ones(len(frame), dtype=bool)
    yy = labels[mask]
    y = (yy == 1).astype(int) if target == 'stage2' else ((yy > 0).astype(int) if target == 'screen' else yy)
    preds = []
    for model in MODELS:
        cols = [f'{model}_p{k}' for k in range(3)] if target == 'threeclass' else f'{model}_' + ('q' if target == 'stage2' else 'screen')
        preds.append(frame.loc[mask, cols].to_numpy())
    return y, preds

def score_rows(target, y, rawloss, boot=None, repeat=None):
    values = np.array([a.mean(0) for a in rawloss])
    values = np.vstack([values, values[0] - values[1]])
    result = []
    for i, model in enumerate((*MODELS, 'primary_minus_agesexcountry')):
        row = dict(target=target, model=model, n=len(y), brier=float(values[i, 0]), log_loss=float(values[i, 1]))
        if repeat is not None:
            row['repeat'] = int(repeat)
        if boot is not None:
            draws = boot[:, i] if i < 2 else boot[:, 0] - boot[:, 1]
            for k, metric in enumerate(['brier', 'log_loss']):
                row[metric + '_lo'], row[metric + '_hi'] = np.quantile(draws[:, k], [.025, .975]).tolist()
        result.append(row)
    return result

def analyze(frame, out):
    score_output, cal_output, checks, failures = [], [], [], []
    for target in TARGETS:
        y, preds = target_arrays(frame, target)
        rawloss = []
        for model, p in zip(MODELS, preds):
            values, clipped = losses(y, p, target == 'threeclass')
            rawloss.append(values)
            checks.append(dict(target=target, model=model, n=len(y), log_loss_clipped_entries=clipped,
                               calibration_clipped_entries=int(np.count_nonzero(p != np.clip(p, 1e-6, 1 - 1e-6))) if target != 'threeclass' else 0))
        rng = np.random.default_rng(SEEDS[target])
        boot = np.empty((NBOOT, 2, 2))
        cb = np.full((NBOOT, 2, 3), np.nan)
        mean_boot = np.empty((NBOOT, 2))
        prevalence_boot = np.empty(NBOOT)
        points = [calibration(y, p) for p in preds] if target != 'threeclass' else []
        for b in range(NBOOT):
            indices = rng.integers(0, len(y), size=len(y))
            for m in range(2):
                boot[b, m] = rawloss[m][indices].mean(0)
            if target != 'threeclass':
                weights = np.bincount(indices, minlength=len(y))
                prevalence_boot[b] = y[indices].mean()
                for m, p in enumerate(preds):
                    mean_boot[b, m] = p[indices].mean()
                    try:
                        cb[b, m] = calibration(y, p, weights)
                    except ValueError as exc:
                        failures.append(dict(target=target, model=MODELS[m], draw=b, reason=str(exc)))
        score_output.extend(score_rows(target, y, rawloss, boot))
        if target != 'threeclass':
            for m, model in enumerate(MODELS):
                row = dict(target=target, model=model, n=len(y), positive_count=int(y.sum()), observed_fraction=float(y.mean()),
                           mean_probability=float(preds[m].mean()), offset_intercept=float(points[m][0]),
                           slope=float(points[m][1]), free_intercept=float(points[m][2]),
                           successful_bootstrap=int(np.isfinite(cb[:, m]).all(1).sum()), total_bootstrap=NBOOT)
                for name, data in [('observed_fraction', prevalence_boot), ('mean_probability', mean_boot[:, m])]:
                    row[name + '_lo'], row[name + '_hi'] = np.quantile(data, [.025, .975]).tolist()
                for k, name in enumerate(['offset_intercept', 'slope', 'free_intercept']):
                    valid = cb[:, m, k][np.isfinite(cb[:, m, k])]
                    ci = np.quantile(valid, [.025, .975]) if len(valid) >= .99 * NBOOT else [None, None]
                    row[name + '_lo'], row[name + '_hi'] = ci
                cal_output.append(row)
        print(json.dumps(dict(completed_target=target, bootstrap=NBOOT)), flush=True)
    pd.DataFrame(score_output).to_csv(out / 'probability_scores.csv', index=False)
    pd.DataFrame(cal_output).to_csv(out / 'calibration_diagnostics.csv', index=False)
    pd.DataFrame(checks).to_csv(out / 'clipping_counts.csv', index=False)
    write_json(out / 'bootstrap_failures.json', dict(count=len(failures), failures=failures))
    return len(score_output), len(cal_output), len(failures)

def repeat_analysis(folds, out):
    scores, cals = [], []
    for repeat, frame in folds.groupby('repeat', sort=True):
        for target in TARGETS:
            y, preds = target_arrays(frame, target)
            rawloss = [losses(y, p, target == 'threeclass')[0] for p in preds]
            scores.extend(score_rows(target, y, rawloss, repeat=repeat))
            if target != 'threeclass':
                for model, p in zip(MODELS, preds):
                    cal = calibration(y, p)
                    cals.append(dict(repeat=int(repeat), target=target, model=model, n=len(y),
                                     observed_fraction=float(y.mean()), mean_probability=float(p.mean()),
                                     offset_intercept=float(cal[0]), slope=float(cal[1]), free_intercept=float(cal[2])))
    pd.DataFrame(scores).to_csv(out / 'repeat_probability_scores.csv', index=False)
    pd.DataFrame(cals).to_csv(out / 'repeat_calibration_diagnostics.csv', index=False)
    return len(scores), len(cals)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--analysis-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--self-test-only', action='store_true')
    args = parser.parse_args()
    tests = synthetic_tests()
    print(json.dumps(tests), flush=True)
    if args.self_test_only:
        return
    out, root = args.output.resolve(), args.analysis_root.resolve()
    if not out.is_relative_to(root / 'results'):
        raise ValueError('Output must be a separate results folder inside the analysis project')
    if (out / 'COMPLETION.json').exists() or (out / 'probability_scores.csv').exists():
        raise FileExistsError('Refusing to overwrite prior results')
    canonical = root / 'results/pdci_demographic_baseline_20260911'
    spec = json.loads((out / 'FROZEN_SPEC.json').read_text(encoding='utf-8'))
    if spec['script_sha256'] != sha(__file__) or spec['protocol_sha256'] != sha(out / 'ANALYSIS_PLAN.md'):
        raise RuntimeError('Frozen code/protocol mismatch')
    for rel, digest in spec['inputs'].items():
        if sha(root / rel) != digest:
            raise RuntimeError('Frozen input mismatch')
    start = now()
    frame, folds = load_and_gate(canonical, out)
    sizes = analyze(frame, out)
    repeats = repeat_analysis(folds, out)
    unchanged = all(sha(root / rel) == digest for rel, digest in spec['inputs'].items())
    if not unchanged:
        raise RuntimeError('An input changed during execution')
    write_json(out / 'COMPLETION.json', dict(status='COMPLETED_PENDING_INDEPENDENT_VERIFICATION', family='F11-CAL',
        started=start, completed=now(), script_sha256=sha(__file__), protocol_sha256=sha(out / 'ANALYSIS_PLAN.md'),
        inputs=spec['inputs'], inputs_unchanged=unchanged, tests=tests, versions=spec['versions'],
        seeds=SEEDS, bootstrap=NBOOT, probability_rows=sizes[0], calibration_rows=sizes[1],
        bootstrap_failures=sizes[2], repeat_probability_rows=repeats[0], repeat_calibration_rows=repeats[1],
        participant_level_output=False))
    print(json.dumps(dict(status='completed', rows=sizes, repeat_rows=repeats)), flush=True)

if __name__ == '__main__':
    main()
