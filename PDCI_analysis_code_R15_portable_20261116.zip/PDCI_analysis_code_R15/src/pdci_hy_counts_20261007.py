"""AR-32: Hoehn and Yahr stage counts for the 90 analysed PD participants (counts only).

Protocol: results/pdci_hy_counts_20261007/ANALYSIS_PLAN.md.
Usage (analysis venv, thread variables set to 1):  python src/pdci_hy_counts_20261007.py freeze|gate|run
"""
from __future__ import annotations

import hashlib
import json
import platform
import re
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import pdci_tasks as PT  # noqa: E402

OUT = C.RESULTS / "pdci_hy_counts_20261007"
AUDIT = C.RESULTS / "pdci_demographic_baseline_20260911" / "INPUT_AUDIT.json"
A8_SUB = C.RESULTS / "pdci_a8_cohort_recount_20261007" / "subtype_recount.csv"
PD_TSV = C.PHENO / "diagnosis" / "parkinsons_disease.tsv"
FIELD = "diagnosis_parkinsons_ds"
SUBFIELD = "diagnosis_parkinsons_disease_subtype"
INPUTS = [C.DATA / "cohort.parquet", C.DATA / "static_bytask.parquet", PD_TSV, AUDIT, A8_SUB,
          Path(PT.__file__), Path(C.__file__)]


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def wj(p: Path, o):
    p.write_text(json.dumps(o, indent=2) + "\n", encoding="utf-8")


def pad(x):
    return pd.Index(pd.Index(x).astype(str).str.strip().str.zfill(6))


def pd_ids():
    ids = PT.ids_for_design("general")
    y = PT.labels(ids, "multiclass")
    return ids, y, pad(y.index[y == 1])


def module():
    m = pd.read_csv(PD_TSV, sep="\t", dtype=str)
    m["pid"] = pad(m["participant_id"])
    assert m["pid"].is_unique
    return m.set_index("pid")


def stage_of(v):
    if v is None or (isinstance(v, float)) or str(v).strip() == "":
        return "not recorded"
    mt = re.match(r"^Stage ([1-5])\b", str(v).strip())
    return f"stage {mt.group(1)}" if mt and not re.match(r"^Stage [1-5]\.\d", str(v).strip()) else f"other: {str(v).strip()}"


def freeze():
    if (OUT / "FROZEN_SPEC.json").exists():
        raise SystemExit("already frozen")
    wj(OUT / "FROZEN_SPEC.json", dict(created=now(), authority="AR-32", protocol_sha256=sha(OUT / "ANALYSIS_PLAN.md"),
       script_sha256=sha(Path(__file__)), inputs={str(p.relative_to(C.ROOT.parent)): sha(p) for p in INPUTS},
       versions=dict(python=platform.python_version(), pandas=pd.__version__)))
    print("frozen")


def check_frozen():
    s = json.loads((OUT / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    assert s["protocol_sha256"] == sha(OUT / "ANALYSIS_PLAN.md") and s["script_sha256"] == sha(Path(__file__))
    for rel, h in s["inputs"].items():
        assert sha(C.ROOT.parent / rel) == h, rel
    return s


def gate():
    check_frozen()
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    ids, y, pdx = pd_ids()
    m = module()
    a8 = pd.read_csv(A8_SUB)
    a8pd = a8[(a8.category == "PD") & (a8.n > 0) & (a8.raw_value != "not in module")].set_index("raw_value")["n"].to_dict()
    sub = m.reindex(pdx)[SUBFIELD].fillna("missing").value_counts().to_dict()
    checks = {"n_750": len(ids) == audit["n"] == 750,
              "class_counts": [int((y == k).sum()) for k in (0, 1, 2)] == audit["class_counts"],
              "all_90_in_module": bool(pdx.isin(m.index).all()) and len(pdx) == 90,
              "a8_subtypes_reproduced": {k: int(v) for k, v in sub.items()} == {k: int(v) for k, v in a8pd.items()}}
    res = dict(time=now(), checks=checks, passed=all(checks.values()))
    wj(OUT / "GATE.json", res)
    print(json.dumps(res, indent=1))
    if not res["passed"]:
        raise SystemExit("GATE FAILED")


def run():
    spec = check_frozen()
    assert json.loads((OUT / "GATE.json").read_text(encoding="utf-8"))["passed"]
    t0 = now()
    _, _, pdx = pd_ids()
    m = module()
    st = m.reindex(pdx)[FIELD].map(stage_of)
    order = [f"stage {k}" for k in range(1, 6)] + ["not recorded"]
    counts = st.value_counts()
    rows = [dict(stage=s, n=int(counts.get(s, 0)), percent_of_90=round(100 * counts.get(s, 0) / 90, 1)) for s in order]
    rows += [dict(stage=s, n=int(n), percent_of_90=round(100 * n / 90, 1)) for s, n in counts.items() if s not in order]
    out = pd.DataFrame(rows)
    assert out.n.sum() == 90
    out.to_csv(OUT / "hy_counts.csv", index=False)
    wj(OUT / "COMPLETION.json", dict(start=t0, end=now(), script_sha256=spec["script_sha256"],
       frozen_spec_sha256=sha(OUT / "FROZEN_SPEC.json"), total=int(out.n.sum())))
    print(out.to_string(index=False))


if __name__ == "__main__":
    {"freeze": freeze, "gate": gate, "run": run}[sys.argv[1]]()
