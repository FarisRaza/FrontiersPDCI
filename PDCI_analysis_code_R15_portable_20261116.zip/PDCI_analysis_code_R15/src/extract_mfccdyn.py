"""Per-recording MFCC *dynamics* features from torchaudio_mfcc-004.parquet.

The static openSMILE table only carries mfcc1-4 means, i.e. a static snapshot of
the low cepstrum.  What this module adds is the *temporal* behaviour of the full
60-coefficient cepstrum: how fast the spectral envelope moves, how varied it is,
at what rate it is modulated, and how the energy contour evolves over the take.

Clinical motivation
-------------------
* Hypokinetic dysarthria (Parkinson's) flattens articulation -> small mean
  |delta| in the low cepstrum, low delta-norm, low eigenvalue entropy of the
  cepstral covariance ("spectrally monotonous" speech).
* Ataxic / hyperkinetic speech shows erratic, high-acceleration cepstral
  trajectories -> raised delta-delta:delta ratio.
* Reduced 2-7 Hz modulation depth tracks loss of the syllabic rhythm.
* Energy-contour decay (last-quartile vs first-quartile) captures the fatigue /
  breath-support failure seen in respiratory and neuromuscular disease.

Everything is computed from a single recording in isolation -- no pooling across
recordings, participants or tasks -- so nothing here can leak across CV folds.

Shape note: the parquet stores (60, time) channel-major; `as_2d(..., 60)`
transposes to (time, 60).  Frame rate is 50 Hz (hop 160 @ 16 kHz, every 2nd
frame kept).  Coefficient 0 is the log-energy/DC term and lives on a completely
different scale (~ -430..-55), so it is handled as its own "energy contour"
block rather than mixed into the cepstral blocks.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import DATA, PARQUET  # noqa: E402
from parquet_stream import (as_2d, band_power, delta_stats, extract,  # noqa: E402
                            robust_stats)

P = "mfccdyn"
FS = 50.0                       # frames per second
N_COEF = 60
LOW_COEFS = range(1, 13)        # 1-12 individually
GROUPS = {"g13_24": (13, 24), "g25_39": (25, 39), "g40_59": (40, 59)}
CORE = slice(1, 20)             # coefficients 1-19: the "speech" cepstrum
N_CORE = 19
MOD_BANDS = {"m0_5_2": (0.5, 2.0), "m2_4": (2.0, 4.0),
             "m4_7": (4.0, 7.0), "m7_12": (7.0, 12.0)}

# minimum frame counts before a block is trustworthy
MIN_T = 5          # any statistic at all
MIN_T_MOD = 50     # 1 s, required by band_power
MIN_T_COV = 40     # 19x19 covariance needs more frames than dimensions
MIN_T_TREND = 20   # slope / quartile contrast


# ---------------------------------------------------------------- schema
def _feature_names() -> list[str]:
    """Fixed column order, so every recording emits an identical schema."""
    n = [f"{P}_dur_s"]
    for k in LOW_COEFS:
        n += [f"{P}_c{k}_mean", f"{P}_c{k}_std", f"{P}_c{k}_dabs"]
    for g in GROUPS:
        n += [f"{P}_{g}_mean", f"{P}_{g}_std", f"{P}_{g}_dabs"]
    n += [f"{P}_dnorm_mean", f"{P}_dnorm_p95", f"{P}_dnorm_cv",
          f"{P}_ddnorm_mean", f"{P}_ddnorm_p95", f"{P}_dd_d_ratio"]
    n += [f"{P}_cv_mean", f"{P}_cv_median", f"{P}_cov_trace", f"{P}_cov_logtrace",
          f"{P}_eig_entropy", f"{P}_eig_top1_frac", f"{P}_eig_top3_frac"]
    for pre in (f"{P}_c1mod", f"{P}_dnormmod"):
        n += [f"{pre}_bp_{b}" for b in MOD_BANDS]
        n += [f"{pre}_peak_freq", f"{pre}_spec_entropy"]
    for s in ("mean", "std", "cv", "p5", "p25", "p50", "p75", "p95",
              "iqr", "range9", "skew", "kurt"):
        n.append(f"{P}_e_{s}")
    n += [f"{P}_e_vel_absmean", f"{P}_e_vel_p95", f"{P}_e_acc_absmean", f"{P}_e_jerk"]
    n += [f"{P}_e_slope", f"{P}_e_q4q1_ratio", f"{P}_e_q4q1_diff",
          f"{P}_e_lowfrac", f"{P}_e_lowseg_rate_hz", f"{P}_e_lowseg_dur_mean"]
    n += [f"{P}_drift_cos", f"{P}_drift_l2"]
    return n


FEATURES = _feature_names()
assert len(FEATURES) == len(set(FEATURES)), "duplicate feature name"


def _blank() -> dict:
    return {k: np.nan for k in FEATURES}


# ---------------------------------------------------------------- small utils
def _safe(fn, out: dict) -> None:
    """Run a feature block; a failure leaves its columns as NaN."""
    try:
        d = fn()
    except Exception:
        return
    if d:
        for k, v in d.items():
            if k in out:
                out[k] = float(v) if np.isfinite(v) else np.nan


def _ratio(num: float, den: float) -> float:
    return float(num / den) if abs(den) > 1e-9 and np.isfinite(den) else np.nan


def _runs(mask: np.ndarray) -> np.ndarray:
    """Lengths of the True runs in a boolean vector."""
    if mask.size == 0:
        return np.zeros(0, dtype=int)
    padded = np.concatenate(([0], mask.astype(np.int8), [0]))
    idx = np.flatnonzero(np.diff(padded))
    return idx[1::2] - idx[0::2]


# ---------------------------------------------------------------- summariser
def summarise(rec: dict) -> dict:
    out = _blank()
    a = as_2d(rec["value"], expect_channels=N_COEF)
    if a.ndim != 2 or a.shape[0] < MIN_T or a.shape[1] < 2:
        return out

    # scrub non-finite frames; bail out if the recording is mostly garbage
    good = np.isfinite(a).all(axis=1)
    if good.mean() < 0.95:
        return out
    if not good.all():
        a = a[good]
    if a.shape[0] < MIN_T:
        return out

    a = a.astype(np.float64, copy=False)
    T, K = a.shape
    out[f"{P}_dur_s"] = T / FS

    means = a.mean(axis=0)
    stds = a.std(axis=0)

    # A recording with no temporal variation at all is digital silence, not
    # maximally monotonous speech.  Emitting 0 would be a strong false signal
    # of hypokinetic articulation, so these are marked unusable (NaN).
    if not np.isfinite(stds).any() or float(np.nanmax(stds)) <= 0.0:
        return out

    dabs = np.abs(np.diff(a, axis=0)).mean(axis=0) * FS      # mean |delta| per coef

    # ---- cepstral coefficients 1-12, individually -----------------------
    def _low():
        d = {}
        for k in LOW_COEFS:
            if k < K:
                d[f"{P}_c{k}_mean"] = means[k]
                d[f"{P}_c{k}_std"] = stds[k]
                d[f"{P}_c{k}_dabs"] = dabs[k]
        return d
    _safe(_low, out)

    # ---- high coefficients, pooled into 3 groups ------------------------
    def _groups():
        d = {}
        for g, (lo, hi) in GROUPS.items():
            hi = min(hi, K - 1)
            if hi < lo:
                continue
            sl = slice(lo, hi + 1)
            d[f"{P}_{g}_mean"] = means[sl].mean()
            d[f"{P}_{g}_std"] = stds[sl].mean()
            d[f"{P}_{g}_dabs"] = dabs[sl].mean()
        return d
    _safe(_groups, out)

    C = a[:, CORE]                                   # (T, 19) speech cepstrum
    if C.shape[1] < 2:
        return out

    # ---- global cepstral dynamics ---------------------------------------
    D = np.diff(C, axis=0) * FS
    dnorm = np.linalg.norm(D, axis=1)
    DD = np.diff(C, n=2, axis=0) * FS * FS if C.shape[0] > 2 else np.zeros((0, C.shape[1]))
    ddnorm = np.linalg.norm(DD, axis=1)

    def _dyn():
        d = {}
        if dnorm.size:
            dm = float(dnorm.mean())
            d[f"{P}_dnorm_mean"] = dm
            d[f"{P}_dnorm_p95"] = float(np.percentile(dnorm, 95))
            d[f"{P}_dnorm_cv"] = _ratio(float(dnorm.std()), dm)
            if ddnorm.size:
                ddm = float(ddnorm.mean())
                d[f"{P}_ddnorm_mean"] = ddm
                d[f"{P}_ddnorm_p95"] = float(np.percentile(ddnorm, 95))
                d[f"{P}_dd_d_ratio"] = _ratio(ddm, dm)
        return d
    _safe(_dyn, out)

    # ---- cepstral variability / spectral monotonicity -------------------
    def _var():
        d = {}
        cm, cs = C.mean(axis=0), C.std(axis=0)
        with np.errstate(divide="ignore", invalid="ignore"):
            cv = np.where(np.abs(cm) > 1e-6, cs / np.abs(cm), np.nan)
        # MFCCs above ~c4 are near zero-mean, so std/|mean| can explode; a CV
        # over 50 already means "the mean is negligible", so cap there and keep
        # a median alongside the mean.
        cv = np.clip(cv, 0.0, 50.0)
        if np.isfinite(cv).any():
            d[f"{P}_cv_mean"] = float(np.nanmean(cv))
            d[f"{P}_cv_median"] = float(np.nanmedian(cv))
        if T >= MIN_T_COV:
            cov = np.cov(C, rowvar=False)
            tr = float(np.trace(cov))
            d[f"{P}_cov_trace"] = tr
            d[f"{P}_cov_logtrace"] = float(np.log(tr)) if tr > 1e-12 else np.nan
            ev = np.clip(np.linalg.eigvalsh(cov), 0.0, None)
            s = ev.sum()
            if s > 1e-12:
                p = np.sort(ev / s)[::-1]
                pp = p[p > 0]
                d[f"{P}_eig_entropy"] = float(-(pp * np.log(pp)).sum() / np.log(p.size))
                d[f"{P}_eig_top1_frac"] = float(p[0])
                d[f"{P}_eig_top3_frac"] = float(p[:3].sum())
        return d
    _safe(_var, out)

    # ---- modulation spectrum --------------------------------------------
    if T >= MIN_T_MOD:
        _safe(lambda: band_power(a[:, 1], FS, MOD_BANDS, f"{P}_c1mod"), out)
        if dnorm.size >= MIN_T_MOD:
            _safe(lambda: band_power(dnorm, FS, MOD_BANDS, f"{P}_dnormmod"), out)

    # ---- energy contour (coefficient 0) ----------------------------------
    e = a[:, 0]
    _safe(lambda: robust_stats(e, f"{P}_e"), out)
    _safe(lambda: delta_stats(e, f"{P}_e", FS), out)

    def _econtour():
        d = {}
        if T >= MIN_T_TREND:
            t = np.arange(T, dtype=np.float64) / FS
            tv = t.var()
            if tv > 1e-12:
                d[f"{P}_e_slope"] = float(((t - t.mean()) * (e - e.mean())).mean() / tv)
            q = max(T // 4, 1)
            q1, q4 = float(e[:q].mean()), float(e[-q:].mean())
            d[f"{P}_e_q4q1_ratio"] = _ratio(q4, q1)
            d[f"{P}_e_q4q1_diff"] = q4 - q1
        lo, hi = np.percentile(e, [5, 95])
        if hi - lo > 1e-6:
            mask = e < lo + 0.25 * (hi - lo)      # bottom quarter of the take's own range
            d[f"{P}_e_lowfrac"] = float(mask.mean())
            L = _runs(mask)
            L = L[L >= 5]                          # >= 100 ms
            d[f"{P}_e_lowseg_rate_hz"] = float(L.size / (T / FS))
            d[f"{P}_e_lowseg_dur_mean"] = float(L.mean() / FS) if L.size else 0.0
        return d
    _safe(_econtour, out)

    # ---- spectral drift, first half vs second half -----------------------
    def _drift():
        d = {}
        h = T // 2
        if h < 3:
            return d
        m1, m2 = C[:h].mean(axis=0), C[h:].mean(axis=0)
        n1, n2 = np.linalg.norm(m1), np.linalg.norm(m2)
        if n1 > 1e-9 and n2 > 1e-9:
            d[f"{P}_drift_cos"] = float(1.0 - np.dot(m1, m2) / (n1 * n2))
        sd = np.linalg.norm(C.std(axis=0))
        if sd > 1e-9:
            d[f"{P}_drift_l2"] = float(np.linalg.norm(m1 - m2) / sd)
        return d
    _safe(_drift, out)

    return out


# ---------------------------------------------------------------- driver
def main(limit_groups: int | None = None) -> None:
    out_path = DATA / f"dyn_{P}.parquet"
    print(f"{len(FEATURES)} feature columns", flush=True)
    df = extract(PARQUET["mfcc"], "mfcc", summarise, out_path,
                 limit_groups=limit_groups)
    feat = [c for c in df.columns if c.startswith(P)]
    print(f"rows={len(df)} feature_cols={len(feat)}")
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        print("MISSING COLUMNS:", missing)
    nan = df[feat].isna().mean().sort_values()
    print(f"NaN fraction: min={nan.min():.4f} max={nan.max():.4f}")
    print(nan.tail(12).to_string())
    print(df[feat].describe().T[["mean", "std", "min", "max"]].to_string())


if __name__ == "__main__":
    lg = int(sys.argv[1]) if len(sys.argv) > 1 else None
    main(lg)
