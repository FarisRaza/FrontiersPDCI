"""Fold-internal task x frequency tensor models for PD/CI.

Declared in ``PRESPECIFICATION_TENSOR_PROFILES.md``.  Tensor cell scaling and
both task/frequency mode bases are fitted on outer-training participants only.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_to_baseline as CB  # noqa: E402
import config as C  # noqa: E402
import extract_linear_profiles as LP  # noqa: E402
import modeling  # noqa: E402
import pdci_exhaustive as E  # noqa: E402
import pdci_locked_moe_validation as M  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")
OUT = C.RESULTS / "pdci_linear_harmonics" / "tensor_profiles"
FOLDS = OUT / "folds"
OUT.mkdir(parents=True, exist_ok=True)
FOLDS.mkdir(parents=True, exist_ok=True)
SEED = C.RANDOM_STATE
TASKS = [t for t in PT.GENERAL_TASKS if t != "free_speech"]
PROFILES = list(LP.PROFILE_LENGTHS)

FIXED_MODELS = [
    "anchor_pca100_lda",
    "tensor_mean_6x20_lda", "tensor_cep_6x20_lda",
    "tensor_variability_6x15_lda", "tensor_modulation_6x15_lda",
    "tensor_all_4x10_lda", "tensor_all_6x15_ridge",
    "base_tensor_100_all4x10_lda", "base_tensor_100_all4x10_ridge",
    "global_profile_pca100_lda",
]
ADAPTIVE_POOL = FIXED_MODELS.copy()
MODELS = FIXED_MODELS + ["crossfit_stack", "adaptive_nested"]
SIMPLICITY = {name: i for i, name in enumerate([
    "anchor_pca100_lda", "tensor_mean_6x20_lda", "tensor_cep_6x20_lda",
    "tensor_variability_6x15_lda", "tensor_modulation_6x15_lda",
    "tensor_all_4x10_lda", "tensor_all_6x15_ridge",
    "base_tensor_100_all4x10_lda", "base_tensor_100_all4x10_ridge",
    "global_profile_pca100_lda",
])}


def _aligned(est, x):
    raw = est.predict_proba(x)
    p = np.zeros((len(x), 3), float)
    for j, cls in enumerate(est.classes_):
        p[:, int(cls)] = raw[:, j]
    return np.clip(p, 1e-7, 1 - 1e-7)


def _head(a, y, b, kind="lda"):
    scale = StandardScaler()
    za, zb = scale.fit_transform(a), scale.transform(b)
    if kind == "lda":
        est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    else:
        est = LogisticRegression(C=.03, penalty="l2", solver="lbfgs",
                                 max_iter=5000, random_state=SEED)
    est.fit(za, y)
    return _aligned(est, zb)


def _locked_anchor(base_tr, cov_tr, ytr, base_te, cov_te):
    prep = modeling.make_prep()
    a = prep.fit_transform(pd.concat([base_tr, cov_tr], axis=1))
    b = prep.transform(pd.concat([base_te, cov_te], axis=1))
    pca = PCA(n_components=min(100, len(a) - 2, a.shape[1]), random_state=SEED)
    za, zb = pca.fit_transform(a), pca.transform(b)
    est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    est.fit(za, ytr)
    return _aligned(est, zb), za, zb


def _cell_scale(a: np.ndarray, b: np.ndarray):
    shape = a.shape
    x = a.reshape(len(a), -1).astype(float)
    z = b.reshape(len(b), -1).astype(float)
    lo = np.nanquantile(x, .005, axis=0)
    hi = np.nanquantile(x, .995, axis=0)
    bad = ~np.isfinite(lo) | ~np.isfinite(hi) | (hi <= lo)
    lo[bad], hi[bad] = -np.inf, np.inf
    x, z = np.clip(x, lo, hi), np.clip(z, lo, hi)
    med = np.nanmedian(x, axis=0)
    med = np.where(np.isfinite(med), med, 0.0)
    x = np.where(np.isfinite(x), x, med)
    z = np.where(np.isfinite(z), z, med)
    mean, sd = x.mean(axis=0), x.std(axis=0)
    sd[sd < 1e-8] = 1.0
    x, z = (x - mean) / sd, (z - mean) / sd
    return x.reshape(shape), z.reshape((len(b), *shape[1:]))


def _tucker(a: np.ndarray, b: np.ndarray, kt=6, kf=20):
    a, b = _cell_scale(a, b)
    nt, nf = a.shape[1:]
    tpca = PCA(n_components=min(kt, nt), svd_solver="full",
               random_state=SEED)
    tpca.fit(a.transpose(0, 2, 1).reshape(-1, nt))
    fpca = PCA(n_components=min(kf, nf), svd_solver="randomized",
               random_state=SEED)
    fpca.fit(a.reshape(-1, nf))
    za = np.einsum("at,ntf,bf->nab", tpca.components_, a,
                   fpca.components_, optimize=True)
    zb = np.einsum("at,ntf,bf->nab", tpca.components_, b,
                   fpca.components_, optimize=True)
    return za, zb


@lru_cache(maxsize=1)
def data():
    ids = pd.Index(PT.ids_for_design("general").astype(str),
                   name="participant_id")
    y = PT.labels(ids, "multiclass").to_numpy(int)
    d = pd.read_parquet(LP.OUT)
    d["participant_id"] = d.participant_id.astype(str)
    d = d[d.task_group.isin(TASKS)]
    cols = list(LP.FEATURES)
    bt = d.groupby(["participant_id", "task_group"])[cols].mean()
    ix = pd.MultiIndex.from_product([ids, TASKS],
                                    names=["participant_id", "task_group"])
    bt = bt.reindex(ix)
    profiles = {}
    for name, nf in LP.PROFILE_LENGTHS.items():
        pc = [f"lprof_{name}_{i:03d}" for i in range(nf)]
        profiles[name] = bt[pc].to_numpy(np.float32).reshape(
            len(ids), len(TASKS), nf)
    locked = PT.build_X("general", "per_task_dynamic").reindex(ids)
    cov = PT.covariates(ids, "general").reindex(ids).astype(np.float32)
    base = locked.drop(columns=cov.columns).astype(np.float32)
    if not pd.concat([base, cov], axis=1).columns.equals(locked.columns):
        raise AssertionError("locked reference columns changed")
    if not bool(PT.task_presence().loc[ids, PT.GENERAL_TASKS].all().all()):
        raise AssertionError("general task presence is not constant")
    return ids, y, base, cov, profiles


def _cov_coords(cov_tr, cov_te):
    prep = modeling.make_prep()
    return prep.fit_transform(cov_tr), prep.transform(cov_te)


def fit_fixed(base_tr, cov_tr, prof_tr, ytr, base_te, cov_te, prof_te):
    pred = {}
    anchor, base_pc_tr, base_pc_te = _locked_anchor(
        base_tr, cov_tr, ytr, base_te, cov_te)
    pred["anchor_pca100_lda"] = anchor
    ctr, cte = _cov_coords(cov_tr, cov_te)

    tcoord = {}
    for name in PROFILES:
        tcoord[name] = _tucker(prof_tr[name], prof_te[name], 6, 20)

    def coord(name, kt, kf):
        a, b = tcoord[name]
        return a[:, :kt, :kf].reshape(len(a), -1), \
            b[:, :kt, :kf].reshape(len(b), -1)

    am, bm = coord("mean", 6, 20)
    pred["tensor_mean_6x20_lda"] = _head(
        np.column_stack([am, ctr]), ytr, np.column_stack([bm, cte]))
    acp, bcp = coord("cep", 6, 20)
    pred["tensor_cep_6x20_lda"] = _head(
        np.column_stack([acp, ctr]), ytr, np.column_stack([bcp, cte]))

    av = np.column_stack([coord(n, 6, 15)[0] for n in ("sd", "flux")])
    bv = np.column_stack([coord(n, 6, 15)[1] for n in ("sd", "flux")])
    pred["tensor_variability_6x15_lda"] = _head(
        np.column_stack([av, ctr]), ytr, np.column_stack([bv, cte]))
    ax = np.column_stack([coord(n, 6, 15)[0]
                          for n in ("mod1_3", "mod3_7")])
    bx = np.column_stack([coord(n, 6, 15)[1]
                          for n in ("mod1_3", "mod3_7")])
    pred["tensor_modulation_6x15_lda"] = _head(
        np.column_stack([ax, ctr]), ytr, np.column_stack([bx, cte]))

    all_low_a = np.column_stack([coord(n, 4, 10)[0] for n in PROFILES])
    all_low_b = np.column_stack([coord(n, 4, 10)[1] for n in PROFILES])
    pred["tensor_all_4x10_lda"] = _head(
        np.column_stack([all_low_a, ctr]), ytr,
        np.column_stack([all_low_b, cte]))
    all_hi_a = np.column_stack([coord(n, 6, 15)[0] for n in PROFILES])
    all_hi_b = np.column_stack([coord(n, 6, 15)[1] for n in PROFILES])
    pred["tensor_all_6x15_ridge"] = _head(
        np.column_stack([all_hi_a, ctr]), ytr,
        np.column_stack([all_hi_b, cte]), "ridge")

    pred["base_tensor_100_all4x10_lda"] = _head(
        np.column_stack([base_pc_tr, all_low_a]), ytr,
        np.column_stack([base_pc_te, all_low_b]))
    pred["base_tensor_100_all4x10_ridge"] = _head(
        np.column_stack([base_pc_tr, all_low_a]), ytr,
        np.column_stack([base_pc_te, all_low_b]), "ridge")

    flat_tr = np.column_stack([prof_tr[n].reshape(len(base_tr), -1)
                               for n in PROFILES])
    flat_te = np.column_stack([prof_te[n].reshape(len(base_te), -1)
                               for n in PROFILES])
    ftr = pd.DataFrame(flat_tr, index=base_tr.index)
    fte = pd.DataFrame(flat_te, index=base_te.index)
    prep = modeling.make_prep()
    aa = prep.fit_transform(pd.concat([ftr, cov_tr], axis=1))
    bb = prep.transform(pd.concat([fte, cov_te], axis=1))
    pca = PCA(n_components=min(100, len(aa) - 2, aa.shape[1]),
              svd_solver="randomized", random_state=SEED)
    za, zb = pca.fit_transform(aa), pca.transform(bb)
    pred["global_profile_pca100_lda"] = _head(za, ytr, zb)
    return pred


def _choose(y, oof):
    case = y > 0
    scores = {name: float(roc_auc_score(
        y[case] == 1, M.conditional(oof[name][case])))
        for name in ADAPTIVE_POOL}
    top = max(scores.values())
    eligible = [n for n, value in scores.items() if value >= top - .01]
    return min(eligible, key=lambda n: SIMPLICITY[n]), scores


def _slice_profiles(profiles, ix):
    return {name: value[ix] for name, value in profiles.items()}


def run_fold(oi, splits=5, repeats=3):
    path = FOLDS / f"r{oi // splits}_f{oi % splits}.parquet"
    meta = path.with_suffix(".json")
    if path.exists() and meta.exists():
        return json.loads(meta.read_text(encoding="utf-8"))
    started = time.time()
    try:
        ids, y, base, cov, profiles = data()
        folds = list(RepeatedStratifiedKFold(
            n_splits=splits, n_repeats=repeats, random_state=SEED).split(
                np.zeros(len(y)), y))
        tr, te = folds[oi]
        full = fit_fixed(base.iloc[tr], cov.iloc[tr], _slice_profiles(profiles, tr),
                         y[tr], base.iloc[te], cov.iloc[te],
                         _slice_profiles(profiles, te))
        inner = StratifiedKFold(n_splits=3, shuffle=True,
                               random_state=SEED + 1009 * oi)
        oof = {n: np.zeros((len(tr), 3), float) for n in FIXED_MODELS}
        for it, iv in inner.split(np.zeros(len(tr)), y[tr]):
            p = fit_fixed(base.iloc[tr[it]], cov.iloc[tr[it]],
                          _slice_profiles(profiles, tr[it]), y[tr[it]],
                          base.iloc[tr[iv]], cov.iloc[tr[iv]],
                          _slice_profiles(profiles, tr[iv]))
            for name in FIXED_MODELS:
                oof[name][iv] = p[name]
        chosen, scores = _choose(y[tr], oof)
        full["adaptive_nested"] = full[chosen]

        stack_x = np.column_stack([
            np.log(np.clip(oof["anchor_pca100_lda"], 1e-6, 1)),
            np.log(np.clip(oof["tensor_all_4x10_lda"], 1e-6, 1)),
        ])
        stack_te = np.column_stack([
            np.log(np.clip(full["anchor_pca100_lda"], 1e-6, 1)),
            np.log(np.clip(full["tensor_all_4x10_lda"], 1e-6, 1)),
        ])
        stack = LogisticRegression(C=.1, penalty="l2", solver="lbfgs",
                                   max_iter=5000, random_state=SEED + oi)
        stack.fit(stack_x, y[tr])
        full["crossfit_stack"] = _aligned(stack, stack_te)

        out = pd.DataFrame({"participant_id": ids[te].astype(str),
                            "y_true": y[te], "repeat": oi // splits,
                            "fold": oi % splits})
        for name in MODELS:
            for cls in range(3):
                out[f"{name}_p{cls}"] = full[name][:, cls].astype(np.float32)
        out.to_parquet(path, index=False)
        rec = {"job_id": path.stem, "status": "ok", "chosen": chosen,
               "inner_scores": scores,
               "seconds": round(time.time() - started, 2)}
    except Exception as exc:
        rec = {"job_id": path.stem, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - started, 2)}
    meta.write_text(json.dumps(rec), encoding="utf-8")
    return rec


def _metrics(y, p):
    case = y > 0
    return {"pd_vs_ci_auc": roc_auc_score(
                y[case] == 1, M.conditional(p[case])),
            "three_class_macro_auc": roc_auc_score(
                y, p, multi_class="ovr", average="macro"),
            "neuro_auc": roc_auc_score(y > 0, p[:, 1:].sum(axis=1)),
            "pd_vs_all_auc": roc_auc_score(y == 1, p[:, 1]),
            "ci_vs_all_auc": roc_auc_score(y == 2, p[:, 2])}


def _fast_bootstrap_pair(y, a, b, n_boot=5000):
    """Vectorized equivalent of the paired participant bootstrap."""
    y = np.asarray(y, bool)
    a, b = np.asarray(a, float), np.asarray(b, float)
    rng = np.random.default_rng(SEED)
    weights = np.zeros((n_boot, len(y)), dtype=np.int16)
    for bi in range(n_boot):
        weights[bi] = np.bincount(
            rng.integers(0, len(y), len(y)), minlength=len(y))
    pos, neg = np.flatnonzero(y), np.flatnonzero(~y)

    def boot_auc(score):
        kernel = ((score[pos, None] > score[neg][None, :]).astype(float) +
                  .5 * (score[pos, None] == score[neg][None, :]))
        numer = np.einsum("bi,ij,bj->b", weights[:, pos], kernel,
                          weights[:, neg], optimize=True)
        den = weights[:, pos].sum(axis=1) * weights[:, neg].sum(axis=1)
        return np.divide(numer, den, out=np.full(n_boot, np.nan), where=den > 0)

    aa, bb = boot_auc(a), boot_auc(b)
    ok = np.isfinite(aa) & np.isfinite(bb)
    aa, bb = aa[ok], bb[ok]
    dd = aa - bb
    obs_a, obs_b = roc_auc_score(y, a), roc_auc_score(y, b)
    p = 2 * min((dd <= 0).mean(), (dd >= 0).mean())
    return {"auc_best": obs_a, "auc_best_lo": float(np.quantile(aa, .025)),
            "auc_best_hi": float(np.quantile(aa, .975)), "auc_base": obs_b,
            "auc_base_lo": float(np.quantile(bb, .025)),
            "auc_base_hi": float(np.quantile(bb, .975)),
            "delta": obs_a - obs_b, "delta_lo": float(np.quantile(dd, .025)),
            "delta_hi": float(np.quantile(dd, .975)),
            "p_boot": float(min(1.0, max(p, 1.0 / (len(dd) + 1)))),
            "n_boot_ok": int(len(dd))}


def report(bootstraps=5000):
    files = sorted(FOLDS.glob("r*_f*.parquet"))
    if len(files) != 15:
        raise RuntimeError(f"expected 15 folds, found {len(files)}")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    pcols = [c for c in raw if c.endswith(("_p0", "_p1", "_p2"))]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in pcols}})
    d.to_parquet(OUT / "oof_predictions.parquet")
    y = d.y_true.to_numpy(int)
    case = y > 0
    probs, rows = {}, []
    for name in MODELS:
        p = d[[f"{name}_p{i}" for i in range(3)]].to_numpy(float)
        probs[name] = p
        rows.append({"model": name, **_metrics(y, p)})
    metrics = pd.DataFrame(rows).sort_values("pd_vs_ci_auc", ascending=False)
    metrics.to_csv(OUT / "metrics.csv", index=False)
    ref = "anchor_pca100_lda"
    yy, qref = y[case] == 1, M.conditional(probs[ref][case])
    comps = []
    for name in MODELS:
        if name == ref:
            continue
        q = M.conditional(probs[name][case])
        delta, pdelong = CB.delong_test(yy, q, qref)
        if not np.isfinite(pdelong) and np.allclose(q, qref):
            pdelong = 1.0
        comps.append({"model": name, "reference": ref,
                      "delta_delong": delta, "p_delong": pdelong,
                      **_fast_bootstrap_pair(yy, q, qref, n_boot=bootstraps)})
    comp = pd.DataFrame(comps)
    comp["fdr_q"] = E._bh(comp.p_delong)
    mm = metrics.set_index("model")
    comp["macro_loss"] = comp.model.map(
        lambda n: mm.loc[ref, "three_class_macro_auc"] -
        mm.loc[n, "three_class_macro_auc"])
    comp["neuro_loss"] = comp.model.map(
        lambda n: mm.loc[ref, "neuro_auc"] - mm.loc[n, "neuro_auc"])
    comp["qualifies"] = ((comp.delta_lo > 0) & (comp.fdr_q < .05) &
                         (comp.macro_loss <= .01) & (comp.neuro_loss <= .01))
    comp.to_csv(OUT / "comparisons.csv", index=False)
    meta = [json.loads(p.read_text(encoding="utf-8"))
            for p in sorted(FOLDS.glob("r*_f*.json"))]
    counts = pd.Series([r.get("chosen") for r in meta], name="count").value_counts()
    counts.rename_axis("model").reset_index().to_csv(
        OUT / "adaptive_selection_counts.csv", index=False)
    promoted = comp.loc[comp.qualifies, "model"].tolist()
    lines = ["# Task x frequency tensor-profile PD/CI models", "",
             "All cell preprocessing and task/frequency mode bases are fitted "
             "inside participant-held-out folds. The exact locked input is "
             "reproduced separately in every fold.", "", "## Performance", "",
             R.markdown_table(metrics.round(4)), "", "## Paired comparisons", "",
             R.markdown_table(comp.round(4)), "", "## Adaptive selections", "",
             R.markdown_table(counts.rename_axis("model").reset_index()), "",
             "## Decision", "",
             ("Qualifying candidates: " + ", ".join(promoted) if promoted else
              "No candidate met the prespecified promotion rule."), "",
             "This is internally selection-informed and not external validation.", ""]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))
    print(comp.to_string(index=False))
    print(counts.to_string())


def audit():
    ids, y, base, cov, profiles = data()
    locked = PT.build_X("general", "per_task_dynamic").reindex(ids)
    split = pd.concat([base, cov], axis=1)
    print(f"n={len(ids)} classes={dict(pd.Series(y).value_counts().sort_index())}")
    print(f"base={base.shape} cov={cov.shape} locked_exact="
          f"{split.columns.equals(locked.columns) and np.allclose(
              split.to_numpy(), locked.to_numpy(), equal_nan=True)}")
    for name, x in profiles.items():
        print(name, x.shape, "nan", float(np.isnan(x).mean()))
    print("task_presence_columns=0 tasks=", TASKS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run", "report"])
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--bootstraps", type=int, default=5000)
    args = ap.parse_args()
    if args.command == "audit":
        return audit()
    if args.command == "report":
        return report(args.bootstraps)
    data()
    total = args.splits * args.repeats
    todo = [i for i in range(total) if not (
        FOLDS / f"r{i // args.splits}_f{i % args.splits}.parquet").exists()]
    print(f"tensor profiles: {len(todo)}/{total} folds pending", flush=True)
    for start in range(0, len(todo), args.jobs):
        batch = todo[start:start + args.jobs]
        ans = Parallel(n_jobs=args.jobs, prefer="threads")(
            delayed(run_fold)(i, args.splits, args.repeats) for i in batch)
        for rec in ans:
            print(rec["job_id"], rec["status"], rec.get("chosen", ""),
                  rec.get("error", ""), rec.get("seconds", ""), flush=True)
    report(args.bootstraps)


if __name__ == "__main__":
    main()
