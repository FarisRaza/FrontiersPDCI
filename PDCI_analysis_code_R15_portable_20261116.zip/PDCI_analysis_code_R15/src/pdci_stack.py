"""Ensembles for the three-class Parkinson's / cognitive-impairment model.

Four combination strategies, and they differ in how honest they are, so each is
reported with its own caveat rather than mixed into one leaderboard:

  vote_fixed      soft-probability average over a PRE-SPECIFIED diverse set --
                  one configuration per feature space, chosen before seeing any
                  score.  Fits no parameters on labels, so it is clean.
  vote_topn       the same averaging over the top-N by out-of-fold score.  The
                  *membership* was chosen using the labels, so this carries
                  selection optimism and is labelled as such.
  confidence      per participant, take the prediction of whichever base model
                  is most confident on that participant.  Also selection-biased
                  through the candidate pool.
  stack_nested    a meta-learner over base-model probabilities, evaluated with
                  **true nested cross-validation**: inside every outer training
                  fold the base models are re-fitted and inner out-of-fold
                  predictions are generated to train the meta-learner, which
                  then scores the untouched outer test fold.  Expensive, and
                  the only ensemble number here that is free of optimism.

The naive version of stacking -- fitting a meta-learner on out-of-fold
predictions that were generated using the whole dataset -- leaks, because a
base prediction for a meta-training sample came from a model that had seen some
of the meta-test samples.  That is why `stack_nested` exists.

Usage:  python src/pdci.py stack [--jobs 6]
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import Pipeline

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import modeling  # noqa: E402
import pdci  # noqa: E402

OUT = pdci.OUT

# One configuration per feature space, fixed in advance so the clean ensemble
# owes nothing to the leaderboard.  Diversity across BOTH the feature space and
# the inductive bias is the point -- averaging four flavours of boosted tree on
# the same columns buys almost nothing.
FIXED_BASE = [
    ("static", "kbest_f", "logreg", 60),
    ("dynamic", "kbest_f", "svm_rbf", 60),
    ("timeresolved", "kbest_f", "logreg", 60),
    ("composed", "l1", "logreg", 60),
    ("acoustic", "trees", "xgb", 150),
    ("acoustic_plus_tr", "kbest_f", "rf", 150),
]


def load_oof(config_ids):
    """Stored out-of-fold probability matrices, keyed by config id."""
    mats = {}
    for cid in config_ids:
        p = pdci.PRED / f"{cid.replace('|', '__')}.npy"
        if p.exists():
            mats[cid] = np.load(p)
    return mats


def blend(mats, weights=None):
    keys = list(mats)
    W = np.ones(len(keys)) if weights is None else np.asarray(weights, float)
    W = W / W.sum()
    out = sum(w * mats[k] for w, k in zip(W, keys))
    return out / np.maximum(out.sum(axis=1, keepdims=True), 1e-9)


def confidence_pick(mats):
    """Per sample, defer to whichever base model is most confident."""
    keys = list(mats)
    stack = np.stack([mats[k] for k in keys])            # (M, n, 3)
    conf = stack.max(axis=2)                             # (M, n)
    best = conf.argmax(axis=0)                           # (n,)
    return stack[best, np.arange(stack.shape[1]), :]


# ------------------------------------------------------------------ nested
def _fit_predict(space, selector, clf, k, tr_idx, te_idx, X_cache, y):
    X = X_cache[space]
    prep = modeling.make_prep()
    Xtr = prep.fit_transform(X.iloc[tr_idx])
    Xte = prep.transform(X.iloc[te_idx])
    kk = min(k, Xtr.shape[1])
    steps = []
    sel = pdci.make_selector(selector, kk)
    if sel != "passthrough":
        steps.append(("sel", sel))
    steps.append(("clf", pdci.make_clf(clf)))
    pipe = Pipeline(steps)
    pipe.fit(Xtr, y.iloc[tr_idx])
    p = pipe.predict_proba(Xte)
    out = np.zeros((len(te_idx), 3))
    for j, c in enumerate(pipe.classes_):
        out[:, int(c)] = p[:, j]
    return out


def _pdci_auc(y, proba):
    m = (y == 1) | (y == 2)
    if m.sum() < 10 or len(np.unique(y[m])) < 2:
        return 0.5
    num = proba[m, 1]
    den = proba[m, 1] + proba[m, 2]
    rel = np.divide(num, den, out=np.full(int(m.sum()), 0.5), where=den > 0)
    from sklearn.metrics import roc_auc_score
    return roc_auc_score((np.asarray(y)[m] == 1).astype(int), rel)


def stack_nested(base, n_splits=5, n_repeats=2, jobs=6, seed=C.RANDOM_STATE,
                 topn=(3, 5)):
    """True nested stacking, plus an honest version of 'vote the top N'.

    `vote_topN` above picks its members using the same out-of-fold scores it is
    then judged on, so it cannot be compared against a single model.  Here the
    ranking is redone **inside each outer training fold** using only inner
    predictions, so selecting-then-voting is evaluated as the procedure it
    actually is.  If the honest version loses to the best single model, the
    apparent ensemble gain was selection optimism.
    """
    spaces = sorted({b[0] for b in base})
    X_cache, y = {}, None
    for s in spaces:
        X_cache[s], y, _ = pdci.build(s)
    n = len(y)

    outer = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats,
                                    random_state=seed)
    acc = np.zeros((n, 3))
    seen = np.zeros(n)
    vote_acc = {k: np.zeros((n, 3)) for k in topn}

    for fold, (tr, te) in enumerate(outer.split(X_cache[spaces[0]], y)):
        # 1. inner out-of-fold base predictions, TRAINING FOLD ONLY
        inner = StratifiedKFold(3, shuffle=True, random_state=seed)
        meta_tr = np.zeros((len(tr), 3 * len(base)))
        for bi, (sp, sel, clf, k) in enumerate(base):
            oof = np.zeros((len(tr), 3))
            for itr, ite in inner.split(X_cache[sp].iloc[tr], y.iloc[tr]):
                oof[ite] = _fit_predict(sp, sel, clf, k, tr[itr], tr[ite],
                                        X_cache, y)
            meta_tr[:, bi * 3:(bi + 1) * 3] = oof

        # 2. meta-learner on those inner predictions
        meta = LogisticRegression(max_iter=4000, C=1.0,
                                  class_weight="balanced", random_state=seed)
        meta.fit(meta_tr, y.iloc[tr])

        # 3. base models refit on the full training fold, applied to the test
        meta_te = np.zeros((len(te), 3 * len(base)))
        preds = Parallel(n_jobs=jobs)(
            delayed(_fit_predict)(sp, sel, clf, k, tr, te, X_cache, y)
            for sp, sel, clf, k in base)
        for bi, p in enumerate(preds):
            meta_te[:, bi * 3:(bi + 1) * 3] = p

        pm = meta.predict_proba(meta_te)
        for j, c in enumerate(meta.classes_):
            acc[te, int(c)] += pm[:, j]

        # Honest select-and-vote: rank the base models on INNER predictions
        # only, then average the top N on the untouched test fold.
        inner_scores = [_pdci_auc(y.iloc[tr].values,
                                  meta_tr[:, bi * 3:(bi + 1) * 3])
                        for bi in range(len(base))]
        order = np.argsort(inner_scores)[::-1]
        for k in topn:
            pick = order[:k]
            v = np.mean([meta_te[:, b * 3:(b + 1) * 3] for b in pick], axis=0)
            vote_acc[k][te] += v / np.maximum(v.sum(axis=1, keepdims=True), 1e-9)
        seen[te] += 1
        print(f"    fold {fold + 1}: done", flush=True)

    acc /= np.maximum(seen, 1)[:, None]
    votes = {}
    for k, v in vote_acc.items():
        v = v / np.maximum(seen, 1)[:, None]
        votes[k] = v / np.maximum(v.sum(axis=1, keepdims=True), 1e-9)
    return acc / np.maximum(acc.sum(axis=1, keepdims=True), 1e-9), y, votes


# ------------------------------------------------------------------ driver
def cmd_stack(args):
    screen = pd.read_json(OUT / "screen.jsonl", lines=True)
    ok = screen[screen.status == "ok"].copy()
    print(f"{len(ok)} screened configurations available\n")
    _, y, _ = pdci.build("demographics")
    rows = []

    # ---- fixed, pre-specified ensemble (clean) -------------------------
    fixed_ids = [f"{s}|{sel}|{c}|k{k}" for s, sel, c, k in FIXED_BASE]
    mats = load_oof(fixed_ids)
    print(f"vote_fixed: {len(mats)}/{len(fixed_ids)} base models found")
    if len(mats) >= 3:
        m = pdci.score3(y, blend(mats))
        m.pop("confusion_matrix")
        rows.append({"ensemble": "vote_fixed", "n_base": len(mats),
                     "optimism": "none (membership fixed in advance)", **m})

    # ---- top-N by out-of-fold score (selection-biased) -----------------
    for n_top in (3, 5, 10, 20):
        top = ok.nlargest(n_top, "pd_vs_ci_auc")
        mats = load_oof(list(top.config_id))
        if len(mats) < 2:
            continue
        m = pdci.score3(y, blend(mats))
        m.pop("confusion_matrix")
        rows.append({"ensemble": f"vote_top{n_top}", "n_base": len(mats),
                     "optimism": "membership chosen on out-of-fold score", **m})

        cm = pdci.score3(y, confidence_pick(mats))
        cm.pop("confusion_matrix")
        rows.append({"ensemble": f"confidence_top{n_top}", "n_base": len(mats),
                     "optimism": "membership chosen on out-of-fold score", **cm})

    # ---- diversity-aware: best configuration per feature space ---------
    per_space = ok.loc[ok.groupby("space").pd_vs_ci_auc.idxmax()]
    mats = load_oof(list(per_space.config_id))
    if len(mats) >= 3:
        m = pdci.score3(y, blend(mats))
        m.pop("confusion_matrix")
        rows.append({"ensemble": "vote_best_per_space", "n_base": len(mats),
                     "optimism": "membership chosen on out-of-fold score", **m})

    # ---- true nested stacking (clean) ---------------------------------
    if not args.no_nested:
        print("\nnested stacking (base models refit inside every fold)...")
        t0 = time.time()
        base = [b for b in FIXED_BASE]
        proba, yy, votes = stack_nested(base, n_splits=5,
                                        n_repeats=args.stack_repeats,
                                        jobs=args.jobs)
        for k, vp in votes.items():
            vm = pdci.score3(yy, vp)
            vm.pop("confusion_matrix")
            rows.append({"ensemble": f"vote_nested_top{k}", "n_base": k,
                         "optimism": "none (members ranked inside each fold)",
                         **vm})
        np.save(OUT / "stack_nested_proba.npy", proba.astype(np.float32))
        m = pdci.score3(yy, proba)
        cm = m.pop("confusion_matrix")
        rows.append({"ensemble": "stack_nested", "n_base": len(base),
                     "optimism": "none (fully nested)", **m})
        print(f"  done in {(time.time() - t0)/60:.1f} min")
        (OUT / "stack_confusion.json").write_text(json.dumps(
            {"classes": pdci.CLASSES, "confusion": cm}, indent=2))

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "ensembles.csv", index=False)
    cols = ["ensemble", "n_base", "macro_ovr_auc", "pd_vs_ci_auc",
            "balanced_accuracy", "accuracy", "optimism"]
    print("\n" + df[cols].sort_values("pd_vs_ci_auc", ascending=False)
          .round(3).to_string(index=False))

    best_single = ok.nlargest(1, "pd_vs_ci_auc").iloc[0]
    print(f"\nbest single configuration: {best_single.config_id}  "
          f"macro={best_single.macro_ovr_auc:.3f}  "
          f"PDvsCI={best_single.pd_vs_ci_auc:.3f}")
