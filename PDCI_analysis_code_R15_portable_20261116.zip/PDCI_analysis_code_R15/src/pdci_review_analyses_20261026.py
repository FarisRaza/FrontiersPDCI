"""Reviewer-requested analyses for the PD/CI Frontiers revision (AR-41, AR-42); post hoc, descriptive, no refitting.

Protocol: results/pdci_review_analyses_20261026/ANALYSIS_PLAN.md.
Usage (analysis venv; thread variables set to 1):  python src/pdci_review_analyses_20261026.py freeze|gate|run
"""
from __future__ import annotations

import hashlib
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import pdci_a8_cohort_recount_20261007 as A8  # noqa: E402

OUT = C.RESULTS / "pdci_review_analyses_20261026"
RUN = C.RESULTS / "pdci_demographic_baseline_20260911"
PRED = RUN / "local_only" / "participant_oof_predictions.parquet"
AUC_RECEIPT = RUN / "auc_intervals.csv"
SEED = 20261026
B = 5000
INPUTS = [PRED, AUC_RECEIPT, RUN / "INPUT_AUDIT.json", C.DATA / "cohort.parquet", C.DATA / "static_bytask.parquet",
          A8.DEMO, A8.PD_TSV, A8.CI_TSV, Path(PT.__file__), Path(A8.__file__), Path(C.__file__)]


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def wj(p: Path, o):
    p.write_text(json.dumps(o, indent=2) + "\n", encoding="utf-8")


def freeze():
    if (OUT / "FROZEN_SPEC.json").exists():
        raise SystemExit("already frozen")
    wj(OUT / "FROZEN_SPEC.json", dict(created=now(), authority=["AR-41", "AR-42"], seed=SEED, bootstrap=B,
       protocol_sha256=sha(OUT / "ANALYSIS_PLAN.md"), script_sha256=sha(Path(__file__)),
       inputs={str(Path(p).relative_to(C.ROOT.parent)): sha(p) for p in INPUTS},
       versions=dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__,
                     sklearn=sklearn.__version__)))
    print("frozen")


def check_frozen():
    s = json.loads((OUT / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    assert s["protocol_sha256"] == sha(OUT / "ANALYSIS_PLAN.md") and s["script_sha256"] == sha(Path(__file__))
    for rel, h in s["inputs"].items():
        assert sha(C.ROOT.parent / rel) == h, rel
    return s


def load():
    pr = pd.read_parquet(PRED)
    if "participant_id" not in pr.columns:
        pr = pr.reset_index()
    pr["pid"] = A8.pad(pr["participant_id"])
    ids, y, _ = A8.cohort_and_labels()
    assert len(pr) == 750 and set(pr["pid"]) == set(A8.pad(ids))
    pr = pr.set_index("pid")
    lab = pd.Series(y.values, index=A8.pad(y.index))
    assert (pr["y_true"].astype(int) == lab.reindex(pr.index)).all()
    demo = A8.demographics(ids)
    demo.index = A8.pad(demo.index)
    pr = pr.join(demo)
    pdm = pd.read_csv(A8.PD_TSV, sep="\t", dtype=str)
    pdm["pid"] = A8.pad(pdm["participant_id"])
    cim = pd.read_csv(A8.CI_TSV, sep="\t", dtype=str)
    cim["pid"] = A8.pad(cim["participant_id"])
    pr["pd_subtype"] = pdm.set_index("pid")[A8.PD_FIELD].reindex(pr.index)
    pr["ci_subtype"] = cim.set_index("pid")[A8.CI_FIELD].reindex(pr.index)
    return pr


def auc_pdci(d, col):
    m = d["y_true"].isin([1, 2])
    return float(roc_auc_score((d.loc[m, "y_true"] == 1).astype(int), d.loc[m, col]))


def gate():
    check_frozen()
    pr = load()
    pd.read_csv(AUC_RECEIPT)  # receipt hashed in FROZEN_SPEC; values compared below
    v, b = auc_pdci(pr, "primary_q"), auc_pdci(pr, "agesexcountry_q")
    checks = {"counts_598_90_62": [int((pr.y_true == k).sum()) for k in (0, 1, 2)] == [598, 90, 62],
              "voice_auc_0.8204301": abs(v - 0.8204301075268817) < 1e-9,
              "baseline_auc_0.6874552": abs(b - 0.6874551971326165) < 1e-9}
    res = dict(time=now(), checks=checks, passed=all(checks.values()), recomputed=dict(voice=v, baseline=b))
    wj(OUT / "GATE.json", res)
    print(json.dumps(res, indent=1))
    if not res["passed"]:
        raise SystemExit("GATE FAILED")


def boot_pair(d, f, rng):
    """Paired class-stratified bootstrap of statistic f(d_sub) -> (voice, baseline)."""
    pdi = np.flatnonzero(d["y_true"].values == 1)
    cii = np.flatnonzero(d["y_true"].values == 2)
    vals = np.empty((B, 2))
    for i in range(B):
        idx = np.r_[rng.choice(pdi, pdi.size, replace=True), rng.choice(cii, cii.size, replace=True)]
        vals[i] = f(d.iloc[idx])
    return vals


def summarize(name, d, stat_v, stat_b, rng):
    v, b = stat_v(d), stat_b(d)
    bs = boot_pair(d, lambda s: (stat_v(s), stat_b(s)), rng)
    diff = bs[:, 0] - bs[:, 1]
    q = lambda a: (float(np.percentile(a, 2.5)), float(np.percentile(a, 97.5)))
    return dict(analysis=name, n_PD=int((d.y_true == 1).sum()), n_CI=int((d.y_true == 2).sum()),
                voice=v, voice_low=q(bs[:, 0])[0], voice_high=q(bs[:, 0])[1],
                baseline=b, baseline_low=q(bs[:, 1])[0], baseline_high=q(bs[:, 1])[1],
                gain=v - b, gain_low=q(diff)[0], gain_high=q(diff)[1])


def run():
    spec = check_frozen()
    assert json.loads((OUT / "GATE.json").read_text(encoding="utf-8"))["passed"]
    t0 = now()
    pr = load()
    cases = pr[pr.y_true.isin([1, 2])].copy()
    av = lambda s: auc_pdci(s, "primary_q")
    ab = lambda s: auc_pdci(s, "agesexcountry_q")
    # S1 within country (AR-41)
    rng = np.random.default_rng(SEED)
    s1 = []
    for ctry in ("Canada", "USA"):
        d = cases[cases.country == ctry]
        npd, nci = int((d.y_true == 1).sum()), int((d.y_true == 2).sum())
        if min(npd, nci) >= 10:
            s1.append(summarize(f"within {ctry}", d, av, ab, rng))
        else:
            s1.append(dict(analysis=f"within {ctry}", n_PD=npd, n_CI=nci, note="too few in one class; no AUROC"))
    pd.DataFrame(s1).to_csv(OUT / "s1_within_country.csv", index=False)
    # S2 subtypes (AR-42)
    rng = np.random.default_rng(SEED + 1)
    idio = cases[((cases.y_true == 1) & (cases.pd_subtype == "Idiopathic Parkinson's Disease (IPD)")) |
                 ((cases.y_true == 2) & (cases.ci_subtype == "Mild Cognitive Impairment (MCI)"))]
    keep = cases[(cases.y_true == 2) | ((cases.y_true == 1) & cases.pd_subtype.isin(
        ["Idiopathic Parkinson's Disease (IPD)", "Not Sure / Undetermined"]))]
    s2 = [summarize("idiopathic PD vs MCI", idio, av, ab, rng),
          summarize("PD without DLB, PSP or other parkinsonism vs all CI", keep, av, ab, rng)]
    pd.DataFrame(s2).to_csv(OUT / "s2_subtypes.csv", index=False)
    # S3 excluded vs analysed (AR-42)
    co = PT.cohort()
    base = PT.clean_base_mask()
    ids_all = co.index[base]
    analysed = set(PT.ids_for_design("general"))
    excl = pd.Index([i for i in ids_all if i not in analysed])
    assert len(ids_all) == 829 and len(excl) == 79
    lab_all = PT.labels(ids_all, "multiclass")
    dem_all = A8.demographics(ids_all)
    rows = []
    for grp, idx in (("analysed", pd.Index(sorted(analysed))), ("excluded", excl)):
        dd, yy = dem_all.loc[idx], lab_all.loc[idx]
        age = dd.age.dropna()
        rows.append(dict(group=grp, n=len(idx), neither=int((yy == 0).sum()), PD=int((yy == 1).sum()), CI=int((yy == 2).sum()),
                         age_observed=int(age.size), age_mean=float(age.mean()), age_sd=float(age.std(ddof=1)),
                         female=int((dd.sex == "Female").sum()), male=int((dd.sex == "Male").sum()),
                         sex_unavailable=int((dd.sex == "unavailable").sum()),
                         USA=int((dd.country == "USA").sum()), Canada=int((dd.country == "Canada").sum()),
                         country_unknown=int((dd.country == "unknown").sum())))
    pd.DataFrame(rows).to_csv(OUT / "s3_excluded_vs_analysed.csv", index=False, float_format="%.4f")
    tp = PT.task_presence().loc[excl, PT.GENERAL_TASKS]
    miss = (~tp).sum().rename("n_excluded_missing").rename_axis("task_family").reset_index()
    miss["n_missing_families_distribution"] = ""
    dist = (~tp).sum(axis=1).value_counts().sort_index()
    pd.concat([miss, pd.DataFrame({"task_family": [f"participants missing {k} families" for k in dist.index],
                                   "n_excluded_missing": dist.values, "n_missing_families_distribution": "count"})]
              ).to_csv(OUT / "s3_missing_task_families.csv", index=False)
    # S4 average precision and score distributions (AR-42)
    rng = np.random.default_rng(SEED + 2)
    def ap(col, pos):
        def f(s):
            yy = (s.y_true == pos).astype(int)
            sc = s[col] if pos == 1 else 1 - s[col]
            return float(average_precision_score(yy, sc))
        return f
    s4 = []
    for pos, nm in ((1, "PD as positive"), (2, "CI as positive")):
        r = summarize(f"average precision, {nm}", cases, ap("primary_q", pos), ap("agesexcountry_q", pos), rng)
        r["prevalence"] = float((cases.y_true == pos).mean())
        s4.append(r)
    pd.DataFrame(s4).to_csv(OUT / "s4_average_precision.csv", index=False)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9, "font.family": "DejaVu Sans"})
    fig, axes = plt.subplots(1, 2, figsize=(7.09, 3.2), sharey=True)
    for ax, (col, ttl) in zip(axes, (("primary_q", "A  Voice procedure"), ("agesexcountry_q", "B  Age, sex and residence country"))):
        data = [cases.loc[cases.y_true == 1, col].values, cases.loc[cases.y_true == 2, col].values]
        parts = ax.violinplot(data, positions=[1, 2], showextrema=False, widths=0.8)
        for b_, c_ in zip(parts["bodies"], ("#3b6ea8", "#c0504d")):
            b_.set_facecolor(c_); b_.set_alpha(0.35); b_.set_edgecolor("none")
        ax.boxplot(data, positions=[1, 2], widths=0.25, showfliers=False)
        ax.set_xticks([1, 2]); ax.set_xticklabels([f"PD (n={len(data[0])})", f"CI (n={len(data[1])})"])
        ax.set_title(ttl, loc="left", fontsize=9, fontweight="bold")
        ax.set_ylim(0, 1)
    axes[0].set_ylabel("Saved held-out stage-2 score q (PD given case)")
    fig.tight_layout()
    fig.savefig(OUT / "s4_score_distributions.png", dpi=300)
    fig.savefig(OUT / "s4_score_distributions.svg")
    wj(OUT / "COMPLETION.json", dict(start=t0, end=now(), script_sha256=spec["script_sha256"],
       frozen_spec_sha256=sha(OUT / "FROZEN_SPEC.json"), seed=SEED, bootstrap=B))
    for f in ("s1_within_country", "s2_subtypes", "s3_excluded_vs_analysed", "s4_average_precision"):
        print(f); print(pd.read_csv(OUT / f"{f}.csv").to_string(index=False))


if __name__ == "__main__":
    {"freeze": freeze, "gate": gate, "run": run}[sys.argv[1]]()
