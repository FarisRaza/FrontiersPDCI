"""Build only the per-task dynamic cache required by this paper; no statistical sweep.

Run after the five dynamic extractors and before harmonic extraction.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
from significance_sweep import DYN_BYTASK, dynamic_bytask

if __name__ == "__main__":
    if not DYN_BYTASK.exists():
        expected = {"dyn_prosody.parquet", "dyn_ema.parquet", "dyn_ppg.parquet",
                    "dyn_mfccdyn.parquet", "dyn_ltas.parquet"}
        present = {p.name for p in C.DATA.glob("dyn_*.parquet") if "TEST" not in p.name}
        assert present == expected, ("Run the five dynamic extractors in a clean analysis/data "
                                     "folder before harmonic extraction; unexpected cache set", present)
    dynamic_bytask()  # Unchanged original aggregation function; no hypothesis tests.
