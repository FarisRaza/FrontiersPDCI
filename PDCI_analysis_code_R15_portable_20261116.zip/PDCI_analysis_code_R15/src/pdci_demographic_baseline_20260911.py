"""User-amended ASC-only baseline with optional timing predictor features.

Run only with analysis/.venv/Scripts/python.exe. Prior results are read-only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
import traceback
import warnings
from pathlib import Path

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_name] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import joblib
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.feature_selection import f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (balanced_accuracy_score, confusion_matrix,
                             roc_auc_score)
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import pdci_tasks as PT
import pdci_linear_harmonics as H

OUT = C.RESULTS / "pdci_demographic_baseline_20260911"
LOCAL = OUT / "local_only"
FOLDS = LOCAL / "folds"
SEED = C.RANDOM_STATE
SPACES = ("mean", "mean_sd", "individual", "individual_mean_sd")
SCREEN = [dict(mode=m, target=t, k=k, c=c, weight=w)
          for m in ("base", "fusion") for t in ("onehot", "neuro")
          for k in (5, 10, 20) for c in (.003, .03)
          for w in ("empirical", "balanced")]
STAGE2 = []
for _space in SPACES:
    STAGE2 += [dict(space=_space, family="pca_lda", k=k, c=0.)
               for k in (5, 10, 20, 40, 75, 100)]
    STAGE2 += [dict(space=_space, family="pca_ridge", k=k, c=c)
               for k in (10, 40) for c in (.01, .1, 1.)]
    STAGE2 += [dict(space=_space, family="elastic", k=k, c=c)
               for k in (20, 60) for c in (.03, .3)]
    STAGE2 += [dict(space=_space, family=f, k=40, c=c)
               for f, cs in (("linear_svm", (.01, .1)), ("rbf_svm", (.1, 1.)))
               for c in cs]
SECONDARY = [dict(space="individual", family=f, k=k, c=c)
             for k in (20, 50, 75, 100)
             for f, c in (("pca_lda", 0.), ("pca_ridge", .1))]
BASELINES = [dict(c=c, weight=w) for c in (.01, .1, 1., 10.)
             for w in ("empirical", "balanced")]
SCREEN = [dict(**c,timing=t) for c in SCREEN for t in ("off","on")]
STAGE2 = [dict(**c,timing=t) for c in STAGE2 for t in ("off","on")]
SECONDARY = [dict(**c,timing=t) for c in SECONDARY for t in ("off","on")]
PREVIOUS = C.RESULTS / "pdci_fully_nested_20260911"
TIMING_DYNAMIC = ("ema_dur_s", "ltas_n_frames", "mfccdyn_dur_s",
                  "ppg_dur_s", "ppg_speech_dur_s", "prosody_dur_s")
NAMES = ("neither", "PD", "cognitive_impairment")
BASELINE_KEYS = {"asc": "agesexcountry"}


def stamp():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def json_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False, default=str), encoding="utf-8")
    os.replace(temp, path)


def ident(spec):
    return "__".join(f"{key}-{value}" for key, value in spec.items())


class Prep:
    """Every data-derived rule is estimated on this fit's training rows only."""
    def fit_transform(self, x):
        x = np.asarray(x, dtype=float).copy()
        x[~np.isfinite(x)] = np.nan
        self.available = np.mean(np.isfinite(x), axis=0) >= .5
        z = x[:, self.available]
        self.lo, self.hi = np.nanquantile(z, [.005, .995], axis=0)
        same = self.hi <= self.lo
        self.lo[same], self.hi[same] = -np.inf, np.inf
        z = np.clip(z, self.lo, self.hi)
        self.med = np.nanmedian(z, axis=0)
        z = np.where(np.isfinite(z), z, self.med)
        self.mean, self.sd = z.mean(axis=0), z.std(axis=0)
        self.vary = self.sd > 1e-8
        if not self.vary.any():
            raise ValueError("no nonconstant training features")
        return ((z - self.mean)[:, self.vary] / self.sd[self.vary])

    def transform(self, x):
        z = np.asarray(x, dtype=float)[:, self.available]
        z = np.where(np.isfinite(z), z, np.nan)
        z = np.clip(z, self.lo, self.hi)
        z = np.where(np.isfinite(z), z, self.med)
        return (z - self.mean)[:, self.vary] / self.sd[self.vary]


def prep_pair(x, z):
    obj = Prep()
    return obj.fit_transform(x), obj.transform(z)


def p_aligned(est, x, nclasses):
    got = est.predict_proba(x)
    out = np.zeros((len(x), nclasses))
    for i, cls in enumerate(est.classes_):
        out[:, int(cls)] = got[:, i]
    return np.clip(out, 1e-8, 1 - 1e-8)


def conditional(p):
    return p[:, 1] / (p[:, 1] + p[:, 2])


def compose(s, q):
    s, q = np.clip(s, 1e-8, 1 - 1e-8), np.clip(q, 1e-8, 1 - 1e-8)
    return np.column_stack((1 - s, s * q, s * (1 - q)))


def ridge_prediction(a, y, b, c, weight="empirical", nclasses=2):
    scaler = StandardScaler()
    aa, bb = scaler.fit_transform(a), scaler.transform(b)
    est = LogisticRegression(C=c, penalty="l2", solver="lbfgs", max_iter=5000,
                             class_weight="balanced" if weight == "balanced" else None,
                             random_state=SEED)
    est.fit(aa, y)
    return p_aligned(est, bb, nclasses)


def stage2_bank(matrices, tr, te, ytrain, configs, nclasses=2):
    result = {}
    for space,timing in sorted({(c["space"],c["timing"]) for c in configs}):
        selected = [c for c in configs if c["space"] == space and c["timing"] == timing]
        key = f"{space}__timing_{timing}"
        a, b = prep_pair(matrices[key][tr], matrices[key][te])
        dims = [c["k"] for c in selected if c["family"].startswith("pca")]
        if dims:
            # Fixed maximum also during selected-only refits: randomized PCA
            # approximation must not depend on which other heads are requested.
            max_k = min(100, len(a) - 2, a.shape[1])
            pca = PCA(n_components=max_k, svd_solver="randomized", iterated_power=4,
                      random_state=SEED)
            pa, pb = pca.fit_transform(a), pca.transform(b)
        if any(not c["family"].startswith("pca") for c in selected):
            scores = np.nan_to_num(f_classif(a, ytrain)[0], nan=-np.inf,
                                   posinf=np.finfo(float).max)
            ranking = np.argsort(-scores, kind="stable")
        for cfg in selected:
            if cfg["family"].startswith("pca"):
                k = min(cfg["k"], pa.shape[1])
                aa, bb = pa[:, :k], pb[:, :k]
            else:
                k = min(cfg["k"], a.shape[1], len(a) - 2)
                aa, bb = a[:, ranking[:k]], b[:, ranking[:k]]
            family = cfg["family"]
            if family == "pca_lda":
                est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
                est.fit(aa, ytrain)
                p = p_aligned(est, bb, nclasses)
            elif family == "pca_ridge":
                p = ridge_prediction(aa, ytrain, bb, cfg["c"], nclasses=nclasses)
            else:
                if family == "elastic":
                    est = LogisticRegression(C=cfg["c"], penalty="elasticnet", l1_ratio=.5,
                                             solver="saga", max_iter=5000, tol=1e-4,
                                             random_state=SEED)
                else:
                    est = SVC(C=cfg["c"], kernel="linear" if family == "linear_svm" else "rbf",
                              gamma="scale", probability=True, cache_size=256,
                              random_state=SEED)
                est.fit(aa, ytrain)
                p = p_aligned(est, bb, nclasses)
            result[ident(cfg)] = conditional(p) if nclasses == 3 else p[:, 1]
    return result


def screen_bank(data, tr, te, configs):
    out = {}
    cov_a, cov_b = prep_pair(data["asc"][tr], data["asc"][te])
    prepared = {}
    for timing in sorted({c["timing"] for c in configs}):
        prepared[("base",timing)] = prep_pair(data[f"base_{timing}"][tr],data[f"base_{timing}"][te])
        if any(c["mode"] == "fusion" and c["timing"] == timing for c in configs):
            prepared[("harm",timing)] = prep_pair(data[f"harm_{timing}"][tr],data[f"harm_{timing}"][te])
    for mode,timing in sorted({(c["mode"],c["timing"]) for c in configs}):
        base_a,base_b = prepared[("base",timing)]
        harm_a,harm_b = prepared[("harm",timing)] if mode == "fusion" else (None,None)
        a = np.column_stack([base_a, cov_a] if mode == "base" else [base_a, harm_a, cov_a])
        b = np.column_stack([base_b, cov_b] if mode == "base" else [base_b, harm_b, cov_b])
        for target in sorted({c["target"] for c in configs if c["mode"] == mode and c["timing"] == timing}):
            yy = data["y"][tr]
            response = np.eye(3)[yy] if target == "onehot" else (yy > 0).astype(float)[:, None]
            # Always the declared maximum; candidate subset cannot change latent fitting.
            pls = PLSRegression(n_components=min(20, len(a) - 2, a.shape[1]),
                                scale=False, max_iter=500, tol=1e-6)
            pls.fit(a, response)
            pa, pb = pls.transform(a), pls.transform(b)
            for cfg in configs:
                if cfg["mode"] != mode or cfg["target"] != target or cfg["timing"] != timing:
                    continue
                k = min(cfg["k"], pa.shape[1])
                p = ridge_prediction(pa[:, :k], yy if target == "onehot" else (yy > 0).astype(int),
                                     pb[:, :k], cfg["c"], cfg["weight"],
                                     nclasses=3 if target == "onehot" else 2)
                out[ident(cfg)] = p[:, 1:].sum(axis=1)
    return out


def baseline_bank(x, tr, te, ytrain, configs):
    a, b = prep_pair(x[tr], x[te])
    return {ident(c): ridge_prediction(a, ytrain, b, c["c"], c["weight"])[:, 1]
            for c in configs}


def complexity(c):
    if "family" in c:
        families = {"pca_lda": 0, "pca_ridge": 1, "elastic": 2, "linear_svm": 3, "rbf_svm": 4}
        return (int(c["timing"]!="off"),c["k"], SPACES.index(c["space"]), families[c["family"]], c["c"])
    if "mode" in c:
        return (int(c["timing"]!="off"),c["k"], int(c["mode"] != "base"), int(c["target"] != "neuro"),
                c["c"], int(c["weight"] != "empirical"))
    return (c["c"], int(c["weight"] != "empirical"))


def choose(y, oof, configs, margin=.005):
    scores = {key: float(roc_auc_score(y, value)) for key, value in oof.items()}
    best = max(scores.values())
    eligible = [c for c in configs if scores[ident(c)] >= best - margin]
    picked = min(eligible, key=lambda c: (*complexity(c), ident(c)))
    return picked, scores


def threshold(y, p, target):
    # Largest threshold satisfying requested empirical training-OOF sensitivity.
    candidates = np.unique(np.r_[0., p, 1.])
    positive = p[np.asarray(y, dtype=bool)]
    good = [v for v in candidates if np.mean(positive >= v) >= target]
    return float(max(good))


def harmonic_raw(ids):
    bt = H.harmonic_bytask()
    cols = list(bt.columns)
    bt = bt.reindex(pd.MultiIndex.from_product([ids, PT.GENERAL_TASKS],
                                              names=["participant_id", "task_group"]))
    wide = bt.unstack("task_group").reindex(columns=pd.MultiIndex.from_product([cols, PT.GENERAL_TASKS]))
    wide.columns = [f"h__{task}__{feat}" for feat, task in wide.columns]
    mean, sd = bt.groupby(level=0).mean(), bt.groupby(level=0).std(ddof=0)
    mean.columns, sd.columns = [f"hmean__{c}" for c in cols], [f"hsd__{c}" for c in cols]
    task_sets = {
        "sustained_minus_connected": (["prolonged_vowel", "maximum_phonation_time", "loudness", "glides"],
                                      ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "ddk_minus_connected": (["diadochokinesis"], ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "resp_minus_connected": (["breathing", "cough_respiration"], ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "read_minus_spontaneous": (["rainbow_passage"], ["free_speech", "picture_description", "story_recall"]),
    }
    parts = [wide.reindex(ids), mean.reindex(ids), sd.reindex(ids)]
    for tag, (left, right) in task_sets.items():
        q = (bt.loc[(slice(None), left), cols].groupby(level=0).mean().reindex(ids)
             - bt.loc[(slice(None), right), cols].groupby(level=0).mean().reindex(ids))
        q.columns = [f"hcontrast__{tag}__{c}" for c in cols]
        parts.append(q)
    parts.append(H._task_geometry(bt, ids, cols))
    return pd.concat(parts, axis=1).replace([np.inf, -np.inf], np.nan).astype(np.float32)


PLAN = """# User-amended demographic-baseline study

This specification implements the user's amendment after the preceding fully
nested run had been reviewed. That run, its BH9 results and manuscript are
preserved unchanged. The new grids and policies are fixed before any new outer
outcomes are viewed; this is an amended internal evaluation on a previously
explored cohort, not a claim of independent or original prospective validation.

## Population and baseline

Retain exactly the same750 physical participants (598 neither,90 PD,62 cognitive
impairment), original identifiers/order, ALS and PD/CI-overlap exclusions, complete
11 general task families and all15 original outer partitions (fivefold x3repeats).
Use the already independently verified canonical demographic linkage: age/sex are
corrected, with4/6 values unavailable, respectively; country is complete.

The ONLY demographic baseline is age, sex_male and residence_country_USA.
These three columns also form the acoustic procedures' demographic block.
Country is residence, not a verified recording-site measure. No constant unknown
indicator, duration, frame count, recording count, task count or completion
indicator occurs in the demographic block. Baseline screen and discriminator
tune ridge C=.01/.1/1/10 and empirical/balanced weighting inside3fold CV.
No age/sex-only or duration-adjusted baseline is fitted in this amended experiment.

## Optional timing features and exact preservation audit

All original nontiming dynamic/harmonic values are preserved bit-for-bit.
Original dynamic spaces are mean505, mean+sample-SD1010, individual5555, and
individual+mean+SD6565 acoustic columns; original harmonic geometry is unchanged.
A timing-off/on flag is an inner-CV candidate choice, not a separate winner
chosen from outer outcomes. Timing-off removes only the explicitly declared
timing block; other temporal acoustic dynamics remain available.

Timing-on includes the14 explicit log1p duration summaries as FEATURES: mean
recorded length for each of11 task families and sum/mean/sample-SD across family
means. They are not demographic covariates or a protected model appendage.
It also restores six distinct cached dynamic size descriptors: ema_dur_s,
ltas_n_frames, mfccdyn_dur_s, ppg_dur_s, ppg_speech_dur_s and prosody_dur_s.
These receive the same per-task/mean/SD construction as the chosen dynamic space.
No new raw tensor extraction is performed. The known duplicate
prosody_f0_ppq3_st remains excluded. The fixed source identity
ltas_dur_s=ltas_n_frames/50 is verified in the saved cache, so actual frame count
is retained and its duplicate duration representation is omitted.

For screening fusion, lin_n_frames is restored as a harmonic timing feature,
with per-task/mean/SD and four task-group contrasts; original nontiming harmonic
values and within-person geometry are unchanged. lin_dur_s=lin_n_frames/50 is
likewise verified and its duplicate omitted. Missing modality frames stay missing,
not zero. Related timing quantities are not interpreted as independent measures.
Neither number of recordings/repetitions/tasks nor any completion/missingness
indicator is introduced as a feature. Source-level exclusions unrelated to
this timing amendment are not reopened.

Timing variables undergo exactly the same within-training availability filtering,
winsorization, imputation, standardization, F filtering/projection, shrinkage and
regularization as other candidate features. They are never force-retained.

## Frozen nested architecture grids

The previous48 screen architectures are crossed with timing-off/on, giving96:
base versus harmonic fusion, binary-neurologic versus three-class one-hot PLS
response,5/10/20 components, ridge C=.003/.03, empirical/balanced class weighting.
PLS always fits the declared maximum20 components capped by training rank, then
heads use the requested prefix. Preprocessing is refitted within every inner fit.

The previous80 dedicated architectures are crossed with timing-off/on, giving160:
four dynamic spaces; per space six PCA/auto-shrinkage-LDA dimensions
5/10/20/40/75/100; PCA/ridge at10/40 PCs and C=.01/.1/1; F-filtered elastic net
at20/60 features and C=.03/.3, l1_ratio=.5; F-filtered linear SVM at40 features
and C=.01/.1; RBF SVM at40 features and C=.1/1, gamma=scale.
PCA always uses the declared maximum100 capped by training rows minus2/width
for consistent shared-bank and selected-only refits. SVM probability calibration
uses only the estimator's training rows. Dedicated training uses true PD/CI cases
only; every outer-test participant receives a conditional score.

The predeclared secondary all-three-class-trained conditional discriminator
retains its eight original individual-space PCA/head specifications crossed with
timing-off/on, giving16. It selects by PD-versus-CI inner AUROC and is not promoted
based on outer outcomes. Its restricted grid makes it an alternative procedure,
not an isolated experiment on whether neither participants should be used.

Both stages use3 inner folds entirely within each matched outer-training set.
All >=50% finite-availability checks, .5/99.5-percentile clipping, medians, scales,
nonconstant filtering, supervised F scores, latent transforms and model choices
are fitted within the appropriate training split. Inner choices maximize AUROC;
within .005, prefer timing-off first, then fewer dimensions, simpler spaces/heads
and stronger regularization, using the saved deterministic order.

## Predictions, decisions and new inference family

Save each outer-test s=P(PD or CI), q=P(PD|PD or CI), and the composed three-class
vector(1-s,s*q,s*(1-q)). Compose within folds, then average each person's three
vectors for macro one-versus-rest AUROC. Average s and q separately for the two
stage-specific AUROCs; stage2 is evaluated in all152 actual cases, regardless of
screen passage. Report pooled, each-repeat and all15 fold metrics.

The original decision policies are unchanged: screen .5, or the largest threshold
meeting90%/95% sensitivity on the selected screen's own outer-training inner-OOF
scores. No outer labels or other outer partitions' OOFs choose thresholds.
After a positive screen, q>=.5 assigns PD. Participant calls use majority of three
held-out calls, with a three-way tie resolved neither; each-repeat matrices are
also reported. No new threshold or abstention optimization is added.

Use5000 class-stratified paired participant bootstrap resamples of saved OOF scores
for nominal percentile95% intervals of AUROCs and differences from ASC-only.
These conditional intervals do not repeat fitting or account for development
history. The new primary comparison family is exactly THREE comparisons:
screen, conditional PD/CI, and three-class macro versus the ASC-only pipeline.

A separately labeled overlap-corrected repeated-CV sensitivity uses paired fold
differences, SE=sqrt((1/15+mean(test/train))*sample_variance), df14, two-sided p,
and NEW BH3. Its mean-fold gain differs from pooled-OOF gain. The earlier BH9
and all earlier results remain unchanged. Comparisons are between a searched
acoustic/timing procedure and tuned-ridge demographics, not architecture-free
or causal acoustic effects. Publication outputs contain only aggregates; exact
partitions and participant predictions remain local_only.
"""


def timing_summaries(bt, ids, prefix, ddof=1, contrasts=False):
    cols=list(bt.columns)
    wide=bt.unstack("task_group")
    wide.columns=[f"{prefix}task__{task}__{feat}" for feat,task in wide.columns]
    mean=bt.groupby(level=0).mean().reindex(ids)
    sd=bt.groupby(level=0).std(ddof=ddof).reindex(ids)
    mean.columns=[f"{prefix}mean__{c}" for c in cols]
    sd.columns=[f"{prefix}sd__{c}" for c in cols]
    spaces={"mean":mean,"mean_sd":pd.concat([mean,sd],axis=1),
            "individual":wide.reindex(ids),
            "individual_mean_sd":pd.concat([wide.reindex(ids),mean,sd],axis=1)}
    if not contrasts:
        return spaces
    groups={
        "sustained_minus_connected":(["prolonged_vowel","maximum_phonation_time","loudness","glides"],
                                    ["free_speech","picture_description","story_recall","rainbow_passage"]),
        "ddk_minus_connected":(["diadochokinesis"],["free_speech","picture_description","story_recall","rainbow_passage"]),
        "resp_minus_connected":(["breathing","cough_respiration"],["free_speech","picture_description","story_recall","rainbow_passage"]),
        "read_minus_spontaneous":(["rainbow_passage"],["free_speech","picture_description","story_recall"]),
    }
    pieces=[spaces["individual_mean_sd"]]
    for tag,(left,right) in groups.items():
        delta=(bt.loc[(slice(None),left),cols].groupby(level=0).mean().reindex(ids)
               -bt.loc[(slice(None),right),cols].groupby(level=0).mean().reindex(ids))
        delta.columns=[f"{prefix}contrast__{tag}__{c}" for c in cols]
        pieces.append(delta)
    return pd.concat(pieces,axis=1)


def prepare():
    if (OUT/"FROZEN_SPEC.json").exists():
        raise RuntimeError("already frozen; use run to resume")
    OUT.mkdir(parents=True,exist_ok=True); LOCAL.mkdir(exist_ok=True); FOLDS.mkdir(exist_ok=True)
    old=joblib.load(PREVIOUS/"local_only/input_payload.joblib")
    ids=pd.Index(old["ids"],name="participant_id"); y=old["y"]; splits=old["splits"]
    assert len(ids)==750 and ids.str.strip().str.zfill(6).nunique()==750
    assert np.bincount(y).tolist()==[598,90,62]
    assert ids.tolist()==PT.ids_for_design("general").astype(str).tolist()
    assert np.array_equal(y,PT.labels(ids,"multiclass").to_numpy(int))
    assert PT.task_presence().loc[ids,PT.GENERAL_TASKS].all().all()
    original_schema=json.loads((PREVIOUS/"feature_schemas.json").read_text(encoding="utf-8"))
    original_audit=json.loads((PREVIOUS/"INPUT_AUDIT.json").read_text(encoding="utf-8"))
    old_cov=pd.DataFrame(old["covcountry"],index=ids,columns=original_audit["covariates"])
    asc=old_cov[["age","sex_male","residence_country_USA"]].copy()
    durations=old_cov[[c for c in old_cov if c.startswith("dur_log__")]].copy()
    assert asc.shape==(750,3) and durations.shape==(750,14)
    assert asc.residence_country_USA.notna().all()
    assert asc.age.isna().sum()==4 and asc.sex_male.isna().sum()==6
    # Independently recheck raw canonical demographic values, never repair old data.
    demo_path=C.ROOT/"phenotype/demographics/demographics.tsv"
    demo=pd.read_csv(demo_path,sep="\t",dtype=str).drop_duplicates("participant_id",keep="first").set_index("participant_id")
    demo.index=demo.index.astype(str).str.strip().str.zfill(6)
    assert demo.index.is_unique
    demo=demo.reindex(ids.str.strip().str.zfill(6)); demo.index=ids
    corrected=pd.DataFrame({"age":pd.to_numeric(demo.age,errors="coerce"),
        "sex_male":demo.sex_at_birth.fillna(demo.sex_assigned_at_birth).map({"Male":1.,"Female":0.}),
        "residence_country_USA":demo.country.map({"USA":1.,"Canada":0.})},index=ids)
    assert np.array_equal(asc.to_numpy(),corrected.to_numpy(),equal_nan=True)
    full_index=pd.MultiIndex.from_product([ids,PT.GENERAL_TASKS],names=["participant_id","task_group"])
    raw=pd.read_parquet(C.DATA/"dynamic_bytask.parquet")
    pair=raw[["ltas_n_frames","ltas_dur_s"]].dropna()
    assert np.allclose(pair.ltas_n_frames/50,pair.ltas_dur_s,rtol=1e-6,atol=1e-6)
    timing_raw=raw[list(TIMING_DYNAMIC)].reindex(full_index).copy()
    timing_raw.columns=[f"dy__{c}" for c in timing_raw]
    dynamic_timing=timing_summaries(timing_raw,ids,"timing__")
    harmonic_source=pd.read_parquet(H.LH.OUT)
    pair_h=harmonic_source[["lin_n_frames","lin_dur_s"]].dropna()
    assert float(H.LH.FS_FRAME)==50.
    assert np.allclose(pair_h.lin_n_frames/50,pair_h.lin_dur_s,rtol=1e-6,atol=1e-6)
    harmonic_source["participant_id"]=harmonic_source.participant_id.astype(str)
    ht=(harmonic_source[harmonic_source.task_group.isin(PT.GENERAL_TASKS)]
        .groupby(["participant_id","task_group"])[["lin_n_frames"]].mean().reindex(full_index))
    harmonic_timing=timing_summaries(ht,ids,"htiming__",ddof=0,contrasts=True)
    matrices={}; schemas={}; preservation={}
    for space in SPACES:
        oldcols=original_schema[space]
        oldmatrix=pd.DataFrame(old["matrices"][space],index=ids,columns=oldcols)
        acoustic=oldmatrix.drop(columns=original_audit["covariates"])
        assert not any(c.startswith(("dur_log__","residence_country")) or c in {"age","sex_male"} for c in acoustic)
        off=pd.concat([acoustic,asc],axis=1)
        on=pd.concat([acoustic,dynamic_timing[space],durations,asc],axis=1)
        assert off.columns.is_unique and on.columns.is_unique
        assert np.array_equal(acoustic.to_numpy(),old["matrices"][space][:,:-18],equal_nan=True)
        assert np.array_equal(off[acoustic.columns].to_numpy(),on[acoustic.columns].to_numpy(),equal_nan=True)
        for timing,frame in (("off",off),("on",on)):
            key=f"{space}__timing_{timing}"
            matrices[key]=frame.to_numpy(np.float32); schemas[key]=list(frame.columns)
        preservation[space]=dict(old_acoustic_width=acoustic.shape[1],old_nontiming_values_bitwise_equal=True,
            timing_off_width=off.shape[1],timing_on_width=on.shape[1],
            added_timing_features=int(dynamic_timing[space].shape[1]+14))
    # Timing is in the feature blocks, never in the three-column demographic block.
    base_off=old["base"].copy()
    base_extra=pd.concat([dynamic_timing["individual"],durations],axis=1)
    base_on=np.column_stack([base_off,base_extra.to_numpy(np.float32)]).astype(np.float32)
    harm_off=old["harm"].copy()
    harm_on=np.column_stack([harm_off,harmonic_timing.to_numpy(np.float32)]).astype(np.float32)
    assert np.array_equal(base_on[:,:base_off.shape[1]],old["base"],equal_nan=True)
    assert np.array_equal(harm_on[:,:harm_off.shape[1]],old["harm"],equal_nan=True)
    fold_checks=[]; manifest=[]
    fresh=list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=SEED).split(np.zeros(len(y)),y))
    protected=[Path(__file__),Path(C.__file__),Path(PT.__file__),Path(H.__file__),Path(H.LH.__file__),
               C.DATA/"cohort.parquet",C.DATA/"dynamic_bytask.parquet",C.DATA/"static_bytask.parquet",
               H.LH.OUT,demo_path,PREVIOUS/"local_only/input_payload.joblib",
               PREVIOUS/"FROZEN_SPEC.json",C.ANALYSIS/"src/pdci_fully_nested_20260911.py"]
    for oi,((tr,te),(tr2,te2)) in enumerate(zip(splits,fresh)):
        assert np.array_equal(tr,tr2) and np.array_equal(te,te2)
        # The fresh splitter must match the prepared payload above; historical
        # exploratory fold files are not a prerequisite of the release copy.
        assert set(tr).isdisjoint(te)
        fold_checks.append(dict(outer_fold=oi,matched_prepared_partitions=True,
            historical_fold_files_checked=False,train_n=len(tr),test_n=len(te),
            train_class_counts=np.bincount(y[tr],minlength=3).tolist(),
            test_class_counts=np.bincount(y[te],minlength=3).tolist()))
        manifest.append(dict(outer_fold=oi,train=tr.tolist(),test=te.tolist()))
    payload=dict(ids=ids.to_numpy(str),y=y,matrices=matrices,
                 base_off=base_off,base_on=base_on,harm_off=harm_off,harm_on=harm_on,
                 asc=asc.to_numpy(np.float32),splits=splits)
    joblib.dump(payload,LOCAL/"input_payload.joblib",compress=3)
    json_write(LOCAL/"split_manifest.json",dict(ids=ids.tolist(),splits=manifest))
    (OUT/"ANALYSIS_PLAN.md").write_text(PLAN,encoding="utf-8")
    json_write(OUT/"candidate_grid.json",dict(screen=SCREEN,stage2=STAGE2,
                                               secondary_threeclass=SECONDARY,baseline=BASELINES))
    schemas["screen_base_off"]=original_schema["individual"][:-18]
    schemas["screen_base_on"]=schemas["screen_base_off"]+list(base_extra.columns)
    schemas["screen_harmonic_off"]=original_schema["screen_harmonic"]
    schemas["screen_harmonic_on"]=schemas["screen_harmonic_off"]+list(harmonic_timing.columns)
    schemas["demographic_baseline"]=list(asc.columns)
    json_write(OUT/"feature_schemas.json",schemas)
    json_write(OUT/"INPUT_AUDIT.json",dict(status="PASS",n=750,class_counts=[598,90,62],
        general_tasks=PT.GENERAL_TASKS,demographic_columns=list(asc.columns),demographic_width=3,
        no_timing_in_demographic_block=True,no_presence_or_recording_count_features=True,
        raw_widths={k:v.shape[1] for k,v in matrices.items()},preserved_nontiming=preservation,
        screen_feature_widths={"base_off":base_off.shape[1],"base_on":base_on.shape[1],
                              "harmonic_off":harm_off.shape[1],"harmonic_on":harm_on.shape[1]},
        restored_dynamic_timing_descriptors=list(TIMING_DYNAMIC),
        restored_harmonic_timing_descriptors=["lin_n_frames"],
        removed_exact_aliases={"ltas_dur_s":"ltas_n_frames/50","lin_dur_s":"lin_n_frames/50"},
        duplicate_timing_formula_cache_checks_pass=True,existing_prosody_duplicate_still_excluded=True,
        old_harmonic_geometry_bitwise_unchanged=True,explicit_duration_feature_names=list(durations.columns),
        corrected_demographics_bitwise_unchanged=True,fold_checks=fold_checks,
        canonical_demographic_join=original_audit["canonical_demographic_join"],
        residence_country_by_class=original_audit["residence_country_by_class"]))
    # Preserve prepared analysis inputs and receipts; live logs are excluded.
    protected.extend(p for p in PREVIOUS.glob("*") if p.is_file()
                     and p.suffix not in {".log"} and p.name!="RUN_STATUS.json")
    protected.extend([OUT/"ANALYSIS_PLAN.md",OUT/"candidate_grid.json",OUT/"feature_schemas.json",
                      OUT/"INPUT_AUDIT.json",LOCAL/"input_payload.joblib",LOCAL/"split_manifest.json"])
    hashes={str(p.resolve()):digest(p) for p in protected}
    json_write(OUT/"FROZEN_SPEC.json",dict(created_utc=stamp(),seed=SEED,source_sha256=digest(Path(__file__)),
        user_amended_after_prior_results=True,screen_candidates=len(SCREEN),stage2_candidates=len(STAGE2),
        secondary_candidates=len(SECONDARY),baseline_candidates=len(BASELINES),primary_BH_family_size=3,
        protected_sha256=hashes))
    print("PREPARED AND FROZEN",len(SCREEN),len(STAGE2),len(SECONDARY),flush=True)


def verify_frozen():
    spec = json.loads((OUT / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    wrong = [p for p, value in spec["protected_sha256"].items() if digest(Path(p)) != value]
    if wrong:
        raise RuntimeError(f"frozen source/input changed: {wrong}")
    return spec


def fit_fold(oi):
    checkpoint = FOLDS / f"fold_{oi:02d}.parquet"
    receipt = FOLDS / f"fold_{oi:02d}.json"
    if checkpoint.exists() and receipt.exists():
        saved = json.loads(receipt.read_text(encoding="utf-8"))
        assert digest(checkpoint) == saved["prediction_sha256"]
        return saved
    started = time.time()
    data = joblib.load(LOCAL / "input_payload.joblib")
    y, matrices = data["y"], data["matrices"]
    tr, te = data["splits"][oi]
    inner = list(StratifiedKFold(3, shuffle=True, random_state=SEED + oi*1009).split(np.zeros(len(tr)), y[tr]))
    banks = {"screen": {ident(c): np.zeros(len(tr)) for c in SCREEN},
             "stage2": {ident(c): np.full(len(tr), np.nan) for c in STAGE2},
             "secondary": {ident(c): np.zeros(len(tr)) for c in SECONDARY}}
    for baseline in BASELINE_KEYS:
        banks[f"{baseline}_screen"] = {ident(c): np.zeros(len(tr)) for c in BASELINES}
        banks[f"{baseline}_stage2"] = {ident(c): np.full(len(tr), np.nan) for c in BASELINES}
    trace = []
    with threadpool_limits(1), warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for inner_i, (it, iv) in enumerate(inner):
            train, valid = tr[it], tr[iv]
            case_train = train[y[train] > 0]
            case_valid_local = iv[y[valid] > 0]
            case_valid = tr[case_valid_local]
            got = screen_bank(data, train, valid, SCREEN)
            for name, value in got.items(): banks["screen"][name][iv] = value
            got = stage2_bank(matrices, case_train, case_valid, (y[case_train] == 1).astype(int), STAGE2)
            for name, value in got.items(): banks["stage2"][name][case_valid_local] = value
            got = stage2_bank(matrices, train, valid, y[train], SECONDARY, nclasses=3)
            for name, value in got.items(): banks["secondary"][name][iv] = value
            for baseline in BASELINE_KEYS:
                got = baseline_bank(data[baseline], train, valid, (y[train] > 0).astype(int), BASELINES)
                for name,value in got.items(): banks[f"{baseline}_screen"][name][iv] = value
                got = baseline_bank(data[baseline], case_train, case_valid, (y[case_train] == 1).astype(int), BASELINES)
                for name,value in got.items(): banks[f"{baseline}_stage2"][name][case_valid_local] = value
            trace.append(dict(inner_fold=inner_i, train_n=len(train), valid_n=len(valid),
                              train_cases=len(case_train), valid_cases=len(case_valid),
                              disjoint=bool(set(train).isdisjoint(valid) and set(train).isdisjoint(te))))
            print(f"fold{oi:02d} inner{inner_i} complete {time.time()-started:.1f}s", flush=True)
        case = y[tr] > 0
        choices, inner_scores, inner_selected = {}, {}, {}
        for name, bank in banks.items():
            cfgs = SCREEN if name == "screen" else STAGE2 if name == "stage2" else SECONDARY if name == "secondary" else BASELINES
            selection_case = (name == "stage2" or name == "secondary" or name.endswith("_stage2"))
            target = (y[tr][case] == 1).astype(int) if selection_case else (y[tr] > 0).astype(int)
            used = {k: v[case] for k,v in bank.items()} if selection_case else bank
            assert all(np.isfinite(v).all() for v in used.values())
            selected, scores = choose(target, used, cfgs)
            choices[name], inner_scores[name] = selected, scores
            inner_selected[name] = bank[ident(selected)]
        case_train = tr[y[tr] > 0]
        s = screen_bank(data, tr, te, [choices["screen"]])[ident(choices["screen"])]
        q = stage2_bank(matrices, case_train, te, (y[case_train] == 1).astype(int), [choices["stage2"]])[ident(choices["stage2"])]
        qs = stage2_bank(matrices, tr, te, y[tr], [choices["secondary"]], nclasses=3)[ident(choices["secondary"])]
        pred = pd.DataFrame(dict(participant_id=data["ids"][te], y_true=y[te], repeat=oi//5, fold=oi%5))
        scores_out = {"primary": (s,q), "secondary_threeclass": (s,qs)}
        for baseline in BASELINE_KEYS:
            bs = baseline_bank(data[baseline], tr, te, (y[tr] > 0).astype(int), [choices[f"{baseline}_screen"]])[ident(choices[f"{baseline}_screen"])]
            bq = baseline_bank(data[baseline], case_train, te, (y[case_train] == 1).astype(int), [choices[f"{baseline}_stage2"]])[ident(choices[f"{baseline}_stage2"])]
            scores_out[BASELINE_KEYS[baseline]] = (bs,bq)
        operating = {}
        for name,(ss,qq) in scores_out.items():
            pred[f"{name}_screen"], pred[f"{name}_q"] = ss, qq
            pp = compose(ss,qq)
            for cls in range(3): pred[f"{name}_p{cls}"] = pp[:,cls]
            key = "screen" if name in ("primary","secondary_threeclass") else next(k for k,v in BASELINE_KEYS.items() if v==name)+"_screen"
            thresholds = {"default": .5, "sens90": threshold(y[tr]>0,inner_selected[key],.90),
                          "sens95": threshold(y[tr]>0,inner_selected[key],.95)}
            operating[name] = thresholds
            for gate,tv in thresholds.items():
                pred[f"{name}_call_{gate}"] = np.where(ss < tv,0,np.where(qq >= .5,1,2))
        for name in scores_out:
            assert np.isfinite(pred[[f"{name}_p{i}" for i in range(3)]]).all().all()
            assert np.allclose(pred[[f"{name}_p{i}" for i in range(3)]].sum(axis=1),1)
        pred.to_parquet(checkpoint, index=False)
        inner_frame = pd.DataFrame(dict(participant_id=data["ids"][tr], y_true=y[tr], **inner_selected))
        inner_frame.to_parquet(FOLDS / f"fold_{oi:02d}_selected_inner.parquet", index=False)
        rec = dict(status="COMPLETE", outer_fold=oi, repeat=oi//5, fold=oi%5,
                   train_n=len(tr), test_n=len(te), train_cases=len(case_train),
                   test_cases=int((y[te]>0).sum()), inner_partition_audit=trace, choices=choices,
                   inner_scores=inner_scores, thresholds=operating,
                   warning_count=len(caught), warning_examples=sorted({str(w.message) for w in caught})[:15],
                   elapsed_seconds=round(time.time()-started,2), prediction_sha256=digest(checkpoint), completed_utc=stamp())
        json_write(receipt,rec)
    print(f"fold{oi:02d} COMPLETE {time.time()-started:.1f}s", flush=True)
    return rec


def metrics(y, s, q, p):
    case = y>0
    return dict(screen=roc_auc_score(case,s), stage2=roc_auc_score(y[case]==1,q[case]),
                macro=roc_auc_score(y,p,multi_class="ovr",average="macro"),
                pd_vs_all=roc_auc_score(y==1,p[:,1]), ci_vs_all=roc_auc_score(y==2,p[:,2]))


def weighted_auc_factory(y, p):
    order = np.argsort(p,kind="stable")
    sorted_p = p[order]
    starts = np.r_[0, np.flatnonzero(np.diff(sorted_p))+1]
    positive = np.asarray(y,dtype=bool)[order]
    def score(w):
        ww = w[order]
        pos = np.add.reduceat(ww*positive,starts)
        neg = np.add.reduceat(ww*(~positive),starts)
        return float(np.dot(pos,np.cumsum(neg)-.5*neg)/(pos.sum()*neg.sum()))
    return score


def bh(p):
    p=np.asarray(p,float); order=np.argsort(p); n=len(p)
    adjusted=np.minimum.accumulate((p[order]*n/np.arange(1,n+1))[::-1])[::-1]
    answer=np.empty(n); answer[order]=np.minimum(1,adjusted)
    return answer


def table(frame,digits=4):
    def text_cell(value):
        return f"{value:.{digits}f}" if isinstance(value,(float,np.floating)) else str(value)
    return "\n".join(["| "+" | ".join(frame.columns)+" |", "| "+" | ".join(["---"]*len(frame.columns))+" |"]+
                     ["| "+" | ".join(text_cell(v) for v in row)+" |" for row in frame.itertuples(index=False,name=None)])


def report():
    verify_frozen()
    payload=joblib.load(LOCAL/"input_payload.joblib")
    yall=payload["y"]
    chunks=[]; records=[]
    for oi in range(15):
        fp=FOLDS/f"fold_{oi:02d}.parquet"; rp=fp.with_suffix(".json")
        rec=json.loads(rp.read_text(encoding="utf-8")); assert rec["status"]=="COMPLETE"
        assert digest(fp)==rec["prediction_sha256"]
        d=pd.read_parquet(fp); tr,te=payload["splits"][oi]
        assert d.participant_id.tolist()==payload["ids"][te].tolist()
        assert d.y_true.tolist()==yall[te].tolist()
        assert all(row["disjoint"] for row in rec["inner_partition_audit"])
        for name,thresholds in rec["thresholds"].items():
            inner=pd.read_parquet(FOLDS/f"fold_{oi:02d}_selected_inner.parquet")
            key="screen" if name in ("primary","secondary_threeclass") else next(k for k,v in BASELINE_KEYS.items() if v==name)+"_screen"
            for gate,target in (("sens90",.9),("sens95",.95)):
                assert abs(threshold(inner.y_true.to_numpy()>0,inner[key].to_numpy(),target)-thresholds[gate])<1e-12
        records.append(rec); chunks.append(d)
    raw=pd.concat(chunks,ignore_index=True)
    assert len(raw)==2250 and raw.groupby("participant_id").size().eq(3).all()
    assert not raw.duplicated(["participant_id","repeat"]).any()
    models=("primary","agesexcountry","secondary_threeclass")
    numeric=[c for c in raw if c.endswith(("_screen","_q","_p0","_p1","_p2"))]
    pooled=raw.groupby("participant_id").agg({"y_true":"first",**{c:"mean" for c in numeric}}).reindex(payload["ids"])
    pooled.to_parquet(LOCAL/"participant_oof_predictions.parquet")
    raw.to_parquet(LOCAL/"all_fold_predictions.parquet",index=False)
    yy=pooled.y_true.to_numpy(int)
    point={}; rows=[]; repeat_rows=[]; fold_rows=[]
    for name in models:
        point[name]=metrics(yy,pooled[f"{name}_screen"].to_numpy(),pooled[f"{name}_q"].to_numpy(),pooled[[f"{name}_p{i}" for i in range(3)]].to_numpy())
        rows.append(dict(model=name,n=750,n_PD=90,n_cognitive_impairment=62,**point[name]))
        for repeat,g in raw.groupby("repeat"):
            repeat_rows.append(dict(model=name,repeat=int(repeat),**metrics(g.y_true.to_numpy(),g[f"{name}_screen"].to_numpy(),g[f"{name}_q"].to_numpy(),g[[f"{name}_p{i}" for i in range(3)]].to_numpy())))
        for (repeat,fold),g in raw.groupby(["repeat","fold"]):
            fold_rows.append(dict(model=name,repeat=int(repeat),fold=int(fold),**metrics(g.y_true.to_numpy(),g[f"{name}_screen"].to_numpy(),g[f"{name}_q"].to_numpy(),g[[f"{name}_p{i}" for i in range(3)]].to_numpy())))
    metric_frame=pd.DataFrame(rows); repeat_frame=pd.DataFrame(repeat_rows); fold_frame=pd.DataFrame(fold_rows)
    metric_frame.to_csv(OUT/"pooled_oof_metrics.csv",index=False)
    repeat_frame.to_csv(OUT/"repeat_metrics.csv",index=False); fold_frame.to_csv(OUT/"fold_metrics.csv",index=False)
    # One paired, class-stratified participant draw is shared by every endpoint/model.
    score_funcs={}
    for name in models:
        score_funcs[(name,"screen")]=[weighted_auc_factory(yy>0,pooled[f"{name}_screen"].to_numpy())]
        case=yy>0
        basefun=weighted_auc_factory(yy[case]==1,pooled.loc[case,f"{name}_q"].to_numpy())
        score_funcs[(name,"stage2")]=[lambda w,f=basefun,mask=case: f(w[mask])]
        score_funcs[(name,"macro")]=[weighted_auc_factory(yy==cls,pooled[f"{name}_p{cls}"].to_numpy()) for cls in range(3)]
    boot={key:np.zeros(5000) for key in score_funcs}
    rng=np.random.default_rng(SEED+9911); classes=[np.flatnonzero(yy==cls) for cls in range(3)]
    for b in range(5000):
        w=np.zeros(len(yy))
        for ix in classes: w[ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)))
        for key,funcs in score_funcs.items(): boot[key][b]=np.mean([f(w) for f in funcs])
    intervals=[]; comparisons=[]
    for (name,endpoint),values in boot.items():
        lo,hi=np.quantile(values,[.025,.975])
        intervals.append(dict(model=name,endpoint=endpoint,auc=point[name][endpoint],ci_low=lo,ci_high=hi,n_boot=5000))
    for endpoint in ("screen","stage2","macro"):
        for base in BASELINE_KEYS.values():
            delta=boot[("primary",endpoint)]-boot[(base,endpoint)]
            lo,hi=np.quantile(delta,[.025,.975])
            a=fold_frame[fold_frame.model=="primary"].sort_values(["repeat","fold"])[endpoint].to_numpy()
            b=fold_frame[fold_frame.model==base].sort_values(["repeat","fold"])[endpoint].to_numpy()
            fold_delta=a-b
            ratios=[r["test_cases"]/r["train_cases"] if endpoint=="stage2" else r["test_n"]/r["train_n"] for r in records]
            se=math.sqrt((1/15+np.mean(ratios))*np.var(fold_delta,ddof=1))
            mean=float(np.mean(fold_delta)); p=float(2*student_t.sf(abs(mean/se),14)) if se>0 else (0. if mean else 1.)
            cvlo,cvhi=mean-student_t.ppf(.975,14)*se,mean+student_t.ppf(.975,14)*se
            comparisons.append(dict(candidate="primary",baseline=base,endpoint=endpoint,
                candidate_auc=point["primary"][endpoint],baseline_auc=point[base][endpoint],
                pooled_oof_gain=point["primary"][endpoint]-point[base][endpoint],bootstrap95_low=lo,bootstrap95_high=hi,
                nominal_bootstrap_positive=bool(lo>0),mean_fold_gain=mean,corrected_cv95_low=cvlo,corrected_cv95_high=cvhi,
                corrected_cv_p=p,corrected_cv_se=se,n_folds=15,n_boot=5000))
    comparison_frame=pd.DataFrame(comparisons)
    comparison_frame["corrected_cv_q_BH3"]=bh(comparison_frame.corrected_cv_p)
    comparison_frame.to_csv(OUT/"primary_baseline_comparisons.csv",index=False)
    interval_frame=pd.DataFrame(intervals); interval_frame.to_csv(OUT/"auc_intervals.csv",index=False)
    # Calls are generated using that participant's own outer-training threshold.
    cms=[]; ops=[]
    def append_calls(name,gate,scope,gy,pred):
        cm=confusion_matrix(gy,pred,labels=[0,1,2]); cases=gy>0; called=pred>0
        tp=int((called&cases).sum()); fp=int((called&~cases).sum()); tn=int((~called&~cases).sum()); fn=int((~called&cases).sum())
        ops.append(dict(model=name,gate=gate,scope=scope,n=len(gy),sensitivity=tp/(tp+fn),specificity=tn/(tn+fp),
                        ppv=tp/(tp+fp) if tp+fp else np.nan,npv=tn/(tn+fn) if tn+fn else np.nan,
                        balanced_accuracy=balanced_accuracy_score(gy,pred),PD_recall=cm[1,1]/cm[1].sum(),
                        cognitive_impairment_recall=cm[2,2]/cm[2].sum(),screen_positive=int(called.sum())))
        for true in range(3):
            for predicted in range(3): cms.append(dict(model=name,gate=gate,scope=scope,true_class=NAMES[true],predicted_class=NAMES[predicted],n=int(cm[true,predicted])))
    for name in models:
        for gate in ("default","sens90","sens95"):
            column=f"{name}_call_{gate}"
            calls=raw.pivot(index="participant_id",columns="repeat",values=column).reindex(pooled.index).to_numpy(int)
            counts=np.column_stack([(calls==cls).sum(axis=1) for cls in range(3)])
            append_calls(name,gate,"participant_majority",yy,np.argmax(counts,axis=1))
            for repeat,g in raw.groupby("repeat"): append_calls(name,gate,f"repeat_{repeat}",g.y_true.to_numpy(),g[column].to_numpy(int))
    pd.DataFrame(cms).to_csv(OUT/"confusion_matrices.csv",index=False)
    op_frame=pd.DataFrame(ops); op_frame.to_csv(OUT/"operating_points.csv",index=False)
    selected=[]
    for r in records:
        for procedure,cfg in r["choices"].items():
            selected.append(dict(repeat=r["repeat"],fold=r["fold"],procedure=procedure,candidate=ident(cfg),inner_auc=r["inner_scores"][procedure][ident(cfg)]))
    selected_frame=pd.DataFrame(selected); selected_frame.to_csv(OUT/"fold_selections.csv",index=False)
    selected_frame.groupby(["procedure","candidate"]).size().rename("fold_count").reset_index().to_csv(OUT/"selection_counts.csv",index=False)
    thresholds=[]
    for r in records:
        for name,values in r["thresholds"].items(): thresholds.append(dict(repeat=r["repeat"],fold=r["fold"],model=name,**values))
    pd.DataFrame(thresholds).to_csv(OUT/"training_only_thresholds.csv",index=False)
    # Numerical and provenance audit. Equal-score paired gain must be exactly zero.
    for name in models:
        for endpoint in ("screen","stage2","macro"):
            expected=point[name][endpoint]
            observed=np.mean([f(np.ones(len(yy))) for f in score_funcs[(name,endpoint)]])
            assert abs(expected-observed)<1e-12
    assert (np.bincount(yy)==[598,90,62]).all()
    verify_frozen()
    assert len(comparison_frame)==3 and comparison_frame.baseline.eq("agesexcountry").all()
    audit=dict(status="PASS",created_utc=stamp(),outer_folds=15,participants=750,cases=152,
               exact_historical_outer_membership=True,all_task_presence_constant=True,
               all_data_derived_preprocessing_inner_fitted=True,dedicated_stage2_case_training_only=True,
               primary_q_averaged_separately=True,composition_before_repeat_averaging=True,
               participant_bootstrap_draws=5000,all_thresholds_reconstructed_from_own_training_oof=True,
               weighted_auc_matches_sklearn=True,protected_source_inputs_unchanged=True,
               baseline_age_sex_country_only=True,timing_selected_inside_inner_CV=True,
               duration_not_in_demographic_block=True,fresh_BH_family_size=3,
               prior_analysis_inputs_unchanged=True,
               warning_count=sum(r["warning_count"] for r in records),
               total_fold_seconds=sum(r["elapsed_seconds"] for r in records))
    json_write(OUT/"AUDIT.json",audit)
    report_text=["# User-amended demographic-baseline PD/cognitive-impairment study", "",f"Completed {stamp()}. Audit PASS. 750 people: 598 neither, 90 PD, 62 cognitive impairment.","",
        "The only baseline uses corrected age, sex and residence country. Duration and actual frame-count variables are optional candidate FEATURES, not covariates: a timing-on/off flag is selected entirely within inner CV for each stage. Exact duration/frame aliases were removed, while all original nontiming acoustic values and harmonic geometry were preserved bit-for-bit. Both stages were freshly fitted after the user amended the preceding analysis; the previous BH9 study and manuscript are unchanged. The same 15 outer partitions, 750 people and labels were retained. This is amended nested internal evaluation, not independent external validation.","",
        "## Participant-level held-out performance", "",table(interval_frame),"",
        "## Three paired primary comparisons", "",table(comparison_frame[["baseline","endpoint","candidate_auc","baseline_auc","pooled_oof_gain","bootstrap95_low","bootstrap95_high","mean_fold_gain","corrected_cv_p","corrected_cv_q_BH3"]]),"",
        "Bootstrap intervals are conditional 5000-resample paired participant intervals, not retraining or multiplicity-adjusted intervals. Corrected-CV q-values form a separate approximate repeated-CV sensitivity with new BH3; mean-fold and pooled-OOF gains are distinct estimands. Comparisons evaluate acoustic/timing predictive procedures versus tuned-ridge age/sex/country, not architecture-independent or causal feature effects. The old BH9 values were not recalculated.","",
        "## Training-only screening gates; participant-majority calls", "",table(op_frame[(op_frame.model=="primary")&(op_frame.scope=="participant_majority")]),"",
        "Rows in confusion_matrices.csv are true classes; columns are predicted classes. Separate matrices and operating points are provided for each repeat. The90/95% labels specify training sensitivity targets, not guarantees of achieved test sensitivity. Every stage2 decision usedq>=.5. All publication-facing files are aggregate and contain no participant IDs; individual predictions and exact partitions are local_only.","",
        "## Repeat-level stability", "",table(repeat_frame),"",
        "The secondary_threeclass discriminator was prespecified for this amendment, used only the individual dynamic representation, and selected 16 PCA/head/timing candidates on a conditional case objective while training all three classes. It is not substituted for the primary result. See ANALYSIS_PLAN.md, candidate_grid.json, fold_selections.csv, training_only_thresholds.csv and AUDIT.json for full specifications and provenance.",""]
    (OUT/"REPORT.md").write_text("\n".join(report_text),encoding="utf-8")
    # Live logs are not scientific outputs and may gain a final completion line.
    outputs={str(p.relative_to(OUT)):digest(p) for p in OUT.glob("*") if p.is_file() and p.suffix!=".log" and p.name not in {"COMPLETION.json","RUN_STATUS.json"}}
    json_write(OUT/"COMPLETION.json",dict(status="COMPLETE",completed_utc=stamp(),audit="PASS",outputs_sha256=outputs))
    print("FINALIZATION COMPLETE",flush=True)


def selftest():
    rng=np.random.default_rng(SEED)
    y=np.repeat([0,1,2],15); n=len(y)
    x=rng.normal(size=(n,125)); x[:5,0]=np.nan; x[:,1]=np.nan; x[:,2]=1
    extra=rng.normal(size=(n,5))
    matrices={f"{space}__timing_{timing}":x if timing=="off" else np.column_stack([x,extra])
              for space in SPACES for timing in ("off","on")}
    data=dict(y=y,base_off=x,base_on=np.column_stack([x,extra]),
              harm_off=x[:,:90],harm_on=np.column_stack([x[:,:90],extra]),
              asc=x[:,3:6],matrices=matrices)
    tr=np.r_[0:10,15:25,30:40]; te=np.setdiff1d(np.arange(n),tr)
    with threadpool_limits(1),warnings.catch_warnings():
        warnings.simplefilter("ignore")
        got=screen_bank(data,tr,te,SCREEN); assert len(got)==96
        case=tr[y[tr]>0]
        got2=stage2_bank(matrices,case,te,(y[case]==1).astype(int),STAGE2); assert len(got2)==160
        got3=stage2_bank(matrices,tr,te,y[tr],SECONDARY,3); assert len(got3)==16
        assert all(np.isfinite(v).all() for v in [*got.values(),*got2.values(),*got3.values()])
        for timing in ("off","on"):
            selected=[next(c for c in SCREEN if c["timing"]==timing)]
            alone=screen_bank(data,tr,te,selected)
            assert np.allclose(alone[ident(selected[0])],got[ident(selected[0])],rtol=0,atol=1e-12)
        # Rank above100: single-candidate refits preserve the shared basis
        # and explicitly choose the same timing-specific matrix.
        large=rng.normal(size=(180,125)); labels=np.repeat([0,1],90)
        ltr=np.r_[0:80,90:170]; lte=np.setdiff1d(np.arange(180),ltr)
        large_matrices={"mean__timing_off":large,
                        "mean__timing_on":np.column_stack([large,rng.normal(size=(180,8))])}
        configs=[dict(space="mean",family=family,k=k,c=c,timing=timing)
                 for family,k,c in (("pca_ridge",10,.1),("pca_lda",100,0.))
                 for timing in ("off","on")]
        bank=stage2_bank(large_matrices,ltr,lte,labels[ltr],configs)
        for timing in ("off","on"):
            chosen=[c for c in configs if c["family"]=="pca_ridge" and c["timing"]==timing]
            alone=stage2_bank(large_matrices,ltr,lte,labels[ltr],chosen)
            assert np.allclose(bank[ident(chosen[0])],alone[ident(chosen[0])],rtol=0,atol=1e-12)
        # In a tied inner score, timing-off is preferred by the declared rule.
        tied={ident(c):np.linspace(.1,.9,20) for c in configs[:2]}
        picked,_=choose(np.repeat([0,1],10),tied,configs[:2])
        assert picked["timing"]=="off"
        assert data["asc"].shape[1]==3
        assert np.allclose(compose(np.array([.2,.8]),np.array([.3,.7])).sum(axis=1),1)
        p=np.round(rng.uniform(size=n),1); f=weighted_auc_factory(y==1,p)
        assert abs(f(np.ones(n))-roc_auc_score(y==1,p))<1e-12
        assert np.allclose(bh([.01,.02,.5]),[.03,.03,.5])
    print("SYNTHETIC SELFTEST PASS",flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=["selftest","prepare","run","report"])
    parser.add_argument("--jobs",type=int,default=2)
    args=parser.parse_args()
    if args.command=="selftest": return selftest()
    if args.command=="prepare": return prepare()
    if args.command=="report": return report()
    verify_frozen()
    import msvcrt
    run_lock = open(LOCAL / "RUN.lock", "a+b")
    if run_lock.tell() == 0:
        run_lock.write(b"0")
        run_lock.flush()
    run_lock.seek(0)
    try:
        msvcrt.locking(run_lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise RuntimeError("another worker already holds this analysis run lock")
    pending=[oi for oi in range(15) if not (FOLDS/f"fold_{oi:02d}.json").exists()]
    json_write(OUT/"RUN_STATUS.json",dict(status="RUNNING",started_utc=stamp(),pending=len(pending)))
    print(f"RUN {len(pending)} folds; workers={args.jobs}",flush=True)
    try:
        results=joblib.Parallel(n_jobs=args.jobs,backend="loky",verbose=10)(joblib.delayed(fit_fold)(oi) for oi in pending)
        report()
        json_write(OUT/"RUN_STATUS.json",dict(status="COMPLETE",completed_utc=stamp()))
    except Exception as exc:
        json_write(OUT/"RUN_STATUS.json",dict(status="FAILED",time_utc=stamp(),error=str(exc),traceback=traceback.format_exc()))
        raise
    finally:
        run_lock.seek(0)
        msvcrt.locking(run_lock.fileno(), msvcrt.LK_UNLCK, 1)
        run_lock.close()


if __name__=="__main__":
    main()
