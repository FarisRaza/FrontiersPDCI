"""Expanded PCA/shrinkage refinement for the PD-versus-CI discriminator.

The starting anchor is the fixed general-task per-task-dynamic PCA-50 plus
Ledoit-Wolf-style shrinkage LDA model (AUC 0.832 in the prior matched run).
This script keeps the representation, participants, and outer folds fixed and
tests additional regularisation/dimensional-reduction strategies:

* ordinary and whitened global PCA with several covariance estimators/heads;
* covariate-residualised acoustic PCA;
* PD-vs-CI case-filtered features followed by PCA (selection remains nested);
* task-, modality-, and task-by-modality blockwise PCA;
* supervised partial least squares components;
* OAS/Ledoit-Wolf/fixed LDA shrinkage, ridge/elastic logistic regression,
  regularised QDA, and diagonal Gaussian heads.

Every supervised operation and every choice is fitted inside outer training
folds.  The abundant neither class remains in training; scoring is the relative
PD-versus-CI preference among held-out neurological cases.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.covariance import LedoitWolf, OAS
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import (LinearDiscriminantAnalysis,
                                            QuadraticDiscriminantAnalysis)
from sklearn.feature_selection import f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_to_baseline as CB  # noqa: E402
import config as C  # noqa: E402
import modeling  # noqa: E402
import pdci_exhaustive as E  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")

OUT = C.RESULTS / "pdci_pca_shrinkage"
FOLDS = OUT / "folds"
OUT.mkdir(parents=True, exist_ok=True)
FOLDS.mkdir(parents=True, exist_ok=True)
SEED = C.RANDOM_STATE

GLOBAL_DIMS = [10, 15, 20, 25, 30, 40, 50, 60, 75, 100, 125, 150, 200]
RESID_DIMS = [20, 30, 40, 50, 60, 75, 100]
FILTER_TOP = [250, 500, 1000, 2000]
FILTER_DIMS = [20, 30, 40, 50, 60, 75]
TASK_DIMS = [2, 3, 5, 8, 12]
MODALITY_DIMS = [5, 10, 15, 20, 30, 40]
TASKMOD_DIMS = [1, 2, 3, 4]
PLS_DIMS = [2, 3, 5, 8, 12, 20]
FAMILIES = ["global_pca", "residual_pca", "casefilter_pca",
            "task_block_pca", "modality_block_pca", "taskmod_block_pca",
            "pls"]

COMPACT_HEADS = ["lda_auto", "lda_oas", "lda_lw",
                 "ridge_scaled_C0.03", "ridge_scaled_C0.1",
                 "ridge_scaled_C0.3"]
GLOBAL_HEADS = [
    "lda_auto", "lda_oas", "lda_lw",
    *[f"lda_fixed_{s}" for s in (0.1, 0.3, 0.5, 0.7, 0.9)],
    *[f"ridge_scaled_C{c}" for c in (0.003, 0.01, 0.03, 0.1, 0.3, 1.0)],
    *[f"ridge_raw_C{c}" for c in (0.01, 0.03, 0.1, 0.3)],
    "elastic_C0.1_r0.2", "elastic_C0.1_r0.5", "elastic_C0.3_r0.5",
    *[f"qda_{r}" for r in (0.5, 0.75, 0.9, 0.97)],
    *[f"gnb_{v}" for v in (0.001, 0.01, 0.1)],
]


@lru_cache(maxsize=1)
def data():
    ids = PT.ids_for_design("general")
    y = PT.labels(ids, "multiclass").to_numpy(int)
    x = PT.build_X("general", "per_task_dynamic").reindex(ids)
    audio = [c for c in x if c.startswith("task__")]
    cov = [c for c in x if c not in audio]
    return ids, y, x, audio, cov


def conditional_auc(y, p):
    case = y > 0
    q = p[case, 1] / np.maximum(1e-12, p[case, 1] + p[case, 2])
    return roc_auc_score((y[case] == 1).astype(int), q)


def aligned(est, x):
    raw = est.predict_proba(x)
    out = np.zeros((len(x), 3), float)
    for j, cls in enumerate(est.classes_):
        out[:, int(cls)] = raw[:, j]
    return out / np.maximum(out.sum(axis=1, keepdims=True), 1e-12)


def make_head(name, seed):
    if name == "lda_auto":
        return LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    if name == "lda_oas":
        return LinearDiscriminantAnalysis(solver="lsqr",
                                          covariance_estimator=OAS())
    if name == "lda_lw":
        return LinearDiscriminantAnalysis(solver="lsqr",
                                          covariance_estimator=LedoitWolf())
    if name.startswith("lda_fixed_"):
        return LinearDiscriminantAnalysis(
            solver="lsqr", shrinkage=float(name.removeprefix("lda_fixed_")))
    if name.startswith("ridge_"):
        scaled = name.startswith("ridge_scaled_")
        c = float(name.rsplit("C", 1)[1])
        clf = LogisticRegression(C=c, penalty="l2", solver="lbfgs",
                                 class_weight="balanced", max_iter=5000,
                                 random_state=seed)
        return make_pipeline(StandardScaler(), clf) if scaled else clf
    if name.startswith("elastic_"):
        _, cs, rs = name.split("_")
        clf = LogisticRegression(
            C=float(cs.removeprefix("C")), penalty="elasticnet",
            l1_ratio=float(rs.removeprefix("r")), solver="saga",
            class_weight="balanced", max_iter=5000, tol=1e-4,
            random_state=seed,
        )
        return make_pipeline(StandardScaler(), clf)
    if name.startswith("qda_"):
        return QuadraticDiscriminantAnalysis(
            reg_param=float(name.removeprefix("qda_")))
    if name.startswith("gnb_"):
        return GaussianNB(var_smoothing=float(name.removeprefix("gnb_")))
    raise ValueError(name)


def fit_head(ztr, zva, ytr, name, seed):
    est = make_head(name, seed)
    est.fit(ztr, ytr)
    return aligned(est, zva)


def whiten(ztr, zva, variance):
    scale = np.sqrt(np.maximum(np.asarray(variance, float), 1e-10))
    return ztr / scale, zva / scale


def pca_bank(atr, ava, dims, seed):
    max_k = min(max(dims), len(atr) - 3, atr.shape[1])
    pca = PCA(n_components=max_k, svd_solver="randomized", iterated_power=4,
              random_state=seed)
    ztr = pca.fit_transform(atr)
    zva = pca.transform(ava)
    for k0 in dims:
        k = min(k0, max_k)
        if k < 1:
            continue
        yield k0, False, ztr[:, :k], zva[:, :k]
        a, b = whiten(ztr[:, :k], zva[:, :k], pca.explained_variance_[:k])
        yield k0, True, a, b


def group_indices(columns):
    task, modality, taskmod = {}, {}, {}
    for i, col in enumerate(columns):
        parts = col.split("__")
        if len(parts) < 4:
            continue
        t = parts[1]
        m = parts[3].split("_", 1)[0]
        task.setdefault(t, []).append(i)
        modality.setdefault(m, []).append(i)
        taskmod.setdefault(f"{t}|{m}", []).append(i)
    return task, modality, taskmod


def block_pca_bank(atr, ava, groups, dims, seed):
    maximum = max(dims)
    blocks = []
    for gi, (_, ix) in enumerate(sorted(groups.items())):
        k = min(maximum, len(atr) - 3, len(ix))
        if k < 1:
            continue
        pca = PCA(n_components=k, svd_solver="randomized", iterated_power=3,
                  random_state=seed + gi * 37)
        a = pca.fit_transform(atr[:, ix])
        b = pca.transform(ava[:, ix])
        blocks.append((a, b, pca.explained_variance_))
    for k0 in dims:
        for white in (False, True):
            aa, bb = [], []
            for a, b, ev in blocks:
                k = min(k0, a.shape[1])
                x, z = (a[:, :k], b[:, :k])
                if white:
                    x, z = whiten(x, z, ev[:k])
                aa.append(x); bb.append(z)
            yield k0, white, np.column_stack(aa), np.column_stack(bb)


def append_cov(a, b, ctr, cva):
    return np.column_stack([a, ctr]), np.column_stack([b, cva])


def view_id(spec):
    fields = [spec["family"]]
    for key in ("top", "k", "white"):
        if key in spec:
            fields.append(f"{key}{spec[key]}")
    return "__".join(fields)


def iter_views(atr, ava, ctr, cva, ytr, columns, seed):
    # Ordinary PCA; extended head grid is evaluated only for this family.
    for k, white, a, b in pca_bank(atr, ava, GLOBAL_DIMS, seed + 11):
        spec = {"family": "global_pca", "k": k, "white": white}
        yield spec, *append_cov(a, b, ctr, cva)

    # Remove the linear age/sex/duration component before PCA, retaining those
    # covariates explicitly for the final discriminant.
    dtr = np.column_stack([np.ones(len(ctr)), ctr])
    dva = np.column_stack([np.ones(len(cva)), cva])
    coef = np.linalg.pinv(dtr, rcond=1e-6) @ atr
    rtr, rva = atr - dtr @ coef, ava - dva @ coef
    for k, white, a, b in pca_bank(rtr, rva, RESID_DIMS, seed + 101):
        spec = {"family": "residual_pca", "k": k, "white": white}
        yield spec, *append_cov(a, b, ctr, cva)

    # Select features using PD-vs-CI cases only, then learn PCA on all three
    # inner-training classes.  The selector never sees an outer/inner test row.
    case = ytr > 0
    score = f_classif(atr[case], (ytr[case] == 1).astype(int))[0]
    score = np.nan_to_num(score, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
    order = np.argsort(score)[::-1]
    for top in FILTER_TOP:
        ix = order[:min(top, atr.shape[1])]
        for k, white, a, b in pca_bank(
                atr[:, ix], ava[:, ix], FILTER_DIMS, seed + 1000 + top):
            spec = {"family": "casefilter_pca", "top": top,
                    "k": k, "white": white}
            yield spec, *append_cov(a, b, ctr, cva)

    task, modality, taskmod = group_indices(columns)
    for family, groups, dims, off in [
        ("task_block_pca", task, TASK_DIMS, 3000),
        ("modality_block_pca", modality, MODALITY_DIMS, 4000),
        ("taskmod_block_pca", taskmod, TASKMOD_DIMS, 5000),
    ]:
        for k, white, a, b in block_pca_bank(
                atr, ava, groups, dims, seed + off):
            spec = {"family": family, "k": k, "white": white}
            yield spec, *append_cov(a, b, ctr, cva)

    # Supervised latent components, trained on three-class one-hot outcomes.
    max_k = min(max(PLS_DIMS), len(atr) - 3, atr.shape[1])
    target = np.eye(3, dtype=float)[ytr]
    pls = PLSRegression(n_components=max_k, scale=False, max_iter=1000,
                        tol=1e-6)
    pls.fit(atr, target)
    za, zb = pls.transform(atr), pls.transform(ava)
    for k0 in PLS_DIMS:
        k = min(k0, za.shape[1])
        spec = {"family": "pls", "k": k0, "white": False}
        yield spec, *append_cov(za[:, :k], zb[:, :k], ctr, cva)


def allowed_heads(spec, n_features):
    heads = GLOBAL_HEADS if spec["family"] == "global_pca" else COMPACT_HEADS
    # QDA covariance estimates become unstable above the per-class sample size.
    return [h for h in heads if not (h.startswith("qda_") and n_features > 75)]


def candidate_complexity(row):
    head = row["head"]
    penalty = (0 if head == "lda_auto" else 2 if head.startswith("lda_")
               else 3 if head.startswith("ridge_") else 5)
    return (int(row["n_reduced"]), penalty, row["candidate_id"])


def inner_search(atr, ctr, y, inner, columns, seed):
    traces = {}
    for fi, (tr, va) in enumerate(inner):
        for spec, ztr, zva in iter_views(
                atr[tr], atr[va], ctr[tr], ctr[va], y[tr], columns,
                seed + fi * 10007):
            for hi, head in enumerate(allowed_heads(spec, ztr.shape[1])):
                cid = f"{view_id(spec)}|{head}"
                rec = traces.setdefault(cid, {
                    "candidate_id": cid, **spec, "head": head,
                    "n_reduced": ztr.shape[1], "fold": [],
                    "p": np.zeros((len(y), 3), dtype=np.float32),
                })
                try:
                    p = fit_head(ztr, zva, y[tr], head,
                                 seed + fi * 1009 + hi * 31)
                    rec["p"][va] = p
                    rec["fold"].append(conditional_auc(y[va], p))
                except Exception:
                    rec["fold"].append(np.nan)
    rows = []
    for rec in traces.values():
        vals = np.asarray(rec.pop("fold"), float)
        p = rec.pop("p")
        if np.isfinite(vals).sum() != len(inner) or not np.any(p):
            continue
        rows.append({**rec, "fold_mean": float(vals.mean()),
                     "fold_sd": float(vals.std(ddof=1)),
                     "fold_se": float(vals.std(ddof=1) / np.sqrt(len(vals))),
                     "pooled_auc": float(conditional_auc(y, p))})
    rows.sort(key=lambda z: (z["fold_mean"], z["pooled_auc"]), reverse=True)
    if not rows:
        raise RuntimeError("all shrinkage/PCA candidates failed")
    winners = {}
    for family in FAMILIES:
        pool = [r for r in rows if r["family"] == family]
        winners[family] = pool[0]
    winners["nested_max"] = rows[0]
    floor = rows[0]["fold_mean"] - rows[0]["fold_se"]
    eligible = [r for r in rows if r["fold_mean"] >= floor]
    winners["nested_one_se"] = min(eligible, key=candidate_complexity)
    return winners, rows


def fit_view(spec, atr, ava, ctr, cva, ytr, columns, seed):
    family, k0 = spec["family"], int(spec["k"])
    white = bool(spec.get("white", False))
    if family == "global_pca":
        source_tr, source_va = atr, ava
    elif family == "residual_pca":
        dtr = np.column_stack([np.ones(len(ctr)), ctr])
        dva = np.column_stack([np.ones(len(cva)), cva])
        coef = np.linalg.pinv(dtr, rcond=1e-6) @ atr
        source_tr, source_va = atr - dtr @ coef, ava - dva @ coef
    elif family == "casefilter_pca":
        case = ytr > 0
        score = f_classif(atr[case], (ytr[case] == 1).astype(int))[0]
        score = np.nan_to_num(score, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
        ix = np.argsort(score)[::-1][:min(int(spec["top"]), atr.shape[1])]
        source_tr, source_va = atr[:, ix], ava[:, ix]
    else:
        source_tr = source_va = None

    if source_tr is not None:
        k = min(k0, len(source_tr) - 3, source_tr.shape[1])
        pca = PCA(n_components=k, svd_solver="randomized", iterated_power=4,
                  random_state=seed)
        a, b = pca.fit_transform(source_tr), pca.transform(source_va)
        if white:
            a, b = whiten(a, b, pca.explained_variance_)
        return append_cov(a, b, ctr, cva)

    task, modality, taskmod = group_indices(columns)
    groups = {"task_block_pca": task, "modality_block_pca": modality,
              "taskmod_block_pca": taskmod}.get(family)
    if groups is not None:
        aa, bb = [], []
        for gi, (_, ix) in enumerate(sorted(groups.items())):
            k = min(k0, len(atr) - 3, len(ix))
            pca = PCA(n_components=k, svd_solver="randomized", iterated_power=3,
                      random_state=seed + gi * 37)
            a, b = pca.fit_transform(atr[:, ix]), pca.transform(ava[:, ix])
            if white:
                a, b = whiten(a, b, pca.explained_variance_)
            aa.append(a); bb.append(b)
        return append_cov(np.column_stack(aa), np.column_stack(bb), ctr, cva)

    if family == "pls":
        k = min(k0, len(atr) - 3, atr.shape[1])
        pls = PLSRegression(n_components=k, scale=False, max_iter=1000,
                            tol=1e-6)
        pls.fit(atr, np.eye(3)[ytr])
        return append_cov(pls.transform(atr), pls.transform(ava), ctr, cva)
    raise ValueError(family)


def fit_anchor(atr, ava, ctr, cva, ytr, seed):
    a, b = append_cov(atr, ava, ctr, cva)
    cfg = dict(selector="pca", clf="lda", k=50)
    est = PT.supervised_pipe(cfg, a.shape[1], len(ytr), 3)
    est.fit(a, ytr)
    return PT.aligned_proba(est, b, 3)


def clean_row(row):
    return {k: v for k, v in row.items()
            if k not in {"fold_sd", "fold_se"} or np.isfinite(v)}


def run_fold(oi, splits, repeats, inner_k):
    path = FOLDS / f"r{oi // splits}_f{oi % splits}.parquet"
    meta = path.with_suffix(".json")
    if path.exists() and meta.exists():
        return json.loads(meta.read_text(encoding="utf-8"))
    t0 = time.time()
    try:
        ids, y, x, audio_cols, cov_cols = data()
        folds = list(RepeatedStratifiedKFold(
            n_splits=splits, n_repeats=repeats, random_state=SEED).split(
                np.zeros(len(y)), y))
        tr, te = folds[oi]

        aprep, cprep = modeling.make_prep(), modeling.make_prep()
        atr = aprep.fit_transform(x.iloc[tr][audio_cols])
        ava = aprep.transform(x.iloc[te][audio_cols])
        ctr = cprep.fit_transform(x.iloc[tr][cov_cols])
        cva = cprep.transform(x.iloc[te][cov_cols])
        kept = np.asarray(audio_cols)[aprep.named_steps["var"].get_support()]
        inner = list(StratifiedKFold(
            inner_k, shuffle=True, random_state=SEED + oi).split(atr, y[tr]))
        winners, trace = inner_search(atr, ctr, y[tr], inner, kept,
                                      SEED + oi * 101)

        preds = {"anchor": fit_anchor(atr, ava, ctr, cva, y[tr],
                                       SEED + oi * 101 + 11)}
        for mi, (name, spec) in enumerate(winners.items()):
            a, b = fit_view(spec, atr, ava, ctr, cva, y[tr], kept,
                            SEED + oi * 1009 + mi * 53)
            preds[name] = fit_head(a, b, y[tr], spec["head"],
                                   SEED + oi * 1009 + mi * 53 + 7)

        d = pd.DataFrame({"participant_id": ids[te].astype(str),
                          "y_true": y[te], "repeat": oi // splits,
                          "fold": oi % splits})
        for model, p in preds.items():
            for cls in range(3):
                d[f"{model}_p{cls}"] = p[:, cls]
        d.to_parquet(path, index=False)
        keep_trace = trace[:30]
        for family in FAMILIES:
            keep_trace.append(next(r for r in trace if r["family"] == family))
        rec = {"job_id": path.stem, "status": "ok",
               "winners": {k: clean_row(v) for k, v in winners.items()},
               "trace_top_and_family": [clean_row(r) for r in keep_trace],
               "n_candidates": len(trace),
               "seconds": round(time.time() - t0, 2)}
        meta.write_text(json.dumps(rec, default=float), encoding="utf-8")
        return rec
    except Exception as exc:
        rec = {"job_id": path.stem, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - t0, 2)}
        meta.write_text(json.dumps(rec), encoding="utf-8")
        return rec


def aggregate():
    files = sorted(FOLDS.glob("r*_f*.parquet"))
    if not files:
        raise RuntimeError("no completed PCA/shrinkage folds")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    pcols = [c for c in raw if "_p" in c]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in pcols}})
    d.to_parquet(OUT / "oof_predictions.parquet")
    return d


def report(bootstraps=5000):
    d = aggregate()
    y = d.y_true.to_numpy(int)
    case = y > 0
    yy = (y[case] == 1).astype(int)
    models = ["anchor", *FAMILIES, "nested_max", "nested_one_se"]
    rows, prob = [], {}
    for model in models:
        cols = [f"{model}_p{i}" for i in range(3)]
        if not set(cols).issubset(d):
            continue
        p = d[cols].to_numpy(float)
        q = p[case, 1] / np.maximum(1e-12, p[case, 1] + p[case, 2])
        prob[model] = q
        rows.append({"model": model, "n_cases": int(case.sum()),
                     "pd_vs_ci_auc": roc_auc_score(yy, q)})
    metrics = pd.DataFrame(rows).sort_values("pd_vs_ci_auc", ascending=False)
    metrics.to_csv(OUT / "metrics.csv", index=False)

    comparisons = []
    for model in models:
        if model == "anchor" or model not in prob:
            continue
        rec = CB.bootstrap_pair(yy, prob[model], prob["anchor"],
                                n_boot=bootstraps)
        delta, p = CB.delong_test(yy, prob[model], prob["anchor"])
        comparisons.append({"model": model, "reference": "pca50_lda_auto",
                            "delta_delong": delta, "p_delong": p, **rec})
    comp = pd.DataFrame(comparisons)
    comp["fdr_q"] = E._bh(comp.p_delong)
    comp.to_csv(OUT / "paired_comparisons.csv", index=False)

    selections = []
    for path in sorted(FOLDS.glob("r*_f*.json")):
        rec = json.loads(path.read_text(encoding="utf-8"))
        if rec.get("status") != "ok":
            continue
        for model, spec in rec["winners"].items():
            selections.append({"fold": rec["job_id"], "model": model, **spec})
    sel = pd.DataFrame(selections)
    sel.to_csv(OUT / "selection_stability.csv", index=False)
    stability = (sel.groupby(["model", "candidate_id"]).size()
                 .rename("fold_count").reset_index().sort_values(
                     ["model", "fold_count"], ascending=[True, False]))

    lines = [
        "# Expanded PCA/shrinkage PD-versus-CI refinement", "",
        "All models use the 750-person complete-general-task cohort and the fixed "
        "per-task dynamic representation. Every dimensionality-reduction, supervised "
        "prefilter, shrinkage, regularisation, and hyperparameter choice is made "
        "inside the outer training folds. Models train on all three classes; the "
        "reported endpoint is relative PD-versus-CI preference among 152 held-out "
        "neurological cases.", "", "## Performance", "",
        R.markdown_table(metrics.round(4)), "", "## Paired versus 0.832 anchor", "",
        R.markdown_table(comp.round(4)), "", "## Selection stability", "",
        R.markdown_table(stability), "",
        "A nested family/global result is the honest adaptive estimate. Any fixed "
        "configuration highlighted after viewing these results is exploratory until "
        "tested in new participants.", "",
    ]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))
    print(comp.to_string(index=False))
    print(stability.to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run", "report"])
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--inner-splits", type=int, default=3)
    ap.add_argument("--bootstraps", type=int, default=5000)
    a = ap.parse_args()
    if a.command == "audit":
        ids, y, x, audio, cov = data()
        print(pd.Series(y).value_counts().sort_index().to_string())
        print(f"X={x.shape}; audio={len(audio)}; covariates={len(cov)}")
        print(f"global heads={len(GLOBAL_HEADS)}; compact heads={len(COMPACT_HEADS)}")
        return
    if a.command == "report":
        return report(a.bootstraps)
    total = a.splits * a.repeats
    todo = [i for i in range(total) if not (
        FOLDS / f"r{i // a.splits}_f{i % a.splits}.parquet").exists()]
    print(f"PCA/shrinkage refinement: {len(todo)}/{total} folds pending", flush=True)
    for start in range(0, len(todo), a.jobs):
        batch = todo[start:start + a.jobs]
        ans = Parallel(n_jobs=a.jobs, prefer="threads", verbose=5)(
            delayed(run_fold)(i, a.splits, a.repeats, a.inner_splits)
            for i in batch)
        for rec in ans:
            print(rec["job_id"], rec["status"], rec.get("error", ""),
                  rec.get("seconds", ""), flush=True)
    report(a.bootstraps)


if __name__ == "__main__":
    main()
