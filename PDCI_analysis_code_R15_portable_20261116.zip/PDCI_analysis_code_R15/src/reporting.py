"""Small report helpers with no optional runtime dependencies."""
from __future__ import annotations

import pandas as pd


def markdown_table(frame: pd.DataFrame, index: bool = False) -> str:
    """Render a compact GitHub-style table without pandas' ``tabulate`` extra."""
    d = frame.reset_index() if index else frame.copy()

    def cell(value) -> str:
        if pd.isna(value):
            return ""
        return str(value).replace("|", "\\|").replace("\r", " ").replace("\n", " ")

    headers = [cell(c) for c in d.columns]
    lines = ["| " + " | ".join(headers) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    lines.extend("| " + " | ".join(cell(v) for v in row) + " |"
                 for row in d.itertuples(index=False, name=None))
    return "\n".join(lines)
