"""Frozen, training-only sensitivity policies for saved fully nested PD/CI scores."""
from __future__ import annotations

import argparse
import os
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, confusion_matrix
from scipy.stats import norm

ROOT = Path(os.environ.get("PDCI_DATA_ROOT", str(Path(__file__).resolve().parents[2]))).resolve()
ANALYSIS = Path(os.environ.get("PDCI_ANALYSIS_ROOT", str(Path(__file__).resolve().parents[1]))).resolve()
SOURCE = ANALYSIS / "results/pdci_demographic_baseline_20260911"
OUT = ANALYSIS / "results/pdci_sensitivity_policy_20260912"
LOCAL = OUT / "local_only"
PRIMARY = "separate98_pd95"
SEED = 20260912
NBOOT = 5000
CLASSES = ("Neither", "PD", "CI")
TARGETS_SCREEN = (.95, .98, 1.)
TARGETS_PD = (.90, .95, .98)


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(2**20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def policies():
    rows = [dict(policy=f"separate{round(t*100)}_pd{round(u*100)}",
                 kind="new", screen_target=t, pd_target=u,
                 primary=(t == .98 and u == .95))
            for t in TARGETS_SCREEN for u in TARGETS_PD]
    for target in (.9, .95):
        for kind in ("legacy", "voting_only"):
            rows.append(dict(policy=f"{kind}{round(target*100)}", kind=kind,
                             screen_target=target, pd_target=None, primary=False))
    return rows


def freeze():
    frozen = OUT / "FROZEN_SPEC.json"
    if frozen.exists():
        verify_protection()
        print("Existing frozen specification verified; not overwritten.", flush=True)
        return
    paths = {Path(__file__).resolve(), OUT / "ANALYSIS_PLAN.md", OUT / "RUN_HANDOFF.md"}
    trees = [SOURCE, ANALYSIS / "results/pdci_fully_nested_20260911"]
    for tree in trees:
        if tree.exists():
            paths.update(p for p in tree.rglob("*") if p.is_file())
    for name in ("pdci_demographic_baseline_20260911.py", "pdci_fully_nested_20260911.py"):
        p = ANALYSIS / "src" / name
        if p.exists(): paths.add(p)
    paths.update(Path(p) for p in json.loads((SOURCE / "FROZEN_SPEC.json").read_text())["protected_sha256"])
    protected = {str(p): digest(p) for p in sorted(paths)}
    spec = dict(created_utc=stamp(), primary_policy=PRIMARY, policies=policies(),
                seed=SEED, bootstrap_draws=NBOOT, new_outer_policy_results_not_yet_computed=True,
                models_refitted=False, source_directory=str(SOURCE), protected_sha256=protected)
    write_json(frozen, spec)
    write_json(OUT / "RUN_STATUS.json", dict(status="FROZEN", created_utc=stamp(), protected_files=len(paths)))
    print(f"FROZEN {len(paths)} protected files; primary {PRIMARY}; no new policy outcome evaluated.", flush=True)


def verify_protection():
    spec = json.loads((OUT / "FROZEN_SPEC.json").read_text())
    changed = [p for p, value in spec["protected_sha256"].items() if not Path(p).is_file() or digest(p) != value]
    assert not changed, f"Protected files changed: {changed}"
    assert spec["policies"] == policies() and spec["primary_policy"] == PRIMARY
    return spec


def largest_threshold(positive_scores, target):
    p = np.asarray(positive_scores, dtype=float)
    assert len(p) and np.isfinite(p).all()
    required = math.ceil(target * len(p) - 1e-12)
    value = float(np.sort(p)[len(p) - required])
    assert int((p >= value).sum()) >= required
    assert int((p >= np.nextafter(value, np.inf)).sum()) < required
    return value


def reference_threshold(y, scores, target, separate):
    classes = (1, 2) if separate else (1,)
    yy = y if separate else (y > 0).astype(int)
    candidates = np.unique(scores)[::-1]
    for value in candidates:
        if all(np.mean(scores[yy == c] >= value) >= target - 1e-12 for c in classes):
            return float(value)
    raise AssertionError("No admissible threshold")


def read_sources():
    manifest = json.loads((SOURCE / "local_only/split_manifest.json").read_text())
    ids = np.asarray(manifest["ids"])
    chunks, inner_frames, receipts = [], [], []
    for oi, split in enumerate(manifest["splits"]):
        fold = SOURCE / f"local_only/folds/fold_{oi:02d}"
        rec = json.loads(fold.with_suffix(".json").read_text())
        test = pd.read_parquet(fold.with_suffix(".parquet"))
        train = pd.read_parquet(fold.parent / f"fold_{oi:02d}_selected_inner.parquet")
        assert rec["status"] == "COMPLETE" and digest(fold.with_suffix(".parquet")) == rec["prediction_sha256"]
        assert train.participant_id.tolist() == ids[split["train"]].tolist()
        assert test.participant_id.tolist() == ids[split["test"]].tolist()
        assert set(train.participant_id).isdisjoint(test.participant_id)
        assert len(train) == 600 and len(test) == 150
        assert (test.repeat == oi // 5).all() and (test.fold == oi % 5).all()
        assert all(x["disjoint"] for x in rec["inner_partition_audit"])
        assert train.loc[train.y_true > 0, "stage2"].notna().all()
        assert train.loc[train.y_true == 0, "stage2"].isna().all()
        chunks.append(test); inner_frames.append(train); receipts.append(rec)
    raw = pd.concat(chunks, ignore_index=True)
    assert len(raw) == 2250 and not raw.duplicated(["participant_id", "repeat"]).any()
    assert raw.groupby("participant_id").size().eq(3).all()
    assert raw.groupby("participant_id").y_true.nunique().eq(1).all()
    y = raw.groupby("participant_id").y_true.first().reindex(ids).to_numpy(int)
    assert np.array_equal(np.bincount(y), [598, 90, 62])
    for oi, split in enumerate(manifest["splits"]):
        assert np.array_equal(inner_frames[oi].y_true.to_numpy(), y[split["train"]])
        assert np.array_equal(chunks[oi].y_true.to_numpy(), y[split["test"]])
    return ids, y, raw, inner_frames, receipts


def construct_thresholds(inner_frames, receipts):
    rows = []
    for oi, train in enumerate(inner_frames):
        y, s, q = (train[c].to_numpy() for c in ("y_true", "screen", "stage2"))
        for pol in policies():
            t, u = pol["screen_target"], pol["pd_target"]
            if pol["kind"] == "new":
                st = min(largest_threshold(s[y == c], t) for c in (1, 2))
                qt = largest_threshold(q[y == 1], u)
                assert st == reference_threshold(y, s, t, separate=True)
                cq, cy = q[y > 0], y[y > 0]
                assert qt == reference_threshold((cy == 1).astype(int), cq, u, separate=False)
            else:
                st = largest_threshold(s[y > 0], t)
                qt = .5
                assert st == reference_threshold(y, s, t, separate=False)
                assert st == receipts[oi]["thresholds"]["primary"][f"sens{round(t*100)}"]
            rows.append(dict(**pol, outer_fold=oi, repeat=oi // 5, fold=oi % 5,
                screen_threshold=st, pd_threshold=qt,
                train_PD_n=int((y == 1).sum()), train_CI_n=int((y == 2).sum()),
                train_neither_n=int((y == 0).sum()),
                train_PD_referred=int(((y == 1) & (s >= st)).sum()),
                train_CI_referred=int(((y == 2) & (s >= st)).sum()),
                train_screen_PD_sensitivity=float(np.mean(s[y == 1] >= st)),
                train_screen_CI_sensitivity=float(np.mean(s[y == 2] >= st)),
                train_screen_specificity=float(np.mean(s[y == 0] < st)),
                train_conditional_PD_positive=int(((y == 1) & (q >= qt)).sum()),
                train_conditional_PD_sensitivity=float(np.mean(q[y == 1] >= qt)),
                train_conditional_CI_specificity=float(np.mean(q[y == 2] < qt))))
    frame = pd.DataFrame(rows)
    for oi in range(15):
        f = frame[(frame.outer_fold == oi) & frame.kind.eq("new")]
        assert np.all(np.diff(f.groupby("screen_target").screen_threshold.first()) <= 0)
        assert np.all(np.diff(f.groupby("pd_target").pd_threshold.first()) <= 0)
        assert (f.train_screen_PD_sensitivity >= f.screen_target - 1e-12).all()
        assert (f.train_screen_CI_sensitivity >= f.screen_target - 1e-12).all()
        assert (f.train_conditional_PD_sensitivity >= f.pd_target - 1e-12).all()
    return frame


def aggregate(policy_rows, ids, kind):
    def matrix(col):
        return policy_rows.pivot(index="participant_id", columns="repeat", values=col).reindex(ids).to_numpy()
    screens, pd_calls, calls = matrix("screen_positive").astype(bool), matrix("conditional_PD").astype(bool), matrix("call").astype(int)
    votes_s = screens.sum(axis=1)
    pd_on_positive = (screens & pd_calls).sum(axis=1)
    ci_on_positive = (screens & ~pd_calls).sum(axis=1)
    subtype_all = pd_calls.sum(axis=1) >= 2
    if kind == "legacy":
        counts = np.column_stack([(calls == c).sum(axis=1) for c in range(3)])
        final = np.argmax(counts, axis=1)
        referral = final > 0
    else:
        referral = votes_s >= 2
        final = np.where(referral, np.where(pd_on_positive >= ci_on_positive, 1, 2), 0)
    # Deliberately separate loop implementation audits all aggregation decisions.
    manual = []
    for sv, qv, cv in zip(screens, pd_calls, calls):
        if kind == "legacy":
            vote_counts = [list(cv).count(c) for c in range(3)]
            manual.append(vote_counts.index(max(vote_counts)))
        elif sum(sv) < 2:
            manual.append(0)
        else:
            manual.append(1 if sum(qv[sv]) >= sum(~qv[sv]) else 2)
    assert np.array_equal(final, manual)
    return dict(final=final, screen=referral, subtype_all=subtype_all,
                screen_votes=votes_s, positive_PD_votes=pd_on_positive,
                positive_CI_votes=ci_on_positive, all_PD_votes=pd_calls.sum(axis=1))


def ratio_masks(y, final, subtype_all):
    case, pd_, ci_, neither, referred = y > 0, y == 1, y == 2, y == 0, final > 0
    ones = np.ones(len(y), dtype=bool)
    both = lambda a, b: a & b
    return {
        "screen_sensitivity": (both(case, referred), case),
        "screen_PD_sensitivity": (both(pd_, referred), pd_),
        "screen_CI_sensitivity": (both(ci_, referred), ci_),
        "screen_specificity": (both(neither, ~referred), neither),
        "screen_PPV": (both(case, referred), referred),
        "screen_NPV": (both(neither, ~referred), ~referred),
        "referral_fraction": (referred, ones),
        "conditional_all_PD_sensitivity": (both(pd_, subtype_all), pd_),
        "conditional_all_CI_specificity": (both(ci_, ~subtype_all), ci_),
        "conditional_all_PPV": (both(pd_, subtype_all), both(case, subtype_all)),
        "conditional_all_NPV": (both(ci_, ~subtype_all), both(case, ~subtype_all)),
        "conditional_referred_PD_sensitivity": (pd_ & (final == 1), pd_ & referred),
        "conditional_referred_CI_specificity": (ci_ & (final == 2), ci_ & referred),
        "conditional_referred_PPV": (pd_ & (final == 1), case & (final == 1)),
        "conditional_referred_NPV": (ci_ & (final == 2), case & (final == 2)),
        "end_to_end_PD_recall": (pd_ & (final == 1), pd_),
        "end_to_end_CI_recall": (ci_ & (final == 2), ci_),
        "end_to_end_PD_specificity_vs_rest": (~pd_ & (final != 1), ~pd_),
        "end_to_end_PD_PPV_vs_rest": (pd_ & (final == 1), final == 1),
        "end_to_end_PD_NPV_vs_rest": (~pd_ & (final != 1), final != 1),
    }


def describe(y, state, policy, scope):
    final, sub = state["final"], state["subtype_all"]
    ratios = ratio_masks(y, final, sub)
    row = dict(policy=policy, scope=scope, n=len(y), n_PD=int((y == 1).sum()), n_CI=int((y == 2).sum()))
    for name, (num, den) in ratios.items():
        a, b = int(num.sum()), int(den.sum())
        row[name] = a / b if b else np.nan
        row[name + "_numerator"], row[name + "_denominator"] = a, b
    cm = confusion_matrix(y, final, labels=[0, 1, 2])
    row.update(referrals=int((final > 0).sum()), PD_to_neither=int(cm[1, 0]), PD_to_CI=int(cm[1, 2]),
               CI_to_neither=int(cm[2, 0]), CI_to_PD=int(cm[2, 1]), neither_referred=int(cm[0, 1:].sum()))
    assert cm.sum() == len(y) and cm[1].sum() == row["n_PD"] and cm[2].sum() == row["n_CI"]
    assert row["screen_sensitivity_numerator"] == int(cm[1:, 1:].sum())
    cms = [dict(policy=policy, scope=scope, true_class=CLASSES[t], predicted_class=CLASSES[p], n=int(cm[t, p]))
           for t in range(3) for p in range(3)]
    return row, cms


def bootstrap(ids, y, states):
    names = (PRIMARY, "legacy95")
    masks = {p: ratio_masks(y, states[p]["final"], states[p]["subtype_all"]) for p in names}
    metrics = list(masks[PRIMARY])
    draws = {p: np.empty((NBOOT, len(metrics))) for p in names}
    rng = np.random.default_rng(SEED)
    classes = [np.flatnonzero(y == c) for c in range(3)]
    validations = 0
    for b in range(NBOOT):
        # Explicit sampled indices make paired participant resampling transparent.
        ix = np.concatenate([rng.choice(c, size=len(c), replace=True) for c in classes])
        weights = np.bincount(ix, minlength=len(y))
        for pol in names:
            for j, key in enumerate(metrics):
                num, den = masks[pol][key]
                a, d = float(weights @ num), float(weights @ den)
                value = a / d if d else np.nan
                draws[pol][b, j] = value
                if b < 20:
                    direct_d = int(den[ix].sum())
                    direct = num[ix].sum() / direct_d if direct_d else np.nan
                    assert np.isclose(value, direct, equal_nan=True)
                    validations += 1
    rows, differences = [], []
    for j, metric in enumerate(metrics):
        points = {}
        for pol in names:
            num, den = masks[pol][metric]
            points[pol] = float(num.sum() / den.sum()) if den.sum() else np.nan
            valid = draws[pol][:, j][np.isfinite(draws[pol][:, j])]
            low, high = np.quantile(valid, [.025, .975]) if len(valid) else (np.nan, np.nan)
            rows.append(dict(policy=pol, metric=metric, numerator=int(num.sum()), denominator=int(den.sum()),
                             estimate=points[pol], ci_low=low, ci_high=high, n_boot=NBOOT,
                             finite_draws=int(np.isfinite(draws[pol][:, j]).sum())))
        gain = draws[PRIMARY][:, j] - draws["legacy95"][:, j]
        valid_gain = gain[np.isfinite(gain)]
        low, high = np.quantile(valid_gain, [.025, .975]) if len(valid_gain) else (np.nan, np.nan)
        differences.append(dict(candidate=PRIMARY, comparator="legacy95", metric=metric,
            difference=points[PRIMARY] - points["legacy95"], ci_low=low, ci_high=high,
            n_boot=NBOOT, finite_draws=int(np.isfinite(gain).sum())))
    np.savez_compressed(LOCAL / "bootstrap_draws.npz", **draws, metrics=np.asarray(metrics))
    return pd.DataFrame(rows), pd.DataFrame(differences), validations


def wilson_reference(intervals):
    z = float(norm.ppf(.975))
    result = intervals[["policy", "metric", "numerator", "denominator", "estimate"]].copy()
    n, p = result.denominator.to_numpy(float), result.estimate.to_numpy(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        center = (p + z*z/(2*n)) / (1 + z*z/n)
        half = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / (1 + z*z/n)
    result["wilson95_low"], result["wilson95_high"] = center-half, center+half
    valid = result.denominator > 0
    assert ((result.loc[valid, "wilson95_low"] >= -1e-14) & (result.loc[valid, "wilson95_high"] <= 1+1e-14)).all()
    assert (result.loc[valid, "wilson95_low"] < result.loc[valid, "wilson95_high"]).all()
    return result


def markdown(frame, digits=4):
    def cell(value):
        if isinstance(value, (float, np.floating)):
            return "NA" if not np.isfinite(value) else f"{value:.{digits}f}"
        return str(value)
    return "\n".join(["| " + " | ".join(frame.columns) + " |",
                       "| " + " | ".join("---" for _ in frame.columns) + " |"] +
                      ["| " + " | ".join(cell(v) for v in row) + " |" for row in frame.itertuples(index=False, name=None)])


def source_auc_check(ids, raw):
    cols = ["primary_screen", "primary_q", "primary_p0", "primary_p1", "primary_p2"]
    pooled = raw.groupby("participant_id")[cols].mean().reindex(ids)
    archived = pd.read_parquet(SOURCE / "local_only/participant_oof_predictions.parquet").reindex(ids)
    assert np.array_equal(pooled.to_numpy(), archived[cols].to_numpy())
    y = archived.y_true.to_numpy(int)
    values = dict(screen=roc_auc_score(y > 0, pooled.primary_screen),
                  stage2=roc_auc_score(y[y > 0] == 1, pooled.loc[y > 0, "primary_q"]),
                  macro=roc_auc_score(y, pooled[[f"primary_p{i}" for i in range(3)]], multi_class="ovr", average="macro"))
    source_metrics = pd.read_csv(SOURCE / "pooled_oof_metrics.csv").set_index("model").loc["primary"]
    for name, value in values.items(): assert abs(value - source_metrics[name]) < 1e-14
    return values


def check_legacy(ops, cms):
    old_cm = pd.read_csv(SOURCE / "confusion_matrices.csv")
    old_ops = pd.read_csv(SOURCE / "operating_points.csv")
    old_names = {"neither": "Neither", "parkinsons_disease": "PD", "cognitive_impairment": "CI"}
    for gate in (90, 95):
        for scope in ("participant_majority", "repeat_0", "repeat_1", "repeat_2"):
            ours = cms[(cms.policy == f"legacy{gate}") & (cms.scope == scope)].copy()
            saved = old_cm[(old_cm.model == "primary") & (old_cm.gate == f"sens{gate}") & (old_cm.scope == scope)].copy()
            # Source labels are human-readable but case conventions vary by file.
            def label(s):
                return "Neither" if s.lower() == "neither" else "PD" if s.lower() in ("pd", "parkinsons_disease") else "CI"
            saved.true_class = saved.true_class.map(label)
            saved.predicted_class = saved.predicted_class.map(label)
            assert ours.set_index(["true_class", "predicted_class"]).n.to_dict() == saved.set_index(["true_class", "predicted_class"]).n.to_dict()
            a = ops[(ops.policy == f"legacy{gate}") & (ops.scope == scope)].iloc[0]
            b = old_ops[(old_ops.model == "primary") & (old_ops.gate == f"sens{gate}") & (old_ops.scope == scope)].iloc[0]
            for new, old in (("screen_sensitivity", "sensitivity"), ("screen_specificity", "specificity"),
                             ("screen_PPV", "ppv"), ("screen_NPV", "npv"), ("referrals", "screen_positive"),
                             ("end_to_end_PD_recall", "PD_recall"), ("end_to_end_CI_recall", "cognitive_impairment_recall")):
                assert abs(a[new] - b[old]) < 1e-14, (gate, scope, new, a[new], b[old])


def audit_saved():
    spec = verify_protection()
    receipt = json.loads((OUT / "AUDIT.json").read_text())
    assert receipt["status"] == "PASS"
    for path, value in receipt["output_sha256"].items(): assert digest(path) == value, path
    print(f"AUDIT PASS: {len(spec['protected_sha256'])} protected files and {len(receipt['output_sha256'])} outputs unchanged.", flush=True)


def run():
    spec = verify_protection()
    if (OUT / "COMPLETE.json").exists():
        audit_saved()
        print("Already complete; no results overwritten.", flush=True)
        return
    LOCAL.mkdir(parents=True, exist_ok=True)
    write_json(OUT / "RUN_STATUS.json", dict(status="RUNNING", started_utc=stamp(), primary=PRIMARY))
    ids, y, raw, inners, receipts = read_sources()
    auc = source_auc_check(ids, raw)
    th = construct_thresholds(inners, receipts)
    th.to_csv(OUT / "training_thresholds.csv", index=False)
    all_decisions, states, rows, confusion_rows, participant_rows = [], {}, [], [], []
    for pol in policies():
        name = pol["policy"]
        cutoff = th[th.policy == name][["repeat", "fold", "screen_threshold", "pd_threshold"]]
        d = raw[["participant_id", "y_true", "repeat", "fold", "primary_screen", "primary_q"]].merge(cutoff, on=["repeat", "fold"], validate="many_to_one")
        d["screen_positive"] = d.primary_screen >= d.screen_threshold
        d["conditional_PD"] = d.primary_q >= d.pd_threshold
        d["call"] = np.where(d.screen_positive, np.where(d.conditional_PD, 1, 2), 0)
        d["policy"] = name
        if pol["kind"] == "legacy":
            old = raw[["participant_id", "repeat", f"primary_call_sens{round(pol['screen_target']*100)}"]]
            compared = d.merge(old, on=["participant_id", "repeat"], validate="one_to_one")
            assert np.array_equal(compared.call, compared.iloc[:, -1])
        all_decisions.append(d)
        state = aggregate(d, ids, pol["kind"])
        states[name] = state
        row, cm = describe(y, state, name, "participant_majority")
        rows.append(row); confusion_rows.extend(cm)
        pp = pd.DataFrame(dict(participant_id=ids, y_true=y, policy=name, **state))
        participant_rows.append(pp)
        for repeat, group in d.groupby("repeat"):
            state_repeat = dict(final=group.call.to_numpy(int), subtype_all=group.conditional_PD.to_numpy(bool))
            row, cm = describe(group.y_true.to_numpy(int), state_repeat, name, f"repeat_{repeat}")
            rows.append(row); confusion_rows.extend(cm)
    ops, cms = pd.DataFrame(rows), pd.DataFrame(confusion_rows)
    check_legacy(ops, cms)
    for u in TARGETS_PD:
        previous = np.zeros(len(y), dtype=bool)
        for t in TARGETS_SCREEN:
            current = states[f"separate{round(t*100)}_pd{round(u*100)}"]["screen"]
            assert not (previous & ~current).any()
            previous = current
    decisions = pd.concat(all_decisions, ignore_index=True)
    participants = pd.concat(participant_rows, ignore_index=True)
    decisions.to_parquet(LOCAL / "per_repeat_decisions.parquet", index=False)
    participants.to_parquet(LOCAL / "participant_decisions.parquet", index=False)
    ops.to_csv(OUT / "operating_points.csv", index=False)
    cms.to_csv(OUT / "confusion_matrices.csv", index=False)
    intervals, gains, checks = bootstrap(ids, y, states)
    intervals.to_csv(OUT / "nominal_bootstrap_intervals.csv", index=False)
    gains.to_csv(OUT / "paired_primary_minus_legacy95.csv", index=False)
    wilson = wilson_reference(intervals)
    wilson.to_csv(OUT / "wilson_binomial_reference_intervals.csv", index=False)
    summary = ops[ops.scope.eq("participant_majority")].copy()
    primary = summary[summary.policy.eq(PRIMARY)].iloc[0]
    comparison_cols = ["policy", "screen_sensitivity", "screen_PD_sensitivity", "screen_CI_sensitivity", "screen_specificity", "referrals", "end_to_end_PD_recall", "end_to_end_CI_recall", "PD_to_neither", "PD_to_CI"]
    subtype_cols = ["policy", "conditional_all_PD_sensitivity", "conditional_all_CI_specificity", "conditional_referred_PD_sensitivity", "conditional_referred_CI_specificity", "CI_to_PD", "CI_to_neither"]
    summary[comparison_cols + [c for c in subtype_cols if c not in comparison_cols]].to_csv(OUT / "policy_summary.csv", index=False)
    threshold_summary = th.groupby("policy").agg(
        screen_cutoff_min=("screen_threshold", "min"), screen_cutoff_max=("screen_threshold", "max"),
        pd_cutoff_min=("pd_threshold", "min"), pd_cutoff_max=("pd_threshold", "max"),
        training_PD_screen_min=("train_screen_PD_sensitivity", "min"), training_CI_screen_min=("train_screen_CI_sensitivity", "min"),
        training_PD_discriminator_min=("train_conditional_PD_sensitivity", "min")).reset_index()
    threshold_summary.to_csv(OUT / "threshold_summary.csv", index=False)
    pd.DataFrame([dict(endpoint=k, auc=v, unchanged=True) for k, v in auc.items()]).to_csv(OUT / "unchanged_auroc.csv", index=False)
    key_metrics = ["screen_sensitivity", "screen_PD_sensitivity", "screen_CI_sensitivity", "screen_specificity", "screen_PPV", "screen_NPV", "conditional_all_PD_sensitivity", "conditional_all_CI_specificity", "conditional_referred_PD_sensitivity", "conditional_referred_CI_specificity", "end_to_end_PD_recall", "end_to_end_CI_recall"]
    report = ["# PD/CI sensitivity-prioritized operating policies", "",
        f"Completed {stamp()}. The prespecified primary policy used separate 98% PD and CI training sensitivity targets at screening and a 95% PD training sensitivity target at discrimination. It referred {int(primary.screen_sensitivity_numerator)}/152 true cases, including {int(primary.screen_PD_sensitivity_numerator)}/90 PD and {int(primary.screen_CI_sensitivity_numerator)}/62 CI. It assigned PD to {int(primary.end_to_end_PD_recall_numerator)}/90 PD participants. Screening specificity was {int(primary.screen_specificity_numerator)}/598 ({primary.screen_specificity:.1%}); {int(primary.referrals)}/750 participants were referred.", "",
        "This was a threshold-and-voting follow-up using the unchanged fully nested models and saved outer-test scores. It did not optimize or refit model architectures for high sensitivity. All nine policies were frozen before their new outer-test performance was calculated; none was chosen as a winner using these results. Previous results and q values are unchanged.", "",
        "## Population and validation", "",
        "The cohort comprised 750 adults: 598 with neither recorded target category, 90 with PD and 62 with CI. ALS and recorded PD+CI overlap were excluded. The source models used 11 general task families, with demographic age/sex/country inputs and optional duration/frame-count voice features selected within inner CV. Neither does not mean absence of every other disease. All thresholds here were obtained from each selected model's own outer-training inner-held-out predictions; no corresponding outer-test labels selected thresholds.", "",
        f"Continuous AUROCs were unchanged: screening {auc['screen']:.4f}; conditional PD versus CI {auc['stage2']:.4f}; composed three-class macro AUROC {auc['macro']:.4f}. Changing a decision threshold does not improve the underlying ranking AUROC.", "",
        "## Held-out operating points: all frozen policies and comparators", "",
        "Rates below are participant-level results after three held-out repeats. New policies require a majority-positive screen. Subtype votes use only positive-screen repeats and resolve a PD/CI tie as PD; subtype disagreement never converts a positive screen into neither. Legacy policies retain the original three-class vote, including ties assigned neither. Voting-only rows change that aggregation rule while retaining original screen thresholds and q=0.5.", "",
        markdown(summary[comparison_cols]), "", "## Conditional discrimination and error direction", "",
        "Conditional-all metrics evaluate all 152 true cases by the majority of their three binary subtype calls without screening. Conditional-referred metrics evaluate actual subtype assignments among true cases referred by each policy. Those are distinct populations and voting rules, so their rates need not be identical. CI specificity is the proportion of CI classified CI by the PD-positive discriminator; increasing PD sensitivity generally reduces it.", "",
        markdown(summary[subtype_cols]), "", "## Three-class confusion matrices", "",
        "Rows are recorded classes and columns are assigned classes. The matrices include all 750 participants. Full per-repeat matrices are in confusion_matrices.csv.", ""]
    for name in [p["policy"] for p in policies()]:
        cm = confusion_matrix(y, states[name]["final"], labels=[0, 1, 2])
        frame = pd.DataFrame(cm, columns=["Predicted neither", "Predicted PD", "Predicted CI"])
        frame.insert(0, "Recorded class", CLASSES)
        report.extend([f"### {name}" + (" (prespecified primary)" if name == PRIMARY else ""), "", markdown(frame), ""])
    report.extend(["## Nominal uncertainty for the primary policy", "",
        "The following 95% percentile intervals used 5,000 class-stratified paired participant resamples of fixed saved decisions. They do not refit the models or re-estimate thresholds and are not multiplicity-adjusted. They do not account for the prior development history or dependence introduced by training overlap. No p or q values are introduced by this descriptive policy analysis.", "",
        markdown(intervals[(intervals.policy == PRIMARY) & intervals.metric.isin(key_metrics)][["metric", "numerator", "denominator", "estimate", "ci_low", "ci_high"]]), "",
        "### Binomial reference intervals", "",
        "These separate 95% Wilson reference intervals remain nondegenerate if no errors are observed. They describe binomial sampling uncertainty using participant-level counts, but do not adjust for cross-validation training dependence, model development or threshold selection. They are not substitutes for the paired bootstrap and are not a guarantee of future performance.", "",
        markdown(wilson[(wilson.policy == PRIMARY) & wilson.metric.isin(key_metrics)]), "",
        "### Paired primary-minus-original-95% policy differences", "",
        "Differences are proportions, not percentage points. For example, +0.05 is +5 percentage points. Among-referred differences compare different policy-specific subsets and should not be interpreted as same-subgroup effects.", "",
        markdown(gains[gains.metric.isin(key_metrics)][["metric", "difference", "ci_low", "ci_high"]]), "",
        "## Training thresholds and attainment", "", markdown(threshold_summary), "",
        "Separate constraints protect against pooled training sensitivity concealing lower training sensitivity in PD or CI. They still cannot guarantee the target in held-out participants. With approximately 72 PD and 49-50 CI training cases per fold, high target rates are discrete; 98% and 100% targets may induce identical cutoffs for a subgroup. Per-fold counts and both class-specific attainment rates are saved in training_thresholds.csv.", "",
        "## Interpretation and qualifications", "",
        f"At the primary policy, {int(primary.PD_to_neither)} PD participants were classified neither and {int(primary.PD_to_CI)} were classified CI. The analogous CI errors were {int(primary.CI_to_neither)} classified neither and {int(primary.CI_to_PD)} classified PD. These counts separate screening failures from within-neurologic misclassification; end-to-end PD recall counts both error types as missed PD.", "",
        "Sensitivity and specificity must be considered jointly. A policy that refers nearly everyone can suppress false negatives without providing useful specificity. Likewise, assigning nearly all referred cases PD preserves PD recall by reducing CI specificity. These policies are candidates for clinical operating-point discussion, not a validated diagnostic rule or proof of zero future misses. A 100% observed rate, including a degenerate fixed-prediction bootstrap interval, does not establish 100% population sensitivity.", "",
        "This internal follow-up uses a previously explored cohort and repeats its held-out predictions; it is not an independent external validation. The primary operating target was prespecified for this follow-up, but the original models were selected by AUROC. No claims about optimal high-sensitivity architectures, causal features or deployment-ready calibration follow from this threshold analysis.", "",
        "## Files and provenance", "",
        "ANALYSIS_PLAN.md and FROZEN_SPEC.json define the frozen policy grid and source hashes. policy_summary.csv and operating_points.csv contain aggregate metrics and exact numerators/denominators; confusion_matrices.csv contains all policy/repeat matrices. nominal_bootstrap_intervals.csv and paired_primary_minus_legacy95.csv contain fixed-prediction intervals. training_thresholds.csv records own-training thresholds and attainment. unchanged_auroc.csv confirms unchanged rankings. Participant-level decisions and bootstrap draws are local_only. AUDIT.json and COMPLETE.json record verification. Previous files were not modified.", ""])
    (OUT / "REPORT.md").write_text("\n".join(report), encoding="utf-8")
    # Verify generated tables against source-of-truth decisions after serialization.
    reloaded = pd.read_parquet(LOCAL / "participant_decisions.parquet")
    loaded_ops = pd.read_csv(OUT / "operating_points.csv")
    for pol, group in reloaded.groupby("policy", sort=False):
        group = group.set_index("participant_id").loc[ids]
        check, _ = describe(y, dict(final=group.final.to_numpy(int), subtype_all=group.subtype_all.to_numpy(bool)), pol, "participant_majority")
        target = loaded_ops[(loaded_ops.policy == pol) & loaded_ops.scope.eq("participant_majority")].iloc[0]
        for key, value in check.items():
            if key not in ("policy", "scope"):
                assert np.isclose(value, target[key], equal_nan=True), (pol, key)
    verify_protection()
    outputs = [p for p in OUT.rglob("*") if p.is_file() and p.name not in ("AUDIT.json", "COMPLETE.json", "RUN_STATUS.json")]
    audit = dict(status="PASS", audited_utc=stamp(), source_protected_files=len(spec["protected_sha256"]),
        participants=750, outer_folds=15, heldout_predictions=2250, policies=9, descriptive_comparators=4,
        own_outer_training_thresholds_only=True, exhaustive_threshold_reconstruction=True,
        threshold_monotonicity=True, training_targets_attained=True, manual_vote_reconstruction=True,
        source_probabilities_bit_identical=True, source_auroc_identical=True,
        legacy90_95_all_confusion_cells_identical=True, legacy_operating_points_identical=True,
        participant_table_roundtrip_checks=True, bootstrap_draws=NBOOT, bootstrap_direct_checks=checks,
        bootstrap_seed=SEED, previous_results_and_manuscripts_unchanged=True, models_refitted=False,
        output_sha256={str(p): digest(p) for p in sorted(outputs)})
    write_json(OUT / "AUDIT.json", audit)
    write_json(OUT / "RUN_STATUS.json", dict(status="COMPLETE", completed_utc=stamp()))
    write_json(OUT / "COMPLETE.json", dict(status="COMPLETE", completed_utc=stamp(), audit="PASS",
        primary_policy=PRIMARY, source_frozen_sha256=digest(OUT / "FROZEN_SPEC.json"),
        audit_sha256=digest(OUT / "AUDIT.json"), report_sha256=digest(OUT / "REPORT.md")))
    print(markdown(summary[comparison_cols]), flush=True)
    print("COMPLETE / AUDIT PASS", flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("command", choices=("freeze", "run", "audit"))
    args = p.parse_args()
    {"freeze": freeze, "run": run, "audit": audit_saved}[args.command]()


if __name__ == "__main__":
    main()
