"""Build the participant-level cohort table: labels, covariates, cohort flags.

Writes analysis/data/cohort.parquet with one row per participant.

Label provenance is explicit.  Three of the phenotype "diagnosis" tables are
symptom questionnaires that were administered to controls as well
(adhd_adult: 33 controls, ptsd_adult: 29 controls, psychiatric_history: 12
controls).  Treating membership in those tables as a diagnosis mislabels a
large block of participants, so ADHD and PTSD are scored from their items with
published cut points instead.
"""
from __future__ import annotations

import json
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import config as C  # noqa: E402


def _read(path):
    return pd.read_csv(path, sep="\t", dtype=str)


def _dedup(df: pd.DataFrame) -> pd.DataFrame:
    """Some participants have several sessions of the same form; keep the first."""
    return df.drop_duplicates(subset="participant_id", keep="first")


# ------------------------------------------------------------------ screeners
def score_asrs(df: pd.DataFrame) -> pd.DataFrame:
    """ASRS v1.1.  Returns Part-A screen positivity plus continuous scores."""
    df = _dedup(df).set_index("participant_id")
    num = df.replace(C.ASRS_LIKERT)

    part_a_hits = pd.Series(0, index=df.index, dtype=float)
    part_a_avail = pd.Series(0, index=df.index, dtype=float)
    for item, cut in C.ASRS_PART_A.items():
        v = pd.to_numeric(num[item], errors="coerce")
        part_a_hits += (v >= cut).astype(float).where(v.notna(), 0.0)
        part_a_avail += v.notna().astype(float)

    all_items = list(C.ASRS_PART_A) + C.ASRS_PART_B
    vals = num[all_items].apply(pd.to_numeric, errors="coerce")
    inatt = ["wrapping_up", "things_in_order", "remembering_appt", "avoidance",
             "careless", "difficulty_attention", "difficulty_concentrating",
             "distracted", "misplace"]
    hyper = ["fidget", "overly_active", "remain_seated", "restless",
             "talking_too_much", "interrupt_others", "finish_other_sent",
             "difficulty_waiting", "difficulty_unwinding"]

    out = pd.DataFrame(index=df.index)
    out["adhd_partA_hits"] = part_a_hits.where(part_a_avail >= 5)
    out["adhd_screen_positive"] = (out["adhd_partA_hits"] >= 4).astype(float)
    out.loc[out["adhd_partA_hits"].isna(), "adhd_screen_positive"] = np.nan
    out["adhd_total_score"] = vals.mean(axis=1) * len(all_items)
    out["adhd_inattention_score"] = vals[inatt].mean(axis=1) * len(inatt)
    out["adhd_hyperactivity_score"] = vals[hyper].mean(axis=1) * len(hyper)
    return out


def score_pcl5(df: pd.DataFrame) -> pd.DataFrame:
    """Abbreviated PCL-5 (items stored as '3=Quite a bit')."""
    df = _dedup(df).set_index("participant_id")
    items = [c for c in C.PCL5_ITEMS if c in df.columns]
    vals = df[items].apply(lambda s: pd.to_numeric(s.str.extract(r"^(\d)")[0], errors="coerce"))
    n_ans = vals.notna().sum(axis=1)
    total = vals.mean(axis=1) * len(items)          # mean-impute missing items
    total = total.where(n_ans >= len(items) - 2)

    out = pd.DataFrame(index=df.index)
    out["ptsd_total_score"] = total
    out["ptsd_screen_positive"] = (total >= C.PCL5_CUTOFF).astype(float)
    out.loc[total.isna(), "ptsd_screen_positive"] = np.nan
    return out


# ------------------------------------------------------------------ covariates
def build_covariates() -> pd.DataFrame:
    demo = _dedup(_read(C.PHENO / "demographics" / "demographics.tsv")).set_index("participant_id")
    out = pd.DataFrame(index=demo.index)
    out["age"] = pd.to_numeric(demo["age"], errors="coerce")

    sex = demo["sex_at_birth"].fillna(demo.get("sex_assigned_at_birth"))
    out["sex_male"] = sex.map({"Male": 1.0, "Female": 0.0})

    edu_order = {
        "Some elementary school": 1, "Some secondary or high school education": 2,
        "High School or secondary school degree complete": 3, "Some college education": 4,
        "Associate's or technical degree complete": 5,
        "College or baccalaureate degree complete": 6,
        "Some post-baccalaureate education": 7,
        "Graduate or professional degree complete": 8,
        "Doctoral or post graduate education": 9,
    }
    out["edu_level_ord"] = demo["edu_level"].map(edu_order)
    out["hispanic"] = demo["ethnicity"].map({"Hispanic or Latino": 1.0,
                                             "Not Hispanic or Latino": 0.0})
    out["race_white"] = demo["race___5"].notna().astype(float)
    out["hearing_impaired"] = demo["hearing"].map({"Yes": 1.0, "No": 0.0})
    out["country_usa"] = demo["country"].map({"USA": 1.0, "Canada": 0.0})

    # Height/weight -> BMI: a genuine covariate for vocal-tract length and for
    # respiratory measures.
    conf = _dedup(_read(C.PHENO / "confounders" / "confounders.tsv")).set_index("participant_id")
    h = pd.to_numeric(conf.get("height"), errors="coerce")
    w = pd.to_numeric(conf.get("weight"), errors="coerce")
    unit = conf.get("unit")
    if unit is not None:
        metric = unit.astype(str).str.lower().str.contains("metric|cm|kg")
        h_m = np.where(metric, h / 100.0, h * 0.0254)
        w_kg = np.where(metric, w, w * 0.453592)
    else:
        h_m, w_kg = h * 0.0254, w * 0.453592
    bmi = pd.Series(w_kg / np.square(h_m), index=conf.index)
    out["bmi"] = bmi.where((bmi > 12) & (bmi < 70))
    return out


# ------------------------------------------------------------------ labels
def build_labels() -> tuple[pd.DataFrame, dict]:
    dx_dir = C.PHENO / "diagnosis"
    participants = set(_read(C.PHENO / "enrollment" / "participant.tsv")["participant_id"])
    participants |= set(_read(C.PHENO / "demographics" / "demographics.tsv")["participant_id"])
    idx = pd.Index(sorted(participants), name="participant_id")

    labels = pd.DataFrame(index=idx)
    provenance: dict[str, dict] = {}

    control_ids = set(_read(dx_dir / "control.tsv")["participant_id"])
    labels["is_control"] = pd.Series(1.0, index=pd.Index(sorted(control_ids))).reindex(idx).fillna(0.0)

    extra_scores = []
    for name, spec in C.TARGETS.items():
        df = _read(dx_dir / f"{spec['file']}.tsv")
        if spec["kind"] == "membership":
            pos = set(_dedup(df)["participant_id"])
            lab = pd.Series(0.0, index=idx)
            lab.loc[sorted(pos & set(idx))] = 1.0
        elif spec["kind"] == "field":
            d = _dedup(df).set_index("participant_id")
            hit = d[spec["field"]].isin(spec["positive"])
            lab = pd.Series(0.0, index=idx)
            lab.loc[sorted(set(hit[hit].index) & set(idx))] = 1.0
            # Participants in the module whose field says No/blank are of
            # uncertain status -- exclude rather than call them negative.
            unclear = sorted((set(d.index) - set(hit[hit].index)) & set(idx))
            lab.loc[unclear] = np.nan
        else:  # screener
            scored = score_asrs(df) if spec["scorer"] == "asrs" else score_pcl5(df)
            extra_scores.append(scored)
            lab = scored[name].reindex(idx)
            # Never administered -> unknown, not negative.
            lab = lab.where(scored[name].reindex(idx).notna(), np.nan)

        labels[name] = lab
        provenance[name] = {
            "kind": spec["kind"], "category": spec["category"],
            "n_positive": int(np.nansum(lab.values)),
            "n_negative": int(((lab == 0).sum())),
            "n_unknown": int(lab.isna().sum()),
        }

    for df in extra_scores:
        for c in df.columns:
            if c not in labels.columns:
                labels[c] = df[c].reindex(idx)

    # ---- rare diagnoses (not modelled; used for cohort construction)
    rare = pd.DataFrame(index=idx)
    for name in C.RARE_DIAGNOSES:
        pos = set(_dedup(_read(dx_dir / f"{name}.tsv"))["participant_id"])
        rare[f"rare_{name}"] = pd.Series(1.0, index=pd.Index(sorted(pos))).reindex(idx).fillna(0.0)

    # ---- category composites, built from clinical diagnoses only
    cats = {}
    for cat, members in C.CATEGORY_TARGETS.items():
        sub = labels[members]
        any_pos = (sub == 1).any(axis=1)
        all_known = sub.notna().all(axis=1)
        lab = any_pos.astype(float)
        lab[~any_pos & ~all_known] = np.nan     # unknown only if no member is positive
        labels[cat] = lab
        cats[cat] = lab
        provenance[cat] = {
            "kind": "composite", "category": cat.replace("CAT_", ""),
            "members": members,
            "n_positive": int(np.nansum(lab.values)),
            "n_negative": int((lab == 0).sum()),
            "n_unknown": int(lab.isna().sum()),
        }

    # ---- cohort structure: how many *clinical* disease categories present
    clinical = [t for t, s in C.TARGETS.items() if s["kind"] != "screener"]
    cat_of = {t: C.TARGETS[t]["category"] for t in clinical}
    for name, cat in C.RARE_DIAGNOSES.items():
        cat_of[f"rare_{name}"] = cat
    allc = pd.concat([labels[clinical], rare], axis=1)

    cat_flags = {}
    for cat in ["voice", "neuro", "respiratory", "mood_psych"]:
        cols = [c for c, k in cat_of.items() if k == cat and c in allc.columns]
        cat_flags[f"has_{cat}"] = (allc[cols] == 1).any(axis=1).astype(float)
    cat_flags = pd.DataFrame(cat_flags, index=idx)
    labels = pd.concat([labels, rare, cat_flags], axis=1)

    labels["n_categories"] = cat_flags.sum(axis=1)
    labels["n_diagnoses"] = (allc == 1).sum(axis=1)
    labels["single_category"] = (labels["n_categories"] == 1).astype(float)
    labels["any_disease"] = (labels["n_diagnoses"] > 0).astype(float)
    return labels, provenance


def main():
    cov = build_covariates()
    labels, prov = build_labels()
    cohort = labels.join(cov, how="left")

    # Recording coverage per participant, used later to require a minimum
    # amount of usable audio.
    sf = pd.read_csv(C.STATIC_TSV, sep="\t",
                     usecols=["participant_id", "session_id", "task_name"], dtype=str)
    sf["task_group"] = sf["task_name"].map(C.task_group)
    cov2 = sf.groupby("participant_id").agg(
        n_recordings=("task_name", "size"),
        n_task_groups=("task_group", "nunique"),
        n_sessions=("session_id", "nunique"),
    )
    cohort = cohort.join(cov2, how="left")
    cohort[["n_recordings", "n_task_groups", "n_sessions"]] = \
        cohort[["n_recordings", "n_task_groups", "n_sessions"]].fillna(0).astype(int)

    cohort.to_parquet(C.DATA / "cohort.parquet")
    (C.DATA / "label_provenance.json").write_text(json.dumps(prov, indent=2))

    print(f"cohort: {cohort.shape[0]} participants x {cohort.shape[1]} columns")
    print(f"  with audio: {(cohort.n_recordings > 0).sum()}   age known: {cohort.age.notna().sum()}"
          f"   sex known: {cohort.sex_male.notna().sum()}")
    print("\n{:<34s} {:>5s} {:>5s} {:>7s}  {}".format("target", "pos", "neg", "unknown", "kind"))
    rows = []
    for t, p in prov.items():
        rows.append((t, p["n_positive"], p["n_negative"], p["n_unknown"], p["kind"]))
    for t, a, b, c, k in sorted(rows, key=lambda r: -r[1]):
        flag = "" if a >= C.MIN_POSITIVES else "   << below n=30"
        print(f"{t:<34s} {a:5d} {b:5d} {c:7d}  {k}{flag}")
    print("\ncohort structure:")
    print("  n_categories:", cohort.n_categories.value_counts().sort_index().to_dict())
    print("  single_category participants:", int(cohort.single_category.sum()))
    print("  controls:", int(cohort.is_control.sum()))


if __name__ == "__main__":
    main()
