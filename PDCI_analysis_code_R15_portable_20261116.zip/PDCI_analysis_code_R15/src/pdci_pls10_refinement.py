"""Nested refinement of the PLS neurological screen.

See results/pdci_pls10_refinement/PRESPECIFICATION.md.  The fixed-grid
landscape is exploratory; ``nested_adaptive_pls`` is the held-out estimate of
the complete configuration-selection algorithm.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.cross_decomposition import PLSRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_to_baseline as CB  # noqa: E402
import config as C  # noqa: E402
import pdci_exhaustive as E  # noqa: E402
import pdci_linear_harmonics as H  # noqa: E402
import pdci_linear_tensor_profiles as T  # noqa: E402
import pdci_locked_moe_validation as M  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")

OUT = C.RESULTS / "pdci_pls10_refinement"
FOLDS = OUT / "folds"
OUT.mkdir(parents=True, exist_ok=True)
FOLDS.mkdir(parents=True, exist_ok=True)
SEED = C.RANDOM_STATE
COMPONENTS = (3, 5, 7, 10, 15, 20)
CS = (.003, .01, .03, .1, .3)
MODES = ("fusion", "base", "harm05", "harm2")
TARGETS = ("onehot", "neuro")
WEIGHTS = ("empirical", "balanced")


@dataclass(frozen=True)
class Config:
    mode: str
    target: str
    components: int
    c: float
    weight: str

    @property
    def id(self) -> str:
        c = f"{self.c:g}".replace(".", "p")
        return (f"m_{self.mode}__t_{self.target}__k_{self.components}"
                f"__c_{c}__w_{self.weight}")


CONFIGS = tuple(Config(m, t, k, c, w)
                for m in MODES for t in TARGETS for k in COMPONENTS
                for c in CS for w in WEIGHTS)
BY_ID = {c.id: c for c in CONFIGS}
CURRENT_ID = Config("fusion", "onehot", 10, .03, "empirical").id


def _block_prep(base_tr, harm_tr, cov_tr, base_te, harm_te, cov_te):
    """Featurewise preprocessing once, then diagnosis-blind block weights."""
    xb, yb = H._prep(base_tr, base_te)
    xh, yh = H._prep(harm_tr, harm_te)
    xc, yc = H._prep(cov_tr, cov_te)
    return {
        "fusion": (np.column_stack([xb, xh, xc]),
                   np.column_stack([yb, yh, yc])),
        "base": (np.column_stack([xb, xc]), np.column_stack([yb, yc])),
        "harm05": (np.column_stack([xb, .5 * xh, xc]),
                   np.column_stack([yb, .5 * yh, yc])),
        "harm2": (np.column_stack([xb, 2 * xh, xc]),
                  np.column_stack([yb, 2 * yh, yc])),
    }


def _binary_head(a, y, b, c, balanced):
    scaler = StandardScaler()
    za, zb = scaler.fit_transform(a), scaler.transform(b)
    est = LogisticRegression(
        C=c, penalty="l2", solver="lbfgs", max_iter=5000,
        class_weight="balanced" if balanced else None,
        random_state=SEED)
    est.fit(za, y)
    return np.clip(est.predict_proba(zb)[:, 1], 1e-7, 1 - 1e-7)


def _multi_head(a, y, b, c, balanced):
    scaler = StandardScaler()
    za, zb = scaler.fit_transform(a), scaler.transform(b)
    est = LogisticRegression(
        C=c, penalty="l2", solver="lbfgs", max_iter=5000,
        class_weight="balanced" if balanced else None,
        random_state=SEED)
    est.fit(za, y)
    p = H._aligned(est, zb)
    return np.clip(p[:, 1:].sum(axis=1), 1e-7, 1 - 1e-7)


def fit_grid(base_tr, harm_tr, cov_tr, ytr,
             base_te, harm_te, cov_te, config_ids=None):
    """Fit requested candidates, sharing each maximum-component PLS fit."""
    wanted = set(BY_ID) if config_ids is None else set(config_ids)
    cfgs = [BY_ID[n] for n in wanted]
    needed_modes = {c.mode for c in cfgs}
    needed_targets = {c.target for c in cfgs}
    blocks = _block_prep(base_tr, harm_tr, cov_tr,
                         base_te, harm_te, cov_te)
    out = {}
    for mode in MODES:
        if mode not in needed_modes:
            continue
        a, b = blocks[mode]
        for target in TARGETS:
            if target not in needed_targets or not any(
                    c.mode == mode and c.target == target for c in cfgs):
                continue
            yy = np.eye(3, dtype=float)[ytr] if target == "onehot" else (
                ytr > 0).astype(float)[:, None]
            subset = [c for c in cfgs
                      if c.mode == mode and c.target == target]
            nk = min(max(c.components for c in subset), len(a) - 2,
                     a.shape[1])
            pls = PLSRegression(n_components=nk, scale=False, max_iter=500,
                                tol=1e-6)
            pls.fit(a, yy)
            ta, tb = pls.transform(a), pls.transform(b)
            for cfg in subset:
                k = min(cfg.components, ta.shape[1])
                balanced = cfg.weight == "balanced"
                if target == "onehot":
                    s = _multi_head(ta[:, :k], ytr, tb[:, :k], cfg.c,
                                    balanced)
                else:
                    s = _binary_head(ta[:, :k], ytr > 0, tb[:, :k], cfg.c,
                                     balanced)
                out[cfg.id] = s.astype(np.float32)
    if set(out) != wanted:
        raise AssertionError(f"missing configs: {wanted - set(out)}")
    return out


def _agesex(base_tr, harm_tr, cov_tr, ytr,
            base_te, harm_te, cov_te):
    del base_tr, harm_tr, base_te, harm_te
    a, b = H._prep(cov_tr[["age", "sex_male"]],
                   cov_te[["age", "sex_male"]])
    return _binary_head(a, ytr > 0, b, 1.0, True).astype(np.float32)


def _priority(cfg: Config):
    # Existing PLS-10 first within the indifference margin, followed by the
    # least transformed and lowest-dimensional alternatives.
    if cfg.id == CURRENT_ID:
        return (0, 0, 0, 0, 0)
    mode_order = {"fusion": 0, "base": 1, "harm05": 2, "harm2": 3}
    target_order = {"onehot": 0, "neuro": 1}
    weight_order = {"empirical": 0, "balanced": 1}
    return (1, mode_order[cfg.mode], abs(cfg.components - 10),
            target_order[cfg.target], weight_order[cfg.weight], cfg.c)


def choose(y, oof):
    yy = y > 0
    scores = {name: float(roc_auc_score(yy, value))
              for name, value in oof.items()}
    top = max(scores.values())
    eligible = [name for name, score in scores.items()
                if score >= top - .003]
    picked = min(eligible, key=lambda name: _priority(BY_ID[name]))
    return picked, scores


def _outer_splits():
    _, y, *_ = H.data()
    return list(RepeatedStratifiedKFold(
        n_splits=5, n_repeats=3, random_state=SEED).split(
            np.zeros(len(y)), y))


def run_fold(oi):
    path = FOLDS / f"r{oi // 5}_f{oi % 5}.parquet"
    meta = path.with_suffix(".json")
    if path.exists() and meta.exists():
        return json.loads(meta.read_text(encoding="utf-8"))
    started = time.time()
    try:
        ids, y, base, harm, cov = H.data()
        tr, te = _outer_splits()[oi]
        inner = StratifiedKFold(n_splits=3, shuffle=True,
                               random_state=SEED + 1009 * oi)
        oof = {c.id: np.zeros(len(tr), dtype=np.float32) for c in CONFIGS}
        for it, iv in inner.split(np.zeros(len(tr)), y[tr]):
            got = fit_grid(
                base.iloc[tr[it]], harm.iloc[tr[it]], cov.iloc[tr[it]], y[tr[it]],
                base.iloc[tr[iv]], harm.iloc[tr[iv]], cov.iloc[tr[iv]])
            for name, score in got.items():
                oof[name][iv] = score
        selected, scores = choose(y[tr], oof)

        # Fit the whole declared fixed landscape. This does not affect the
        # nested selection made above, but allows an explicitly exploratory map.
        full = fit_grid(base.iloc[tr], harm.iloc[tr], cov.iloc[tr], y[tr],
                        base.iloc[te], harm.iloc[te], cov.iloc[te])
        age = _agesex(base.iloc[tr], harm.iloc[tr], cov.iloc[tr], y[tr],
                      base.iloc[te], harm.iloc[te], cov.iloc[te])
        out = pd.DataFrame({
            "participant_id": ids[te].astype(str), "y_true": y[te],
            "repeat": oi // 5, "fold": oi % 5,
            "demographics_only__agesex": age,
            "nested_adaptive_pls": full[selected],
            **full,
        })
        out.to_parquet(path, index=False)
        order = sorted(scores, key=scores.get, reverse=True)
        rec = {
            "job_id": path.stem, "status": "ok", "selected": selected,
            "selected_inner_auc": scores[selected],
            "top_inner_auc": scores[order[0]], "top_inner_config": order[0],
            "current_inner_auc": scores[CURRENT_ID],
            "seconds": round(time.time() - started, 2),
        }
    except Exception as exc:
        rec = {
            "job_id": path.stem, "status": "error",
            "error": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc()[-7000:],
            "seconds": round(time.time() - started, 2),
        }
    meta.write_text(json.dumps(rec), encoding="utf-8")
    return rec


def aggregate():
    files = sorted(FOLDS.glob("r*_f*.parquet"))
    if len(files) != 15:
        raise RuntimeError(f"expected 15 folds, found {len(files)}")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    score_cols = ["demographics_only__agesex", "nested_adaptive_pls"] + [
        c.id for c in CONFIGS]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in score_cols}})
    d.to_parquet(OUT / "oof_screen_predictions.parquet")
    return raw, d


def _metrics(y, p):
    case = y > 0
    return {
        "pd_vs_ci_auc": roc_auc_score(y[case] == 1, M.conditional(p[case])),
        "three_class_macro_auc": roc_auc_score(
            y, p, multi_class="ovr", average="macro"),
        "neuro_auc": roc_auc_score(y > 0, p[:, 1:].sum(axis=1)),
        "pd_vs_all_auc": roc_auc_score(y == 1, p[:, 1]),
        "ci_vs_all_auc": roc_auc_score(y == 2, p[:, 2]),
    }


def _threshold_tables(y, scores):
    rows, mats = [], []
    q = scores.pop("_locked_q")
    for name, screen in scores.items():
        for threshold in np.arange(.1, 1.0, .1):
            called = screen >= threshold
            pred = np.zeros(len(y), dtype=int)
            pred[called] = np.where(q[called] >= .5, 1, 2)
            cm = confusion_matrix(y, pred, labels=[0, 1, 2])
            yy = y > 0
            rows.append({
                "model": name, "screen_threshold": round(threshold, 1),
                "neuro_sensitivity": float((called & yy).sum() / yy.sum()),
                "neuro_specificity": float((~called & ~yy).sum() / (~yy).sum()),
                "screen_positive": int(called.sum()),
            })
            for true in range(3):
                for predicted in range(3):
                    mats.append({
                        "model": name, "screen_threshold": round(threshold, 1),
                        "true_class": ("neither", "PD", "CI")[true],
                        "predicted_class": ("neither", "PD", "CI")[predicted],
                        "n": int(cm[true, predicted]),
                    })
    return pd.DataFrame(rows), pd.DataFrame(mats)


def report(bootstraps=5000):
    raw, d = aggregate()
    y = d.y_true.to_numpy(int)
    old = pd.read_parquet(H.OUT / "oof_predictions.parquet").reindex(d.index)
    if old.y_true.to_numpy(int).tolist() != y.tolist():
        raise AssertionError("locked prediction labels do not align")
    anchor = old[[f"anchor_pca100_lda_p{i}" for i in range(3)]].to_numpy(float)
    prior = old[[f"fusion_pls10_ridge_p{i}" for i in range(3)]].to_numpy(float)
    q = M.conditional(anchor)
    screens = {
        "demographics_only__agesex": d["demographics_only__agesex"].to_numpy(),
        "locked_pca100_lda": anchor[:, 1:].sum(axis=1),
        "prior_fixed_pls10": prior[:, 1:].sum(axis=1),
        "grid_reproduced_pls10": d[CURRENT_ID].to_numpy(),
        "nested_adaptive_pls": d["nested_adaptive_pls"].to_numpy(),
    }
    probs = {"locked_pca100_lda": anchor}
    for name in ("prior_fixed_pls10", "grid_reproduced_pls10",
                 "nested_adaptive_pls"):
        probs[name] = M.compose(screens[name], q)
    metric_rows = [{"model": name, **_metrics(y, p)}
                   for name, p in probs.items()]
    metrics = pd.DataFrame(metric_rows).sort_values("neuro_auc", ascending=False)
    metrics.to_csv(OUT / "stagewise_metrics.csv", index=False)

    # The full fixed landscape is useful for mechanism/hyperparameter mapping,
    # but its best row is not an unbiased selected-model estimate.
    fixed = pd.DataFrame([
        {**asdict(cfg), "config_id": cfg.id,
         "neuro_auc": roc_auc_score(y > 0, d[cfg.id])}
        for cfg in CONFIGS]).sort_values("neuro_auc", ascending=False)
    fixed["delta_vs_prior_fixed_pls10"] = (
        fixed.neuro_auc - roc_auc_score(y > 0, screens["prior_fixed_pls10"]))
    fixed.to_csv(OUT / "exploratory_fixed_grid.csv", index=False)

    comp_rows = []
    comparisons = [
        ("prior_fixed_pls10", "locked_pca100_lda"),
        ("nested_adaptive_pls", "locked_pca100_lda"),
        ("nested_adaptive_pls", "prior_fixed_pls10"),
        ("prior_fixed_pls10", "demographics_only__agesex"),
        ("nested_adaptive_pls", "demographics_only__agesex"),
    ]
    yy = y > 0
    for candidate, reference in comparisons:
        delta, p_delong = CB.delong_test(
            yy, screens[candidate], screens[reference])
        comp_rows.append({
            "candidate": candidate, "reference": reference,
            "candidate_auc": roc_auc_score(yy, screens[candidate]),
            "reference_auc": roc_auc_score(yy, screens[reference]),
            "delta_delong": delta, "p_delong": p_delong,
            **T._fast_bootstrap_pair(yy, screens[candidate],
                                     screens[reference], bootstraps),
        })
    comp = pd.DataFrame(comp_rows)
    comp["fdr_q"] = E._bh(comp.p_delong)
    comp.to_csv(OUT / "paired_screen_comparisons.csv", index=False)

    meta = pd.DataFrame([json.loads(p.read_text(encoding="utf-8"))
                         for p in sorted(FOLDS.glob("r*_f*.json"))])
    meta.to_csv(OUT / "fold_selections.csv", index=False)
    counts = meta.selected.value_counts().rename_axis("config_id").reset_index(
        name="outer_folds_selected")
    parsed = pd.DataFrame([{"config_id": c.id, **asdict(c)} for c in CONFIGS])
    counts = counts.merge(parsed, on="config_id", how="left")
    counts.to_csv(OUT / "selection_counts.csv", index=False)

    ops, cm = _threshold_tables(y, {
        "_locked_q": q.copy(),
        "locked_pca100_lda": screens["locked_pca100_lda"],
        "prior_fixed_pls10": screens["prior_fixed_pls10"],
        "nested_adaptive_pls": screens["nested_adaptive_pls"],
    })
    ops.to_csv(OUT / "screen_threshold_operating_points.csv", index=False)
    cm.to_csv(OUT / "three_class_confusion_matrices.csv", index=False)

    current_diff = np.abs(screens["grid_reproduced_pls10"] -
                          screens["prior_fixed_pls10"])
    qualify_row = comp[(comp.candidate == "nested_adaptive_pls") &
                       (comp.reference == "locked_pca100_lda")].iloc[0]
    mm = metrics.set_index("model")
    qualifies = bool(
        qualify_row.delta_lo > 0 and qualify_row.fdr_q < .05 and
        mm.loc["locked_pca100_lda", "three_class_macro_auc"] -
        mm.loc["nested_adaptive_pls", "three_class_macro_auc"] <= .01 and
        abs(mm.loc["locked_pca100_lda", "pd_vs_ci_auc"] -
            mm.loc["nested_adaptive_pls", "pd_vs_ci_auc"]) < 1e-10)

    top = fixed.head(20)
    lines = [
        "# PLS neurological-screen refinement", "",
        "The adaptive result below is the honest internal estimate of the full "
        "PLS search. The fixed-grid ranking is exploratory because its rows were "
        "ranked on their outer held-out outcomes.", "", "## Stagewise performance", "",
        R.markdown_table(metrics.round(4)), "", "## Paired screen comparisons", "",
        R.markdown_table(comp.round(4)), "", "## Nested selections", "",
        R.markdown_table(counts), "", "## Top exploratory fixed configurations", "",
        R.markdown_table(top.round(4)), "", "## Reproduction audit", "",
        f"The grid implementation's nominal PLS-10 screen differs from the prior "
        f"fixed PLS-10 screen by mean absolute {current_diff.mean():.3g} and "
        f"maximum absolute {current_diff.max():.3g} probability.", "",
        "## Decision", "",
        ("The nested PLS screen meets the prespecified internal promotion rule."
         if qualifies else
         "The nested PLS screen does not meet the prespecified internal promotion rule."),
        "This cohort already motivated the PLS search, so all results remain "
        "internal and require new same-protocol external/site validation.", "",
    ]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))
    print(comp.to_string(index=False))
    print(counts.to_string(index=False))
    print("top fixed")
    print(top.head(10).to_string(index=False))
    print("reproduction", current_diff.mean(), current_diff.max())


def audit():
    ids, y, base, harm, cov = H.data()
    print(f"n={len(ids)} classes={dict(pd.Series(y).value_counts().sort_index())}")
    print(f"base={base.shape} harmonic={harm.shape} cov={cov.shape}")
    print(f"configs={len(CONFIGS)} current={CURRENT_ID}")
    print(pd.DataFrame([asdict(c) | {"config_id": c.id}
                        for c in CONFIGS]).groupby(
                            ["mode", "target"]).size())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run", "report"])
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--bootstraps", type=int, default=5000)
    args = ap.parse_args()
    if args.command == "audit":
        return audit()
    if args.command == "report":
        return report(args.bootstraps)
    if not 1 <= args.jobs <= 8:
        raise ValueError("--jobs must be between 1 and 8")
    audit()
    todo = [i for i in range(15) if not (
        FOLDS / f"r{i // 5}_f{i % 5}.parquet").exists()]
    print(f"PLS refinement: {len(todo)}/15 folds pending", flush=True)
    for start in range(0, len(todo), args.jobs):
        batch = todo[start:start + args.jobs]
        ans = Parallel(n_jobs=args.jobs, prefer="threads")(
            delayed(run_fold)(i) for i in batch)
        for rec in ans:
            print(rec["job_id"], rec["status"], rec.get("selected", ""),
                  rec.get("error", ""), rec.get("seconds", ""), flush=True)
        if any(r["status"] != "ok" for r in ans):
            raise RuntimeError("one or more fold jobs failed; inspect fold JSON")
    report(args.bootstraps)


if __name__ == "__main__":
    main()
