"""Feature-space catalogue for the exhaustive, nested PD/CI study.

Representations are fixed by acoustic meaning and aggregation rule.  Labels are
never consulted here.  Matrices are materialised once as float32 ``.npy`` files
so nested workers can memory-map them without duplicating several gigabytes.
"""
from __future__ import annotations

import json
import re
import sys
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import pdci_tasks as PT  # noqa: E402
from pdci_informed_ensemble import CONSTRUCTS  # noqa: E402

OUT = C.RESULTS / "pdci_exhaustive"
CACHE = OUT / "cache"
OUT.mkdir(parents=True, exist_ok=True)
CACHE.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class Recipe:
    name: str
    group: str
    operator: str


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)


def cache_stem(design: str, recipe: str) -> Path:
    return CACHE / f"{_safe(design)}__{_safe(recipe)}"


def recipe_catalog_path(design: str) -> Path:
    return CACHE / f"{_safe(design)}__recipe_catalog.json"


@lru_cache(maxsize=1)
def all_task_blocks() -> pd.DataFrame:
    """Existing acoustic blocks plus raw-tensor summaries, with safe prefixes."""
    base = PT.task_blocks()
    tp = C.DATA / "tensor_bytask.parquet"
    if not tp.exists():
        raise FileNotFoundError(f"run extract_tensor_geometry.py first: {tp}")
    tn = pd.read_parquet(tp).copy()
    tn.columns = [f"tn__{c}" for c in tn.columns]
    out = pd.concat([base, tn], axis=1, join="outer")
    out = out.loc[:, ~out.columns.duplicated()]
    return out.replace([np.inf, -np.inf], np.nan).astype(np.float32)


def feature_groups() -> dict[str, list[str]]:
    cols = list(all_task_blocks().columns)

    def pref(*p):
        return [c for c in cols if c.startswith(p)]

    groups = {
        "static": pref("st__"),
        "dynamic": pref("dy__"),
        "timeresolved": pref("tr__"),
        "tensor_all": pref("tn__"),
    }
    groups["all"] = groups["static"] + groups["dynamic"] + groups["timeresolved"]
    groups["all_tensor"] = groups["all"] + groups["tensor_all"]

    groups["tensor_pairs"] = [c for c in groups["tensor_all"] if "_corr_c" in c]
    groups["tensor_3d"] = [c for c in groups["tensor_all"] if "tensor_3d_" in c]
    groups["tensor_summary"] = [c for c in groups["tensor_all"]
                                if c not in set(groups["tensor_pairs"])]

    dyn_modal = {
        "prosody": "dy__prosody_", "ema": "dy__ema_", "ppg": "dy__ppg_",
        "mfcc": "dy__mfccdyn_", "ltas": "dy__ltas_",
    }
    for name, p in dyn_modal.items():
        groups[f"dynamic_{name}"] = [c for c in cols if c.startswith(p)]
    tr_modal = {"joint": "tr__joint_", "xcoupling": "tr__xcoup_", "rqa": "tr__rqa_"}
    for name, p in tr_modal.items():
        groups[f"timeresolved_{name}"] = [c for c in cols if c.startswith(p)]
    for name in ("ppg", "ema", "mel", "mfcc", "spectrogram"):
        groups[f"tensor_{name}"] = [c for c in cols
                                     if c.startswith(f"tn__tensor_{name}_")]

    # Label-blind clinical constructs.  Coverage/duration patterns are excluded
    # because task presence must never become a predictor.
    acoustic = groups["all_tensor"]
    for name, pats in CONSTRUCTS:
        if name == "coverage":
            continue
        take = [c for c in acoustic if any(p.lower() in c.lower() for p in pats)
                and "dur_s" not in c and "n_frames" not in c]
        if len(take) >= 8:
            groups[f"construct_{name}"] = take
    return {k: list(dict.fromkeys(v)) for k, v in groups.items() if v}


def recipes(design: str) -> list[Recipe]:
    """Broad, prespecified representation catalogue (no outcome information)."""
    # Persist the label-blind catalogue once it has been constructed.  This is
    # more than a speed optimization on Windows: loky workers otherwise each
    # rebuild ``feature_groups()``, materialising the full 10,538 x 2,185
    # participant-task table in every process before they can memory-map the
    # already-built design matrices.
    catalog_path = recipe_catalog_path(design)
    if catalog_path.exists():
        payload = json.loads(catalog_path.read_text(encoding="utf-8"))
        return [Recipe(**r) for r in payload]

    out: list[Recipe] = []

    core = ["static", "dynamic", "timeresolved", "all", "tensor_summary",
            "tensor_pairs", "tensor_3d", "tensor_all", "all_tensor"]
    for g in core:
        out.append(Recipe(f"avg_{g}", g, "avg"))
        out.append(Recipe(f"mean_sd_{g}", g, "mean_sd"))
    for g in ["dynamic", "all", "tensor_all", "all_tensor"]:
        out.append(Recipe(f"robust_{g}", g, "robust"))
    for g in core:
        out.append(Recipe(f"per_task_{g}", g, "per_task"))
    for g in ["dynamic", "all", "tensor_all", "all_tensor"]:
        out.append(Recipe(f"per_task_plus_stats_{g}", g, "per_task_plus_stats"))

    modality = [
        "dynamic_prosody", "dynamic_ema", "dynamic_ppg", "dynamic_mfcc",
        "dynamic_ltas", "timeresolved_joint", "timeresolved_xcoupling",
        "timeresolved_rqa", "tensor_ppg", "tensor_ema", "tensor_mel",
        "tensor_mfcc", "tensor_spectrogram",
    ]
    for g in modality:
        out.append(Recipe(f"avg_{g}", g, "avg"))
        out.append(Recipe(f"per_task_{g}", g, "per_task"))

    for g in sorted(k for k in feature_groups() if k.startswith("construct_")):
        out.append(Recipe(f"mean_sd_{g}", g, "mean_sd"))

    if design == "combined":
        for g in ["dynamic", "timeresolved", "all", "tensor_summary", "tensor_3d",
                  "tensor_all", "all_tensor"]:
            out.append(Recipe(f"split_avg_{g}", g, "split_avg"))
            out.append(Recipe(f"split_mean_sd_{g}", g, "split_mean_sd"))
            out.append(Recipe(f"per_task_plus_split_{g}", g, "per_task_plus_split"))

    # Explicit task contrasts (and general-vs-neuro contrasts for combined).
    out.append(Recipe("engineered_contrasts_all", "all", "contrasts"))
    out.append(Recipe("engineered_contrasts_all_tensor", "all_tensor", "contrasts"))
    # Preserve insertion order and guarantee stable unique names.
    result = list({r.name: r for r in out}.values())
    catalog_path.write_text(json.dumps([asdict(r) for r in result]),
                            encoding="utf-8")
    return result


def _task_frame(design: str, columns: list[str], ids: pd.Index) -> pd.DataFrame:
    tasks = PT.DESIGN_TASKS[design]
    idx = pd.MultiIndex.from_product([ids, tasks],
                                     names=["participant_id", "task_group"])
    return all_task_blocks()[columns].reindex(idx)


def _rename(d: pd.DataFrame, tag: str) -> pd.DataFrame:
    d = d.copy()
    d.columns = [f"{tag}__{c}" for c in d.columns]
    return d


def _mean_sd(bt: pd.DataFrame, tag="") -> pd.DataFrame:
    g = bt.groupby(level="participant_id")
    return pd.concat([_rename(g.mean(), f"{tag}mean"),
                      _rename(g.std(), f"{tag}sd")], axis=1)


def _robust(bt: pd.DataFrame) -> pd.DataFrame:
    g = bt.groupby(level="participant_id")
    mean, sd = g.mean(), g.std()
    med = g.median()
    q25 = g.quantile(0.25)
    q75 = g.quantile(0.75)
    return pd.concat([_rename(mean, "mean"), _rename(sd, "sd"),
                      _rename(med, "median"), _rename(q75 - q25, "iqr")], axis=1)


def _per_task(bt: pd.DataFrame, tasks: list[str]) -> pd.DataFrame:
    w = bt.unstack("task_group").reindex(columns=pd.MultiIndex.from_product(
        [bt.columns, tasks]))
    w.columns = [f"task__{task}__{col}" for col, task in w.columns]
    return w


def _split(bt: pd.DataFrame, operator: str) -> pd.DataFrame:
    gmask = bt.index.get_level_values("task_group").isin(PT.GENERAL_TASKS)
    nmask = bt.index.get_level_values("task_group").isin(PT.NEURO_TASKS)
    if operator == "split_avg":
        return pd.concat([
            _rename(bt[gmask].groupby(level="participant_id").mean(), "general_mean"),
            _rename(bt[nmask].groupby(level="participant_id").mean(), "neuro_mean"),
        ], axis=1)
    return pd.concat([_mean_sd(bt[gmask], "general_"),
                      _mean_sd(bt[nmask], "neuro_")], axis=1)


def _contrasts(design: str, columns: list[str], ids: pd.Index) -> pd.DataFrame:
    bt = all_task_blocks()[columns]
    pairs = []
    for a, b, tag in PT.GENERAL_CONTRASTS + PT.NEURO_CONTRASTS:
        if a not in PT.DESIGN_TASKS[design] or b not in PT.DESIGN_TASKS[design]:
            continue
        xa = bt.xs(a, level="task_group").reindex(ids)
        xb = bt.xs(b, level="task_group").reindex(ids)
        z = xa - xb
        z.columns = [f"contrast__{tag}__{c}" for c in z.columns]
        pairs.append(z)
    # Always retain cross-task location/scale alongside the explicit contrasts.
    base = _mean_sd(_task_frame(design, columns, ids))
    out = [base, *pairs]
    if design == "combined":
        full = _task_frame(design, columns, ids)
        gm = full[full.index.get_level_values("task_group").isin(PT.GENERAL_TASKS)] \
            .groupby(level="participant_id").mean()
        nm = full[full.index.get_level_values("task_group").isin(PT.NEURO_TASKS)] \
            .groupby(level="participant_id").mean()
        delta = nm - gm
        delta.columns = [f"battery_delta__{c}" for c in delta.columns]
        rel = 2 * (nm - gm) / (nm.abs() + gm.abs()).replace(0, np.nan)
        rel.columns = [f"battery_relative__{c}" for c in rel.columns]
        out += [delta, rel]
    return pd.concat(out, axis=1)


def build_audio(design: str, recipe: Recipe, ids: pd.Index) -> pd.DataFrame:
    groups = feature_groups()
    columns = groups[recipe.group]
    bt = _task_frame(design, columns, ids)
    op = recipe.operator
    if op == "avg":
        return _rename(bt.groupby(level="participant_id").mean(), "mean")
    if op == "mean_sd":
        return _mean_sd(bt)
    if op == "robust":
        return _robust(bt)
    if op == "per_task":
        return _per_task(bt, PT.DESIGN_TASKS[design])
    if op == "per_task_plus_stats":
        return pd.concat([_per_task(bt, PT.DESIGN_TASKS[design]), _robust(bt)], axis=1)
    if op in {"split_avg", "split_mean_sd"}:
        return _split(bt, op)
    if op == "per_task_plus_split":
        return pd.concat([_per_task(bt, PT.DESIGN_TASKS[design]),
                          _split(bt, "split_mean_sd")], axis=1)
    if op == "contrasts":
        return _contrasts(design, columns, ids)
    raise ValueError(op)


def build_matrix(design: str, recipe: Recipe, force: bool = False) -> dict:
    stem = cache_stem(design, recipe.name)
    matrix_path = stem.with_suffix(".npy")
    manifest_path = stem.with_suffix(".json")
    if matrix_path.exists() and manifest_path.exists() and not force:
        return json.loads(manifest_path.read_text(encoding="utf-8"))

    ids = PT.ids_for_design(design)
    audio = build_audio(design, recipe, ids).reindex(ids)
    audio = audio.replace([np.inf, -np.inf], np.nan)
    # Unsupervised availability/constant filtering.  Complete-task eligibility
    # makes this incapable of encoding whether a requested task was performed.
    audio = audio.loc[:, audio.notna().mean() >= 0.50]
    audio = audio.loc[:, audio.nunique(dropna=True) > 1]
    cov = PT.covariates(ids, design)
    x = pd.concat([audio.astype(np.float32), cov.astype(np.float32)], axis=1)
    x = x.loc[:, ~x.columns.duplicated()]
    np.save(matrix_path, x.to_numpy(dtype=np.float32, copy=False))
    manifest = {
        "design": design,
        "recipe": asdict(recipe),
        "ids": [str(i) for i in x.index],
        "columns": list(x.columns),
        "n": len(x),
        "n_features": x.shape[1],
        "n_audio": audio.shape[1],
        "n_covariates": cov.shape[1],
        "missing_fraction": float(x.isna().to_numpy().mean()),
        "matrix": str(matrix_path),
    }
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    return manifest


def build_all(designs: list[str], force: bool = False) -> pd.DataFrame:
    rows = []
    for design in designs:
        rr = recipes(design)
        for i, recipe in enumerate(rr, 1):
            m = build_matrix(design, recipe, force=force)
            rows.append({k: v for k, v in m.items() if k not in {"ids", "columns"}})
            print(f"[{design} {i:03d}/{len(rr):03d}] {recipe.name}: "
                  f"{m['n']} x {m['n_features']} ({m['n_audio']} audio)", flush=True)
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "feature_manifest.csv", index=False)
    return d


def load_manifest(design: str, recipe: str) -> dict:
    return json.loads(cache_stem(design, recipe).with_suffix(".json").read_text(
        encoding="utf-8"))


def load_matrix(design: str, recipe: str, mmap=True) -> tuple[np.ndarray, dict]:
    m = load_manifest(design, recipe)
    return np.load(m["matrix"], mmap_mode="r" if mmap else None), m
