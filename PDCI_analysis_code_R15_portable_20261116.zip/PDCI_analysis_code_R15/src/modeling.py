"""Nested cross-validation harness.

The methodological point of this module: **feature selection and
hyperparameter tuning happen strictly inside the training folds.**  Selecting
the top-k features on the full dataset and then cross-validating the resulting
model is the standard way to manufacture a 0.95 ROC-AUC out of noise, and it is
the most likely explanation for high-AUC/low-F1 result patterns.

Every estimator is a Pipeline of
    median impute -> standardise -> variance filter -> SelectKBest -> model
and `k` is itself a tuned hyperparameter, so nothing outside a training fold
ever touches the selection.
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.feature_selection import SelectKBest, VarianceThreshold, f_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score,
                             balanced_accuracy_score, brier_score_loss, confusion_matrix,
                             f1_score, matthews_corrcoef, precision_score, recall_score,
                             roc_auc_score, roc_curve)
from sklearn.model_selection import (GridSearchCV, RepeatedStratifiedKFold,
                                     StratifiedKFold, cross_val_predict)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402

warnings.filterwarnings("ignore")

# Feature-set sizes to try inside each training fold.  Kept to four values:
# the sweep is 1700+ configurations and every extra k multiplies every inner
# fit.  5/15 bracket the team's existing top-5/top-15 convention.
K_GRID = [5, 15, 40, 100]


class Winsorizer(BaseEstimator, TransformerMixin):
    """Clip every column to training-fold quantiles.

    Several acoustic features are pathologically heavy-tailed -- spectral
    kurtosis reaches 21000 against a median of 23, and coefficients of
    variation computed on interval scales blow up when the mean approaches
    zero.  Under StandardScaler a single such recording dominates the whole
    column, and distance- and gradient-based learners follow it.  Limits are
    learned on training data only, so this leaks nothing.
    """

    def __init__(self, lower=0.005, upper=0.995):
        self.lower = lower
        self.upper = upper

    def fit(self, X, y=None):
        A = np.asarray(X, dtype=float)
        self.lo_ = np.nanquantile(A, self.lower, axis=0)
        self.hi_ = np.nanquantile(A, self.upper, axis=0)
        same = ~np.isfinite(self.lo_) | ~np.isfinite(self.hi_) | (self.hi_ <= self.lo_)
        self.lo_[same], self.hi_[same] = -np.inf, np.inf
        return self

    def transform(self, X):
        return np.clip(np.asarray(X, dtype=float), self.lo_, self.hi_)


def make_prep():
    """The unsupervised half of the pipeline.

    Winsorising, imputing, scaling and variance-filtering never look at y, so
    fitting them once per outer training fold is equivalent to refitting them
    inside every inner fold -- and with ~6500 features it is the difference
    between a two-hour sweep and a nine-hour one, because otherwise these four
    steps run for every hyperparameter combination.  Everything that *does*
    look at y (SelectKBest, the classifier) stays inside the inner CV, which is
    what actually protects against selection leakage.
    """
    return Pipeline([
        ("winsor", Winsorizer()),
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("var", VarianceThreshold(threshold=1e-8)),
    ])


def make_model(name: str, seed: int = C.RANDOM_STATE):
    """Return (supervised_pipeline, param_grid)."""
    steps = [("select", SelectKBest(score_func=f_classif, k=15))]
    g = {"select__k": K_GRID}

    if name == "dummy":
        return Pipeline(steps + [("clf", DummyClassifier(strategy="prior"))]), \
            {"select__k": [5]}

    if name == "logreg_l2":
        clf = LogisticRegression(penalty="l2", solver="liblinear", max_iter=4000,
                                 class_weight="balanced", random_state=seed)
        g |= {"clf__C": [0.01, 0.1, 1.0, 10.0]}
    elif name == "logreg_l1":
        clf = LogisticRegression(penalty="l1", solver="liblinear", max_iter=4000,
                                 class_weight="balanced", random_state=seed)
        g |= {"clf__C": [0.03, 0.1, 1.0, 10.0]}
    elif name == "elasticnet":
        clf = LogisticRegression(penalty="elasticnet", solver="saga", max_iter=6000,
                                 class_weight="balanced", random_state=seed)
        g |= {"clf__C": [0.05, 0.5, 5.0], "clf__l1_ratio": [0.2, 0.5, 0.8]}
    elif name == "random_forest":
        clf = RandomForestClassifier(n_estimators=300, min_samples_leaf=2,
                                     class_weight="balanced_subsample",
                                     n_jobs=1, random_state=seed)
        g |= {"clf__max_depth": [None, 6]}
    elif name == "extra_trees":
        clf = ExtraTreesClassifier(n_estimators=300, min_samples_leaf=2,
                                   class_weight="balanced", n_jobs=1, random_state=seed)
        g |= {"clf__max_depth": [None, 8]}
    elif name == "svm_rbf":
        clf = SVC(kernel="rbf", probability=True, class_weight="balanced",
                  random_state=seed)
        g |= {"clf__C": [1.0, 10.0]}
    elif name == "xgboost":
        from xgboost import XGBClassifier
        clf = XGBClassifier(n_estimators=250, learning_rate=0.06, max_depth=3,
                            subsample=0.8, colsample_bytree=0.8, n_jobs=1,
                            eval_metric="logloss", random_state=seed,
                            tree_method="hist")
        g |= {"clf__max_depth": [2, 4]}
    elif name == "lightgbm":
        from lightgbm import LGBMClassifier
        clf = LGBMClassifier(n_estimators=250, learning_rate=0.06, num_leaves=15,
                             subsample=0.8, colsample_bytree=0.8, n_jobs=1,
                             class_weight="balanced", verbose=-1, random_state=seed)
        g |= {"clf__num_leaves": [7, 31]}
    else:
        raise ValueError(f"unknown model {name}")
    return Pipeline(steps + [("clf", clf)]), g


MODELS_SCREEN = ["dummy", "logreg_l2", "logreg_l1", "random_forest", "svm_rbf", "xgboost"]
MODELS_FULL = MODELS_SCREEN + ["elasticnet", "extra_trees", "lightgbm"]


# ------------------------------------------------------------------ metrics
def _spec(y, yhat):
    tn, fp, fn, tp = confusion_matrix(y, yhat, labels=[0, 1]).ravel()
    return tn / (tn + fp) if (tn + fp) else np.nan


def threshold_metrics(y, prob, thr, suffix=""):
    yhat = (prob >= thr).astype(int)
    return {
        f"accuracy{suffix}": accuracy_score(y, yhat),
        f"balanced_accuracy{suffix}": balanced_accuracy_score(y, yhat),
        f"precision{suffix}": precision_score(y, yhat, zero_division=0),
        f"recall{suffix}": recall_score(y, yhat, zero_division=0),
        f"specificity{suffix}": _spec(y, yhat),
        f"f1{suffix}": f1_score(y, yhat, zero_division=0),
        f"mcc{suffix}": matthews_corrcoef(y, yhat) if len(np.unique(yhat)) > 1 else 0.0,
        f"threshold{suffix}": float(thr),
    }


def score_predictions(y, prob, thr_tuned=None):
    y = np.asarray(y)
    prob = np.asarray(prob)
    out = {
        "roc_auc": roc_auc_score(y, prob) if len(np.unique(y)) > 1 else np.nan,
        "pr_auc": average_precision_score(y, prob),
        "brier": brier_score_loss(y, prob),
        "prevalence": float(y.mean()),
    }
    out |= threshold_metrics(y, prob, 0.5, "_at50")
    # Prevalence-matched threshold: flag the top `prevalence` fraction of
    # scores.  Needs no labels, so it costs nothing in leakage terms and is
    # far more informative than 0.5 under heavy imbalance.
    q = np.quantile(prob, 1 - y.mean()) if 0 < y.mean() < 1 else 0.5
    out |= threshold_metrics(y, prob, q, "_atprev")
    if thr_tuned is not None:
        out |= threshold_metrics(y, prob, thr_tuned, "_attuned")
    return out


def youden_threshold(y, prob):
    if len(np.unique(y)) < 2:
        return 0.5
    fpr, tpr, thr = roc_curve(y, prob)
    return float(thr[np.argmax(tpr - fpr)])


# ------------------------------------------------------------------ evaluation
def evaluate(X: pd.DataFrame, y: pd.Series, model_name: str, n_splits: int = 5,
             n_repeats: int = 1, tune_threshold: bool = False, inner_cv: int = 3,
             seed: int = C.RANDOM_STATE, n_jobs_inner: int = 1):
    """Nested CV.  Returns (metrics dict, per-participant prediction frame)."""
    pipe, grid = make_model(model_name, seed)
    n_pos = int(y.sum())
    inner_k = max(2, min(inner_cv, n_pos // 4)) if n_pos >= 8 else 2

    # Never ask SelectKBest for more features than exist.
    grid = dict(grid)
    grid["select__k"] = [k for k in grid["select__k"] if k <= X.shape[1]] or [X.shape[1]]

    outer = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats,
                                    random_state=seed)
    rows = []
    fold_aucs = []
    for fold, (tr, te) in enumerate(outer.split(X, y)):
        Xtr, Xte = X.iloc[tr], X.iloc[te]
        ytr, yte = y.iloc[tr], y.iloc[te]

        prep = make_prep()
        Xtr_t = prep.fit_transform(Xtr)
        Xte_t = prep.transform(Xte)

        gs = GridSearchCV(clone(pipe), grid, scoring="roc_auc",
                          cv=StratifiedKFold(inner_k, shuffle=True, random_state=seed),
                          n_jobs=n_jobs_inner, refit=True, error_score=np.nan)
        gs.fit(Xtr_t, ytr)
        best = gs.best_estimator_

        prob = best.predict_proba(Xte_t)[:, 1]
        thr = np.nan
        if tune_threshold:
            # Threshold chosen from held-out predictions *within the training
            # fold* -- never from the test fold.
            oof_tr = cross_val_predict(
                clone(best), Xtr_t, ytr,
                cv=StratifiedKFold(inner_k, shuffle=True, random_state=seed),
                method="predict_proba", n_jobs=n_jobs_inner)[:, 1]
            thr = youden_threshold(ytr, oof_tr)

        if len(np.unique(yte)) > 1:
            fold_aucs.append(roc_auc_score(yte, prob))
        rows.append(pd.DataFrame({
            "participant_id": Xte.index, "repeat": fold // n_splits, "fold": fold % n_splits,
            "y_true": yte.values, "prob": prob, "fold_threshold": thr,
            "best_k": gs.best_params_.get("select__k", np.nan),
        }))

    preds = pd.concat(rows, ignore_index=True)
    # Average the repeats so each participant contributes one score.
    per_part = preds.groupby("participant_id").agg(
        y_true=("y_true", "first"), prob=("prob", "mean"),
        fold_threshold=("fold_threshold", "mean"), best_k=("best_k", "median"))

    thr_tuned = per_part["fold_threshold"].mean() if tune_threshold else None
    m = score_predictions(per_part["y_true"], per_part["prob"], thr_tuned)
    m["auc_fold_mean"] = float(np.mean(fold_aucs)) if fold_aucs else np.nan
    m["auc_fold_std"] = float(np.std(fold_aucs)) if fold_aucs else np.nan
    m["n_folds"] = len(fold_aucs)
    m["median_selected_k"] = float(per_part["best_k"].median())

    per_part = per_part.copy()
    thr_use = thr_tuned if thr_tuned is not None else \
        np.quantile(per_part["prob"], 1 - per_part["y_true"].mean())
    per_part["y_pred"] = (per_part["prob"] >= thr_use).astype(int)
    per_part["correct"] = (per_part["y_pred"] == per_part["y_true"]).astype(int)
    per_part["error_type"] = np.where(
        per_part["correct"] == 1, "correct",
        np.where(per_part["y_true"] == 1, "false_negative", "false_positive"))
    return m, per_part


def permutation_test(X, y, model_name, observed_auc, n_perm=200, n_splits=5,
                     seed=C.RANDOM_STATE):
    """Empirical p-value for ROC-AUC against label-shuffled nulls.

    This is the honest significance test for a whole modelling pipeline: it
    reruns the entire nested procedure on permuted labels, so any optimism
    baked into the pipeline shows up in the null as well.
    """
    rng = np.random.default_rng(seed)
    null = []
    for i in range(n_perm):
        yp = pd.Series(rng.permutation(y.values), index=y.index)
        try:
            m, _ = evaluate(X, yp, model_name, n_splits=n_splits, n_repeats=1,
                            seed=seed + i)
            null.append(m["roc_auc"])
        except Exception:
            continue
    null = np.asarray([v for v in null if np.isfinite(v)])
    if not null.size:
        return {"perm_p": np.nan, "perm_null_mean": np.nan, "perm_null_p95": np.nan,
                "n_perm": 0}
    return {
        "perm_p": float((1 + (null >= observed_auc).sum()) / (1 + null.size)),
        "perm_null_mean": float(null.mean()),
        "perm_null_p95": float(np.quantile(null, 0.95)),
        "n_perm": int(null.size),
    }


# ------------------------------------------------------------------ explanation
def explain(X: pd.DataFrame, y: pd.Series, model_name: str, n_boot: int = 200,
            inner_cv: int = 3, seed: int = C.RANDOM_STATE):
    """Refit on all data and describe which features drive the model.

    Reports bootstrap *selection stability* rather than a naive post-selection
    p-value: after data-driven feature selection, the classical p-value on the
    selected features is not valid, whereas "this feature survived selection in
    83% of bootstrap resamples, with a consistently positive coefficient" is.
    """
    pipe, grid = make_model(model_name, seed)
    grid = dict(grid)
    grid["select__k"] = [k for k in grid["select__k"] if k <= X.shape[1]] or [X.shape[1]]
    n_pos = int(y.sum())
    inner_k = max(2, min(inner_cv, n_pos // 4)) if n_pos >= 8 else 2

    prep = make_prep()
    Xt = prep.fit_transform(X)
    kept = np.asarray(X.columns)[prep.named_steps["var"].get_support()]

    gs = GridSearchCV(clone(pipe), grid, scoring="roc_auc",
                      cv=StratifiedKFold(inner_k, shuffle=True, random_state=seed),
                      n_jobs=1, refit=True, error_score=np.nan)
    gs.fit(Xt, y)
    best = gs.best_estimator_
    names = kept[best.named_steps["select"].get_support()]

    clf = best.named_steps["clf"]
    if hasattr(clf, "coef_"):
        eff = clf.coef_.ravel()
        eff_kind = "standardised_logistic_coefficient"
    elif hasattr(clf, "feature_importances_"):
        eff = clf.feature_importances_
        eff_kind = "impurity_importance"
    else:
        eff = np.full(len(names), np.nan)
        eff_kind = "none"

    full = pd.DataFrame({"feature": names, "effect": eff, "effect_kind": eff_kind})

    # Univariate association, computed once on all data.  Reported alongside
    # the model effect so a reader can tell a genuinely discriminative feature
    # from one that only matters in combination.
    from scipy import stats
    uni = []
    for f in X.columns:
        v = X[f]
        a, b = v[y == 1].dropna(), v[y == 0].dropna()
        if len(a) < 5 or len(b) < 5:
            uni.append((f, np.nan, np.nan, np.nan))
            continue
        try:
            u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
            d = (a.mean() - b.mean()) / np.sqrt(((len(a) - 1) * a.var()
                                                 + (len(b) - 1) * b.var())
                                                / max(1, len(a) + len(b) - 2))
            auc1 = u / (len(a) * len(b))
        except Exception:
            p, d, auc1 = np.nan, np.nan, np.nan
        uni.append((f, p, d, auc1))
    uni = pd.DataFrame(uni, columns=["feature", "p_mannwhitney", "cohens_d",
                                     "univariate_auc"])
    ok = uni["p_mannwhitney"].notna()
    uni["p_fdr"] = np.nan
    if ok.sum():
        from statsmodels.stats.multitest import multipletests
        uni.loc[ok, "p_fdr"] = multipletests(uni.loc[ok, "p_mannwhitney"],
                                             method="fdr_bh")[1]

    # Bootstrap selection stability.
    rng = np.random.default_rng(seed)
    counts = {f: 0 for f in X.columns}
    signs = {f: [] for f in X.columns}
    done = 0
    for _ in range(n_boot):
        idx = rng.choice(len(X), len(X), replace=True)
        yb = y.iloc[idx]
        if yb.nunique() < 2 or yb.sum() < 5:
            continue
        try:
            b = clone(best)
            b.fit(Xt[idx], yb)
            nm = kept[b.named_steps["select"].get_support()]
            c = b.named_steps["clf"]
            co = c.coef_.ravel() if hasattr(c, "coef_") else \
                getattr(c, "feature_importances_", np.zeros(len(nm)))
            for f, cf in zip(nm, co):
                counts[f] += 1
                signs[f].append(float(cf))
            done += 1
        except Exception:
            continue

    stab = pd.DataFrame({
        "feature": list(counts),
        "selection_freq": [counts[f] / done if done else np.nan for f in counts],
        "boot_effect_mean": [np.mean(signs[f]) if signs[f] else np.nan for f in counts],
        "boot_effect_lo": [np.percentile(signs[f], 2.5) if len(signs[f]) > 10 else np.nan
                           for f in counts],
        "boot_effect_hi": [np.percentile(signs[f], 97.5) if len(signs[f]) > 10 else np.nan
                           for f in counts],
        "sign_consistency": [max(np.mean(np.array(signs[f]) > 0),
                                 np.mean(np.array(signs[f]) < 0)) if signs[f] else np.nan
                             for f in counts],
    })

    out = (stab.merge(full, on="feature", how="outer")
                .merge(uni, on="feature", how="left"))
    out["in_final_model"] = out["feature"].isin(names)
    out["n_bootstraps"] = done
    out = out.sort_values(["in_final_model", "selection_freq"], ascending=[False, False])
    return out, dict(gs.best_params_), float(gs.best_score_)
