"""Diagnosis-blind task x linear-frequency profile extraction.

Produces six vector profiles per recording for the tensor experiment declared
in ``PRESPECIFICATION_TENSOR_PROFILES.md``. Row-group parts make the second
6.4-GB source pass resumable.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from joblib import Parallel, delayed
from scipy.signal import welch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import extract_linear_harmonics as LH  # noqa: E402

SOURCE = C.PARQUET["spectrogram"]
OUT = C.DATA / "dyn_linear_profiles.parquet"
PARTS = C.DATA / "linear_profile_parts"
TEST_PARTS = C.DATA / "linear_profile_test_parts"
PROFILE_LENGTHS = {
    "mean": LH.N_BINS, "sd": LH.N_BINS, "flux": LH.N_BINS,
    "mod1_3": LH.N_BINS, "mod3_7": LH.N_BINS,
    "cep": LH.Q_HI - LH.Q_LO,
}
FEATURES = [f"lprof_{name}_{i:03d}" for name, n in PROFILE_LENGTHS.items()
            for i in range(n)]


def summarise(value) -> dict[str, float]:
    out = {name: np.nan for name in FEATURES}
    d0 = LH._time_major(value)
    if d0.shape[0] < 10 or not np.isfinite(d0).all():
        return out
    d = d0[::LH.STRIDE].astype(np.float64)
    level = LH._log_band_power(d, np.ones(LH.N_BINS, dtype=bool))
    active = level >= np.percentile(level, 95) - LH.ACTIVE_DROP_DB
    if int(active.sum()) < 5:
        return out

    act = d[active]
    mean = act.mean(axis=0)
    mean = mean - mean.mean()
    sd = act.std(axis=0)
    flux = (np.abs(np.diff(d, axis=0)).mean(axis=0)
            if len(d) >= 2 else np.full(LH.N_BINS, np.nan))

    nper = min(256, len(d))
    if nper >= 10:
        f, ps = welch(d, fs=LH.FS_CONTOUR, nperseg=nper,
                      noverlap=nper // 2, detrend="constant", axis=0)
        total = ps[f > 0].sum(axis=0) + 1e-30
        mod1 = ps[(f >= 1) & (f < 3)].sum(axis=0) / total
        mod3 = ps[(f >= 3) & (f < 7)].sum(axis=0) / total
    else:
        mod1 = mod3 = np.full(LH.N_BINS, np.nan)

    cep = np.fft.irfft(mean, n=LH.NFFT)[LH.Q_LO:LH.Q_HI]
    cep = cep - np.median(cep)
    values = {"mean": mean, "sd": sd, "flux": flux,
              "mod1_3": mod1, "mod3_7": mod3, "cep": cep}
    for name, vec in values.items():
        out.update({f"lprof_{name}_{i:03d}": float(v)
                    for i, v in enumerate(vec)})
    return out


def run_group(group_id: int, part_dir: Path) -> dict:
    out_path = part_dir / f"group_{group_id:03d}.parquet"
    meta_path = part_dir / f"group_{group_id:03d}.json"
    if out_path.exists() and meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if meta.get("status") == "ok":
                return {**meta, "cached": True}
        except Exception:
            pass
    started = time.time()
    rows = []
    try:
        pf = pq.ParquetFile(SOURCE)
        frame = pf.read_row_group(
            group_id, columns=["participant_id", "session_id", "task_name",
                               "spectrogram", "n_frames"]).to_pandas()
        for row in frame.itertuples(index=False):
            task = C.task_group(row.task_name)
            if task not in LH.GENERAL_TASKS:
                continue
            rec = {"participant_id": row.participant_id,
                   "session_id": row.session_id, "task_name": row.task_name,
                   "task_group": task}
            rec.update(summarise(row.spectrogram))
            rows.append(rec)
        del frame
        out = pd.DataFrame.from_records(rows)
        for col in FEATURES:
            out[col] = pd.to_numeric(out[col], errors="coerce").astype(np.float32)
        out.to_parquet(out_path, index=False)
        rec = {"group": group_id, "status": "ok", "rows": len(out),
               "seconds": round(time.time() - started, 2)}
    except Exception as exc:
        rec = {"group": group_id, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - started, 2)}
    meta_path.write_text(json.dumps(rec), encoding="utf-8")
    return rec


def combine(part_dir: Path, n_groups: int, output: Path):
    files = [part_dir / f"group_{i:03d}.parquet" for i in range(n_groups)]
    missing = [p for p in files if not p.exists()]
    if missing:
        raise RuntimeError(f"missing {len(missing)} profile parts")
    out = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    out = out.sort_values(["participant_id", "session_id", "task_name"])
    out.to_parquet(output, index=False)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run"])
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--limit-groups", type=int)
    args = ap.parse_args()
    pf = pq.ParquetFile(SOURCE)
    if args.command == "audit":
        print(f"source_rows={pf.metadata.num_rows} groups={pf.num_row_groups} "
              f"features={len(FEATURES)} profiles={PROFILE_LENGTHS}")
        return
    n_groups = (pf.num_row_groups if args.limit_groups is None else
                min(args.limit_groups, pf.num_row_groups))
    part_dir = PARTS if args.limit_groups is None else TEST_PARTS
    output = OUT if args.limit_groups is None else C.DATA / "dyn_linear_profiles_TEST.parquet"
    part_dir.mkdir(parents=True, exist_ok=True)
    todo = [i for i in range(n_groups) if not (
        part_dir / f"group_{i:03d}.parquet").exists()]
    print(f"linear profiles: {len(todo)}/{n_groups} groups pending", flush=True)
    for start in range(0, len(todo), args.jobs):
        batch = todo[start:start + args.jobs]
        ans = Parallel(n_jobs=args.jobs, prefer="threads")(
            delayed(run_group)(i, part_dir) for i in batch)
        for rec in ans:
            print(json.dumps(rec), flush=True)
    out = combine(part_dir, n_groups, output)
    f = out[FEATURES]
    print(f"wrote {output}: {out.shape}; nan_min_max="
          f"{float(f.isna().mean().min()):.4f}/"
          f"{float(f.isna().mean().max()):.4f}")
    for name, n in PROFILE_LENGTHS.items():
        cols = [f"lprof_{name}_{i:03d}" for i in range(n)]
        a = f[cols].to_numpy(float)
        print(name, "mean", float(np.nanmean(a)), "sd", float(np.nanstd(a)),
              "min", float(np.nanmin(a)), "max", float(np.nanmax(a)))


if __name__ == "__main__":
    main()
