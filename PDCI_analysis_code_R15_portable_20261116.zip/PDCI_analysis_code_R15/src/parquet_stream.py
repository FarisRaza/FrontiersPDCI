"""Row-group streaming over the large feature parquet files.

The dynamic feature files are 30 MB - 6 GB on disk and expand roughly ten-fold
in memory, so nothing here ever loads a whole file.  Each extractor supplies a
`summarise(record) -> dict` callback and gets back a tidy per-recording frame.
"""
from __future__ import annotations

import time
import os
from pathlib import Path
from typing import Callable, Iterator

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

KEYS = ["participant_id", "session_id", "task_name"]


def iter_row_groups(path: Path, columns: list[str] | None = None,
                    limit_groups: int | None = None) -> Iterator[pd.DataFrame]:
    pf = pq.ParquetFile(path)
    n = pf.num_row_groups if limit_groups is None else min(limit_groups, pf.num_row_groups)
    batch_rows = int(os.environ.get("PDCI_PARQUET_BATCH_ROWS", "0"))
    for i in range(n):
        if batch_rows:
            for batch in pf.iter_batches(batch_size=batch_rows, row_groups=[i],
                                         columns=columns, use_threads=False):
                yield batch.to_pandas()
        else:
            yield pf.read_row_group(i, columns=columns, use_threads=False).to_pandas()


def as_1d(x) -> np.ndarray:
    """Parquet list<float> -> float32 vector, NaN/inf scrubbed."""
    a = np.asarray(x, dtype=np.float32).ravel()
    return a[np.isfinite(a)] if a.size else a


def as_2d(x, expect_channels: int | None = None) -> np.ndarray:
    """Parquet list<list<float>> -> (time, channel) float32 matrix.

    Some sources store (channel, time); if `expect_channels` is given and the
    matrix is obviously transposed, it is flipped.
    """
    rows = list(x)
    if not rows:
        return np.zeros((0, expect_channels or 0), dtype=np.float32)
    a = np.asarray([np.asarray(r, dtype=np.float32) for r in rows], dtype=np.float32)
    if a.ndim != 2:
        return np.zeros((0, expect_channels or 0), dtype=np.float32)
    if expect_channels is not None and a.shape[0] == expect_channels and a.shape[1] != expect_channels:
        a = a.T
    return a


def extract(path: Path, value_col: str, summarise: Callable[[dict], dict],
            out_path: Path, limit_groups: int | None = None,
            progress_every: int = 1) -> pd.DataFrame:
    """Stream `path`, apply `summarise` per recording, write a parquet table."""
    t0 = time.time()
    chunks: list[pd.DataFrame] = []
    n_rows = n_fail = 0
    for gi, g in enumerate(iter_row_groups(path, columns=KEYS + [value_col, "n_frames"],
                                           limit_groups=limit_groups)):
        recs = []
        for row in g.itertuples(index=False):
            d = dict(zip(KEYS, (row.participant_id, row.session_id, row.task_name)))
            try:
                d.update(summarise({"value": getattr(row, value_col),
                                    "n_frames": row.n_frames}))
            except Exception:
                n_fail += 1
            recs.append(d)
        n_rows += len(recs)
        chunks.append(pd.DataFrame.from_records(recs))
        if progress_every and gi % progress_every == 0:
            print(f"  group {gi}: {n_rows} rows, {time.time() - t0:.0f}s", flush=True)
        del g

    out = pd.concat(chunks, ignore_index=True)
    for c in out.columns:
        if c not in KEYS:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype(np.float32)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_parquet(out_path, index=False)
    print(f"wrote {out_path.name}: {out.shape[0]} rows x {out.shape[1]} cols "
          f"({n_fail} failures) in {time.time() - t0:.0f}s", flush=True)
    return out


# ---------------------------------------------------------------- helpers
def robust_stats(a: np.ndarray, prefix: str) -> dict:
    """Location/scale/shape summary that tolerates short and empty signals."""
    out = {}
    if a.size < 3:
        return out
    q = np.percentile(a, [5, 25, 50, 75, 95])
    m, s = float(a.mean()), float(a.std())
    out[f"{prefix}_mean"] = m
    out[f"{prefix}_std"] = s
    out[f"{prefix}_cv"] = s / abs(m) if abs(m) > 1e-9 else np.nan
    out[f"{prefix}_p5"], out[f"{prefix}_p25"], out[f"{prefix}_p50"], \
        out[f"{prefix}_p75"], out[f"{prefix}_p95"] = map(float, q)
    out[f"{prefix}_iqr"] = float(q[3] - q[1])
    out[f"{prefix}_range9"] = float(q[4] - q[0])
    if s > 1e-9:
        z = (a - m) / s
        out[f"{prefix}_skew"] = float((z ** 3).mean())
        out[f"{prefix}_kurt"] = float((z ** 4).mean() - 3.0)
    return out


def delta_stats(a: np.ndarray, prefix: str, fs: float) -> dict:
    """First/second difference magnitudes -- velocity and acceleration."""
    out = {}
    if a.size < 5:
        return out
    d1 = np.diff(a) * fs
    d2 = np.diff(a, n=2) * fs * fs
    out[f"{prefix}_vel_absmean"] = float(np.abs(d1).mean())
    out[f"{prefix}_vel_p95"] = float(np.percentile(np.abs(d1), 95))
    out[f"{prefix}_acc_absmean"] = float(np.abs(d2).mean())
    out[f"{prefix}_jerk"] = float(np.abs(np.diff(d2)).mean()) if d2.size > 1 else np.nan
    return out


def band_power(a: np.ndarray, fs: float, bands: dict[str, tuple[float, float]],
               prefix: str) -> dict:
    """Relative power of a 1-D signal in named frequency bands.

    Tremor lives at 4-7 Hz (vocal/parkinsonian) and the syllable rhythm of
    running speech at 3-8 Hz, so these bands carry real clinical signal.
    """
    out = {}
    if a.size < int(fs * 1.0):
        return out
    x = a - a.mean()
    win = np.hanning(x.size)
    spec = np.abs(np.fft.rfft(x * win)) ** 2
    freqs = np.fft.rfftfreq(x.size, d=1.0 / fs)
    total = spec[freqs > 0].sum()
    if total <= 0:
        return out
    for name, (lo, hi) in bands.items():
        sel = (freqs >= lo) & (freqs < hi)
        out[f"{prefix}_bp_{name}"] = float(spec[sel].sum() / total)
    pos = freqs > 0.2
    if pos.any():
        out[f"{prefix}_peak_freq"] = float(freqs[pos][np.argmax(spec[pos])])
        p = spec[pos] / spec[pos].sum()
        out[f"{prefix}_spec_entropy"] = float(-(p * np.log(p + 1e-12)).sum() / np.log(p.size))
    return out
