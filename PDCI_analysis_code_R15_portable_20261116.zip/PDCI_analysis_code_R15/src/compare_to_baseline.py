"""Does the audio actually beat age + sex? Marginal and paired inference.

For every target x cohort this refits BOTH models -- the best audio model and
the age+sex baseline -- under **identical cross-validation folds and the same
seed**, so the two sets of out-of-fold predictions are paired participant by
participant.  That pairing is what makes the difference testable; comparing two
independently-run models would leave fold assignment as an uncontrolled source
of variance.

Reports three things per target:

  MARGINAL   ROC-AUC and a 95% percentile bootstrap CI for each model
             separately.  Useful for reporting, useless for comparing.
  PAIRED     the difference and its 95% CI, from resampling PARTICIPANTS and
             recomputing both AUCs on the same resample.  This is the correct
             comparison.
  DELONG     an analytic p-value for correlated ROC curves (Sun & Xu 2014), as
             a check that the bootstrap is not doing something odd.

Overlapping marginal CIs do NOT imply a non-significant difference -- the two
models are evaluated on the same people, so their errors are correlated and the
paired interval is much narrower than the marginals suggest.  Read the PAIRED
column.

p-values are FDR-corrected (Benjamini-Hochberg) across targets within a cohort,
because 16 diseases are being tested at once.

Usage:  python src/compare_to_baseline.py [--jobs 6] [--repeats 5]
"""
from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from scipy import stats
from sklearn.metrics import roc_auc_score
from statsmodels.stats.multitest import multipletests

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import datasets  # noqa: E402
import modeling  # noqa: E402

SCREEN = C.RESULTS / "screen_metrics.jsonl"
BASELINE_FS = "demographics_only__agesex"
TIER_A_SETS = ["static_avg__agesex", "static_full__agesex", "dynamic_full__agesex",
               "acoustic_full__agesex", "acoustic_plus_interactions__agesex"]


# ---------------------------------------------------------------- DeLong
def _midrank(x):
    J = np.argsort(x)
    z = x[J]
    N = len(x)
    t = np.zeros(N, dtype=float)
    i = 0
    while i < N:
        j = i
        while j < N and z[j] == z[i]:
            j += 1
        t[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(N, dtype=float)
    out[J] = t
    return out


def delong_test(y, p1, p2):
    """Two-sided p-value for AUC(p1) == AUC(p2) on the same samples."""
    y = np.asarray(y)
    pos = np.c_[p1, p2][y == 1].T
    neg = np.c_[p1, p2][y == 0].T
    m, n = pos.shape[1], neg.shape[1]
    k = 2
    tx = np.array([_midrank(pos[r]) for r in range(k)])
    ty = np.array([_midrank(neg[r]) for r in range(k)])
    tz = np.array([_midrank(np.r_[pos[r], neg[r]]) for r in range(k)])
    aucs = tz[:, :m].sum(axis=1) / (m * n) - (m + 1.0) / (2.0 * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    s = sx / m + sy / n
    s = np.atleast_2d(s)
    L = np.array([[1, -1]])
    var = np.asarray(L @ s @ L.T).item()
    if var <= 0:
        return float(aucs[0] - aucs[1]), np.nan
    z = float((aucs[0] - aucs[1]) / np.sqrt(var))
    return float(aucs[0] - aucs[1]), float(2 * stats.norm.sf(abs(z)))


# ---------------------------------------------------------------- bootstrap
def bootstrap_pair(y, p_best, p_base, n_boot=4000, seed=C.RANDOM_STATE):
    """Marginal and paired percentile intervals from one resampling loop.

    The same participant bootstrap indices are used for both models, so the
    paired interval correctly reflects their correlated errors.
    """
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    a, b = np.asarray(p_best), np.asarray(p_base)
    A, B, D = [], [], []
    for _ in range(n_boot):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) < 2:
            continue
        ai = roc_auc_score(y[i], a[i])
        bi = roc_auc_score(y[i], b[i])
        A.append(ai)
        B.append(bi)
        D.append(ai - bi)
    A, B, D = map(np.asarray, (A, B, D))
    if not D.size:
        return {}
    # Two-sided bootstrap p-value: how often the difference crosses zero.
    p = 2 * min((D <= 0).mean(), (D >= 0).mean())
    return {
        "auc_best": float(roc_auc_score(y, a)),
        "auc_best_lo": float(np.percentile(A, 2.5)),
        "auc_best_hi": float(np.percentile(A, 97.5)),
        "auc_base": float(roc_auc_score(y, b)),
        "auc_base_lo": float(np.percentile(B, 2.5)),
        "auc_base_hi": float(np.percentile(B, 97.5)),
        "delta": float(roc_auc_score(y, a) - roc_auc_score(y, b)),
        "delta_lo": float(np.percentile(D, 2.5)),
        "delta_hi": float(np.percentile(D, 97.5)),
        "p_boot": float(min(1.0, max(p, 1.0 / (D.size + 1)))),
        "n_boot_ok": int(D.size),
    }


def pick_best(screen, target, cohort):
    g = screen[(screen.status == "ok") & (screen.target == target)
               & (screen.cohort == cohort) & screen.feature_set.isin(TIER_A_SETS)]
    if not len(g):
        return None
    r = g.sort_values(["roc_auc", "pr_auc"], ascending=False).iloc[0]
    return r.feature_set, r.model


def pick_baseline_model(screen, target, cohort):
    g = screen[(screen.status == "ok") & (screen.target == target)
               & (screen.cohort == cohort) & (screen.feature_set == BASELINE_FS)
               & (screen.model != "dummy")]
    if not len(g):
        return "logreg_l2"
    return g.sort_values("roc_auc", ascending=False).iloc[0].model


def run_one(target, cohort, best_fs, best_model, base_model, splits, repeats, n_boot):
    try:
        Xb, yb, meta = datasets.build(target, cohort, best_fs)
        Xa, ya, _ = datasets.build(target, cohort, BASELINE_FS)
        # Identical seed -> RepeatedStratifiedKFold produces identical folds,
        # so the two prediction vectors are paired on the same participants
        # evaluated under the same splits.
        _, pb = modeling.evaluate(Xb, yb, best_model, n_splits=splits,
                                  n_repeats=repeats, seed=C.RANDOM_STATE)
        _, pa = modeling.evaluate(Xa, ya, base_model, n_splits=splits,
                                  n_repeats=repeats, seed=C.RANDOM_STATE)
        j = pb[["y_true", "prob"]].join(pa[["prob"]], rsuffix="_base", how="inner")
        if len(j) < 30 or j.y_true.nunique() < 2:
            return {"target": target, "cohort": cohort, "status": "too_small"}

        out = {"target": target, "cohort": cohort, "status": "ok",
               "best_feature_set": best_fs, "best_model": best_model,
               "baseline_model": base_model,
               "n": int(len(j)), "n_pos": int(j.y_true.sum()),
               "underpowered": bool(meta["n_pos"] < C.MIN_POSITIVES)}
        out |= bootstrap_pair(j.y_true, j.prob, j.prob_base, n_boot=n_boot)
        d, p = delong_test(j.y_true.values, j.prob.values, j.prob_base.values)
        out["delta_delong"] = d
        out["p_delong"] = p
        # Do the marginal intervals overlap?  Recorded to show that this is the
        # wrong way to judge the comparison.
        if "auc_best_lo" in out:
            out["marginal_cis_overlap"] = bool(
                out["auc_best_lo"] <= out["auc_base_hi"]
                and out["auc_base_lo"] <= out["auc_best_hi"])
        return out
    except Exception as e:
        return {"target": target, "cohort": cohort, "status": "error",
                "error": f"{type(e).__name__}: {e}",
                "traceback": traceback.format_exc()[-800:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=6)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=5)
    ap.add_argument("--boot", type=int, default=4000)
    ap.add_argument("--cohorts", type=str, default="all,single_category,vs_control")
    args = ap.parse_args()

    screen = pd.read_json(SCREEN, lines=True)
    jobs = []
    for cohort in args.cohorts.split(","):
        for target in datasets.all_targets():
            b = pick_best(screen, target, cohort)
            if b is None:
                continue
            jobs.append((target, cohort, b[0], b[1],
                         pick_baseline_model(screen, target, cohort)))
    print(f"{len(jobs)} target x cohort comparisons on {args.jobs} workers "
          f"({args.splits}x{args.repeats} CV, {args.boot} bootstrap resamples)\n")

    res = Parallel(n_jobs=args.jobs, verbose=5)(
        delayed(run_one)(t, c, fs, m, bm, args.splits, args.repeats, args.boot)
        for t, c, fs, m, bm in jobs)

    df = pd.DataFrame([r for r in res if r.get("status") == "ok"])
    bad = [r for r in res if r.get("status") != "ok"]
    if bad:
        print(f"{len(bad)} failed:")
        for r in bad[:5]:
            print("  ", r.get("target"), r.get("cohort"), r.get("status"),
                  r.get("error", ""))
    if not len(df):
        return

    # 16 diseases tested at once -> control the false discovery rate.
    df["p_boot_fdr"] = np.nan
    df["p_delong_fdr"] = np.nan
    for ch, g in df.groupby("cohort"):
        for src, dst in [("p_boot", "p_boot_fdr"), ("p_delong", "p_delong_fdr")]:
            ok = g[src].notna()
            if ok.sum():
                df.loc[g.index[ok], dst] = multipletests(g.loc[ok, src],
                                                         method="fdr_bh")[1]
    df["audio_helps"] = (df.delta_lo > 0) & (df.p_delong_fdr < 0.05)
    df = df.sort_values(["cohort", "delta"], ascending=[True, False])
    df.to_csv(C.RESULTS / "baseline_comparison.csv", index=False)

    for ch, g in df.groupby("cohort"):
        print(f"\n{'=' * 108}\ncohort: {ch}\n{'=' * 108}")
        print(f"{'target':<32s} {'n+':>4s}  {'audio AUC (95% CI)':>24s}  "
              f"{'age+sex AUC (95% CI)':>24s}  {'delta (95% CI)':>22s}  "
              f"{'q':>7s}  sig")
        for _, r in g.iterrows():
            star = "*" if r.underpowered else " "
            print(f"{r.target:<32s}{star}{int(r.n_pos):4d}  "
                  f"{r.auc_best:.3f} [{r.auc_best_lo:.3f},{r.auc_best_hi:.3f}]  "
                  f"{r.auc_base:.3f} [{r.auc_base_lo:.3f},{r.auc_base_hi:.3f}]  "
                  f"{r.delta:+.3f} [{r.delta_lo:+.3f},{r.delta_hi:+.3f}]  "
                  f"{r.p_delong_fdr:7.4f}  {'YES' if r.audio_helps else 'no'}")
        n_ov = int(g.marginal_cis_overlap.sum())
        n_sig_ov = int((g.marginal_cis_overlap & g.audio_helps).sum())
        print(f"\n  marginal CIs overlap for {n_ov}/{len(g)} targets, of which "
              f"{n_sig_ov} still show a significant paired difference")
        print(f"  audio significantly beats age+sex for "
              f"{int(g.audio_helps.sum())}/{len(g)} targets (FDR < 0.05)")
    print(f"\nwrote {C.RESULTS / 'baseline_comparison.csv'}")


if __name__ == "__main__":
    main()
