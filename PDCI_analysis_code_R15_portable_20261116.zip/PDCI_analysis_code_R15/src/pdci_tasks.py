"""Leakage-safe task-battery study for Parkinson's vs cognitive impairment.

This is deliberately separate from :mod:`pdci`.  The earlier study answers
the broad PD/CI question using participant-level blocks.  This study answers
three protocol questions while making task presence constant within every
cohort:

1. ``general``  -- the 11 task groups completed by >90% of the audio cohort.
2. ``neuro``    -- the four cognitive/neurological task groups, restricted to
                   people who completed the whole neurological battery.
3. ``combined`` -- general + neurological audio on exactly the same people as
                   (2).

ALS participants and the single PD+CI overlap are excluded.  Every feature
space includes age, sex, and task duration.  No task-completion or coverage
indicator is exposed to a model.  Supervised selection is fitted only on the
training portion of each CV fold.

The workflow is resumable::

    python src/pdci_tasks.py audit
    python src/pdci_tasks.py screen --jobs 8
    python src/pdci_tasks.py confirm --jobs 6
    python src/pdci_tasks.py null --jobs 8 --perms 20
    python src/pdci_tasks.py report
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.base import clone
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.feature_selection import SelectFromModel, SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score,
                             balanced_accuracy_score, confusion_matrix,
                             f1_score, precision_score, recall_score,
                             roc_auc_score)
from sklearn.model_selection import (RepeatedStratifiedKFold, StratifiedKFold,
                                     cross_val_predict)
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC, SVC

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import modeling  # noqa: E402

warnings.filterwarnings("ignore")

OUT = C.RESULTS / "pdci_tasks"
PRED = OUT / "predictions"
OUT.mkdir(parents=True, exist_ok=True)
PRED.mkdir(parents=True, exist_ok=True)
SCREEN_FILE = OUT / "screen.jsonl"
CONFIRM_FILE = OUT / "confirmed.jsonl"
NULL_FILE = OUT / "null.jsonl"

CLASSES = ["other", "parkinsons", "cognitive"]

# >90% overall completion in the 833-person audio cohort.  Keeping only people
# who completed all 11 makes task presence constant rather than merely common.
GENERAL_TASKS = [
    "prolonged_vowel", "maximum_phonation_time", "loudness", "glides",
    "free_speech", "diadochokinesis", "picture_description", "breathing",
    "cough_respiration", "story_recall", "rainbow_passage",
]

# The diagnosis-dependent cognitive battery identified in HANDOFF.md and in
# the original task-assignment audit.
NEURO_TASKS = [
    "productive_vocabulary", "random_item_generation", "word_color_stroop",
    "cinderella_story",
]

DESIGN_TASKS = {
    "general": GENERAL_TASKS,
    "neuro": NEURO_TASKS,
    "combined": GENERAL_TASKS + NEURO_TASKS,
}

BLOCKS = {
    "static": ["st__"],
    "dynamic": ["dy__"],
    "static_dynamic": ["st__", "dy__"],
    "timeresolved": ["tr__"],
    "all": ["st__", "dy__", "tr__"],
}


def recipes_for(design: str) -> list[str]:
    """Prespecified feature representations for one protocol design."""
    if design in {"general", "neuro"}:
        recipes = [
            "avg_static", "avg_dynamic", "avg_static_dynamic",
            "avg_timeresolved", "avg_all", "avg_sd_static_dynamic",
            "avg_sd_all", "per_task_static", "per_task_dynamic",
            "per_task_static_dynamic", "per_task_timeresolved",
            "per_task_all", "per_task_plus_avg_sd_all", "engineered_all",
        ]
        # Focused follow-up requested after the broad sweep: retain the winning
        # per-task dynamic representation while adding only its cross-task mean
        # and SD.  Restrict it to the general-task protocol being compared so a
        # follow-up does not silently expand the neurological-task experiment.
        if design == "general":
            recipes.insert(-2, "per_task_plus_avg_sd_dynamic")
        return recipes
    if design == "combined":
        return [
            "pooled_avg_all", "split_avg_static", "split_avg_dynamic",
            "split_avg_static_dynamic", "split_avg_timeresolved",
            "split_avg_all", "split_avg_sd_all", "per_task_static",
            "per_task_dynamic", "per_task_static_dynamic",
            "per_task_timeresolved", "per_task_all",
            "per_task_plus_split_all", "engineered_all",
            "general_avg_all", "neuro_avg_all", "general_per_task_all",
            "neuro_per_task_all",
        ]
    raise ValueError(design)


OBJECTIVES = ["multiclass", "pd_binary", "ci_binary"]

# A broad but tractable screen.  k is fixed per configuration; because the
# selector itself sits after training-fold preprocessing, no test outcome can
# influence which columns survive.
SCREEN_CONFIGS = [
    *(dict(selector="kbest_f", clf="logreg", k=k) for k in (20, 60, 150)),
    *(dict(selector="kbest_f", clf="lda", k=k) for k in (20, 60, 150)),
    *(dict(selector="pca", clf="logreg", k=k) for k in (20, 50)),
    *(dict(selector="pca", clf="lda", k=k) for k in (20, 50)),
    *(dict(selector="l1", clf="logreg", k=k) for k in (60, 150)),
    dict(selector="kbest_f", clf="svm_rbf", k=60),
    dict(selector="kbest_f", clf="lgbm", k=60),
]

GENERAL_CONTRASTS = [
    ("prolonged_vowel", "picture_description", "vowel_minus_picture"),
    ("diadochokinesis", "picture_description", "ddk_minus_picture"),
    ("story_recall", "rainbow_passage", "recall_minus_read"),
    ("free_speech", "rainbow_passage", "spontaneous_minus_read"),
    ("maximum_phonation_time", "prolonged_vowel", "mpt_minus_vowel"),
    ("loudness", "prolonged_vowel", "loud_minus_habitual"),
]
NEURO_CONTRASTS = [
    ("word_color_stroop", "productive_vocabulary", "stroop_minus_vocab"),
    ("random_item_generation", "productive_vocabulary", "random_minus_vocab"),
    ("cinderella_story", "productive_vocabulary", "story_minus_vocab"),
    ("cinderella_story", "word_color_stroop", "story_minus_stroop"),
]


# --------------------------------------------------------------------- inputs
@lru_cache(maxsize=1)
def cohort() -> pd.DataFrame:
    return pd.read_parquet(C.DATA / "cohort.parquet")


@lru_cache(maxsize=1)
def static_bytask() -> pd.DataFrame:
    return pd.read_parquet(C.DATA / "static_bytask.parquet")


@lru_cache(maxsize=1)
def task_presence() -> pd.DataFrame:
    bt = static_bytask()
    z = pd.Series(1, index=bt.index).unstack("task_group").fillna(0).astype(bool)
    return z.reindex(cohort().index, fill_value=False)


@lru_cache(maxsize=1)
def task_blocks() -> pd.DataFrame:
    """Static, dynamic and time-resolved per-task blocks with safe prefixes."""
    st = static_bytask().copy()
    st = st.drop(columns=["duration", *C.QUALITY_FEATURES], errors="ignore")
    st.columns = [f"st__{c}" for c in st.columns]

    dy = pd.read_parquet(C.DATA / "dynamic_bytask.parquet").copy()
    # Match build_dynamic_features.py: raw recording-length proxies and the
    # known exact duplicate do not enter the acoustic block.  Task duration is
    # supplied explicitly as a covariate below.
    dy_cols = [c for c in dy.columns
               if c not in {"prosody_f0_ppq3_st", "ltas_n_frames"}
               and not c.endswith("_dur_s")]
    dy = dy[dy_cols]
    dy.columns = [f"dy__{c}" for c in dy.columns]

    tr = pd.read_parquet(C.DATA / "xdyn_bytask.parquet").copy()
    tr = tr.drop(columns=["rqa_dur_s"], errors="ignore")
    tr.columns = [f"tr__{c}" for c in tr.columns]

    out = pd.concat([st, dy, tr], axis=1, join="outer")
    out = out.loc[:, ~out.columns.duplicated()]
    return out.replace([np.inf, -np.inf], np.nan).astype(np.float32)


def clean_base_mask() -> pd.Series:
    co = cohort()
    pdx = co["parkinsons_disease"].eq(1)
    cix = co["cognitive_impairment"].eq(1)
    als = co["rare_amyotrophic_lateral_sclerosis"].eq(1)
    return co["n_recordings"].gt(0) & ~als & ~(pdx & cix)


def ids_for_design(design: str) -> pd.Index:
    """Eligibility with exactly constant task presence inside each design."""
    did = task_presence()
    base = clean_base_mask()
    if design == "general":
        keep = base & did[GENERAL_TASKS].all(axis=1)
    elif design in {"neuro", "combined"}:
        # Both designs use this identical cohort.  Requiring the general tasks
        # as well costs two people and prevents design 3 from reintroducing a
        # missing-task signature absent in design 2.
        keep = base & did[GENERAL_TASKS + NEURO_TASKS].all(axis=1)
    else:
        raise ValueError(design)
    return cohort().index[keep]


def labels(ids: pd.Index, objective: str) -> pd.Series:
    co = cohort().loc[ids]
    pdx = co["parkinsons_disease"].eq(1)
    cix = co["cognitive_impairment"].eq(1)
    if objective == "multiclass":
        y = pd.Series(0, index=ids, dtype=int)
        y[pdx] = 1
        y[cix] = 2
        return y
    if objective == "pd_binary":
        return pdx.astype(int)
    if objective == "ci_binary":
        return cix.astype(int)
    raise ValueError(objective)


def block_columns(block: str) -> list[str]:
    prefs = BLOCKS[block]
    return [c for c in task_blocks().columns if c.startswith(tuple(prefs))]


def _sub(tasks: list[str], block: str, ids: pd.Index) -> pd.DataFrame:
    bt = task_blocks()[block_columns(block)]
    mask = bt.index.get_level_values("task_group").isin(tasks)
    return bt.loc[mask].reindex(pd.MultiIndex.from_product(
        [ids, tasks], names=["participant_id", "task_group"]))


def task_mean(tasks: list[str], block: str, ids: pd.Index, tag: str) -> pd.DataFrame:
    d = _sub(tasks, block, ids).groupby(level="participant_id").mean().reindex(ids)
    d.columns = [f"{tag}__{c}" for c in d.columns]
    return d


def task_sd(tasks: list[str], block: str, ids: pd.Index, tag: str) -> pd.DataFrame:
    d = _sub(tasks, block, ids).groupby(level="participant_id").std().reindex(ids)
    d.columns = [f"{tag}__{c}" for c in d.columns]
    return d


def task_individual(tasks: list[str], block: str, ids: pd.Index,
                    tag: str = "task") -> pd.DataFrame:
    d = _sub(tasks, block, ids).unstack("task_group")
    d.columns = [f"{tag}__{task}__{feat}" for feat, task in d.columns]
    return d.reindex(ids)


def task_contrasts(tasks: list[str], block: str, ids: pd.Index) -> pd.DataFrame:
    pairs = []
    if set(GENERAL_TASKS).issuperset(tasks) or set(tasks).intersection(GENERAL_TASKS):
        pairs += [p for p in GENERAL_CONTRASTS if p[0] in tasks and p[1] in tasks]
    if set(tasks).intersection(NEURO_TASKS):
        pairs += [p for p in NEURO_CONTRASTS if p[0] in tasks and p[1] in tasks]
    bt = task_blocks()[block_columns(block)]
    out = []
    for a, b, name in pairs:
        try:
            xa = bt.xs(a, level="task_group").reindex(ids)
            xb = bt.xs(b, level="task_group").reindex(ids)
        except KeyError:
            continue
        z = xa - xb
        z.columns = [f"contrast__{name}__{c}" for c in z.columns]
        out.append(z)
    return pd.concat(out, axis=1) if out else pd.DataFrame(index=ids)


def cross_battery_contrasts(block: str, ids: pd.Index) -> pd.DataFrame:
    g = _sub(GENERAL_TASKS, block, ids).groupby(level="participant_id").mean()
    n = _sub(NEURO_TASKS, block, ids).groupby(level="participant_id").mean()
    common = g.columns.intersection(n.columns)
    g, n = g[common].reindex(ids), n[common].reindex(ids)
    delta = n - g
    delta.columns = [f"battery_delta__{c}" for c in common]
    # Bounded relative contrast: unlike a plain ratio, this is well behaved
    # when an interval-scale feature crosses zero.
    rel = 2.0 * (n - g) / (n.abs() + g.abs()).replace(0, np.nan)
    rel.columns = [f"battery_relative__{c}" for c in common]
    return pd.concat([delta, rel], axis=1)


def duration_features(ids: pd.Index, tasks: list[str]) -> pd.DataFrame:
    dur = static_bytask()[["duration"]]
    mask = dur.index.get_level_values("task_group").isin(tasks)
    wide = dur.loc[mask]["duration"].unstack("task_group").reindex(index=ids,
                                                                    columns=tasks)
    # Eligibility guarantees these are observed.  Log duration is more stable
    # while preserving all ordering information.
    if wide.isna().any().any():
        raise AssertionError("task duration missing despite complete-task eligibility")
    out = np.log1p(wide.clip(lower=0))
    out.columns = [f"dur_log__{t}" for t in out.columns]
    out["dur_log__total"] = np.log1p(wide.sum(axis=1).clip(lower=0))
    out["dur_log__mean"] = np.log1p(wide.mean(axis=1).clip(lower=0))
    out["dur_log__sd"] = np.log1p(wide.std(axis=1).clip(lower=0))
    return out.astype(np.float32)


def covariates(ids: pd.Index, design: str) -> pd.DataFrame:
    co = cohort().loc[ids]
    out = co[["age", "sex_male"]].astype(np.float32)
    return pd.concat([out, duration_features(ids, DESIGN_TASKS[design])], axis=1)


def _mean_sd(tasks: list[str], block: str, ids: pd.Index, prefix: str = "") -> pd.DataFrame:
    return pd.concat([
        task_mean(tasks, block, ids, f"{prefix}mean".strip("_")),
        task_sd(tasks, block, ids, f"{prefix}sd".strip("_")),
    ], axis=1)


def audio_for_recipe(design: str, recipe: str, ids: pd.Index) -> pd.DataFrame:
    tasks = DESIGN_TASKS[design]

    if design in {"general", "neuro"}:
        if recipe.startswith("avg_sd_"):
            block = recipe.removeprefix("avg_sd_")
            return _mean_sd(tasks, block, ids)
        if recipe.startswith("avg_"):
            block = recipe.removeprefix("avg_")
            return task_mean(tasks, block, ids, "mean")
        if recipe == "per_task_plus_avg_sd_dynamic":
            return pd.concat([task_individual(tasks, "dynamic", ids),
                              _mean_sd(tasks, "dynamic", ids)], axis=1)
        if (recipe.startswith("per_task_")
                and recipe not in {"per_task_plus_avg_sd_all",
                                   "per_task_plus_avg_sd_dynamic"}):
            block = recipe.removeprefix("per_task_")
            return task_individual(tasks, block, ids)
        if recipe == "per_task_plus_avg_sd_all":
            return pd.concat([task_individual(tasks, "all", ids),
                              _mean_sd(tasks, "all", ids)], axis=1)
        if recipe == "engineered_all":
            return pd.concat([_mean_sd(tasks, "all", ids),
                              task_contrasts(tasks, "all", ids)], axis=1)

    if design == "combined":
        if recipe == "pooled_avg_all":
            return task_mean(tasks, "all", ids, "pooled_mean")
        if recipe.startswith("split_avg_") and recipe != "split_avg_sd_all":
            block = recipe.removeprefix("split_avg_")
            return pd.concat([
                task_mean(GENERAL_TASKS, block, ids, "general_mean"),
                task_mean(NEURO_TASKS, block, ids, "neuro_mean"),
            ], axis=1)
        if recipe == "split_avg_sd_all":
            return pd.concat([
                _mean_sd(GENERAL_TASKS, "all", ids, "general_"),
                _mean_sd(NEURO_TASKS, "all", ids, "neuro_"),
            ], axis=1)
        if recipe.startswith("per_task_") and recipe != "per_task_plus_split_all":
            block = recipe.removeprefix("per_task_")
            return task_individual(tasks, block, ids)
        if recipe == "per_task_plus_split_all":
            return pd.concat([
                task_individual(tasks, "all", ids),
                task_mean(GENERAL_TASKS, "all", ids, "general_mean"),
                task_mean(NEURO_TASKS, "all", ids, "neuro_mean"),
            ], axis=1)
        if recipe == "engineered_all":
            return pd.concat([
                _mean_sd(GENERAL_TASKS, "all", ids, "general_"),
                _mean_sd(NEURO_TASKS, "all", ids, "neuro_"),
                task_contrasts(tasks, "all", ids),
                cross_battery_contrasts("all", ids),
            ], axis=1)
        if recipe == "general_avg_all":
            return task_mean(GENERAL_TASKS, "all", ids, "general_mean")
        if recipe == "neuro_avg_all":
            return task_mean(NEURO_TASKS, "all", ids, "neuro_mean")
        if recipe == "general_per_task_all":
            return task_individual(GENERAL_TASKS, "all", ids)
        if recipe == "neuro_per_task_all":
            return task_individual(NEURO_TASKS, "all", ids)

    raise ValueError(f"unsupported recipe: {design}/{recipe}")


def build_X(design: str, recipe: str) -> pd.DataFrame:
    ids = ids_for_design(design)
    audio = audio_for_recipe(design, recipe, ids)
    # Dataset-wide missingness/constant filtering is unsupervised.  A 50%
    # floor prevents a sparse extractor failure from becoming a pseudo task-
    # completion indicator after imputation.
    audio = audio.replace([np.inf, -np.inf], np.nan)
    audio = audio.loc[:, audio.notna().mean() >= 0.50]
    audio = audio.loc[:, audio.nunique(dropna=True) > 1]
    X = pd.concat([audio.astype(np.float32), covariates(ids, design)], axis=1)
    X = X.loc[:, ~X.columns.duplicated()]
    return X.astype(np.float32)


# ---------------------------------------------------------------------- audit
def audit_inputs() -> None:
    co = cohort()
    did = task_presence()
    base = clean_base_mask()
    pdx, cix = co.parkinsons_disease.eq(1), co.cognitive_impairment.eq(1)
    cls = pd.Series("other", index=co.index)
    cls[pdx] = "PD"
    cls[cix] = "CI"

    coverage = did.loc[base, GENERAL_TASKS + NEURO_TASKS].groupby(cls[base]).mean().T
    coverage["overall"] = did.loc[base, coverage.index].mean().values
    coverage.to_csv(OUT / "task_coverage.csv")

    rows = []
    for design in DESIGN_TASKS:
        ids = ids_for_design(design)
        counts = labels(ids, "multiclass").value_counts().reindex([0, 1, 2], fill_value=0)
        rows.append(dict(design=design, n=len(ids), other=int(counts[0]),
                         parkinsons=int(counts[1]), cognitive=int(counts[2]),
                         neuro_fraction=float((counts[1] + counts[2]) / len(ids)),
                         n_tasks=len(DESIGN_TASKS[design])))
        assert did.loc[ids, DESIGN_TASKS[design]].all().all()
    pd.DataFrame(rows).to_csv(OUT / "cohort_counts.csv", index=False)

    ci = pd.read_csv(C.PHENO / "diagnosis" / "cognitive_impairment.tsv", sep="\t",
                     dtype={"participant_id": str})
    field = "diagnosis_alz_dementia_mci_dt"
    ci[field].fillna("Unspecified").value_counts().rename_axis("CI subtype").rename(
        "n").to_csv(OUT / "ci_subtypes.csv")

    manifests = []
    for design in DESIGN_TASKS:
        for recipe in recipes_for(design):
            X = build_X(design, recipe)
            audio_cols = [c for c in X if c not in {"age", "sex_male"}
                          and not c.startswith("dur_")]
            manifests.append(dict(design=design, recipe=recipe, n=len(X),
                                  n_features=X.shape[1], n_audio=len(audio_cols),
                                  n_duration=sum(c.startswith("dur_") for c in X),
                                  missing_fraction=float(X.isna().mean().mean())))
            banned = [c for c in X if c.startswith(("cov_", "cf_", "q_"))]
            if banned:
                raise AssertionError(f"leaking/non-acoustic columns: {banned[:5]}")
    pd.DataFrame(manifests).to_csv(OUT / "feature_manifest.csv", index=False)
    print(pd.read_csv(OUT / "cohort_counts.csv").to_string(index=False))
    print(f"\n{len(manifests)} feature recipes audited; task presence is constant.")


# --------------------------------------------------------------------- models
def make_selector(name: str, k: int, n_features: int, n_samples: int):
    kk = max(1, min(k, n_features, max(1, n_samples - 2)))
    if name == "none":
        return "passthrough"
    if name == "kbest_f":
        return SelectKBest(f_classif, k=kk)
    if name == "pca":
        return PCA(n_components=kk, random_state=C.RANDOM_STATE)
    if name == "l1":
        return SelectFromModel(
            LinearSVC(penalty="l1", dual=False, C=0.05, max_iter=5000,
                      class_weight="balanced", random_state=C.RANDOM_STATE),
            threshold=-np.inf, max_features=kk)
    raise ValueError(name)


def make_clf(name: str, n_classes: int):
    if name == "logreg":
        return LogisticRegression(C=1.0, max_iter=5000, class_weight="balanced",
                                  solver="lbfgs", random_state=C.RANDOM_STATE)
    if name == "lda":
        return LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    if name == "svm_rbf":
        return SVC(C=2.0, kernel="rbf", probability=True,
                   class_weight="balanced", random_state=C.RANDOM_STATE)
    if name == "lgbm":
        from lightgbm import LGBMClassifier
        return LGBMClassifier(n_estimators=250, learning_rate=0.05,
                              num_leaves=15, min_child_samples=10,
                              subsample=0.8, colsample_bytree=0.8,
                              class_weight="balanced", n_jobs=1, verbose=-1,
                              random_state=C.RANDOM_STATE)
    raise ValueError(name)


def supervised_pipe(cfg: dict, n_features: int, n_samples: int, n_classes: int):
    sel = make_selector(cfg["selector"], int(cfg["k"]), n_features, n_samples)
    steps = [] if sel == "passthrough" else [("select", sel)]
    steps.append(("clf", make_clf(cfg["clf"], n_classes)))
    return Pipeline(steps)


def aligned_proba(est, X, n_classes: int) -> np.ndarray:
    raw = est.predict_proba(X)
    out = np.zeros((len(X), n_classes), dtype=float)
    for j, c in enumerate(est.classes_):
        out[:, int(c)] = raw[:, j]
    s = out.sum(axis=1, keepdims=True)
    return out / np.maximum(s, 1e-12)


def choose_threshold(y, p, mode: str) -> float:
    y, p = np.asarray(y).astype(int), np.asarray(p, dtype=float)
    if len(np.unique(y)) < 2:
        return 0.5
    grid = np.unique(np.r_[0.0, np.linspace(0.01, 0.99, 99), p, 1.0])
    rows = []
    for t in grid:
        h = p >= t
        tn, fp, fn, tp = confusion_matrix(y, h, labels=[0, 1]).ravel()
        sens = tp / max(1, tp + fn)
        spec = tn / max(1, tn + fp)
        prec = tp / max(1, tp + fp)
        f1 = 2 * prec * sens / max(1e-12, prec + sens)
        rows.append((t, sens, spec, prec, f1))
    d = pd.DataFrame(rows, columns=["t", "sens", "spec", "prec", "f1"])
    if mode == "screen":
        ok = d[d.sens >= 0.90]
        if ok.empty:
            ok = d.nlargest(1, "sens")
        return float(ok.sort_values(["spec", "t"], ascending=False).iloc[0].t)
    if mode == "precise":
        ok = d[d.spec >= 0.90]
        if ok.empty:
            ok = d.nlargest(1, "spec")
        return float(ok.sort_values(["f1", "prec", "t"], ascending=False).iloc[0].t)
    raise ValueError(mode)


def binary_at(y, p, threshold) -> dict:
    y, p = np.asarray(y).astype(int), np.asarray(p, dtype=float)
    h = p >= np.asarray(threshold)
    tn, fp, fn, tp = confusion_matrix(y, h, labels=[0, 1]).ravel()
    return dict(threshold=float(np.mean(threshold)), tn=int(tn), fp=int(fp),
                fn=int(fn), tp=int(tp), sensitivity=recall_score(y, h),
                specificity=tn / max(1, tn + fp),
                precision=precision_score(y, h, zero_division=0),
                npv=tn / max(1, tn + fn), f1=f1_score(y, h, zero_division=0),
                balanced_accuracy=balanced_accuracy_score(y, h))


def score_multiclass(y, proba) -> dict:
    y = np.asarray(y).astype(int)
    pred = proba.argmax(axis=1)
    out = {
        "macro_ovr_auc": float(roc_auc_score(y, proba, multi_class="ovr",
                                               average="macro")),
        "neuro_auc": float(roc_auc_score((y > 0).astype(int), proba[:, 1:].sum(axis=1))),
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
    }
    m = y > 0
    rel = proba[m, 1] / np.maximum(1e-12, proba[m, 1] + proba[m, 2])
    out["pd_vs_ci_auc"] = float(roc_auc_score((y[m] == 1).astype(int), rel))
    cm = confusion_matrix(y, pred, labels=[0, 1, 2])
    out["confusion"] = json.dumps(cm.tolist())
    for c, name in enumerate(CLASSES):
        out[f"recall_{name}"] = float(recall_score(y == c, pred == c))
        out[f"precision_{name}"] = float(precision_score(y == c, pred == c,
                                                          zero_division=0))
    return out


def score_binary(y, p) -> dict:
    y = np.asarray(y).astype(int)
    h = p >= 0.5
    tn, fp, fn, tp = confusion_matrix(y, h, labels=[0, 1]).ravel()
    return {
        "roc_auc": float(roc_auc_score(y, p)),
        "pr_auc": float(average_precision_score(y, p)),
        "prevalence": float(y.mean()),
        "accuracy_at50": float(accuracy_score(y, h)),
        "balanced_accuracy_at50": float(balanced_accuracy_score(y, h)),
        "sensitivity_at50": float(tp / max(1, tp + fn)),
        "specificity_at50": float(tn / max(1, tn + fp)),
        "precision_at50": float(tp / max(1, tp + fp)),
    }


def evaluate_fixed(X: pd.DataFrame, y: pd.Series, cfg: dict, n_splits: int,
                   n_repeats: int, thresholds: bool = False,
                   seed: int = C.RANDOM_STATE) -> tuple[dict, pd.DataFrame]:
    """Repeated OOF evaluation with every learned transform inside folds."""
    n_classes = int(y.nunique())
    outer = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats,
                                    random_state=seed)
    rows = []
    for fold, (tr, te) in enumerate(outer.split(X, y)):
        Xtr, Xte, ytr = X.iloc[tr], X.iloc[te], y.iloc[tr]
        prep = modeling.make_prep()
        A = prep.fit_transform(Xtr)
        B = prep.transform(Xte)
        pipe = supervised_pipe(cfg, A.shape[1], len(tr), n_classes)
        pipe.fit(A, ytr)
        p = aligned_proba(pipe, B, n_classes)
        row = pd.DataFrame({
            "participant_id": X.index[te], "repeat": fold // n_splits,
            "fold": fold % n_splits, "y_true": y.iloc[te].values,
        })
        for j in range(n_classes):
            row[f"p{j}"] = p[:, j]

        if thresholds:
            inner_k = min(3, int(ytr.value_counts().min()))
            inner = StratifiedKFold(inner_k, shuffle=True,
                                    random_state=seed + fold)
            train_p = cross_val_predict(clone(pipe), A, ytr, cv=inner,
                                        method="predict_proba", n_jobs=1)
            # cross_val_predict preserves sorted class order here (0..K-1).
            if n_classes == 2:
                pt = train_p[:, 1]
                row["thr_screen"] = choose_threshold(ytr, pt, "screen")
                row["thr_precise"] = choose_threshold(ytr, pt, "precise")
            else:
                nt = train_p[:, 1] + train_p[:, 2]
                row["thr_screen"] = choose_threshold((ytr > 0).astype(int), nt,
                                                       "screen")
                case = ytr.values > 0
                rel = train_p[case, 1] / np.maximum(
                    1e-12, train_p[case, 1] + train_p[case, 2])
                row["thr_precise"] = choose_threshold(
                    (ytr.values[case] == 1).astype(int), rel, "precise")
        rows.append(row)

    raw = pd.concat(rows, ignore_index=True)
    aggs = {"y_true": "first", **{f"p{j}": "mean" for j in range(n_classes)}}
    if thresholds:
        aggs |= {"thr_screen": "mean", "thr_precise": "mean"}
    pred = raw.groupby("participant_id").agg(aggs)

    if n_classes == 3:
        proba = pred[["p0", "p1", "p2"]].to_numpy()
        metrics = score_multiclass(pred.y_true, proba)
        if thresholds:
            neuro = proba[:, 1] + proba[:, 2]
            s = binary_at(pred.y_true.to_numpy() > 0, neuro, pred.thr_screen)
            metrics |= {f"screen_{k}": v for k, v in s.items()}
            case = pred.y_true.to_numpy() > 0
            rel = proba[case, 1] / np.maximum(1e-12,
                                              proba[case, 1] + proba[case, 2])
            q = binary_at(pred.y_true.to_numpy()[case] == 1, rel,
                          pred.thr_precise.to_numpy()[case])
            metrics |= {f"differential_{k}": v for k, v in q.items()}
    else:
        metrics = score_binary(pred.y_true, pred.p1)
        if thresholds:
            s = binary_at(pred.y_true, pred.p1, pred.thr_screen)
            q = binary_at(pred.y_true, pred.p1, pred.thr_precise)
            metrics |= {f"screen_{k}": v for k, v in s.items()}
            metrics |= {f"precise_{k}": v for k, v in q.items()}
    return metrics, pred


def config_id(design: str, objective: str, recipe: str, cfg: dict) -> str:
    return (f"{design}|{objective}|{recipe}|{cfg['selector']}|"
            f"{cfg['clf']}|k{cfg['k']}")


def _run_one(design: str, objective: str, recipe: str, cfg: dict,
             splits: int, repeats: int, thresholds: bool = False) -> tuple[dict, pd.DataFrame | None]:
    cid = config_id(design, objective, recipe, cfg)
    t0 = time.time()
    try:
        X = build_X(design, recipe)
        y = labels(X.index, objective)
        m, p = evaluate_fixed(X, y, cfg, splits, repeats, thresholds=thresholds)
        rec = dict(config_id=cid, status="ok", design=design,
                   objective=objective, recipe=recipe, **cfg, n=len(X),
                   n_features=X.shape[1], n_positive=int((y > 0).sum()),
                   seconds=round(time.time() - t0, 2), **m)
        return rec, p
    except Exception as e:
        return dict(config_id=cid, status="error", design=design,
                    objective=objective, recipe=recipe, **cfg,
                    error=f"{type(e).__name__}: {e}",
                    traceback=traceback.format_exc()[-1400:],
                    seconds=round(time.time() - t0, 2)), None


def _screen_group(design: str, objective: str, recipe: str, configs: list[dict],
                  splits: int, repeats: int) -> list[dict]:
    out = []
    for cfg in configs:
        rec, _ = _run_one(design, objective, recipe, cfg, splits, repeats)
        out.append(rec)
    return out


def read_done(path: Path) -> set[str]:
    done = set()
    if path.exists():
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                    if rec.get("status") == "ok":
                        done.add(rec["config_id"])
                except Exception:
                    pass
    return done


def cmd_screen(args) -> None:
    done = read_done(SCREEN_FILE)
    jobs = []
    total = 0
    for design in DESIGN_TASKS:
        for objective in OBJECTIVES:
            for recipe in recipes_for(design):
                missing = [cfg for cfg in SCREEN_CONFIGS
                           if config_id(design, objective, recipe, cfg) not in done]
                if missing:
                    jobs.append((design, objective, recipe, missing))
                    total += len(missing)
    print(f"screen: {total} configurations in {len(jobs)} feature/objective groups; "
          f"{len(done)} already done")
    if not jobs:
        return
    # Threads are intentional on Windows.  The cached task matrices are large,
    # and loky's spawn-based workers cannot pickle functools cache wrappers
    # defined by a script executed as __main__.  The numerical estimators used
    # here release the GIL, while threads share the read-only matrices.
    n_ok = n_err = n_cfg = 0
    # Commit after each worker-sized batch.  Besides giving useful progress,
    # this keeps the sweep resumable across desktop/shell time ceilings.
    for start in range(0, len(jobs), args.jobs):
        chunk = jobs[start:start + args.jobs]
        res = Parallel(n_jobs=args.jobs, verbose=5, prefer="threads")(
            delayed(_screen_group)(d, o, r, cfgs, args.splits, args.repeats)
            for d, o, r, cfgs in chunk)
        with open(SCREEN_FILE, "a", encoding="utf-8") as fh:
            for group in res:
                for rec in group:
                    fh.write(json.dumps(rec, default=float) + "\n")
                    n_cfg += 1
                    n_ok += rec["status"] == "ok"
                    n_err += rec["status"] != "ok"
            fh.flush()
        print(f"  committed {min(start + len(chunk), len(jobs))}/{len(jobs)} groups "
              f"({n_cfg}/{total} configs this launch)", flush=True)
    print(f"wrote {n_ok} successful screen results; {n_err} errors")


def required_recipes(design: str) -> list[str]:
    if design == "general":
        return ["avg_all", "per_task_all", "per_task_plus_avg_sd_dynamic",
                "engineered_all"]
    if design == "neuro":
        return ["avg_all", "per_task_all", "engineered_all"]
    return ["pooled_avg_all", "split_avg_all", "per_task_all", "engineered_all"]


def select_confirmation_candidates() -> list[dict]:
    if not SCREEN_FILE.exists():
        raise SystemExit("run screen first")
    d = pd.read_json(SCREEN_FILE, lines=True)
    d = d[d.status == "ok"].drop_duplicates("config_id", keep="last")
    chosen = []
    for design in DESIGN_TASKS:
        for objective in OBJECTIVES:
            z = d[(d.design == design) & (d.objective == objective)]
            metrics = (["macro_ovr_auc", "neuro_auc", "pd_vs_ci_auc"]
                       if objective == "multiclass" else ["roc_auc", "pr_auc"])
            for metric in metrics:
                if metric in z and z[metric].notna().any():
                    chosen.append(z.loc[z[metric].idxmax()].to_dict())
                # In the combined design, general-only and neuro-only recipes
                # are ablations, not valid answers to "use both batteries".
                # Confirm the best true combined recipe separately even when
                # an ablation leads the overall table.
                if design == "combined":
                    full = z[~z.recipe.str.startswith(("general_", "neuro_"))]
                    if metric in full and full[metric].notna().any():
                        chosen.append(full.loc[full[metric].idxmax()].to_dict())
            for recipe in required_recipes(design):
                q = z[z.recipe == recipe]
                metric = "pd_vs_ci_auc" if objective == "multiclass" else "roc_auc"
                if len(q) and q[metric].notna().any():
                    chosen.append(q.loc[q[metric].idxmax()].to_dict())
    out = {r["config_id"]: r for r in chosen}
    return list(out.values())


def _confirm_one(row: dict, splits: int, repeats: int) -> dict:
    cfg = dict(selector=row["selector"], clf=row["clf"], k=int(row["k"]))
    rec, pred = _run_one(row["design"], row["objective"], row["recipe"], cfg,
                         splits, repeats, thresholds=True)
    if pred is not None:
        path = PRED / f"{rec['config_id'].replace('|', '__')}.csv"
        pred.to_csv(path)
        rec["prediction_file"] = str(path.relative_to(C.ANALYSIS))
    return rec


def _baseline_one(design: str, objective: str, kind: str,
                  splits: int, repeats: int) -> dict:
    ids = ids_for_design(design)
    if kind == "age_sex":
        X = cohort().loc[ids, ["age", "sex_male"]].astype(np.float32)
    elif kind == "age_sex_duration":
        X = covariates(ids, design)
    else:
        raise ValueError(kind)
    y = labels(ids, objective)
    cfg = dict(selector="none", clf="logreg", k=X.shape[1])
    recipe = f"baseline_{kind}"
    cid = f"{design}|{objective}|{recipe}|none|logreg|k{X.shape[1]}"
    try:
        m, pred = evaluate_fixed(X, y, cfg, splits, repeats, thresholds=True)
        path = PRED / f"{cid.replace('|', '__')}.csv"
        pred.to_csv(path)
        return dict(config_id=cid, status="ok", design=design,
                    objective=objective, recipe=recipe,
                    **cfg, n=len(X), n_features=X.shape[1],
                    n_positive=int((y > 0).sum()), **m,
                    prediction_file=str(path.relative_to(C.ANALYSIS)))
    except Exception as e:
        return dict(config_id=cid, status="error", design=design,
                    objective=objective, recipe=recipe,
                    **cfg, error=f"{type(e).__name__}: {e}",
                    traceback=traceback.format_exc()[-1400:])


def cmd_confirm(args) -> None:
    candidates = select_confirmation_candidates()
    done = read_done(CONFIRM_FILE)
    candidates = [r for r in candidates if r["config_id"] not in done]
    baselines = [(d, o, kind) for d in DESIGN_TASKS for o in OBJECTIVES
                 for kind in ("age_sex", "age_sex_duration")
                 if not any(x.startswith(f"{d}|{o}|baseline_{kind}|") for x in done)]
    print(f"confirm: {len(candidates)} selected acoustic configurations + "
          f"{len(baselines)} baselines; {len(done)} already done")
    work = ([("model", r) for r in candidates]
            + [("baseline", (d, o, kind)) for d, o, kind in baselines])
    n_ok = n_err = 0
    for start in range(0, len(work), args.jobs):
        chunk = work[start:start + args.jobs]
        calls = []
        for kind, payload in chunk:
            if kind == "model":
                calls.append(delayed(_confirm_one)(payload, args.splits, args.repeats))
            else:
                calls.append(delayed(_baseline_one)(payload[0], payload[1], payload[2],
                                                    args.splits, args.repeats))
        res = Parallel(n_jobs=args.jobs, verbose=5, prefer="threads")(calls)
        with open(CONFIRM_FILE, "a", encoding="utf-8") as fh:
            for rec in res:
                fh.write(json.dumps(rec, default=float) + "\n")
                n_ok += rec["status"] == "ok"
                n_err += rec["status"] != "ok"
            fh.flush()
        print(f"  committed {min(start + len(chunk), len(work))}/{len(work)} confirmations",
              flush=True)
    print(f"wrote {n_ok} confirmed results; {n_err} errors")


# --------------------------------------------------------------- null control
def _null_one(row: dict, perm: int, splits: int) -> dict:
    cfg = dict(selector=row["selector"], clf=row["clf"], k=int(row["k"]))
    X = build_X(row["design"], row["recipe"])
    y = labels(X.index, row["objective"])
    rng = np.random.default_rng(C.RANDOM_STATE + 1009 * perm)
    yp = pd.Series(rng.permutation(y.to_numpy()), index=y.index)
    m, _ = evaluate_fixed(X, yp, cfg, splits, 1, thresholds=False,
                          seed=C.RANDOM_STATE + perm)
    rec = dict(config_id=row["config_id"], permutation=perm,
               design=row["design"], objective=row["objective"],
               recipe=row["recipe"])
    keys = (["pd_vs_ci_auc", "neuro_auc", "macro_ovr_auc"]
            if row["objective"] == "multiclass" else ["roc_auc"])
    rec.update({k: m[k] for k in keys})
    return rec


def cmd_null(args) -> None:
    if not CONFIRM_FILE.exists():
        raise SystemExit("run confirm first")
    d = pd.read_json(CONFIRM_FILE, lines=True)
    d = d[(d.status == "ok") & ~d.recipe.str.startswith("baseline")]
    # One headline model per design/objective.
    rows = []
    for (design, obj), z in d.groupby(["design", "objective"]):
        if design == "combined":
            z = z[~z.recipe.str.startswith(("general_", "neuro_"))]
        metrics = ["pd_vs_ci_auc", "neuro_auc"] if obj == "multiclass" else ["roc_auc"]
        for metric in metrics:
            rows.append(z.loc[z[metric].idxmax()].to_dict())
    rows = list({r["config_id"]: r for r in rows}.values())
    done = set()
    if NULL_FILE.exists():
        q = pd.read_json(NULL_FILE, lines=True)
        done = set(zip(q.config_id, q.permutation))
    todo = [(r, p) for r in rows for p in range(args.perms)
            if (r["config_id"], p) not in done]
    print(f"null: {len(todo)} permutation evaluations")
    for start in range(0, len(todo), max(args.jobs, 2 * args.jobs)):
        chunk = todo[start:start + max(args.jobs, 2 * args.jobs)]
        res = Parallel(n_jobs=args.jobs, verbose=5, prefer="threads")(
            delayed(_null_one)(r, p, args.splits) for r, p in chunk)
        with open(NULL_FILE, "a", encoding="utf-8") as fh:
            for rec in res:
                fh.write(json.dumps(rec, default=float) + "\n")
            fh.flush()
        print(f"  committed {min(start + len(chunk), len(todo))}/{len(todo)} null runs",
              flush=True)


# -------------------------------------------------------------------- report
def load_prediction(row: pd.Series | dict) -> pd.DataFrame:
    return pd.read_csv(C.ANALYSIS / row["prediction_file"],
                       dtype={"participant_id": str}).set_index("participant_id")


def metric_from_prediction(objective: str, pred: pd.DataFrame, metric: str) -> float:
    y = pred.y_true.to_numpy().astype(int)
    if objective != "multiclass":
        return float(roc_auc_score(y, pred.p1))
    p = pred[["p0", "p1", "p2"]].to_numpy()
    if metric == "macro_ovr_auc":
        return float(roc_auc_score(y, p, multi_class="ovr", average="macro"))
    if metric == "neuro_auc":
        return float(roc_auc_score(y > 0, p[:, 1] + p[:, 2]))
    if metric == "pd_vs_ci_auc":
        m = y > 0
        rel = p[m, 1] / np.maximum(1e-12, p[m, 1] + p[m, 2])
        return float(roc_auc_score(y[m] == 1, rel))
    raise ValueError(metric)


def paired_bootstrap(model_row, base_row, metric: str, n_boot: int = 2000) -> dict:
    a, b = load_prediction(model_row), load_prediction(base_row)
    ids = a.index.intersection(b.index)
    a, b = a.loc[ids], b.loc[ids]
    obs_a = metric_from_prediction(model_row["objective"], a, metric)
    obs_b = metric_from_prediction(base_row["objective"], b, metric)
    rng = np.random.default_rng(C.RANDOM_STATE)
    va, vb, gains = [], [], []
    n = len(ids)
    for _ in range(n_boot):
        ix = rng.integers(0, n, n)
        try:
            aa = metric_from_prediction(model_row["objective"], a.iloc[ix], metric)
            bb = metric_from_prediction(base_row["objective"], b.iloc[ix], metric)
        except ValueError:
            continue
        va.append(aa); vb.append(bb); gains.append(aa - bb)
    return dict(metric=metric, value=obs_a, baseline=obs_b, gain=obs_a - obs_b,
                value_lo=float(np.quantile(va, .025)),
                value_hi=float(np.quantile(va, .975)),
                baseline_lo=float(np.quantile(vb, .025)),
                baseline_hi=float(np.quantile(vb, .975)),
                gain_lo=float(np.quantile(gains, .025)),
                gain_hi=float(np.quantile(gains, .975)),
                paired_p=float(2 * min(np.mean(np.asarray(gains) <= 0),
                                       np.mean(np.asarray(gains) >= 0))))


def _fmt(x) -> str:
    return "--" if pd.isna(x) else f"{x:.3f}"


def markdown_table(df: pd.DataFrame) -> str:
    """Render a compact Markdown table without pandas' optional tabulate dep."""
    d = df.copy()
    def cell(v):
        if pd.isna(v):
            return "--"
        return str(v).replace("|", "\\|").replace("\n", " ")
    head = "| " + " | ".join(cell(c) for c in d.columns) + " |"
    sep = "|" + "|".join("---" for _ in d.columns) + "|"
    rows = ["| " + " | ".join(cell(v) for v in row) + " |"
            for row in d.itertuples(index=False, name=None)]
    return "\n".join([head, sep] + rows)


def cmd_report(args) -> None:
    if not SCREEN_FILE.exists() or not CONFIRM_FILE.exists():
        raise SystemExit("run screen and confirm first")
    screen = pd.read_json(SCREEN_FILE, lines=True)
    screen = screen[screen.status == "ok"].drop_duplicates("config_id", keep="last")
    confirm = pd.read_json(CONFIRM_FILE, lines=True)
    confirm = confirm[confirm.status == "ok"].drop_duplicates("config_id", keep="last")

    # Best screen result for every feature representation, not only winners.
    recipe_rows = []
    for (design, obj, recipe), z in screen.groupby(["design", "objective", "recipe"]):
        metric = "pd_vs_ci_auc" if obj == "multiclass" else "roc_auc"
        recipe_rows.append(z.loc[z[metric].idxmax()])
    pd.DataFrame(recipe_rows).to_csv(OUT / "screen_best_by_recipe.csv", index=False)

    comp_path = OUT / "baseline_comparisons.csv"
    can_reuse = (comp_path.exists()
                 and comp_path.stat().st_mtime >= CONFIRM_FILE.stat().st_mtime)
    if can_reuse:
        comp = pd.read_csv(comp_path)
        print(f"reusing {len(comp)} paired comparisons from {comp_path.name}")
    else:
        comparisons = []
        for _, row in confirm[~confirm.recipe.str.startswith("baseline")].iterrows():
            b = confirm[(confirm.design == row.design) &
                        (confirm.objective == row.objective) &
                        confirm.recipe.str.startswith("baseline")]
            if b.empty:
                continue
            metrics = (["macro_ovr_auc", "neuro_auc", "pd_vs_ci_auc"]
                       if row.objective == "multiclass" else ["roc_auc"])
            for _, base in b.iterrows():
                for metric in metrics:
                    rec = paired_bootstrap(row, base, metric, args.bootstraps)
                    comparisons.append(dict(config_id=row.config_id, design=row.design,
                                            objective=row.objective, recipe=row.recipe,
                                            selector=row.selector, clf=row.clf, k=row.k,
                                            n=row.n, n_features=row.n_features,
                                            baseline_recipe=base.recipe, **rec))
        comp = pd.DataFrame(comparisons)
        comp.to_csv(comp_path, index=False)

    ops_cols = [c for c in confirm.columns if c.startswith(("screen_", "precise_",
                                                             "differential_"))]
    confirm[["config_id", "design", "objective", "recipe"] + ops_cols].to_csv(
        OUT / "operating_points.csv", index=False)

    # Permutation summary for headline models, if available.
    null_summary = pd.DataFrame()
    if NULL_FILE.exists():
        q = pd.read_json(NULL_FILE, lines=True)
        obs = []
        for cid, z in q.groupby("config_id"):
            row = confirm[confirm.config_id == cid]
            if row.empty:
                continue
            rr = row.iloc[0]
            metrics = (["pd_vs_ci_auc", "neuro_auc", "macro_ovr_auc"]
                       if rr.objective == "multiclass" else ["roc_auc"])
            for metric in metrics:
                if metric not in z:
                    continue
                observed = rr[metric]
                vals = z[metric].dropna()
                obs.append(dict(config_id=cid, metric=metric, n_perm=len(vals),
                                observed=observed, null_mean=vals.mean(),
                                null_p95=vals.quantile(.95),
                                perm_p=(1 + (vals >= observed).sum()) / (1 + len(vals))))
        null_summary = pd.DataFrame(obs)
        null_summary.to_csv(OUT / "null_summary.csv", index=False)

    # Compact headline table: confirmed best per design/objective and metric.
    headline = []
    for design in DESIGN_TASKS:
        for obj in OBJECTIVES:
            z = confirm[(confirm.design == design) & (confirm.objective == obj) &
                        ~confirm.recipe.str.startswith("baseline")]
            if design == "combined":
                z = z[~z.recipe.str.startswith(("general_", "neuro_"))]
            metric = "pd_vs_ci_auc" if obj == "multiclass" else "roc_auc"
            if z.empty:
                continue
            r = z.loc[z[metric].idxmax()]
            c = comp[(comp.config_id == r.config_id) & (comp.metric == metric) &
                     (comp.baseline_recipe == "baseline_age_sex_duration")].iloc[0]
            c_age = comp[(comp.config_id == r.config_id) & (comp.metric == metric) &
                         (comp.baseline_recipe == "baseline_age_sex")]
            c_age = c_age.iloc[0] if len(c_age) else None
            headline.append(dict(design=design, objective=obj, n=int(r.n),
                                 config_id=r.config_id,
                                 recipe=r.recipe, selector=r.selector, clf=r.clf,
                                 k=int(r.k), n_features=int(r.n_features),
                                 metric=metric, value=c.value, value_lo=c.value_lo,
                                 value_hi=c.value_hi, baseline=c.baseline,
                                 gain=c.gain, gain_lo=c.gain_lo, gain_hi=c.gain_hi,
                                 paired_p=c.paired_p,
                                 agesex_baseline=(c_age.baseline if c_age is not None else np.nan),
                                 gain_vs_agesex=(c_age.gain if c_age is not None else np.nan)))
    head = pd.DataFrame(headline)
    head.to_csv(OUT / "headline.csv", index=False)

    # A separate multiclass specification optimized for detecting either
    # neurological condition, rather than differentiating PD from CI.
    screen_rows = []
    for design in DESIGN_TASKS:
        z = confirm[(confirm.design == design) &
                    (confirm.objective == "multiclass") &
                    ~confirm.recipe.str.startswith("baseline")]
        if design == "combined":
            z = z[~z.recipe.str.startswith(("general_", "neuro_"))]
        r = z.loc[z.neuro_auc.idxmax()]
        q = comp[(comp.config_id == r.config_id) &
                 (comp.metric == "neuro_auc") &
                 (comp.baseline_recipe == "baseline_age_sex_duration")].iloc[0]
        qa = comp[(comp.config_id == r.config_id) &
                  (comp.metric == "neuro_auc") &
                  (comp.baseline_recipe == "baseline_age_sex")].iloc[0]
        screen_rows.append(dict(
            design=design, n=int(r.n), config_id=r.config_id, recipe=r.recipe,
            selector=r.selector, clf=r.clf, k=int(r.k), n_features=int(r.n_features),
            neuro_auc=q.value, value_lo=q.value_lo, value_hi=q.value_hi,
            agesex_baseline=qa.baseline, duration_baseline=q.baseline,
            gain=q.gain, gain_lo=q.gain_lo, gain_hi=q.gain_hi,
            paired_p=q.paired_p, sensitivity=r.screen_sensitivity,
            specificity=r.screen_specificity, precision=r.screen_precision))
    screen_head = pd.DataFrame(screen_rows)
    screen_head.to_csv(OUT / "screen_headline.csv", index=False)

    # Direct technique 3 minus technique 2 comparison.  These designs use the
    # same 169 IDs and split seed, so a paired participant bootstrap answers
    # whether adding general-task audio helps beyond neurological tasks.
    protocol_rows = []
    for obj in OBJECTIVES:
        metric = "pd_vs_ci_auc" if obj == "multiclass" else "roc_auc"
        full = head[(head.design == "combined") & (head.objective == obj)]
        neuro = head[(head.design == "neuro") & (head.objective == obj)]
        if len(full) and len(neuro):
            fr = confirm[confirm.config_id == full.iloc[0].config_id].iloc[0]
            nr = confirm[confirm.config_id == neuro.iloc[0].config_id].iloc[0]
            q = paired_bootstrap(fr, nr, metric, args.bootstraps)
            protocol_rows.append(dict(
                objective=obj, comparison="combined_minus_neuro_design",
                metric=metric, combined=q["value"], neurological=q["baseline"],
                difference=q["gain"], difference_lo=q["gain_lo"],
                difference_hi=q["gain_hi"], paired_p=q["paired_p"]))

        # Within the combined design, hold the duration covariates and cohort
        # fixed and compare its true both-battery winner to a neuro-audio-only
        # ablation when that ablation was confirmed.
        if len(full):
            ab = confirm[(confirm.design == "combined") &
                         (confirm.objective == obj) &
                         confirm.recipe.str.startswith("neuro_")]
            if len(ab):
                ar = ab.loc[ab[metric].idxmax()]
                fr = confirm[confirm.config_id == full.iloc[0].config_id].iloc[0]
                q = paired_bootstrap(fr, ar, metric, args.bootstraps)
                protocol_rows.append(dict(
                    objective=obj, comparison="combined_minus_neuro_audio_ablation",
                    metric=metric, combined=q["value"], neurological=q["baseline"],
                    difference=q["gain"], difference_lo=q["gain_lo"],
                    difference_hi=q["gain_hi"], paired_p=q["paired_p"]))
    protocol = pd.DataFrame(protocol_rows)
    protocol.to_csv(OUT / "protocol_comparisons.csv", index=False)

    # Compact confirmed comparison of the representations explicitly requested
    # by the study, plus the winning task-aware ablations.
    rep_recipes = {
        "general": ["avg_all", "per_task_all", "per_task_dynamic",
                    "per_task_timeresolved", "engineered_all"],
        "neuro": ["avg_all", "per_task_all", "avg_sd_static_dynamic",
                  "avg_static", "engineered_all"],
        "combined": ["pooled_avg_all", "split_avg_all", "per_task_all",
                     "neuro_avg_all", "engineered_all"],
    }
    rep_rows = []
    for design, recipes in rep_recipes.items():
        for recipe in recipes:
            rec = {"design": design, "recipe": recipe}
            for obj, col, label in [("multiclass", "pd_vs_ci_auc", "pd_vs_ci_auc"),
                                    ("pd_binary", "roc_auc", "pd_auc"),
                                    ("ci_binary", "roc_auc", "ci_auc")]:
                z = confirm[(confirm.design == design) &
                            (confirm.objective == obj) &
                            (confirm.recipe == recipe)]
                rec[label] = z[col].max() if len(z) else np.nan
            rep_rows.append(rec)
    reps = pd.DataFrame(rep_rows)
    reps.to_csv(OUT / "representation_summary.csv", index=False)

    counts = pd.read_csv(OUT / "cohort_counts.csv")
    lines = [
        "# Task-specific Parkinson's vs cognitive-impairment models", "",
        "ALS participants and the single PD+CI overlap are excluded. Task presence is "
        "constant inside every cohort; no completion/coverage indicator enters a model. "
        "CI is the umbrella diagnosis covering MCI, Alzheimer's disease, and other dementias.",
        "", "## Cohorts", "", markdown_table(counts), "",
        "## Confirmed headline models", "",
        "Every acoustic result is paired to an age + sex + task-duration baseline on the "
        "same out-of-fold participants. Feature selection is fitted inside CV folds.", "",
    ]
    show = head.copy()
    if len(show):
        show["estimate (95% CI)"] = show.apply(
            lambda r: f"{r.value:.3f} ({r.value_lo:.3f}-{r.value_hi:.3f})", axis=1)
        show["age+sex+duration baseline"] = show.baseline.map(_fmt)
        show["age+sex baseline"] = show.agesex_baseline.map(_fmt)
        show["paired gain (95% CI)"] = show.apply(
            lambda r: f"{r.gain:+.3f} ({r.gain_lo:+.3f}, {r.gain_hi:+.3f})", axis=1)
        lines += [markdown_table(show[["design", "objective", "n", "recipe",
                                      "selector", "clf", "metric",
                                      "estimate (95% CI)", "age+sex baseline",
                                      "age+sex+duration baseline",
                                      "paired gain (95% CI)"]]), ""]

    sh = screen_head.copy()
    sh["estimate (95% CI)"] = sh.apply(
        lambda r: f"{r.neuro_auc:.3f} ({r.value_lo:.3f}-{r.value_hi:.3f})", axis=1)
    sh["gain vs age+sex+duration (95% CI)"] = sh.apply(
        lambda r: f"{r.gain:+.3f} ({r.gain_lo:+.3f}, {r.gain_hi:+.3f})", axis=1)
    for col in ["sensitivity", "specificity", "precision"]:
        sh[col] = sh[col].map(_fmt)
    lines += ["## Screen-optimized multiclass specification", "",
              "These models maximize PD-or-CI versus other AUC. The operating threshold "
              "targets 90% sensitivity inside each training fold; held-out sensitivity may "
              "fall below that target.", "",
              markdown_table(sh[["design", "recipe", "selector", "clf",
                                  "estimate (95% CI)",
                                  "gain vs age+sex+duration (95% CI)",
                                  "sensitivity", "specificity", "precision"]]), ""]

    lines += ["## Operating specifications", "",
              "`screen_*` thresholds were chosen inside each training fold to target at "
              "least 90% sensitivity. `precise_*` thresholds require at least 90% "
              "specificity and then maximize training-fold F1. For the three-class model, "
              "the screen detects PD-or-CI and the differential threshold distinguishes PD "
              "from CI among cases.", ""]
    for _, h in head.iterrows():
        r = confirm[confirm.config_id == h.config_id].iloc[0] if "config_id" in h else None
        # headline.csv intentionally stays compact; recover by keys.
        z = confirm[(confirm.design == h.design) & (confirm.objective == h.objective) &
                    (confirm.recipe == h.recipe)]
        if z.empty:
            continue
        r = z.loc[z[h.metric].idxmax()]
        if h.objective == "multiclass":
            lines.append(
                f"- **{h.design} / multiclass:** neuro screen sensitivity "
                f"{r.get('screen_sensitivity', np.nan):.3f}, specificity "
                f"{r.get('screen_specificity', np.nan):.3f}; PD-vs-CI precise sensitivity "
                f"{r.get('differential_sensitivity', np.nan):.3f}, specificity "
                f"{r.get('differential_specificity', np.nan):.3f}, precision "
                f"{r.get('differential_precision', np.nan):.3f}.")
        else:
            lines.append(
                f"- **{h.design} / {h.objective}:** screen sensitivity "
                f"{r.get('screen_sensitivity', np.nan):.3f}, specificity "
                f"{r.get('screen_specificity', np.nan):.3f}; precise sensitivity "
                f"{r.get('precise_sensitivity', np.nan):.3f}, specificity "
                f"{r.get('precise_specificity', np.nan):.3f}, precision "
                f"{r.get('precise_precision', np.nan):.3f}.")

    lines += ["", "## Representation sweep", "",
              "The full comparison of pooled averages, separate general/neurological "
              "means, cross-task SDs, task-feature columns, and engineered contrasts is in "
              "`results/pdci_tasks/screen_best_by_recipe.csv`. Confirmed predictions, paired "
              "baseline intervals, and operating points are in the same directory.", ""]
    rs = reps.copy()
    for c in ["pd_vs_ci_auc", "pd_auc", "ci_auc"]:
        rs[c] = rs[c].map(_fmt)
    lines += [markdown_table(rs), "",
              "General-cohort discrimination benefits from retaining task identity, especially "
              "for dynamic/time-resolved features. In the neurological cohort, averaging is "
              "usually better than thousands of per-task columns. For the combined protocol, "
              "separate general and neurological means beat one pooled mean for PD-vs-CI, while "
              "per-task features are strongest for the two binary objectives. The larger "
              "engineered blocks do not win.", ""]
    if len(protocol):
        ps = protocol.copy()
        for c in ["combined", "neurological", "difference"]:
            ps[c] = ps[c].map(_fmt)
        ps["difference (95% CI)"] = protocol.apply(
            lambda r: f"{r.difference:+.3f} ({r.difference_lo:+.3f}, "
                      f"{r.difference_hi:+.3f})", axis=1)
        lines += ["## Does adding general-task audio help?", "",
                  "Technique 2 and technique 3 contain the identical 169 participants. "
                  "Positive differences favor the combined general+neurological protocol.", "",
                  markdown_table(ps[["objective", "comparison", "metric", "combined",
                                     "neurological", "difference (95% CI)", "paired_p"]]), ""]
    if len(null_summary):
        lines += ["## Label-shuffled null", "", markdown_table(null_summary), ""]
    report_path = C.ANALYSIS / "RESULTS_pdci_tasks.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(head.to_string(index=False))
    print(f"\nwrote {report_path}")


# ---------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "screen", "confirm", "null", "report"])
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--splits", type=int, default=None)
    ap.add_argument("--repeats", type=int, default=None)
    ap.add_argument("--perms", type=int, default=20)
    ap.add_argument("--bootstraps", type=int, default=2000)
    args = ap.parse_args()
    if args.command == "audit":
        audit_inputs()
    elif args.command == "screen":
        args.splits = args.splits or 3
        args.repeats = args.repeats or 1
        cmd_screen(args)
    elif args.command == "confirm":
        args.splits = args.splits or 5
        args.repeats = args.repeats or 5
        cmd_confirm(args)
    elif args.command == "null":
        args.splits = args.splits or 3
        cmd_null(args)
    else:
        cmd_report(args)


if __name__ == "__main__":
    main()
