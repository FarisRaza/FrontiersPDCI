"""SPARC prosody dynamics: F0 contour, voicing structure, tremor, loudness.

Three 50 Hz frame-level SPARC streams are summarised per recording:

  sparc_pitch        CREPE F0 (Hz).  NOTE: CREPE emits an F0 estimate on *every*
                     frame -- there are no zeros or NaNs -- so voicing has to be
                     decided from the periodicity stream, never from the pitch
                     values themselves.
  sparc_periodicity  CREPE voicing confidence in [0, 1].
  sparc_loudness     mean |amplitude| per 20 ms window of the z-scored waveform.

pitch and periodicity are byte-for-byte row aligned (same 32 row groups, same
31633 keys in the same order) so they are streamed in lockstep, which is what
lets the F0 contour be gated on voicing.  loudness has 17 fewer rows and drifts
out of alignment after the first row group, so it is extracted on its own and
outer-merged back on (participant_id, session_id, task_name).

Every feature is computed from a single recording in isolation -- no pooling
across recordings, participants or tasks -- so nothing here can leak across a
cross-validation split.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view
from scipy.signal import find_peaks

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import PARQUET, DATA                                   # noqa: E402
from parquet_stream import (KEYS, iter_row_groups, extract,        # noqa: E402
                            robust_stats, delta_stats, band_power)

NAME = "prosody"
P = f"{NAME}_"
FS = 50.0                       # frame rate of all three SPARC streams
VOICE_THR = 0.5                 # periodicity above this counts as voiced
ST_REF_HZ = 55.0                # semitone reference (A1); any fixed ref works
LD_FLOOR = 1e-3                 # amplitude floor -> -60 dB
SCRATCH = (Path(DATA).parent    # DATA_ROOT/analysis/scratch/prosody: temporary intermediates
           / "scratch"
           / "prosody")

# Modulation bands.  1.5-4 Hz and 7-12 Hz bracket the classic 4-7 Hz
# vocal/parkinsonian tremor band; 3-8 Hz is the syllable rate of running speech.
F0_MOD_BANDS = {"m0_1p5": (0.2, 1.5), "m1p5_4": (1.5, 4.0), "m4_7": (4.0, 7.0),
                "m7_12": (7.0, 12.0), "m12_25": (12.0, 25.0)}
F0_TREM_BANDS = {"m1p5_4": (1.5, 4.0), "m4_7": (4.0, 7.0), "m7_12": (7.0, 12.0)}
LD_MOD_BANDS = {"m0_1p5": (0.2, 1.5), "m1p5_4": (1.5, 4.0), "m3_8": (3.0, 8.0),
                "m4_7": (4.0, 7.0), "m7_12": (7.0, 12.0), "m12_25": (12.0, 25.0)}


# ------------------------------------------------------------------ helpers
def _raw1d(x) -> np.ndarray:
    """list<float16> -> float32 vector, *keeping* frame positions (unlike as_1d)."""
    if x is None:
        return np.zeros(0, dtype=np.float32)
    return np.asarray(x, dtype=np.float32).ravel()


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    """[(start, stop), ...] half-open index pairs for every True run."""
    m = np.asarray(mask, dtype=bool)
    if m.size == 0:
        return []
    d = np.diff(m.astype(np.int8))
    starts = (np.flatnonzero(d == 1) + 1).tolist()
    stops = (np.flatnonzero(d == -1) + 1).tolist()
    if m[0]:
        starts.insert(0, 0)
    if m[-1]:
        stops.append(int(m.size))
    return list(zip(starts, stops))


def _detrend(y: np.ndarray) -> np.ndarray:
    """Remove mean and linear trend so a drift does not masquerade as tremor."""
    y = np.asarray(y, dtype=np.float64)
    n = y.size
    if n < 3:
        return y - y.mean() if n else y
    t = np.arange(n, dtype=np.float64)
    tm, ym = t - t.mean(), y - y.mean()
    den = float((tm * tm).sum())
    b = float((tm * ym).sum() / den) if den > 0 else 0.0
    return ym - b * tm


def _slope(t: np.ndarray, y: np.ndarray, prefix: str) -> dict:
    """OLS slope of y on t (per second) plus its r^2."""
    out: dict = {}
    if y.size < 5 or t.size != y.size:
        return out
    tm = np.asarray(t, np.float64) - float(np.mean(t))
    ym = np.asarray(y, np.float64) - float(np.mean(y))
    den = float((tm * tm).sum())
    if den <= 0:
        return out
    b = float((tm * ym).sum() / den)
    sy = float((ym * ym).sum())
    out[f"{prefix}_slope"] = b
    out[f"{prefix}_slope_r2"] = float(b * b * den / sy) if sy > 1e-12 else np.nan
    return out


def _band_amp(x: np.ndarray, fs: float, bands: dict, prefix: str) -> dict:
    """Absolute magnitude (std) of the signal component inside each band.

    Complements band_power's *relative* powers: a contour can put 40 % of its
    power at 4-7 Hz and still be perfectly steady if the total is tiny.
    """
    out: dict = {}
    if x.size < int(fs):
        return out
    xc = np.asarray(x, np.float64)
    xc = xc - xc.mean()
    if not np.isfinite(xc).all() or float(np.abs(xc).max()) <= 0:
        return out
    X = np.fft.rfft(xc)
    freqs = np.fft.rfftfreq(xc.size, d=1.0 / fs)
    for name, (lo, hi) in bands.items():
        Y = np.where((freqs >= lo) & (freqs < hi), X, 0.0 + 0.0j)
        out[f"{prefix}_amp_{name}"] = float(np.fft.irfft(Y, n=xc.size).std())
    return out


def _run_stats(lengths_s: np.ndarray, prefix: str, with_cv: bool = False) -> dict:
    out: dict = {}
    if lengths_s.size == 0:
        return out
    out[f"{prefix}_mean_s"] = float(lengths_s.mean())
    out[f"{prefix}_med_s"] = float(np.median(lengths_s))
    out[f"{prefix}_max_s"] = float(lengths_s.max())
    if with_cv:
        m = float(lengths_s.mean())
        out[f"{prefix}_cv"] = float(lengths_s.std() / m) if m > 1e-9 else np.nan
    return out


def _win_std(y: np.ndarray, ok: np.ndarray, w: int, step: int) -> np.ndarray:
    """std of y inside every fully-usable window of w frames (vectorised)."""
    n = y.size
    if n < w:
        return np.zeros(0, dtype=np.float64)
    idx = np.arange(0, n - w + 1, step)
    sw = sliding_window_view(y, w)[idx]
    sm = sliding_window_view(ok, w)[idx]
    good = sm.all(axis=1)
    if not good.any():
        return np.zeros(0, dtype=np.float64)
    return sw[good].astype(np.float64).std(axis=1)


# ------------------------------------------------------- pitch + periodicity
def summarise_pitch(pitch, periodicity, n_frames) -> dict:
    f0 = _raw1d(pitch)
    per = _raw1d(periodicity)
    n = int(min(f0.size, per.size)) if per.size else int(f0.size)
    out: dict = {}
    if f0.size:
        out[f"{P}dur_s"] = float(f0.size) / FS
    if n < 5 or per.size == 0:
        return out
    f0, per = f0[:n], per[:n]
    per = np.clip(np.nan_to_num(per.astype(np.float64), nan=0.0), 0.0, 1.0)
    dur = n / FS
    t_all = np.arange(n, dtype=np.float64) / FS

    # ---- periodicity level ------------------------------------------------
    out.update(robust_stats(per, f"{P}per"))
    out[f"{P}per_frac_gt80"] = float((per >= 0.8).mean())
    out[f"{P}per_frac_lt20"] = float((per < 0.2).mean())
    out[f"{P}per_vel_absmean"] = float(np.abs(np.diff(per)).mean() * FS)
    out.update(_slope(t_all, per, f"{P}per"))

    # ---- voicing structure / voice breaks ---------------------------------
    usable = np.isfinite(f0) & (f0 > 40.0) & (f0 < 700.0)
    vcd = usable & (per >= VOICE_THR)
    rv, ru = _runs(vcd), _runs(~vcd)
    out[f"{P}vcd_frac"] = float(vcd.mean())
    out[f"{P}vcd_nruns_per_s"] = len(rv) / dur
    out[f"{P}vcd_trans_per_s"] = float((np.diff(vcd.astype(np.int8)) != 0).sum()) / dur
    lv = np.array([b - a for a, b in rv], dtype=np.float64) / FS
    lu = np.array([b - a for a, b in ru], dtype=np.float64) / FS
    out.update(_run_stats(lv, f"{P}vcd_run", with_cv=True))
    out.update(_run_stats(lu, f"{P}vcd_unv", with_cv=False))
    interior = np.array([(b - a) / FS for a, b in ru if a > 0 and b < n], dtype=np.float64)
    out[f"{P}vcd_breaks_per_s"] = float(interior.size) / dur
    out[f"{P}vcd_shortbreak_per_s"] = float((interior < 0.25).sum()) / dur

    # ---- F0 contour, on the semitone scale --------------------------------
    st = 12.0 * np.log2(np.clip(f0.astype(np.float64), 40.0, 700.0) / ST_REF_HZ)
    stv = st[vcd]
    if stv.size >= 10:
        out.update(robust_stats(stv, f"{P}f0_st"))
        out[f"{P}f0_hz_p50"] = float(np.median(f0[vcd]))
        out.update(_slope(t_all[vcd], stv, f"{P}f0_st"))
        q = stv.size // 4
        if q >= 2:
            out[f"{P}f0_q4q1_st"] = float(stv[-q:].mean() - stv[:q].mean())

    # velocity / acceleration, only across frame pairs that are both voiced
    if n >= 4:
        m1 = vcd[1:] & vcd[:-1]
        d1 = (st[1:] - st[:-1])[m1] * FS
        if d1.size >= 5:
            out[f"{P}f0_st_vel_absmean"] = float(np.abs(d1).mean())
            out[f"{P}f0_st_vel_p95"] = float(np.percentile(np.abs(d1), 95))
            out[f"{P}f0_st_vel_std"] = float(d1.std())
            up, dn = d1[d1 > 0], d1[d1 < 0]
            if up.size >= 3 and dn.size >= 3 and np.abs(dn).mean() > 1e-9:
                out[f"{P}f0_st_rise_fall_ratio"] = float(up.mean() / np.abs(dn).mean())
        m2 = vcd[2:] & vcd[1:-1] & vcd[:-2]
        d2 = (st[2:] - 2.0 * st[1:-1] + st[:-2])[m2] * FS * FS
        if d2.size >= 5:
            out[f"{P}f0_st_acc_absmean"] = float(np.abs(d2).mean())
        # 3-point perturbation quotient: cycle-scale instability
        ppq = np.abs(st[1:-1] - 0.5 * (st[:-2] + st[2:]))[m2]
        if ppq.size >= 5:
            out[f"{P}f0_ppq3_st"] = float(ppq.mean())

    # short-window F0 scatter: instability that survives removing the melody
    w100 = _win_std(st, vcd, 5, 3)
    w200 = _win_std(st, vcd, 10, 5)
    if w100.size:
        out[f"{P}f0_jit100_mean"] = float(w100.mean())
    if w200.size:
        out[f"{P}f0_jit200_mean"] = float(w200.mean())
        out[f"{P}f0_jit200_med"] = float(np.median(w200))
        out[f"{P}f0_jit200_p90"] = float(np.percentile(w200, 90))
        sd = out.get(f"{P}f0_st_std", np.nan)
        if np.isfinite(sd) and sd > 1e-6:
            out[f"{P}f0_jit_ratio"] = float(w200.mean() / sd)

    # ---- F0 modulation spectrum (whole contour, gaps interpolated) --------
    nv = int(vcd.sum())
    if nv >= 25 and n >= int(FS):
        vi = np.flatnonzero(vcd)
        st_i = np.interp(np.arange(n, dtype=np.float64), vi.astype(np.float64), st[vi])
        st_i = _detrend(st_i)
        out.update(band_power(st_i, FS, F0_MOD_BANDS, f"{P}f0mod"))

    # ---- F0 tremor on the longest continuous voiced stretch ---------------
    # Dropouts of <= 60 ms are bridged first: a momentary CREPE loss inside a
    # sustained vowel should not split the segment (voice breaks themselves are
    # already counted by the vcd_* block above, which uses the unbridged mask).
    vb = vcd.copy()
    for a, b in ru:
        if a > 0 and b < n and (b - a) <= 3:
            vb[a:b] = True
    rb = _runs(vb)
    if rb:
        a, b = max(rb, key=lambda r: r[1] - r[0])
        if (b - a) >= int(FS):
            seg = _detrend(st[a:b])
            out.update(band_power(seg, FS, F0_TREM_BANDS, f"{P}f0trem"))
            out.update(_band_amp(seg, FS, F0_TREM_BANDS, f"{P}f0trem"))
    return out


# ------------------------------------------------------------------ loudness
def summarise_loudness(rec: dict) -> dict:
    l = _raw1d(rec["value"])
    l = np.nan_to_num(l.astype(np.float64), nan=0.0, posinf=0.0, neginf=0.0)
    l = np.clip(l, 0.0, None)
    n = l.size
    out: dict = {}
    if n < 5:
        return out
    dur = n / FS
    t_all = np.arange(n, dtype=np.float64) / FS
    db = 20.0 * np.log10(np.clip(l, LD_FLOOR, None))

    # ---- envelope level and rate of change --------------------------------
    out.update(robust_stats(db, f"{P}ld_db"))
    out.update(delta_stats(db, f"{P}ld_db", FS))

    # ---- amplitude modulation: syllable rhythm and amplitude tremor -------
    dbd = _detrend(db)
    out.update(band_power(dbd, FS, LD_MOD_BANDS, f"{P}ldmod"))
    out.update(_band_amp(dbd, FS, LD_MOD_BANDS, f"{P}ldmod"))

    # ---- envelope peaks: syllable/pulse count and rhythm regularity -------
    if n >= 9:
        sm = np.convolve(db, np.ones(3) / 3.0, mode="same")
        pk, props = find_peaks(sm, prominence=4.0, distance=3)
        out[f"{P}ld_peak_rate"] = float(pk.size) / dur
        if pk.size >= 1:
            out[f"{P}ld_peak_prom_mean"] = float(np.mean(props["prominences"]))
        if pk.size >= 3:
            ioi = np.diff(pk).astype(np.float64) / FS
            m = float(ioi.mean())
            out[f"{P}ld_ioi_mean_s"] = m
            out[f"{P}ld_ioi_cv"] = float(ioi.std() / m) if m > 1e-9 else np.nan

    # ---- pause structure from low-loudness runs ---------------------------
    thr = float(np.percentile(db, 95)) - 25.0
    low = db < thr
    out[f"{P}pause_lowfrac"] = float(low.mean())
    rl = _runs(low)
    pl = np.array([(b - a) / FS for a, b in rl if (b - a) >= 8], dtype=np.float64)
    out[f"{P}pause_rate_per_s"] = float(pl.size) / dur
    out[f"{P}pause_time_frac"] = float(pl.sum() / dur) if pl.size else 0.0
    out.update(_run_stats(pl, f"{P}pause"))
    pmask = np.zeros(n, dtype=bool)
    for a, b in rl:
        if (b - a) >= 8:
            pmask[a:b] = True
    sp = np.array([(b - a) / FS for a, b in _runs(~pmask)], dtype=np.float64)
    if sp.size:
        out[f"{P}speech_run_mean_s"] = float(sp.mean())
        out[f"{P}speech_run_med_s"] = float(np.median(sp))

    # ---- trend and phonation decay ----------------------------------------
    out.update(_slope(t_all, db, f"{P}ld_db"))
    q = n // 4
    if q >= 2:
        f, la = float(l[:q].mean()), float(l[-q:].mean())
        if f > 1e-9:
            out[f"{P}ld_q4q1_ratio"] = la / f
            out[f"{P}ld_q4q1_db"] = 20.0 * np.log10(max(la, LD_FLOOR) / max(f, LD_FLOOR))
    return out


# ------------------------------------------------- deterministic column sets
def _rs(prefix):
    return [f"{prefix}_{s}" for s in ("mean", "std", "cv", "p5", "p25", "p50",
                                      "p75", "p95", "iqr", "range9", "skew", "kurt")]


def _bp(prefix, bands):
    return ([f"{prefix}_bp_{b}" for b in bands]
            + [f"{prefix}_peak_freq", f"{prefix}_spec_entropy"])


PITCH_COLS = (
    [f"{P}dur_s"]
    + _rs(f"{P}per") + [f"{P}per_frac_gt80", f"{P}per_frac_lt20",
                        f"{P}per_vel_absmean", f"{P}per_slope", f"{P}per_slope_r2"]
    + [f"{P}vcd_frac", f"{P}vcd_nruns_per_s", f"{P}vcd_trans_per_s",
       f"{P}vcd_run_mean_s", f"{P}vcd_run_med_s", f"{P}vcd_run_max_s", f"{P}vcd_run_cv",
       f"{P}vcd_unv_mean_s", f"{P}vcd_unv_med_s", f"{P}vcd_unv_max_s",
       f"{P}vcd_breaks_per_s", f"{P}vcd_shortbreak_per_s"]
    + _rs(f"{P}f0_st") + [f"{P}f0_hz_p50", f"{P}f0_st_slope", f"{P}f0_st_slope_r2",
                          f"{P}f0_q4q1_st"]
    + [f"{P}f0_st_vel_absmean", f"{P}f0_st_vel_p95", f"{P}f0_st_vel_std",
       f"{P}f0_st_rise_fall_ratio", f"{P}f0_st_acc_absmean", f"{P}f0_ppq3_st"]
    + [f"{P}f0_jit100_mean", f"{P}f0_jit200_mean", f"{P}f0_jit200_med",
       f"{P}f0_jit200_p90", f"{P}f0_jit_ratio"]
    + _bp(f"{P}f0mod", F0_MOD_BANDS)
    + _bp(f"{P}f0trem", F0_TREM_BANDS)
    + [f"{P}f0trem_amp_{b}" for b in F0_TREM_BANDS]
)

LOUD_COLS = (
    _rs(f"{P}ld_db")
    + [f"{P}ld_db_vel_absmean", f"{P}ld_db_vel_p95", f"{P}ld_db_acc_absmean",
       f"{P}ld_db_jerk"]
    + _bp(f"{P}ldmod", LD_MOD_BANDS)
    + [f"{P}ldmod_amp_{b}" for b in LD_MOD_BANDS]
    + [f"{P}ld_peak_rate", f"{P}ld_peak_prom_mean", f"{P}ld_ioi_mean_s", f"{P}ld_ioi_cv"]
    + [f"{P}pause_lowfrac", f"{P}pause_rate_per_s", f"{P}pause_time_frac",
       f"{P}pause_mean_s", f"{P}pause_med_s", f"{P}pause_max_s",
       f"{P}speech_run_mean_s", f"{P}speech_run_med_s"]
    + [f"{P}ld_db_slope", f"{P}ld_db_slope_r2", f"{P}ld_q4q1_ratio", f"{P}ld_q4q1_db"]
)


# ------------------------------------------------------------------- drivers
def run_pitch(limit_groups=None) -> pd.DataFrame:
    """Stream sparc_pitch and sparc_periodicity in lockstep."""
    t0 = time.time()
    gp = iter_row_groups(PARQUET["sparc_pitch"], columns=KEYS + ["pitch", "n_frames"],
                         limit_groups=limit_groups)
    ge = iter_row_groups(PARQUET["sparc_periodicity"], columns=KEYS + ["periodicity"],
                         limit_groups=limit_groups)
    chunks, n_rows, n_fail, n_mis = [], 0, 0, 0
    for gi, (a, b) in enumerate(zip(gp, ge)):
        recs = []
        aligned = len(a) == len(b) and a[KEYS].reset_index(drop=True).equals(
            b[KEYS].reset_index(drop=True))
        if not aligned:
            n_mis += len(a)
        pv = b["periodicity"].to_numpy() if aligned else None
        for i, row in enumerate(a.itertuples(index=False)):
            d = dict(zip(KEYS, (row.participant_id, row.session_id, row.task_name)))
            try:
                d.update(summarise_pitch(row.pitch,
                                         pv[i] if pv is not None else None,
                                         row.n_frames))
            except Exception:
                n_fail += 1
            recs.append(d)
        n_rows += len(recs)
        chunks.append(pd.DataFrame.from_records(recs))
        print(f"  pitch group {gi}: {n_rows} rows, {time.time() - t0:.0f}s", flush=True)
        del a, b
    out = pd.concat(chunks, ignore_index=True)
    print(f"pitch/periodicity: {out.shape[0]} rows, {n_fail} failures, "
          f"{n_mis} unaligned, {time.time() - t0:.0f}s", flush=True)
    return out


def main(limit_groups=None, tag=""):
    SCRATCH.mkdir(parents=True, exist_ok=True)
    pit = run_pitch(limit_groups)
    lou = extract(PARQUET["sparc_loudness"], "loudness", summarise_loudness,
                  SCRATCH / f"_loudness{tag}.parquet", limit_groups=limit_groups,
                  progress_every=4)

    pit = pit.reindex(columns=KEYS + PITCH_COLS)
    lou = lou.reindex(columns=KEYS + LOUD_COLS)
    out = pit.merge(lou, on=KEYS, how="outer")
    out = out.reindex(columns=KEYS + PITCH_COLS + LOUD_COLS)
    for c in out.columns:
        if c not in KEYS:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype(np.float32)
        else:
            out[c] = out[c].astype(str)
    out = out.replace([np.inf, -np.inf], np.nan)

    dest = (DATA if not tag else SCRATCH) / f"dyn_{NAME}{tag}.parquet"
    out.to_parquet(dest, index=False)
    print(f"\nwrote {dest}: {out.shape[0]} rows x {out.shape[1]} cols "
          f"({out.shape[1] - 3} features)", flush=True)
    nanfrac = out.drop(columns=KEYS).isna().mean().sort_values()
    print(f"NaN fraction: min={nanfrac.min():.4f} max={nanfrac.max():.4f}")
    print(nanfrac.tail(12).to_string())
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=None)
    a = ap.parse_args()
    main(a.limit, tag="_test" if a.limit else "")
