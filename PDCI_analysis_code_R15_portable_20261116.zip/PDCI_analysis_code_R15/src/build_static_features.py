"""Per-participant static (openSMILE/Praat) feature matrix + engineered features.

Three stages:
  recording -> (participant x task_group) mean  -> participant-level blocks

Averaging through the task-group level first matters: `breathing` contributes
6798 recordings and `rainbow_passage` only 823, so a plain mean over recordings
would let the respiration trials dominate the "average across tasks" feature.

Output blocks, all written to analysis/data/:
  static_bytask.parquet  participant x task_group x feature (long-form intermediate)
  static_participant.parquet  the modelling matrix, columns prefixed by block:
     avg_*   mean across task groups          (Yicheng's "average of all tasks")
     sdt_*   std across task groups           (within-participant instability)
     t_<task>_*  per-core-task means          (the "individual task features" set)
     eng_*   engineered contrasts and indices
     qc_*    recording-quality / coverage nuisance variables
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402

warnings.filterwarnings("ignore", category=RuntimeWarning)

KEY = ["participant_id", "session_id", "task_name"]


def load_recordings() -> pd.DataFrame:
    df = pd.read_csv(C.STATIC_TSV, sep="\t", dtype={"participant_id": str,
                                                    "session_id": str,
                                                    "task_name": str})
    df = df.drop(columns=["transcription"], errors="ignore")
    feats = [c for c in df.columns if c not in KEY]
    df[feats] = df[feats].apply(pd.to_numeric, errors="coerce")
    df["task_group"] = df["task_name"].map(C.task_group)
    df["task_fine"] = df["task_name"].map(C.task_fine)
    return df


def by_task(df: pd.DataFrame, feats: list[str]) -> pd.DataFrame:
    """Mean of each feature within participant x task_group."""
    return df.groupby(["participant_id", "task_group"])[feats].mean()


# ------------------------------------------------------------------ engineered
def _t(bt: pd.DataFrame, task: str, feat: str) -> pd.Series:
    """Feature `feat` for task group `task`, indexed by participant."""
    try:
        return bt.xs(task, level="task_group")[feat]
    except KeyError:
        return pd.Series(dtype=float)


def engineered(df: pd.DataFrame, bt: pd.DataFrame, feats: list[str],
               index: pd.Index) -> pd.DataFrame:
    e = pd.DataFrame(index=index)

    def g(task, feat):
        return _t(bt, task, feat).reindex(index)

    # -- 1. sustained phonation vs connected speech ------------------------
    # The sustained vowel isolates laryngeal function; connected speech adds
    # prosodic and neuromotor load.  The contrast separates a purely
    # structural voice problem from a neurological one.
    for feat, tag in [("mean_f0_hertz", "f0"), ("local_jitter", "jitter"),
                      ("local_shimmer", "shimmer"), ("mean_hnr_db", "hnr"),
                      ("cepstral_peak_prominence_mean", "cpp"),
                      ("HNRdBACF_sma3nz_amean", "hnracf")]:
        v, s = g("prolonged_vowel", feat), g("free_speech", feat)
        e[f"eng_{tag}_vowel_minus_speech"] = v - s
        with np.errstate(divide="ignore", invalid="ignore"):
            e[f"eng_{tag}_vowel_over_speech"] = v / s.replace(0, np.nan)

    # -- 2. reading vs spontaneous speech ---------------------------------
    # Reading is externally paced; spontaneous speech adds lexical retrieval
    # and planning load, so the gap indexes cognitive-linguistic cost.
    for feat, tag in [("speaking_rate", "speechrate"), ("articulation_rate", "artrate"),
                      ("pause_rate", "pauserate"), ("mean_pause_duration", "pausedur"),
                      ("phonation_ratio", "phonratio")]:
        read = g("rainbow_passage", feat)
        spont = pd.concat([g("free_speech", feat), g("picture_description", feat)],
                          axis=1).mean(axis=1)
        e[f"eng_{tag}_read_minus_spont"] = read - spont
    # Story recall additionally taxes memory; contrast it with plain reading.
    e["eng_speechrate_recall_minus_read"] = (g("story_recall", "speaking_rate")
                                             - g("rainbow_passage", "speaking_rate"))
    e["eng_pauserate_recall_minus_read"] = (g("story_recall", "pause_rate")
                                            - g("rainbow_passage", "pause_rate"))

    # -- 3. vocal dynamic range -------------------------------------------
    e["eng_intensity_loud_minus_habitual"] = (g("loudness", "mean_intensity_db")
                                              - g("free_speech", "mean_intensity_db"))
    e["eng_loudness_loud_minus_habitual"] = (g("loudness", "loudness_sma3_amean")
                                             - g("free_speech", "loudness_sma3_amean"))

    # -- 4. phonational frequency range from the pitch glides -------------
    up = df[df.task_fine == "glide_up"]
    dn = df[df.task_fine == "glide_down"]
    hi = up.groupby("participant_id")["F0semitoneFrom27.5Hz_sma3nz_percentile80.0"].mean()
    lo = dn.groupby("participant_id")["F0semitoneFrom27.5Hz_sma3nz_percentile20.0"].mean()
    e["eng_phonational_range_st"] = (hi.reindex(index) - lo.reindex(index))
    e["eng_glide_range_st"] = g("glides", "F0semitoneFrom27.5Hz_sma3nz_pctlrange0-2")
    e["eng_glide_slope_rise"] = g("glides", "F0semitoneFrom27.5Hz_sma3nz_meanRisingSlope")
    e["eng_glide_slope_fall"] = g("glides", "F0semitoneFrom27.5Hz_sma3nz_meanFallingSlope")
    with np.errstate(divide="ignore", invalid="ignore"):
        e["eng_glide_slope_asym"] = (e["eng_glide_slope_rise"].abs()
                                     / e["eng_glide_slope_fall"].abs().replace(0, np.nan))

    # -- 5. diadochokinesis: alternating vs sequential motion rate --------
    # Sequential motion (pataka) degrades before alternating motion (pa/ta/ka)
    # in dysarthria, so the gap is more specific than either rate alone.
    ddk = df[df.task_fine.notna() & df.task_fine.str.startswith("ddk_", na=False)]
    for rate_feat, tag in [("loudnessPeaksPerSec", "peakrate"),
                           ("VoicedSegmentsPerSec", "vseg"),
                           ("speaking_rate", "sylrate")]:
        alt = ddk[ddk.task_fine.isin(["ddk_pa", "ddk_ta", "ddk_ka"])]
        seq = ddk[ddk.task_fine.isin(["ddk_pataka", "ddk_buttercup"])]
        a = alt.groupby("participant_id")[rate_feat].mean().reindex(index)
        s = seq.groupby("participant_id")[rate_feat].mean().reindex(index)
        e[f"eng_ddk_alt_{tag}"] = a
        e[f"eng_ddk_seq_{tag}"] = s
        e[f"eng_ddk_seq_minus_alt_{tag}"] = s - a
    # Consistency across the three alternating syllables: place-of-articulation
    # asymmetry and trial-to-trial irregularity.
    alt = ddk[ddk.task_fine.isin(["ddk_pa", "ddk_ta", "ddk_ka"])]
    per_syll = alt.groupby(["participant_id", "task_fine"])["loudnessPeaksPerSec"].mean()
    e["eng_ddk_syllable_sd"] = per_syll.groupby("participant_id").std().reindex(index)
    e["eng_ddk_trial_cv"] = (alt.groupby("participant_id")["loudnessPeaksPerSec"].std()
                             / alt.groupby("participant_id")["loudnessPeaksPerSec"].mean()
                             ).reindex(index)
    e["eng_ddk_pa_minus_ka"] = (
        alt[alt.task_fine == "ddk_pa"].groupby("participant_id")["loudnessPeaksPerSec"].mean()
        - alt[alt.task_fine == "ddk_ka"].groupby("participant_id")["loudnessPeaksPerSec"].mean()
    ).reindex(index)

    # -- 6. maximum phonation time -----------------------------------------
    mpt = df[df.task_group == "maximum_phonation_time"]
    grp = mpt.groupby("participant_id")["duration"]
    e["eng_mpt_max"] = grp.max().reindex(index)
    e["eng_mpt_mean"] = grp.mean().reindex(index)
    e["eng_mpt_cv"] = (grp.std() / grp.mean()).reindex(index)
    # Phonation decay within the longest trial: HNR and intensity variability
    # rise as the fold closure fails late in a sustained /a/.
    e["eng_mpt_hnr"] = g("maximum_phonation_time", "mean_hnr_db")
    e["eng_mpt_intensity_sd"] = g("maximum_phonation_time", "std_intensity_db")
    e["eng_mpt_f0_sd"] = g("maximum_phonation_time", "std_f0_hertz")
    with np.errstate(divide="ignore", invalid="ignore"):
        e["eng_s_over_mpt"] = (g("prolonged_vowel", "duration")
                               / e["eng_mpt_max"].replace(0, np.nan))

    # -- 7. respiratory / cough --------------------------------------------
    e["eng_cough_intensity"] = g("cough_respiration", "mean_intensity_db")
    e["eng_cough_spectral_gravity"] = g("cough_respiration", "spectral_gravity")
    e["eng_cough_duration"] = g("cough_respiration", "duration")
    e["eng_breath_duration"] = g("breathing", "duration")
    e["eng_breath_intensity"] = g("breathing", "mean_intensity_db")
    with np.errstate(divide="ignore", invalid="ignore"):
        e["eng_cough_over_speech_intensity"] = (
            e["eng_cough_intensity"] / g("free_speech", "mean_intensity_db").replace(0, np.nan))

    # -- 8. composite clinical indices -------------------------------------
    # Acoustic-voice-quality style composite: breathiness/noise up, harmonic
    # structure down.  Standardised so the components share a scale.
    def z(s):
        s = s.astype(float)
        sd = s.std()
        return (s - s.mean()) / sd if sd and np.isfinite(sd) else s * 0.0

    cpp = g("prolonged_vowel", "cepstral_peak_prominence_mean")
    hnr = g("prolonged_vowel", "mean_hnr_db")
    shim = g("prolonged_vowel", "local_shimmer")
    jit = g("prolonged_vowel", "local_jitter")
    tilt = g("prolonged_vowel", "spectral_tilt")
    e["eng_dysphonia_index"] = (z(shim) + z(jit) - z(cpp) - z(hnr)) / 4.0
    e["eng_avqi_proxy"] = (-z(cpp) - z(hnr) + z(tilt) + z(shim)) / 4.0
    with np.errstate(divide="ignore", invalid="ignore"):
        e["eng_jitter_shimmer_ratio"] = jit / shim.replace(0, np.nan)
        e["eng_cpp_over_hnr"] = cpp / hnr.replace(0, np.nan)

    # Pause burden and speech efficiency across connected-speech tasks.
    conn = ["free_speech", "picture_description", "rainbow_passage", "story_recall"]
    pr = pd.concat([g(t, "pause_rate") for t in conn], axis=1).mean(axis=1)
    pd_ = pd.concat([g(t, "mean_pause_duration") for t in conn], axis=1).mean(axis=1)
    sr = pd.concat([g(t, "speaking_rate") for t in conn], axis=1).mean(axis=1)
    ar = pd.concat([g(t, "articulation_rate") for t in conn], axis=1).mean(axis=1)
    e["eng_pause_burden"] = pr * pd_
    with np.errstate(divide="ignore", invalid="ignore"):
        e["eng_speech_efficiency"] = sr / ar.replace(0, np.nan)
    e["eng_conn_speaking_rate"] = sr
    e["eng_conn_articulation_rate"] = ar

    # -- 9. cross-task instability -----------------------------------------
    # A voice that behaves inconsistently across tasks is itself a signal
    # (laryngeal dystonia, muscle tension dysphonia).
    for feat, tag in [("mean_f0_hertz", "f0"), ("local_jitter", "jitter"),
                      ("cepstral_peak_prominence_mean", "cpp"),
                      ("mean_hnr_db", "hnr"), ("mean_intensity_db", "intensity")]:
        sub = bt[feat].unstack("task_group").reindex(index)
        core = [t for t in C.CORE_TASKS if t in sub.columns]
        e[f"eng_crosstask_cv_{tag}"] = (sub[core].std(axis=1)
                                        / sub[core].mean(axis=1).abs().replace(0, np.nan))

    # Within-task trial-to-trial instability for the repeated tasks.
    for tg, tag in [("free_speech", "fs"), ("maximum_phonation_time", "mpt"),
                    ("cape_v_sentences", "capev")]:
        sub = df[df.task_group == tg]
        if len(sub):
            for feat, ft in [("mean_f0_hertz", "f0"), ("local_jitter", "jitter")]:
                m = sub.groupby("participant_id")[feat].mean()
                s = sub.groupby("participant_id")[feat].std()
                e[f"eng_trialcv_{tag}_{ft}"] = (s / m.abs().replace(0, np.nan)).reindex(index)
    return e


def quality_block(df: pd.DataFrame, index: pd.Index) -> pd.DataFrame:
    q = pd.DataFrame(index=index)
    for f in C.QUALITY_FEATURES:
        if f in df.columns:
            g = df.groupby("participant_id")[f]
            q[f"qc_{f}_mean"] = g.mean().reindex(index)
            q[f"qc_{f}_std"] = g.std().reindex(index)
    q["qc_n_recordings"] = df.groupby("participant_id").size().reindex(index)
    q["qc_n_task_groups"] = df.groupby("participant_id")["task_group"].nunique().reindex(index)
    q["qc_n_sessions"] = df.groupby("participant_id")["session_id"].nunique().reindex(index)
    q["qc_total_duration"] = df.groupby("participant_id")["duration"].sum().reindex(index)
    return q


def main():
    df = load_recordings()
    feats = [c for c in df.columns if c not in KEY + ["task_group", "task_fine"]]
    print(f"recordings: {len(df)}   raw features: {len(feats)}   "
          f"participants: {df.participant_id.nunique()}")

    bt = by_task(df, feats)
    bt.to_parquet(C.DATA / "static_bytask.parquet")
    index = pd.Index(sorted(df.participant_id.unique()), name="participant_id")

    # Model features only -- recording quality goes in its own block so a
    # model can be run with or without it.
    model_feats = [f for f in feats if f not in C.QUALITY_FEATURES]

    wide = bt[model_feats].unstack("task_group")            # (participant, feat x task)
    avg = wide.T.groupby(level=0).mean().T                  # mean across task groups
    sdt = wide.T.groupby(level=0).std().T                   # std across task groups
    avg.columns = [f"avg_{c}" for c in avg.columns]
    sdt.columns = [f"sdt_{c}" for c in sdt.columns]
    avg, sdt = avg.reindex(index), sdt.reindex(index)

    per_task = {}
    for t in C.CORE_TASKS:
        if t in wide.columns.get_level_values(1):
            sub = wide.xs(t, axis=1, level=1)
            sub.columns = [f"t_{t}_{c}" for c in sub.columns]
            per_task[t] = sub.reindex(index)
    per_task = pd.concat(per_task.values(), axis=1)

    eng = engineered(df, bt, feats, index)
    qc = quality_block(df, index)

    out = pd.concat([avg, sdt, per_task, eng, qc], axis=1)
    out = out.replace([np.inf, -np.inf], np.nan)
    out.to_parquet(C.DATA / "static_participant.parquet")

    blocks = {"avg": avg.shape[1], "sdt": sdt.shape[1], "per_task": per_task.shape[1],
              "eng": eng.shape[1], "qc": qc.shape[1]}
    print(f"static_participant: {out.shape[0]} participants x {out.shape[1]} features")
    print("  blocks:", blocks)
    nan_frac = out.isna().mean()
    print(f"  columns >50% NaN: {(nan_frac > .5).sum()}   >20% NaN: {(nan_frac > .2).sum()}")
    print(f"  all-NaN columns:  {(nan_frac == 1).sum()}")
    worst = nan_frac[nan_frac > .5].sort_values(ascending=False).head(12)
    if len(worst):
        print("  worst:", {k: round(v, 2) for k, v in worst.items()})
    print("\nengineered feature NaN fractions (sample):")
    en = eng.isna().mean().sort_values(ascending=False)
    print("  worst 8:", {k: round(v, 3) for k, v in en.head(8).items()})
    print("  best 4: ", {k: round(v, 3) for k, v in en.tail(4).items()})


if __name__ == "__main__":
    main()
