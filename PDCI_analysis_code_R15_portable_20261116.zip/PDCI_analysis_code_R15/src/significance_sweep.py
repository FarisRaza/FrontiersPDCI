"""Per-task and per-feature significance counts, across every target.

This is the corrected, extended version of the team's counts_by_task /
counts_by_feature tables.  Three differences from the existing version:

  * labels are the corrected ones (ADHD and PTSD are scored screeners, not
    "was handed this questionnaire"), so the psychiatric targets are no longer
    contrasting cohort assignment with itself;
  * dynamic time-series features are included alongside the static ones;
  * counts are reported after Benjamini-Hochberg FDR control as well as at raw
    alpha.  At raw alpha=0.05 roughly 5% of tests are expected to be
    "significant" with no signal at all, so a raw proportion is only
    interpretable against that floor.

Usage:  python src/significance_sweep.py [--jobs N]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import datasets  # noqa: E402

KEY = ["participant_id", "session_id", "task_name"]
DYN_BYTASK = C.DATA / "dynamic_bytask.parquet"


def dynamic_bytask() -> pd.DataFrame:
    if DYN_BYTASK.exists():
        return pd.read_parquet(DYN_BYTASK)
    frames = []
    for p in sorted(C.DATA.glob("dyn_*.parquet")):
        if "TEST" in p.name:
            continue
        d = pd.read_parquet(p).drop_duplicates(subset=KEY, keep="first")
        frames.append(d.set_index(KEY)[[c for c in d.columns if c not in KEY]])
    df = pd.concat(frames, axis=1, join="outer")
    df = df.loc[:, ~df.columns.duplicated()].reset_index()
    df["task_group"] = df["task_name"].map(C.task_group)
    feats = [c for c in df.columns if c not in KEY + ["task_group"]]
    out = df.groupby(["participant_id", "task_group"])[feats].mean()
    out.to_parquet(DYN_BYTASK)
    return out


def test_block(bt: pd.DataFrame, labels: pd.Series, target: str,
               modality: str, min_per_group: int = 8) -> pd.DataFrame:
    """Mann-Whitney U for every (task_group, feature) against one target."""
    rows = []
    for task, sub in bt.groupby(level="task_group"):
        m = sub.droplevel("task_group")
        y = labels.reindex(m.index)
        keep = y.notna()
        m, y = m[keep], y[keep].astype(int)
        if y.sum() < min_per_group or (y == 0).sum() < min_per_group:
            continue
        A = m[y == 1].to_numpy(dtype=float)
        B = m[y == 0].to_numpy(dtype=float)
        nA = np.isfinite(A).sum(axis=0)
        nB = np.isfinite(B).sum(axis=0)
        usable = (nA >= min_per_group) & (nB >= min_per_group)
        if not usable.any():
            continue
        idx = np.flatnonzero(usable)
        try:
            u, p = stats.mannwhitneyu(A[:, idx], B[:, idx], axis=0,
                                      alternative="two-sided",
                                      nan_policy="omit")
        except Exception:
            continue
        auc = np.asarray(u, dtype=float) / (nA[idx] * nB[idx])
        rows.append(pd.DataFrame({
            "target": target, "modality": modality, "task_group": task,
            "feat": m.columns[idx], "p": np.asarray(p, dtype=float),
            "auc": auc, "n_pos": int(y.sum()), "n_neg": int((y == 0).sum()),
        }))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-positives", type=int, default=C.MIN_POSITIVES)
    args = ap.parse_args()

    cohort = pd.read_parquet(C.DATA / "cohort.parquet")
    static_bt = pd.read_parquet(C.DATA / "static_bytask.parquet")
    dyn_bt = dynamic_bytask()
    print(f"static by-task: {static_bt.shape}   dynamic by-task: {dyn_bt.shape}")

    targets = [t for t in datasets.all_targets()
               if np.nansum(cohort[t].values) >= args.min_positives]
    print(f"testing {len(targets)} targets\n")

    all_rows = []
    for t in targets:
        y = cohort[t]
        a = test_block(static_bt, y, t, "static")
        b = test_block(dyn_bt, y, t, "dynamic")
        part = pd.concat([x for x in (a, b) if len(x)], ignore_index=True)
        if not len(part):
            continue
        # FDR is controlled within each target: the question "which features
        # separate THIS disease" is one family of tests.
        ok = part["p"].notna()
        part["p_fdr"] = np.nan
        part.loc[ok, "p_fdr"] = multipletests(part.loc[ok, "p"], method="fdr_bh")[1]
        all_rows.append(part)
        print(f"  {t:<32s} {len(part):6d} tests, "
              f"{int((part.p < .05).sum()):5d} raw p<.05, "
              f"{int((part.p_fdr < .05).sum()):5d} FDR<.05")

    res = pd.concat(all_rows, ignore_index=True)
    res.to_parquet(C.RESULTS / "significance_tests.parquet", index=False)

    def counts(by):
        g = res.groupby(by)
        out = g.agg(n_tests=("p", "size"),
                    n_sig_95=("p", lambda s: int((s < .05).sum())),
                    n_sig_99=("p", lambda s: int((s < .01).sum())),
                    n_sig_fdr=("p_fdr", lambda s: int((s < .05).sum())),
                    median_abs_auc=("auc", lambda s: float((s - .5).abs().median() + .5)),
                    max_abs_auc=("auc", lambda s: float(
                        (s - .5).abs().max() + .5 if len(s) else np.nan)))
        out["prop_sig_95"] = out.n_sig_95 / out.n_tests
        out["prop_sig_99"] = out.n_sig_99 / out.n_tests
        out["prop_sig_fdr"] = out.n_sig_fdr / out.n_tests
        return out.sort_values("prop_sig_fdr", ascending=False)

    by_task = counts("task_group")
    by_feat = counts("feat")
    by_target = counts("target")
    by_task.to_csv(C.RESULTS / "counts_by_task.csv")
    by_feat.to_csv(C.RESULTS / "counts_by_feature.csv")
    by_target.to_csv(C.RESULTS / "counts_by_target.csv")
    counts(["modality"]).to_csv(C.RESULTS / "counts_by_modality.csv")

    print(f"\ntotal tests: {len(res)}   raw p<.05: {(res.p < .05).mean():.3f}  "
          f"(0.050 expected under the null)   FDR<.05: {(res.p_fdr < .05).mean():.3f}")
    print("\ntop tasks by FDR-significant proportion:")
    print(by_task[["n_tests", "n_sig_95", "n_sig_fdr", "prop_sig_95",
                   "prop_sig_fdr", "max_abs_auc"]].head(12).round(3).to_string())
    print("\ntop features by FDR-significant proportion:")
    print(by_feat[["n_tests", "n_sig_fdr", "prop_sig_fdr", "max_abs_auc"]]
          .head(20).round(3).to_string())
    print("\nby modality:")
    print(counts(["modality"])[["n_tests", "n_sig_fdr", "prop_sig_fdr"]]
          .round(3).to_string())


if __name__ == "__main__":
    main()
