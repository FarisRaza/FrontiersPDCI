"""A5 matched sensitivity-policy comparison; local author review only."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, platform, sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import scipy, sklearn
from scipy.stats import norm
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

ANALYSIS=Path(__file__).resolve().parents[1]
OUT=ANALYSIS/"results/pdci_a5_matched_policy_20261001"
SOURCE=ANALYSIS/"results/pdci_demographic_baseline_20260911"
ARCHIVE=ANALYSIS/"results/pdci_sensitivity_policy_20260912"
LOCAL=OUT/"local_only"
PRIMARY="separate98_pd95"
MODELS={"voice":("primary","screen","stage2"),"baseline":("agesexcountry","asc_screen","asc_stage2")}
NBOOT=5000
SEED=20261001
TOL=1e-12
spec=importlib.util.spec_from_file_location("archived_policy",ANALYSIS/"src/pdci_sensitivity_policy_20260912.py")
P=importlib.util.module_from_spec(spec)
spec.loader.exec_module(P)

def stamp(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for chunk in iter(lambda:f.read(1024**2),b""): h.update(chunk)
    return h.hexdigest()
def write_json(p,v):
    Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+"\n",encoding="utf-8")
def read_csv(p): return pd.read_csv(p,float_precision="round_trip")
def write_csv(name,df): df.to_csv(OUT/name,index=False,float_format="%.17g")
def inputs():
    paths=[Path(__file__).resolve(),OUT/"ANALYSIS_PLAN.md",
        ANALYSIS/"src/pdci_sensitivity_policy_20260912.py",
        ANALYSIS/"src/pdci_demographic_baseline_20260911.py",
        SOURCE/"local_only/split_manifest.json",SOURCE/"local_only/participant_oof_predictions.parquet"]
    for name in ("FROZEN_SPEC.json","AUDIT.json","COMPLETION.json","feature_schemas.json",
                 "pooled_oof_metrics.csv","operating_points.csv","confusion_matrices.csv"):
        paths.append(SOURCE/name)
    for oi in range(15):
        for suffix in (".json",".parquet","_selected_inner.parquet"):
            paths.append(SOURCE/f"local_only/folds/fold_{oi:02d}{suffix}")
    for name in ("ANALYSIS_PLAN.md","FROZEN_SPEC.json","AUDIT.json","COMPLETE.json",
                 "training_thresholds.csv","operating_points.csv","confusion_matrices.csv",
                 "local_only/participant_decisions.parquet"):
        paths.append(ARCHIVE/name)
    return sorted(set(paths))
def freeze():
    assert not (OUT/"FROZEN_SPEC.json").exists(),"A5 is already frozen; no overwrite"
    hashes={str(p):sha(p) for p in inputs()}
    old=json.loads((ARCHIVE/"FROZEN_SPEC.json").read_text())
    oldhash=old["protected_sha256"]
    verified=0
    for p,v in hashes.items():
        if p in oldhash:
            assert v==oldhash[p],"Historical source hash differs"
            verified+=1
    assert verified>=47,"Insufficient archived source hash coverage"
    oldaudit=json.loads((ARCHIVE/"AUDIT.json").read_text())
    for p,v in hashes.items():
        if p in oldaudit["output_sha256"]: assert v==oldaudit["output_sha256"][p],"Archived policy output hash differs"
    write_json(OUT/"FROZEN_SPEC.json",dict(status="FROZEN",created_utc=stamp(),
        analysis_family="F8-A5",post_hoc=True,primary_policy=PRIMARY,
        author_ruling="AR-24",hold_for_author_review=True,models_refitted=False,
        n_boot=NBOOT,seed=SEED,contrast="voice minus age/sex/country baseline at primary policy",
        scripts_and_inputs_sha256=hashes,
        archived_source_hashes_verified=verified,
        versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                      scipy=scipy.__version__,sklearn=sklearn.__version__)))
    print("Protocol frozen; historical source hashes verified; no new outcomes calculated.",flush=True)
def verify():
    frozen=json.loads((OUT/"FROZEN_SPEC.json").read_text())
    for section in ("scripts_and_inputs_sha256",):
        assert all(Path(p).exists() and sha(p)==v for p,v in frozen[section].items()),"Protected input changed"
    return frozen
def close(a,b):
    a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
    assert np.allclose(a,b,rtol=0,atol=TOL,equal_nan=True),"Numerical reproduction mismatch"
    x=np.abs(a-b); return float(np.nanmax(x)) if np.isfinite(x).any() else 0.
def selftest():
    p=np.array([.2,.2,.3,.6,.8])
    assert P.largest_threshold(p,.8)==.2
    assert P.largest_threshold(p,.4)==.6
    assert P.largest_threshold(p,1)==.2
    assert P.largest_threshold(p,.98)<=P.largest_threshold(p,.95)
    for bad in ([],[np.nan],[np.inf]):
        try: P.largest_threshold(bad,.95)
        except AssertionError: pass
        else: raise AssertionError("Missing finite-score guard")
    synthetic=pd.DataFrame(dict(participant_id=np.repeat(["a","b","c"],3),repeat=np.tile(range(3),3),
        screen_positive=[1,1,0,1,0,0,1,1,1],conditional_PD=[1,0,0,1,0,0,0,0,1],
        call=[1,2,0,1,0,0,2,2,1]))
    st=P.aggregate(synthetic,np.array(["a","b","c"]),"new")
    assert st["final"].tolist()==[1,0,2]
    old=P.aggregate(synthetic,np.array(["a","b","c"]),"legacy")
    assert old["final"].tolist()==[0,0,2]
    assert (np.array([.8])-np.array([.6])).item()>0
    return dict(status="PASS",ties=True,largest_feasible=True,nonfinite_rejected=True,
                voting_hand_cases=True,contrast_sign=True)
def load():
    ids,y,raw,inner,receipts=P.read_sources()
    for frame in inner:
        yy=frame.y_true.to_numpy()
        assert np.isfinite(frame.asc_screen).all()
        assert np.isfinite(frame.loc[yy>0,"asc_stage2"]).all()
        assert frame.loc[yy==0,"asc_stage2"].isna().all()
        for key in ("screen","asc_screen"):
            assert frame[key].between(0,1).all()
        for key in ("stage2","asc_stage2"):
            assert frame.loc[yy>0,key].between(0,1).all()
    assert np.isfinite(raw[["agesexcountry_screen","agesexcountry_q"]]).all().all()
    schema=json.loads((SOURCE/"feature_schemas.json").read_text())
    assert schema["demographic_baseline"]==["age","sex_male","residence_country_USA"]
    for r in receipts:
        assert "asc_screen" in r["choices"] and "asc_stage2" in r["choices"]
    return ids,y,raw,inner,receipts
def thresholds(inner,receipts,model,policies):
    prefix,sc,qc=MODELS[model]
    rows=[]
    for oi,train in enumerate(inner):
        y,s,q=(train[c].to_numpy() for c in ("y_true",sc,qc))
        for policy in policies:
            new=policy==PRIMARY
            st=min(P.largest_threshold(s[y==c],.98) for c in (1,2)) if new else P.largest_threshold(s[y>0],.95)
            qt=P.largest_threshold(q[y==1],.95) if new else .5
            close(st,P.reference_threshold(y,s,.98 if new else .95,separate=new))
            if new:
                close(qt,P.reference_threshold((y[y>0]==1).astype(int),q[y>0],.95,separate=False))
            else: close(st,receipts[oi]["thresholds"][prefix]["sens95"])
            row=dict(model=model,policy=policy,outer_fold=oi,repeat=oi//5,fold=oi%5,
                screen_threshold=st,pd_threshold=qt,train_PD_n=int((y==1).sum()),
                train_CI_n=int((y==2).sum()),train_neither_n=int((y==0).sum()),
                train_PD_referred=int(((y==1)&(s>=st)).sum()),
                train_CI_referred=int(((y==2)&(s>=st)).sum()),
                train_screen_PD_sensitivity=float(np.mean(s[y==1]>=st)),
                train_screen_CI_sensitivity=float(np.mean(s[y==2]>=st)),
                train_screen_specificity=float(np.mean(s[y==0]<st)),
                train_conditional_PD_positive=int(((y==1)&(q>=qt)).sum()),
                train_conditional_PD_sensitivity=float(np.mean(q[y==1]>=qt)),
                train_conditional_CI_specificity=float(np.mean(q[y==2]<qt)))
            if new:
                assert row["train_screen_PD_sensitivity"]>=.98-TOL
                assert row["train_screen_CI_sensitivity"]>=.98-TOL
                assert row["train_conditional_PD_sensitivity"]>=.95-TOL
            rows.append(row)
    return pd.DataFrame(rows)
def evaluate(ids,y,raw,th,model,policy):
    prefix=MODELS[model][0]
    d=raw[["participant_id","y_true","repeat","fold",prefix+"_screen",prefix+"_q"]].merge(
        th[th.policy.eq(policy)][["repeat","fold","screen_threshold","pd_threshold"]],
        on=["repeat","fold"],validate="many_to_one")
    assert len(d)==2250
    d["screen_positive"]=d[prefix+"_screen"]>=d.screen_threshold
    d["conditional_PD"]=d[prefix+"_q"]>=d.pd_threshold
    d["call"]=np.where(d.screen_positive,np.where(d.conditional_PD,1,2),0)
    if policy=="legacy95":
        old=raw.set_index(["participant_id","repeat"])[prefix+"_call_sens95"]
        close(d.call,old.reindex(pd.MultiIndex.from_frame(d[["participant_id","repeat"]])).to_numpy())
    state=P.aggregate(d,ids,"new" if policy==PRIMARY else "legacy")
    row,cm=P.describe(y,state,policy,"participant_majority")
    rows=[dict(model=model,**row)]
    cms=[dict(model=model,**z) for z in cm]
    for rep,group in d.groupby("repeat"):
        rr,cc=P.describe(group.y_true.to_numpy(int),
            dict(final=group.call.to_numpy(int),subtype_all=group.conditional_PD.to_numpy(bool)),
            policy,f"repeat_{rep}")
        rows.append(dict(model=model,**rr));cms.extend(dict(model=model,**z) for z in cc)
    return state,pd.DataFrame(rows),pd.DataFrame(cms),d
def cmcheck(frame,archive,model,policy):
    left=frame.set_index(["scope","true_class","predicted_class"]).n.sort_index()
    right=archive.copy()
    def label(x):
        return "Neither" if x.lower()=="neither" else "PD" if x.lower() in ("pd","parkinsons_disease") else "CI"
    right["true_class"]=right.true_class.map(label)
    right["predicted_class"]=right.predicted_class.map(label)
    right=right.set_index(["scope","true_class","predicted_class"]).n.sort_index()
    assert left.index.equals(right.index)
    assert np.array_equal(left.to_numpy(),right.to_numpy()),"Confusion gate mismatch"
    return len(left)
def gate():
    verify(); tests=selftest()
    ids,y,raw,inner,receipts=load()
    P.source_auc_check(ids,raw)
    archived=pd.read_parquet(SOURCE/"local_only/participant_oof_predictions.parquet").reindex(ids)
    cols=["agesexcountry_screen","agesexcountry_q"]+[f"agesexcountry_p{i}" for i in range(3)]
    pooled=raw.groupby("participant_id")[cols].mean().reindex(ids)
    close(pooled.to_numpy(),archived[cols].to_numpy())
    values=dict(screen=roc_auc_score(y>0,pooled[cols[0]]),
        stage2=roc_auc_score(y[y>0]==1,pooled.loc[y>0,cols[1]]),
        macro=roc_auc_score(y,pooled[cols[2:]],multi_class="ovr",average="macro"))
    saved_auc=read_csv(SOURCE/"pooled_oof_metrics.csv").set_index("model").loc["agesexcountry"]
    for k,v in values.items(): close(v,saved_auc[k])
    source_cm=read_csv(SOURCE/"confusion_matrices.csv")
    source_ops=read_csv(SOURCE/"operating_points.csv")
    arch_cm=read_csv(ARCHIVE/"confusion_matrices.csv")
    arch_ops=read_csv(ARCHIVE/"operating_points.csv")
    arch_th=read_csv(ARCHIVE/"training_thresholds.csv")
    checks=0; maxerr=0.; statecheck=0; verified=[]
    for model in MODELS:
        policies=[PRIMARY,"legacy95"] if model=="voice" else ["legacy95"]
        th=thresholds(inner,receipts,model,policies)
        if model=="voice":
            for pol in policies:
                left=th[th.policy.eq(pol)].sort_values("outer_fold")
                right=arch_th[arch_th.policy.eq(pol)].sort_values("outer_fold")
                for col in ("screen_threshold","pd_threshold"):
                    maxerr=max(maxerr,close(left[col],right[col]))
        for policy in policies:
            state,ops,cms,_=evaluate(ids,y,raw,th,model,policy)
            if model=="voice":
                checks+=cmcheck(cms,arch_cm[arch_cm.policy.eq(policy)],model,policy)
                saved=arch_ops[arch_ops.policy.eq(policy)].set_index("scope")
                ours=ops.set_index("scope")
                for col in saved.select_dtypes(include=[np.number]).columns:
                    if col in ours: maxerr=max(maxerr,close(ours.loc[saved.index,col],saved[col]))
            if policy=="legacy95":
                prefix=MODELS[model][0]
                checks+=cmcheck(cms,source_cm[source_cm.model.eq(prefix)&source_cm.gate.eq("sens95")],model,policy)
                saved=source_ops[source_ops.model.eq(prefix)&source_ops.gate.eq("sens95")].set_index("scope")
                ours=ops.set_index("scope")
                for new,old in (("screen_sensitivity","sensitivity"),("screen_specificity","specificity"),
                                ("screen_PPV","ppv"),("screen_NPV","npv"),("referrals","screen_positive"),
                                ("end_to_end_PD_recall","PD_recall"),("end_to_end_CI_recall","cognitive_impairment_recall")):
                    maxerr=max(maxerr,close(ours.loc[saved.index,new],saved[old]))
            if model=="voice" and policy==PRIMARY:
                saved=pd.read_parquet(ARCHIVE/"local_only/participant_decisions.parquet")
                saved=saved[saved.policy.eq(PRIMARY)].set_index("participant_id").reindex(ids)
                for col in state:
                    assert np.array_equal(state[col],saved[col].to_numpy()),"Participant vote mismatch"
                    statecheck+=len(ids)
            a=ops[ops.scope.eq("participant_majority")].iloc[0]
            got=[int(a.screen_sensitivity_numerator),int(a.end_to_end_PD_recall_numerator),
                 int(a.end_to_end_CI_recall_numerator),int(a.referrals)]
            expected=([149,84,22,366] if policy==PRIMARY else [139,65,29,266]) if model=="voice" else [135,56,17,246]
            assert got==expected,"User-reference counts differ from archive"
            verified.append(dict(model=model,policy=policy,counts=got))
    write_json(OUT/"GATE.json",dict(status="PASS",completed_utc=stamp(),tests=tests,
        outer_folds=15,participants=750,held_out_records=2250,disjoint_splits=True,
        own_training_inner_scores=True,baseline_columns=["age","sex_male","residence_country_USA"],
        archived_confusion_cells_matched=checks,voice_participant_state_values_matched=statecheck,
        max_numeric_error=maxerr,archived_reference_counts=verified,pooled_source_probabilities_and_AUROCs_matched=True))
    print("Reproduction gate PASS; archived voice policy and both original95 procedures matched.",flush=True)
def masks(y,state):
    final,sub=state["final"],state["subtype_all"]
    out=P.ratio_masks(y,final,sub)
    pd_,ci,neither=y==1,y==2,y==0
    out.update(screen_false_positive_rate=(neither&(final>0),neither),
        end_to_end_CI_PPV_vs_rest=(ci&(final==2),final==2),
        end_to_end_CI_specificity_vs_rest=((~ci)&(final!=2),~ci),
        correct_case_assignment=(((pd_&(final==1))|(ci&(final==2))),y>0),
        overall_accuracy=(y==final,np.ones(len(y),dtype=bool)))
    for c,label in enumerate(("neither","PD","CI")):
        for pred,plabel in enumerate(("neither","PD","CI")):
            if c!=pred: out[f"{label}_to_{plabel}_rate"]=((y==c)&(final==pred),y==c)
    return out
def point_rows(y,state,model):
    return [dict(model=model,policy=PRIMARY,metric=k,numerator=int(a.sum()),denominator=int(b.sum()),
                 estimate=float(a.sum()/b.sum()) if b.sum() else np.nan)
            for k,(a,b) in masks(y,state).items()]
def uncertainty(y,states):
    allmasks={m:masks(y,states[m]) for m in MODELS}
    metrics=list(allmasks["voice"])
    rng=np.random.default_rng(SEED)
    groups=[np.flatnonzero(y==c) for c in range(3)]
    weights=np.empty((NBOOT,len(y)),dtype=np.int16)
    for b in range(NBOOT):
        ix=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in groups])
        weights[b]=np.bincount(ix,minlength=len(y))
        assert all(int(weights[b,g].sum())==len(g) for g in groups)
    intervals=[]; arrays={}; points={}; direct=0
    for model in MODELS:
        nums=np.column_stack([a for a,b in allmasks[model].values()])
        dens=np.column_stack([b for a,b in allmasks[model].values()])
        n=weights.astype(float)@nums.astype(float); d=weights.astype(float)@dens.astype(float)
        arr=np.divide(n,d,out=np.full_like(n,np.nan),where=d>0)
        base=point_rows(y,states[model],model)
        points[model]={r["metric"]:r["estimate"] for r in base}
        for j,row in enumerate(base):
            valid=arr[:,j][np.isfinite(arr[:,j])]
            lo,hi=np.quantile(valid,[.025,.975]) if len(valid) else [np.nan,np.nan]
            intervals.append(dict(**row,ci_low=float(lo),ci_high=float(hi),n_boot=NBOOT,finite_draws=len(valid)))
        count_data={"referrals":states[model]["final"]>0,"neither_referred":(y==0)&(states[model]["final"]>0)}
        for key,mask in count_data.items():
            values=weights.astype(float)@mask.astype(float)
            arr=np.column_stack([arr,values])
            points[model][key]=int(mask.sum())
            lo,hi=np.quantile(values,[.025,.975])
            intervals.append(dict(model=model,policy=PRIMARY,metric=key,numerator=int(mask.sum()),denominator=1,
                estimate=int(mask.sum()),ci_low=float(lo),ci_high=float(hi),n_boot=NBOOT,finite_draws=NBOOT))
        arrays[model]=arr
        for i in range(20):
            ix=np.repeat(np.arange(len(y)),weights[i])
            for j,(a,b) in enumerate(allmasks[model].values()):
                expected=a[ix].sum()/b[ix].sum() if b[ix].sum() else np.nan
                close(arr[i,j],expected);direct+=1
    metrics+=["referrals","neither_referred"]
    differences=[]
    for j,k in enumerate(metrics):
        delta=arrays["voice"][:,j]-arrays["baseline"][:,j]
        valid=delta[np.isfinite(delta)]
        lo,hi=np.quantile(valid,[.025,.975]) if len(valid) else [np.nan,np.nan]
        differences.append(dict(policy=PRIMARY,candidate="voice",comparator="baseline",metric=k,
            difference=points["voice"][k]-points["baseline"][k],ci_low=float(lo),ci_high=float(hi),
            n_boot=NBOOT,finite_draws=len(valid)))
    np.savez_compressed(LOCAL/"bootstrap_draws.npz",voice=arrays["voice"],baseline=arrays["baseline"],metrics=np.array(metrics))
    return pd.DataFrame(intervals),pd.DataFrame(differences),direct
def run():
    verify()
    assert json.loads((OUT/"GATE.json").read_text())["status"]=="PASS"
    assert not (OUT/"RUN_RECEIPT.json").exists(),"Results already computed; refuse overwrite"
    started=stamp()
    ids,y,raw,inner,receipts=load()
    allth=[];allops=[];allcm=[];decisions=[]; primary_states={}
    for model in MODELS:
        th=thresholds(inner,receipts,model,[PRIMARY,"legacy95"]);allth.append(th)
        for policy in (PRIMARY,"legacy95"):
            state,ops,cm,_=evaluate(ids,y,raw,th,model,policy)
            allops.append(ops);allcm.append(cm)
            decisions.append(pd.DataFrame(dict(participant_id=ids,y_true=y,model=model,policy=policy,**state)))
            if policy==PRIMARY: primary_states[model]=state
    th=pd.concat(allth,ignore_index=True);ops=pd.concat(allops,ignore_index=True);cms=pd.concat(allcm,ignore_index=True)
    assert len(th)==60 and len(cms)==144
    assert all(g.n.sum()==750 for _,g in cms.groupby(["model","policy","scope"]))
    LOCAL.mkdir(exist_ok=True)
    pd.concat(decisions,ignore_index=True).to_parquet(LOCAL/"participant_decisions.parquet",index=False)
    intervals,differences,direct=uncertainty(y,primary_states)
    reference=intervals[~intervals.metric.isin(["referrals","neither_referred"])].copy()
    z=norm.ppf(.975); n=reference.denominator.to_numpy(float); p=reference.estimate.to_numpy(float)
    with np.errstate(divide="ignore",invalid="ignore"):
        center=(p+z*z/(2*n))/(1+z*z/n)
        half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    reference["wilson95_low"]=center-half;reference["wilson95_high"]=center+half
    reference=reference.drop(columns=["ci_low","ci_high","n_boot","finite_draws"])
    summary=ops[ops.scope.eq("participant_majority")][["model","policy","referrals","neither_referred",
        "screen_sensitivity_numerator","screen_sensitivity","screen_specificity",
        "end_to_end_PD_recall_numerator","end_to_end_PD_recall","end_to_end_CI_recall_numerator","end_to_end_CI_recall",
        "PD_to_neither","PD_to_CI","CI_to_neither","CI_to_PD"]]
    for name,frame in (("training_thresholds.csv",th),("operating_points.csv",ops),("confusion_matrices.csv",cms),
        ("policy_comparison.csv",summary),("nominal_bootstrap_intervals.csv",intervals),
        ("paired_primary_voice_minus_baseline.csv",differences),("wilson_reference_intervals.csv",reference)):
        write_csv(name,frame)
    verify()
    outputs=[p for p in OUT.glob("*.csv")]+[LOCAL/"participant_decisions.parquet",LOCAL/"bootstrap_draws.npz"]
    write_json(OUT/"RUN_RECEIPT.json",dict(status="AWAITING_INDEPENDENT_AUDIT",started_utc=started,ended_utc=stamp(),
        analysis_family="F8-A5",hold_for_author_review=True,models_refitted=False,outer_folds=15,participants=750,
        thresholds_rows=len(th),confusion_cells=len(cms),operating_rows=len(ops),bootstrap_draws=NBOOT,
        paired_metrics=len(differences),direct_bootstrap_checks=direct,
        all_frozen_analysis_inputs_unchanged=True,output_sha256={str(p):sha(p) for p in outputs}))
    print("A5 calculations saved locally; awaiting independent verification. No results pushed.",flush=True)
def main():
    ap=argparse.ArgumentParser();ap.add_argument("action",choices=["freeze","gate","run","verify"]);args=ap.parse_args()
    with threadpool_limits(1):
        if args.action=="freeze": freeze()
        elif args.action=="gate": gate()
        elif args.action=="run": run()
        else: verify();print("Protected inputs and manuscript unchanged.")
if __name__=="__main__": main()
