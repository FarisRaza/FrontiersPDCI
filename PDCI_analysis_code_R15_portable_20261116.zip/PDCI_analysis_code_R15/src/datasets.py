"""Assemble (X, y) for a given target x cohort x feature-set combination.

Feature blocks are kept separate on disk and combined here so that every model
run declares exactly which information it is allowed to see, and so the
per-target leakage filter is applied in one place.
"""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402

# Covariates appended to every feature set.
#
# Two tiers, because they answer different questions:
#
#   DEPLOYABLE  age + sex only.  These are the covariates a screening tool
#               actually has at the point of use.  Any feature set whose name
#               ends in `__agesex` uses this list -- that is the headline
#               configuration.
#   CLINIC      adds BMI, which is derived from self-reported height and weight
#               on the confounders form (13% missing) and so is a clinic
#               variable rather than a deployment one.
#
# Everything outside audio + age + sex (questionnaires, medical history) lives
# in its own feature block, never silently mixed into an "acoustic" model.
COVARIATES_DEPLOYABLE = ["age", "sex_male"]
COVARIATES = ["age", "sex_male", "bmi"]
AGESEX_SUFFIX = "__agesex"

# Which on-disk column prefixes make up each named feature set.
FEATURE_SETS = {
    # baselines
    "demographics_only": [],
    "survey_only": ["q_"],
    # static acoustic
    "static_avg": ["avg_"],
    "static_coretask": ["t_"],
    "static_avg_task": ["avg_", "t_"],
    "static_engineered": ["avg_", "sdt_", "eng_"],
    "static_full": ["avg_", "sdt_", "t_", "eng_"],
    # dynamic acoustic
    "dynamic_avg": ["davg_"],
    "dynamic_full": ["davg_", "dsdt_", "dt_", "deng_"],
    # age/sex interactions and age-adjusted residuals
    "interactions_only": ["ix_"],
    # combined
    "acoustic_full": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_", "dt_", "deng_"],
    "acoustic_plus_interactions": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_",
                                   "dt_", "deng_", "ix_"],
    "acoustic_plus_survey": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_", "dt_", "deng_", "q_"],
    "everything": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_", "dt_", "deng_",
                   "q_", "cf_"],
    "everything_plus_interactions": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_",
                                     "dt_", "deng_", "q_", "cf_", "ix_"],
}

# One feature set per elicitation task, static + dynamic features from that
# task alone.  Comparing these answers a protocol-design question the combined
# models cannot: if a clinic could record only one task, which one carries the
# signal for this disease?
#
# Restricted to the tasks that carry BOTH a static and a dynamic block --
# `loudness`, `breathing` and `story_recall` have no dynamic per-task features,
# so including them would compare 131 features against 632 and read as a task
# difference when it is really a feature-count difference.
from build_dynamic_features import DYN_CORE_TASKS  # noqa: E402

_BOTH_BLOCKS = [t for t in C.CORE_TASKS if t in DYN_CORE_TASKS]
for _task in _BOTH_BLOCKS:
    FEATURE_SETS[f"task_{_task}"] = [f"t_{_task}_", f"dt_{_task}_"]
SINGLE_TASK_SETS = [f"task_{t}" for t in _BOTH_BLOCKS]

COHORTS = {
    # every participant with usable audio -- the "n_any" sample
    "all": lambda co: co["n_recordings"] > 0,
    # only participants whose clinical picture is a single disease category
    # (or none at all) -- the "n_single_category" sample
    "single_category": lambda co: (co["n_recordings"] > 0) & (co["n_categories"] <= 1),
    # the cleanest possible contrast: cases against screened controls
    "vs_control": None,   # handled specially below
}


@lru_cache(maxsize=1)
def load_blocks() -> pd.DataFrame:
    """All feature blocks joined on participant_id.

    Feature columns are held as float32.  With ~6900 features and a dozen
    parallel workers the sweep is memory-bound, not CPU-bound, and float64
    buys nothing here -- the inputs are float32 on disk to begin with.
    """
    cohort = pd.read_parquet(C.DATA / "cohort.parquet")
    frames = [cohort]
    for name in ["static_participant", "dynamic_participant",
                 "survey_participant", "confounder_participant",
                 "interaction_participant"]:
        p = C.DATA / f"{name}.parquet"
        if p.exists():
            d = pd.read_parquet(p).reindex(cohort.index)
            num = d.select_dtypes("number").columns
            d[num] = d[num].astype(np.float32)
            frames.append(d)
        else:
            print(f"  [warn] {name}.parquet missing -- feature sets using it will be empty")
    out = pd.concat(frames, axis=1)
    return out.loc[:, ~out.columns.duplicated()]


def resolve(feature_set: str) -> tuple[str, list[str]]:
    """Split a feature-set name into its base name and covariate list."""
    if feature_set.endswith(AGESEX_SUFFIX):
        return feature_set[: -len(AGESEX_SUFFIX)], COVARIATES_DEPLOYABLE
    return feature_set, COVARIATES


def feature_columns(df: pd.DataFrame, feature_set: str, target: str,
                    include_quality: bool = False) -> list[str]:
    feature_set, covariates = resolve(feature_set)
    prefixes = FEATURE_SETS[feature_set]
    cols = [c for c in df.columns if any(c.startswith(p) for p in prefixes)]

    # Per-target leakage filter: self-reported history and treatment columns
    # that restate the diagnosis are removed for that target only.
    pats = C.TARGET_LEAK_PATTERNS.get(target, [])
    if pats:
        cols = [c for c in cols if not any(p in c.lower() for p in pats)]

    if include_quality:
        cols += [c for c in df.columns if c.startswith("qc_")]

    cols += [c for c in covariates if c in df.columns]
    # Never let another target, a rare-diagnosis flag, or a cohort-structure
    # column into X.
    banned = set(C.TARGETS) | set(C.CATEGORY_TARGETS) | {
        "is_control", "any_disease", "n_categories", "n_diagnoses", "single_category",
        "has_voice", "has_neuro", "has_respiratory", "has_mood_psych",
        "adhd_partA_hits", "adhd_total_score", "adhd_inattention_score",
        "adhd_hyperactivity_score", "ptsd_total_score",
    }
    banned |= {f"rare_{r}" for r in C.RARE_DIAGNOSES}
    cols = [c for c in dict.fromkeys(cols) if c not in banned]
    return cols


def build(target: str, cohort_name: str, feature_set: str,
          min_notna_frac: float = 0.5, include_quality: bool = False):
    """Return (X, y, meta).  X is a DataFrame indexed by participant_id."""
    df = load_blocks()
    y_all = df[target]

    if cohort_name == "vs_control":
        # 15 participants appear in control.tsv *and* carry a diagnosis (11 of
        # them psychiatric_history, which is one of the modules administered to
        # controls).  Requiring `any_disease == 0` as well keeps the control arm
        # genuinely disease-free instead of 10% contaminated.
        clean_control = (df["is_control"] == 1) & (df["any_disease"] == 0)
        mask = (df["n_recordings"] > 0) & ((y_all == 1) | clean_control)
        mask &= y_all.notna()
    else:
        mask = COHORTS[cohort_name](df) & y_all.notna()

    sub = df.loc[mask]
    y = sub[target].astype(int)

    cols = feature_columns(df, feature_set, target, include_quality)
    X = sub[cols].astype(np.float32)

    # Drop features that are unusable in *this* cohort.
    notna = X.notna().mean()
    X = X.loc[:, notna >= min_notna_frac]
    nun = X.nunique(dropna=True)
    X = X.loc[:, nun[X.columns] > 1]
    X = X.replace([np.inf, -np.inf], np.nan)

    meta = {
        "target": target, "cohort": cohort_name, "feature_set": feature_set,
        "n": int(len(y)), "n_pos": int(y.sum()), "n_neg": int((y == 0).sum()),
        "prevalence": float(y.mean()), "n_features": int(X.shape[1]),
        "n_features_before_filter": len(cols),
    }
    return X, y, meta


def all_targets() -> list[str]:
    return list(C.TARGETS) + list(C.CATEGORY_TARGETS)


if __name__ == "__main__":
    df = load_blocks()
    print(f"joined blocks: {df.shape[0]} participants x {df.shape[1]} columns")
    pref = {}
    for c in df.columns:
        k = c.split("_")[0] + "_"
        pref[k] = pref.get(k, 0) + 1
    print("  column prefixes:", dict(sorted(pref.items(), key=lambda x: -x[1])[:14]))
    print()
    for t in all_targets():
        for ch in ["all", "single_category", "vs_control"]:
            X, y, m = build(t, ch, "static_full")
            print(f"{t:<32s} {ch:<16s} n={m['n']:4d} pos={m['n_pos']:4d} "
                  f"({m['prevalence']:.3f})  p={m['n_features']:5d}")
        print()
