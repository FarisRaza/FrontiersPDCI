"""Resumable staged nested-CV search for neurological impairment, PD and CI.

The unit selected inside each outer training fold is the entire specification:
feature representation, selector, dimensionality/feature count, classifier and
regularisation.  Consequently the held-out predictions remain honest even
though the search is broad.  A fast two-family representation screen retains
the best few spaces *within that fold* before the larger architecture sweep.

Primary objectives:
  neuro vs non-neuro; PD vs everyone else; CI vs everyone else; PD vs CI; and
  other vs PD vs CI (selected with a balanced screen/differential composite).

Usage (all commands are resumable)::

  analysis/.venv/Scripts/python.exe analysis/src/pdci_exhaustive.py cache
  analysis/.venv/Scripts/python.exe analysis/src/pdci_exhaustive.py nested --jobs 8
  analysis/.venv/Scripts/python.exe analysis/src/pdci_exhaustive.py report
"""
from __future__ import annotations

import argparse
import gc
import json
import math
import sys
import time
import traceback
import warnings
from functools import partial
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
import scipy.special as scipy_special
from sklearn.base import clone
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel, SelectKBest, f_classif, mutual_info_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score,
                             balanced_accuracy_score, confusion_matrix,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC, SVC

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import modeling  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import pdci_exhaustive_features as F  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")

OUT = F.OUT
PRED = OUT / "nested_predictions"
TRACE = OUT / "search_traces"
PRED.mkdir(parents=True, exist_ok=True)
TRACE.mkdir(parents=True, exist_ok=True)
NESTED = OUT / "nested.jsonl"
SEED = C.RANDOM_STATE
TARGETS = ["multiclass", "neuro_binary", "pd_binary", "ci_binary", "pd_vs_ci"]


# ---------------------------------------------------------------- model specs
def spec(name: str, selector: str, clf: str, k=0, c=1.0, **kw) -> dict:
    return dict(name=name, selector=selector, clf=clf, k=int(k), c=float(c), **kw)


def sentinel_specs() -> list[dict]:
    return [
        spec("screen_k60_ridgeC0.1", "kbest_f", "ridge", 60, 0.1,
             complexity=1),
        spec("screen_pca30_lda", "pca", "lda", 30, 1.0,
             shrinkage="auto", complexity=1),
    ]


def expanded_specs() -> list[dict]:
    out = []
    for k in [10, 30, 60, 120, 250]:
        for c in [0.01, 0.1, 1.0, 10.0]:
            out.append(spec(f"kf{k}_ridgeC{c:g}", "kbest_f", "ridge", k, c,
                            complexity=1))
    for k in [20, 60, 150]:
        out.append(spec(f"mi{k}_ridgeC0.3", "kbest_mi", "ridge", k, 0.3,
                        complexity=2))
    # Retain the exact k=50 PCA setting used by the strongest earlier PD/CI
    # recipes; adjacent 40/75 components are not a true matched comparison.
    for k in [5, 10, 20, 40, 50, 75]:
        for c in [0.01, 0.1, 1.0]:
            out.append(spec(f"pca{k}_ridgeC{c:g}", "pca", "ridge", k, c,
                            complexity=1))
        for shrink in ["auto", 0.2, 0.7]:
            out.append(spec(f"pca{k}_ldaS{shrink}", "pca", "lda", k, 1.0,
                            shrinkage=shrink, complexity=1))
    # k=150 is the exact earlier screen configuration; keep 160 as the broader
    # logarithmic-grid candidate.
    for k in [30, 80, 150, 160]:
        for sel_c in [0.01, 0.05]:
            for c in [0.1, 1.0]:
                out.append(spec(f"l1s{sel_c:g}k{k}_ridgeC{c:g}", "l1", "ridge",
                                k, c, selector_c=sel_c, complexity=2))
    for c in [0.003, 0.03, 0.3, 3.0]:
        out.append(spec(f"direct_ridgeC{c:g}", "none", "ridge", 0, c,
                        complexity=2))
    for k in [30, 80]:
        for c in [0.3, 3.0]:
            out.append(spec(f"kf{k}_rbfC{c:g}", "kbest_f", "rbf", k, c,
                            complexity=4))
        for depth in [4, 8]:
            out.append(spec(f"kf{k}_extraD{depth}", "kbest_f", "extra", k, 1.0,
                            depth=depth, complexity=4))
        for leaves in [7, 15]:
            out.append(spec(f"kf{k}_lgbmL{leaves}", "kbest_f", "lgbm", k, 1.0,
                            leaves=leaves, complexity=4))
    return out


def _cap_k(k: int, n_features: int, n_train: int) -> int:
    return max(1, min(int(k), int(n_features), max(1, int(n_train) - 2)))


def make_estimator(s: dict, n_features: int, n_train: int, n_classes: int,
                   seed: int) -> Pipeline:
    steps = []
    kind = s["selector"]
    k = _cap_k(s.get("k", 0), n_features, n_train)
    if kind == "kbest_f":
        steps.append(("select", SelectKBest(f_classif, k=k)))
    elif kind == "kbest_mi":
        score_func = partial(mutual_info_classif, random_state=seed, n_neighbors=3)
        steps.append(("select", SelectKBest(score_func, k=k)))
    elif kind == "pca":
        steps.append(("select", PCA(n_components=k, svd_solver="randomized",
                                    iterated_power=3, random_state=seed)))
    elif kind == "l1":
        base = LinearSVC(C=float(s.get("selector_c", 0.05)), penalty="l1",
                         dual=False, class_weight="balanced", max_iter=5000,
                         random_state=seed)
        steps.append(("select", SelectFromModel(base, threshold=-np.inf,
                                                max_features=k)))
    elif kind != "none":
        raise ValueError(kind)

    clf = s["clf"]
    if clf == "ridge":
        model = LogisticRegression(C=float(s["c"]), penalty="l2", solver="lbfgs",
                                   class_weight="balanced", max_iter=3000,
                                   random_state=seed)
    elif clf == "lda":
        model = LinearDiscriminantAnalysis(solver="lsqr",
                                           shrinkage=s.get("shrinkage", "auto"))
    elif clf == "rbf":
        # Thresholds are fitted on inner decision scores, so Platt scaling is
        # unnecessary and would add another hidden five-fold loop.
        model = SVC(C=float(s["c"]), kernel="rbf", gamma="scale",
                    probability=False, class_weight="balanced", random_state=seed)
    elif clf == "extra":
        model = ExtraTreesClassifier(n_estimators=350, max_depth=int(s["depth"]),
                                     min_samples_leaf=3, max_features="sqrt",
                                     class_weight="balanced", n_jobs=1,
                                     random_state=seed)
    elif clf == "lgbm":
        from lightgbm import LGBMClassifier
        model = LGBMClassifier(n_estimators=300, learning_rate=0.04,
                               num_leaves=int(s["leaves"]), min_child_samples=12,
                               subsample=0.8, colsample_bytree=0.8,
                               reg_lambda=1.0, class_weight="balanced", n_jobs=1,
                               verbosity=-1, random_state=seed)
    else:
        raise ValueError(clf)
    steps.append(("clf", model))
    return Pipeline(steps)


def predict_aligned(est, x: np.ndarray, n_classes: int) -> np.ndarray:
    classes = np.asarray(est.classes_, dtype=int)
    if hasattr(est, "predict_proba"):
        raw = np.asarray(est.predict_proba(x), dtype=float)
    else:
        d = np.asarray(est.decision_function(x), dtype=float)
        if d.ndim == 1:
            q = scipy_special.expit(d)
            raw = np.column_stack([1 - q, q])
        else:
            raw = scipy_special.softmax(d, axis=1)
    out = np.zeros((len(x), n_classes), dtype=float)
    for j, cls in enumerate(classes):
        out[:, cls] = raw[:, j]
    out /= np.maximum(out.sum(axis=1, keepdims=True), 1e-12)
    return out


# ------------------------------------------------------------------- targets
def target_data(design: str, target: str) -> tuple[pd.Index, np.ndarray, np.ndarray]:
    ids = PT.ids_for_design(design)
    y3 = PT.labels(ids, "multiclass").to_numpy(dtype=int)
    pos = np.arange(len(ids))
    if target == "multiclass":
        return ids, y3, pos
    if target == "neuro_binary":
        return ids, (y3 > 0).astype(int), pos
    if target == "pd_binary":
        return ids, (y3 == 1).astype(int), pos
    if target == "ci_binary":
        return ids, (y3 == 2).astype(int), pos
    if target == "pd_vs_ci":
        keep = y3 > 0
        return ids[keep], (y3[keep] == 1).astype(int), pos[keep]
    raise ValueError(target)


def score_prob(y: np.ndarray, p: np.ndarray, target: str) -> dict[str, float]:
    if target != "multiclass":
        q = p[:, 1]
        return {
            "score": float(roc_auc_score(y, q)),
            "roc_auc": float(roc_auc_score(y, q)),
            "pr_auc": float(average_precision_score(y, q)),
        }
    macro = float(roc_auc_score(y, p, multi_class="ovr", average="macro"))
    neuro = float(roc_auc_score((y > 0).astype(int), p[:, 1] + p[:, 2]))
    case = y > 0
    rel = p[case, 1] / np.maximum(1e-12, p[case, 1] + p[case, 2])
    pdci = float(roc_auc_score((y[case] == 1).astype(int), rel))
    vals = np.array([macro, neuro, pdci])
    # Differential performance has the largest weight; the dispersion penalty
    # prevents an easy neuro screen from hiding a failed PD/CI discriminator.
    composite = float(0.30 * macro + 0.30 * neuro + 0.40 * pdci
                      - 0.10 * vals.std())
    return {"score": composite, "macro_ovr_auc": macro,
            "neuro_auc": neuro, "pd_vs_ci_auc": pdci}


def inner_evaluate(a: np.ndarray, y: np.ndarray, s: dict, target: str,
                   splits: list[tuple[np.ndarray, np.ndarray]], seed: int) -> dict:
    n_classes = len(np.unique(y))
    oof = np.zeros((len(y), n_classes), dtype=float)
    fold_scores = []
    for i, (tr, va) in enumerate(splits):
        est = make_estimator(s, a.shape[1], len(tr), n_classes, seed + i)
        est.fit(a[tr], y[tr])
        pp = predict_aligned(est, a[va], n_classes)
        oof[va] = pp
        fold_scores.append(score_prob(y[va], pp, target)["score"])
    m = score_prob(y, oof, target)
    m["fold_mean"] = float(np.mean(fold_scores))
    m["fold_sd"] = float(np.std(fold_scores, ddof=1)) if len(fold_scores) > 1 else 0.0
    m["fold_se"] = m["fold_sd"] / math.sqrt(max(1, len(fold_scores)))
    return m


def _one_se(rows: list[dict]) -> dict:
    ok = [r for r in rows if np.isfinite(r.get("fold_mean", np.nan))]
    if not ok:
        raise RuntimeError("all inner candidates failed")
    best = max(ok, key=lambda r: r["fold_mean"])
    floor = best["fold_mean"] - best.get("fold_se", 0.0)
    eligible = [r for r in ok if r["fold_mean"] >= floor]
    return min(eligible, key=lambda r: (r.get("complexity", 99), r.get("k", 10**9),
                                        -r.get("fold_mean", -np.inf)))


def _threshold_constraint(y: np.ndarray, p: np.ndarray, kind: str,
                          level: float) -> float:
    grid = np.unique(np.r_[0.0, p, 1.0])
    rows = []
    for t in grid:
        h = p >= t
        tn, fp, fn, tp = confusion_matrix(y, h, labels=[0, 1]).ravel()
        sens = tp / max(1, tp + fn)
        specv = tn / max(1, tn + fp)
        prec = tp / max(1, tp + fp)
        rows.append((float(t), sens, specv, prec))
    d = pd.DataFrame(rows, columns=["t", "sens", "spec", "prec"])
    if kind == "sens":
        q = d[d.sens >= level]
        if q.empty:
            q = d.nlargest(1, "sens")
        return float(q.sort_values(["spec", "t"], ascending=False).iloc[0].t)
    q = d[d.spec >= level]
    if q.empty:
        q = d.nlargest(1, "spec")
    return float(q.sort_values(["sens", "prec", "t"], ascending=False).iloc[0].t)


def _thresholds(y: np.ndarray, p: np.ndarray, target: str) -> dict[str, float]:
    if target == "multiclass":
        yy = (y > 0).astype(int)
        q = p[:, 1] + p[:, 2]
    else:
        yy, q = y, p[:, 1]
    out = {}
    for level in [0.80, 0.90, 0.95]:
        tag = int(level * 100)
        out[f"thr_sens{tag}"] = _threshold_constraint(yy, q, "sens", level)
        out[f"thr_spec{tag}"] = _threshold_constraint(yy, q, "spec", level)
    if target == "multiclass":
        case = y > 0
        rel = p[case, 1] / np.maximum(1e-12, p[case, 1] + p[case, 2])
        yy = (y[case] == 1).astype(int)
        for level in [0.80, 0.90, 0.95]:
            tag = int(level * 100)
            out[f"diff_thr_sens{tag}"] = _threshold_constraint(yy, rel, "sens", level)
            out[f"diff_thr_spec{tag}"] = _threshold_constraint(yy, rel, "spec", level)
    return out


def _selected_names(prep, est, columns: list[str]) -> list[str]:
    names = np.asarray(columns, dtype=object)
    try:
        names = names[prep.named_steps["var"].get_support()]
    except Exception:
        return []
    sel = est.named_steps.get("select")
    if sel is None or isinstance(sel, PCA):
        return []
    try:
        return [str(x) for x in names[sel.get_support()][:500]]
    except Exception:
        return []


def _fit_baseline(design: str, target: str, positions: np.ndarray,
                  tr: np.ndarray, te: np.ndarray, y: np.ndarray,
                  inner: list[tuple[np.ndarray, np.ndarray]], kind: str,
                  seed: int) -> tuple[np.ndarray, dict]:
    ids_all = PT.ids_for_design(design)
    cov = PT.covariates(ids_all, design).to_numpy(dtype=np.float32)[positions]
    if kind == "agesex":
        cov = cov[:, :2]
    prep = modeling.make_prep()
    a = prep.fit_transform(cov[tr])
    b = prep.transform(cov[te])
    cand = []
    for c in [0.003, 0.03, 0.3, 3.0, 30.0]:
        s = spec(f"baseline_ridgeC{c:g}", "none", "ridge", 0, c, complexity=1)
        try:
            m = inner_evaluate(a, y[tr], s, target, inner, seed)
            cand.append({**s, **m})
        except Exception:
            continue
    win = _one_se(cand)
    est = make_estimator(win, a.shape[1], len(tr), len(np.unique(y)), seed)
    est.fit(a, y[tr])
    return predict_aligned(est, b, len(np.unique(y))), win


# --------------------------------------------------------------- nested outer
def run_outer(design: str, target: str, outer_index: int, outer_splits: int,
              outer_repeats: int, inner_splits: int, top_recipes: int,
              recipe_names: list[str] | None = None) -> tuple[dict, pd.DataFrame | None]:
    jid = (f"{design}|{target}|s{outer_splits}|"
           f"r{outer_index // outer_splits}|f{outer_index % outer_splits}")
    t0 = time.time()
    try:
        ids, y, positions = target_data(design, target)
        outer = list(RepeatedStratifiedKFold(
            n_splits=outer_splits, n_repeats=outer_repeats,
            random_state=SEED).split(np.zeros(len(y)), y))
        tr, te = outer[outer_index]
        ytr = y[tr]
        ik = min(inner_splits, int(pd.Series(ytr).value_counts().min()))
        inner = list(StratifiedKFold(ik, shuffle=True,
                                    random_state=SEED + outer_index).split(
                                        np.zeros(len(ytr)), ytr))
        catalog = F.recipes(design)
        if recipe_names:
            wanted = set(recipe_names)
            catalog = [r for r in catalog if r.name in wanted]
        screen_rows = []
        sent = sentinel_specs()
        for ri, recipe in enumerate(catalog):
            x, man = F.load_matrix(design, recipe.name)
            if man["ids"] != [str(i) for i in PT.ids_for_design(design)]:
                raise AssertionError(f"cache ID mismatch: {design}/{recipe.name}")
            xx = np.asarray(x[positions])
            prep = modeling.make_prep()
            a = prep.fit_transform(xx[tr])
            for s in sent:
                try:
                    m = inner_evaluate(a, ytr, s, target, inner,
                                       SEED + outer_index * 101 + ri)
                    screen_rows.append({"recipe": recipe.name, **s, **m})
                except Exception as e:
                    screen_rows.append({"recipe": recipe.name, **s,
                                        "fold_mean": np.nan,
                                        "error": f"{type(e).__name__}: {e}"})
            del x, xx, a, prep
            gc.collect()

        sd = pd.DataFrame(screen_rows)
        best_rep = sd.sort_values("fold_mean", ascending=False).drop_duplicates("recipe")
        shortlisted = best_rep.head(top_recipes).recipe.tolist()
        if not shortlisted:
            raise RuntimeError("representation screen produced no valid candidate")

        detailed = []
        for ri, recipe_name in enumerate(shortlisted):
            x, man = F.load_matrix(design, recipe_name)
            xx = np.asarray(x[positions])
            prep = modeling.make_prep()
            a = prep.fit_transform(xx[tr])
            for s in expanded_specs():
                # Unselected direct regression on enormous per-task matrices is
                # computationally wasteful and statistically implausible.
                if s["selector"] == "none" and a.shape[1] > 8000:
                    continue
                if s["selector"] == "kbest_mi" and a.shape[1] > 8000:
                    continue
                try:
                    m = inner_evaluate(a, ytr, s, target, inner,
                                       SEED + outer_index * 1009 + ri)
                    detailed.append({"recipe": recipe_name, **s, **m})
                except Exception as e:
                    detailed.append({"recipe": recipe_name, **s,
                                     "fold_mean": np.nan,
                                     "error": f"{type(e).__name__}: {e}"})
            # Do not retain all shortlisted matrices simultaneously.  The
            # winner is rebuilt once below; this keeps eight Windows workers
            # within the 16-GB host's memory budget even when a representation
            # has >40,000 columns.
            del x, xx, a, prep, man
            gc.collect()

        win = _one_se(detailed)
        x, man = F.load_matrix(design, win["recipe"])
        xx = np.asarray(x[positions])
        prep = modeling.make_prep()
        a = prep.fit_transform(xx[tr])
        b = prep.transform(xx[te])
        del x, xx
        gc.collect()
        est = make_estimator(win, a.shape[1], len(tr), len(np.unique(y)),
                             SEED + outer_index)
        est.fit(a, ytr)
        acoustic = predict_aligned(est, b, len(np.unique(y)))

        # Training-only OOF scores provide all operating thresholds.
        train_p = np.zeros((len(tr), len(np.unique(y))), dtype=float)
        for ii, (itr, iva) in enumerate(inner):
            q = make_estimator(win, a.shape[1], len(itr), len(np.unique(y)),
                               SEED + outer_index + ii + 77)
            q.fit(a[itr], ytr[itr])
            train_p[iva] = predict_aligned(q, a[iva], len(np.unique(y)))
        thresholds = _thresholds(ytr, train_p, target)

        agesex, agewin = _fit_baseline(design, target, positions, tr, te, y,
                                       inner, "agesex", SEED + outer_index)
        duration, durwin = _fit_baseline(design, target, positions, tr, te, y,
                                         inner, "duration", SEED + outer_index)

        row = pd.DataFrame({
            "participant_id": ids[te].astype(str), "y_true": y[te],
            "outer_repeat": outer_index // outer_splits,
            "outer_fold": outer_index % outer_splits,
        })
        for j in range(acoustic.shape[1]):
            row[f"acoustic_p{j}"] = acoustic[:, j]
            row[f"agesex_p{j}"] = agesex[:, j]
            row[f"duration_p{j}"] = duration[:, j]
        for k, v in thresholds.items():
            row[k] = v
        path = PRED / f"{F._safe(jid)}.parquet"
        row.to_parquet(path, index=False)
        trace = pd.concat([
            pd.DataFrame(screen_rows).assign(stage="representation_screen"),
            pd.DataFrame(detailed).assign(stage="architecture_sweep"),
        ], ignore_index=True)
        if "shrinkage" in trace:
            trace["shrinkage"] = trace["shrinkage"].map(
                lambda v: "" if pd.isna(v) else str(v))
        trace.insert(0, "job_id", jid)
        trace.insert(1, "design", design)
        trace.insert(2, "target", target)
        trace_path = TRACE / f"{F._safe(jid)}.parquet"
        trace.to_parquet(trace_path, index=False)
        selected = _selected_names(prep, est, man["columns"])
        rec = {
            "job_id": jid, "status": "ok", "design": design, "target": target,
            "outer_index": outer_index, "outer_splits": outer_splits,
            "outer_repeat": outer_index // outer_splits,
            "outer_fold": outer_index % outer_splits, "n": len(y),
            "n_train": len(tr), "n_test": len(te), "n_classes": len(np.unique(y)),
            "selected_recipe": win["recipe"], "selected_spec": win["name"],
            "selected_selector": win["selector"], "selected_clf": win["clf"],
            "selected_k": win.get("k"), "selected_c": win.get("c"),
            "inner_score": win["fold_mean"], "inner_score_se": win["fold_se"],
            "shortlisted_recipes": shortlisted,
            "screen_top": best_rep.head(10)[["recipe", "name", "fold_mean"]]
                .to_dict("records"),
            "selected_features": selected,
            "n_selected_named": len(selected),
            "agesex_spec": agewin["name"], "duration_spec": durwin["name"],
            "prediction_file": str(path), "search_trace_file": str(trace_path),
            "seconds": round(time.time() - t0, 2),
        }
        return rec, row
    except Exception as e:
        return ({"job_id": jid, "status": "error", "design": design,
                 "target": target, "outer_index": outer_index,
                 "error": f"{type(e).__name__}: {e}",
                 "traceback": traceback.format_exc()[-3000:],
                 "seconds": round(time.time() - t0, 2)}, None)


def read_done() -> set[str]:
    if not NESTED.exists():
        return set()
    done = set()
    for line in NESTED.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(line)
            if r.get("status") == "ok" and Path(r.get("prediction_file", "")).exists():
                done.add(r["job_id"])
        except Exception:
            pass
    return done


def cmd_audit(a) -> None:
    designs = [x.strip() for x in a.designs.split(",") if x.strip()]
    rows = []
    banned_patterns = ["parkinson", "cognitive_impair", "diagnosis", "confound",
                       "task_present", "task_complete", "completion", "n_recordings"]
    for design in designs:
        ids = PT.ids_for_design(design)
        present = PT.task_presence().loc[ids, PT.DESIGN_TASKS[design]]
        if not present.all().all():
            raise AssertionError(f"nonconstant task presence in {design}")
        y = PT.labels(ids, "multiclass")
        for recipe in F.recipes(design):
            m = F.load_manifest(design, recipe.name)
            if m["ids"] != [str(i) for i in ids]:
                raise AssertionError(f"ID/order mismatch {design}/{recipe.name}")
            bad = [c for c in m["columns"]
                   if any(p in c.lower() for p in banned_patterns)]
            if bad:
                raise AssertionError(f"leaking columns {design}/{recipe.name}: {bad[:5]}")
            raw_length = [c for c in m["columns"]
                          if ("n_frames" in c or c.endswith("_dur_s"))]
            if raw_length:
                raise AssertionError(f"raw length proxies {design}/{recipe.name}: {raw_length[:5]}")
            rows.append({"design": design, "recipe": recipe.name, "n": len(ids),
                         "other": int((y == 0).sum()), "pd": int((y == 1).sum()),
                         "ci": int((y == 2).sum()), "tasks": len(PT.DESIGN_TASKS[design]),
                         "task_presence_constant": True, "n_features": m["n_features"],
                         "n_audio": m["n_audio"], "missing_fraction": m["missing_fraction"]})
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "leakage_audit.csv", index=False)
    print(d.groupby("design").agg(n=("n", "first"), other=("other", "first"),
                                  pd=("pd", "first"), ci=("ci", "first"),
                                  tasks=("tasks", "first"), recipes=("recipe", "size"),
                                  min_features=("n_features", "min"),
                                  max_features=("n_features", "max")).to_string())
    print("task presence constant; no target/confounder/completion/raw-length columns found")


def cmd_nested(a) -> None:
    designs = [x.strip() for x in a.designs.split(",") if x.strip()]
    targets = [x.strip() for x in a.targets.split(",") if x.strip()]
    done = read_done()
    jobs = []
    for design in designs:
        for target in targets:
            for oi in range(a.outer_splits * a.outer_repeats):
                jid = (f"{design}|{target}|s{a.outer_splits}|"
                       f"r{oi // a.outer_splits}|f{oi % a.outer_splits}")
                if jid not in done:
                    jobs.append((design, target, oi))
    print(f"nested outer jobs: {len(jobs)} pending, {len(done)} already complete", flush=True)
    if not jobs:
        return
    NESTED.parent.mkdir(parents=True, exist_ok=True)
    # A small batch makes progress durable; each job already parallelises a
    # large matrix search internally through optimized BLAS.
    with NESTED.open("a", encoding="utf-8") as fh:
        batch = max(1, a.jobs)
        for start in range(0, len(jobs), batch):
            todo = jobs[start:start + batch]
            ans = Parallel(n_jobs=a.jobs, backend="loky", verbose=10)(
                delayed(run_outer)(d, t, oi, a.outer_splits, a.outer_repeats,
                                   a.inner_splits, a.top_recipes, None)
                for d, t, oi in todo)
            for rec, _ in ans:
                fh.write(json.dumps(rec, default=float) + "\n")
                print(f"{rec['job_id']}: {rec['status']} "
                      f"{rec.get('selected_recipe', rec.get('error', ''))} "
                      f"{rec.get('seconds', 0):.0f}s", flush=True)
            fh.flush()


# -------------------------------------------------------------------- report
def _aggregate(design: str, target: str) -> pd.DataFrame:
    if not NESTED.exists():
        raise FileNotFoundError(NESTED)
    rows = [json.loads(x) for x in NESTED.read_text(encoding="utf-8").splitlines()
            if x.strip()]
    rows = [r for r in rows if r.get("status") == "ok"
            and r.get("design") == design and r.get("target") == target]
    frames = [pd.read_parquet(r["prediction_file"]) for r in rows]
    if not frames:
        raise RuntimeError(f"no predictions for {design}/{target}")
    raw = pd.concat(frames, ignore_index=True)
    pcols = [c for c in raw if re_match_prob(c)]
    tcols = [c for c in raw if c.startswith(("thr_", "diff_thr_"))]
    agg = {"y_true": "first", **{c: "mean" for c in pcols + tcols}}
    return raw.groupby("participant_id").agg(agg)


def re_match_prob(c: str) -> bool:
    return any(c.startswith(f"{m}_p") for m in ("acoustic", "agesex", "duration"))


def full_metrics(y: np.ndarray, p: np.ndarray, target: str) -> dict:
    m = score_prob(y, p, target)
    pred = p.argmax(axis=1)
    m["accuracy"] = float(accuracy_score(y, pred))
    m["balanced_accuracy"] = float(balanced_accuracy_score(y, pred))
    m["confusion"] = json.dumps(confusion_matrix(y, pred,
                                                  labels=list(range(p.shape[1]))).tolist())
    if target != "multiclass":
        m["sensitivity_at50"] = float(recall_score(y, pred, zero_division=0))
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
        m["specificity_at50"] = float(tn / max(1, tn + fp))
        m["precision_at50"] = float(precision_score(y, pred, zero_division=0))
    return m


def metric_value(y: np.ndarray, p: np.ndarray, target: str, metric: str) -> float:
    # Bootstrap reporting calls this tens of thousands of times.  Compute only
    # the requested statistic instead of rebuilding the complete metric bundle
    # (which previously repeated the same ROC-AUC two or three times).
    if target != "multiclass":
        if metric in {"score", "roc_auc"}:
            return float(roc_auc_score(y, p[:, 1]))
        if metric == "pr_auc":
            return float(average_precision_score(y, p[:, 1]))
        raise KeyError(metric)

    if metric == "macro_ovr_auc":
        return float(roc_auc_score(y, p, multi_class="ovr", average="macro"))
    if metric == "neuro_auc":
        return float(roc_auc_score((y > 0).astype(int), p[:, 1] + p[:, 2]))
    if metric == "pd_vs_ci_auc":
        case = y > 0
        rel = p[case, 1] / np.maximum(1e-12, p[case, 1] + p[case, 2])
        return float(roc_auc_score((y[case] == 1).astype(int), rel))
    if metric == "score":
        return float(score_prob(y, p, target)["score"])
    raise KeyError(metric)


def paired_bootstrap(y: np.ndarray, pa: np.ndarray, pb: np.ndarray, target: str,
                     metric: str = "score", n_boot=3000, seed=SEED) -> dict:
    rng = np.random.default_rng(seed)
    obs = metric_value(y, pa, target, metric) - metric_value(y, pb, target, metric)
    vals = []
    n = len(y)
    for _ in range(n_boot):
        ix = rng.integers(0, n, n)
        try:
            vals.append(metric_value(y[ix], pa[ix], target, metric)
                        - metric_value(y[ix], pb[ix], target, metric))
        except Exception:
            pass
    v = np.asarray(vals)
    lo, hi = np.percentile(v, [2.5, 97.5]) if len(v) else (np.nan, np.nan)
    p = 2 * min((np.sum(v <= 0) + 1) / (len(v) + 1),
                (np.sum(v >= 0) + 1) / (len(v) + 1)) if len(v) else np.nan
    return {"lift_metric": metric, "lift": float(obs),
            "lift_ci_low": float(lo), "lift_ci_high": float(hi),
            "lift_p": float(min(1.0, p))}


def _operating(y: np.ndarray, p: np.ndarray, threshold: np.ndarray) -> dict:
    h = p >= threshold
    tn, fp, fn, tp = confusion_matrix(y, h, labels=[0, 1]).ravel()
    return {"threshold_mean": float(np.mean(threshold)), "tn": int(tn), "fp": int(fp),
            "fn": int(fn), "tp": int(tp), "sensitivity": float(tp / max(1, tp + fn)),
            "specificity": float(tn / max(1, tn + fp)),
            "precision": float(tp / max(1, tp + fp)),
            "npv": float(tn / max(1, tn + fn))}


def _bh(p: pd.Series) -> np.ndarray:
    p = p.to_numpy(float)
    order = np.argsort(p)
    q = np.empty(len(p), float)
    vals = p[order] * len(p) / np.arange(1, len(p) + 1)
    vals = np.minimum.accumulate(vals[::-1])[::-1]
    q[order] = np.clip(vals, 0, 1)
    return q


def _cascade_metrics(y: np.ndarray, pred: np.ndarray, neuro_score: np.ndarray,
                     neuro_thr: np.ndarray) -> dict:
    cm = confusion_matrix(y, pred, labels=[0, 1, 2])
    neuro_y = y > 0
    neuro_h = neuro_score >= neuro_thr
    tn, fp, fn, tp = confusion_matrix(neuro_y, neuro_h, labels=[0, 1]).ravel()
    return {
        "confusion": json.dumps(cm.tolist()),
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "recall_other": float(recall_score(y == 0, pred == 0)),
        "recall_pd": float(recall_score(y == 1, pred == 1)),
        "recall_ci": float(recall_score(y == 2, pred == 2)),
        "neuro_sensitivity": float(tp / max(1, tp + fn)),
        "neuro_specificity": float(tn / max(1, tn + fp)),
        "neuro_missed": int(fn), "neuro_false_positive": int(fp),
    }


def cascade_report(design: str) -> pd.DataFrame:
    """Honest back-to-back screen -> differential results from aligned OOF scores."""
    need = ["multiclass", "neuro_binary", "pd_binary", "ci_binary"]
    d = {t: _aggregate(design, t) for t in need}
    common = d["multiclass"].index
    for t in need[1:]:
        common = common.intersection(d[t].index)
    mc = d["multiclass"].loc[common]
    y = mc.y_true.to_numpy(int)
    neu = d["neuro_binary"].loc[common]
    neuro_score = neu.acoustic_p1.to_numpy(float)
    pdh = d["pd_binary"].loc[common].acoustic_p1.to_numpy(float)
    cih = d["ci_binary"].loc[common].acoustic_p1.to_numpy(float)
    # Independent head scores need a common scale. Odds normalization retains
    # confidence away from 0.5 and avoids forcing p_PD + p_CI to equal one.
    podds = pdh / np.maximum(1e-6, 1 - pdh)
    codds = cih / np.maximum(1e-6, 1 - cih)
    head_rel = podds / np.maximum(1e-12, podds + codds)
    direct_rel = (mc.acoustic_p1 / np.maximum(1e-12,
                  mc.acoustic_p1 + mc.acoustic_p2)).to_numpy(float)
    rows = []
    for tag in [80, 90, 95]:
        nthr = neu[f"thr_sens{tag}"].to_numpy(float)
        for method, rel in [("separate_pd_ci_heads", head_rel),
                            ("direct_multiclass_conditional", direct_rel)]:
            pred = np.zeros(len(y), dtype=int)
            passed = neuro_score >= nthr
            pred[passed] = np.where(rel[passed] >= 0.5, 1, 2)
            rows.append({"design": design, "screen_constraint": f"sens{tag}",
                         "differential": method, "n": len(y),
                         **_cascade_metrics(y, pred, neuro_score, nthr)})
    return pd.DataFrame(rows)


def cmd_report(a) -> None:
    designs = [x.strip() for x in a.designs.split(",") if x.strip()]
    targets = [x.strip() for x in a.targets.split(",") if x.strip()]
    rows, op_rows = [], []
    for design in designs:
        for target in targets:
            try:
                d = _aggregate(design, target)
            except Exception as e:
                print(f"skip {design}/{target}: {e}")
                continue
            y = d.y_true.to_numpy(int)
            ncls = 3 if target == "multiclass" else 2
            probs = {}
            for model in ["acoustic", "agesex", "duration"]:
                p = d[[f"{model}_p{i}" for i in range(ncls)]].to_numpy(float)
                probs[model] = p
                rows.append({"design": design, "target": target, "model": model,
                             "n": len(d), **full_metrics(y, p, target)})
            lift_metrics = (["score", "macro_ovr_auc", "neuro_auc", "pd_vs_ci_auc"]
                            if target == "multiclass" else ["roc_auc"])
            for base in ["agesex", "duration"]:
                for metric in lift_metrics:
                    lift = paired_bootstrap(y, probs["acoustic"], probs[base], target,
                                            metric=metric, n_boot=a.bootstraps,
                                            seed=SEED + len(rows))
                    rows.append({"design": design, "target": target,
                                 "model": f"acoustic_vs_{base}", "n": len(d), **lift})

            if target == "multiclass":
                yy = (y > 0).astype(int)
                q = probs["acoustic"][:, 1:].sum(axis=1)
            else:
                yy, q = y, probs["acoustic"][:, 1]
            for tag in [80, 90, 95]:
                for kind in ["sens", "spec"]:
                    c = f"thr_{kind}{tag}"
                    if c in d:
                        op_rows.append({"design": design, "target": target,
                                        "constraint": f"{kind}{tag}",
                                        **_operating(yy, q, d[c].to_numpy(float))})

            d.reset_index().to_parquet(OUT / f"oof_{design}_{target}.parquet", index=False)

    res = pd.DataFrame(rows)
    lifts = res.model.str.startswith("acoustic_vs_", na=False)
    if lifts.any():
        res.loc[lifts, "fdr_q"] = _bh(res.loc[lifts, "lift_p"])
    res.to_csv(OUT / "nested_metrics.csv", index=False)
    pd.DataFrame(op_rows).to_csv(OUT / "operating_points.csv", index=False)

    cascades = []
    for design in designs:
        try:
            cascades.append(cascade_report(design))
        except Exception as e:
            print(f"skip cascade {design}: {e}")
    cascade = pd.concat(cascades, ignore_index=True) if cascades else pd.DataFrame()
    cascade.to_csv(OUT / "cascade_results.csv", index=False)

    # Selection stability / modal deployment candidates.
    records = [json.loads(x) for x in NESTED.read_text(encoding="utf-8").splitlines()
               if x.strip()]
    ok = pd.DataFrame([r for r in records if r.get("status") == "ok"])
    stability = (ok.groupby(["design", "target", "selected_recipe", "selected_spec"])
                 .size().rename("outer_folds").reset_index())
    stability["selection_fraction"] = stability.outer_folds / stability.groupby(
        ["design", "target"]).outer_folds.transform("sum")
    stability.sort_values(["design", "target", "outer_folds"], ascending=[True, True, False]) \
        .to_csv(OUT / "selection_stability.csv", index=False)

    traces = []
    for r in records:
        p = Path(r.get("search_trace_file", ""))
        if r.get("status") == "ok" and p.exists():
            traces.append(pd.read_parquet(p))
    if traces:
        tr = pd.concat(traces, ignore_index=True)
        tr.to_parquet(OUT / "search_trace_all.parquet", index=False)
        rep = (tr[tr.stage == "representation_screen"]
               .groupby(["design", "target", "recipe", "name"], dropna=False)
               .agg(inner_score_mean=("fold_mean", "mean"),
                    inner_score_sd=("fold_mean", "std"), outer_folds=("job_id", "nunique"))
               .reset_index().sort_values(["design", "target", "inner_score_mean"],
                                           ascending=[True, True, False]))
        rep.to_csv(OUT / "representation_leaderboard.csv", index=False)
        arch = (tr[tr.stage == "architecture_sweep"]
                .groupby(["design", "target", "recipe", "selector", "clf", "name"],
                         dropna=False)
                .agg(inner_score_mean=("fold_mean", "mean"),
                     inner_score_sd=("fold_mean", "std"), outer_folds=("job_id", "nunique"))
                .reset_index().sort_values(["design", "target", "inner_score_mean"],
                                            ascending=[True, True, False]))
        arch.to_csv(OUT / "architecture_leaderboard.csv", index=False)

    lines = ["# Exhaustive nested PD/CI search", "",
             "All representation, feature-selection, architecture and hyperparameter choices "
             "were made inside each outer training fold. Task presence is constant within each protocol.",
             "", "## Nested performance", ""]
    show = res[~res.model.str.startswith("acoustic_vs_", na=False)].copy()
    keep = [c for c in ["design", "target", "model", "n", "score", "roc_auc",
                           "macro_ovr_auc", "neuro_auc", "pd_vs_ci_auc",
                           "balanced_accuracy"] if c in show]
    lines.append(R.markdown_table(show[keep].round(3)))
    lines += ["", "## Paired acoustic lift", ""]
    liftshow = res[lifts].copy()
    keep = ["design", "target", "model", "lift", "lift_ci_low", "lift_ci_high",
            "lift_p", "fdr_q"]
    lines.append(R.markdown_table(liftshow[keep].round(4)))
    lines += ["", "## Training-fold operating points", ""]
    op = pd.DataFrame(op_rows)
    if len(op):
        lines.append(R.markdown_table(op.round(3)))
    if len(cascade):
        lines += ["", "## Back-to-back neuro screen and differential", ""]
        cshow = cascade.drop(columns=["confusion"]).copy()
        lines.append(R.markdown_table(cshow.round(3)))
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines[:30]))
    print(f"\nwrote {OUT / 'REPORT.md'}")


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("cache")
    c.add_argument("--designs", default="general,neuro,combined")
    c.add_argument("--force", action="store_true")
    u = sub.add_parser("audit")
    u.add_argument("--designs", default="general,neuro,combined")
    n = sub.add_parser("nested")
    n.add_argument("--designs", default="general")
    n.add_argument("--targets", default=",".join(TARGETS))
    n.add_argument("--jobs", type=int, default=8)
    n.add_argument("--outer-splits", type=int, default=5)
    n.add_argument("--outer-repeats", type=int, default=2)
    n.add_argument("--inner-splits", type=int, default=3)
    n.add_argument("--top-recipes", type=int, default=4)
    r = sub.add_parser("report")
    r.add_argument("--designs", default="general,neuro,combined")
    r.add_argument("--targets", default=",".join(TARGETS))
    r.add_argument("--bootstraps", type=int, default=3000)
    a = ap.parse_args()
    if a.cmd == "cache":
        F.build_all([x.strip() for x in a.designs.split(",") if x.strip()], a.force)
    elif a.cmd == "audit":
        cmd_audit(a)
    elif a.cmd == "nested":
        cmd_nested(a)
    else:
        cmd_report(a)


if __name__ == "__main__":
    main()
