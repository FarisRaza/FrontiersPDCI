"""Per-recording summary features from the phonetic posteriorgrams (PPG).

The source file stores, for every recording, a (40, T) matrix of phoneme-class
posteriors at 100 Hz (40 classes = 39 ARPAbet phonemes + silence).  Each frame
is a probability distribution over the 40 classes.

What we are trying to measure is *articulatory precision and phonetic timing*:

* how confidently the acoustic model can commit to a phoneme identity
  (blurred / imprecise articulation -> low max-posterior, high entropy),
* the pause structure of the recording (silence runs),
* how fast phoneme identity turns over (a speaking-rate proxy),
* which broad phonetic classes carry the posterior mass, including the
  voiced:voiceless obstruent balance (devoicing is a dysarthria marker),
* the rhythm of the posteriorgram itself (2-12 Hz band power of the silence
  track and of the frame-to-frame change track).

Every feature is computed from a single recording in isolation -- nothing is
pooled across recordings, participants or tasks -- so none of this can leak
across a later cross-validation split.

Run:  python src/extract_ppg.py [--test]
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import DATA, PARQUET                     # noqa: E402
from parquet_stream import as_2d, band_power, extract  # noqa: E402

NAME = "ppg"
P_ = f"{NAME}_"
FS = 100.0            # posteriorgram frame rate, Hz
N_CLASS = 40
SIL = 39              # index of the "silence" class

PHONES = ["aa", "ae", "ah", "ao", "aw", "ay", "b", "ch", "d", "dh",
          "eh", "er", "ey", "f", "g", "hh", "ih", "iy", "jh", "k",
          "l", "m", "n", "ng", "ow", "oy", "p", "r", "s", "sh",
          "t", "th", "uh", "uw", "v", "w", "y", "z", "zh", "silence"]
IDX = {p: i for i, p in enumerate(PHONES)}

GROUPS = {
    "vowel":  ["aa", "ae", "ah", "ao", "aw", "ay", "eh", "er", "ey",
               "ih", "iy", "ow", "oy", "uh", "uw"],
    "stop":   ["b", "d", "g", "k", "p", "t"],
    "fric":   ["f", "s", "sh", "th", "v", "z", "zh", "dh", "hh"],
    "affr":   ["ch", "jh"],
    "nasal":  ["m", "n", "ng"],
    "approx": ["l", "r", "w", "y"],
}
GROUP_IX = {g: np.array([IDX[p] for p in ps]) for g, ps in GROUPS.items()}
CONS_IX = np.concatenate([GROUP_IX[g] for g in ("stop", "fric", "affr", "nasal", "approx")])
VOICED_OBS_IX = np.array([IDX[p] for p in ["b", "d", "g", "v", "z", "zh", "jh"]])
VOICELESS_OBS_IX = np.array([IDX[p] for p in ["p", "t", "k", "f", "s", "sh", "th", "ch"]])

BANDS = {"2_4": (2.0, 4.0), "4_7": (4.0, 7.0), "7_12": (7.0, 12.0)}
RATIO_CAP = 50.0      # ratios are clipped so one silent recording cannot
                      # dominate a downstream linear model
LOG40 = float(np.log(N_CLASS))
LOG39 = float(np.log(N_CLASS - 1))


# ---------------------------------------------------------------- column list
def _feature_names() -> list[str]:
    n = []
    # confidence / precision, all frames
    n += ["maxpost_mean", "maxpost_std", "maxpost_p10", "maxpost_p50", "maxpost_p90",
          "lowconf_frac05", "lowconf_frac03", "highconf_frac08",
          "entropy_mean", "entropy_std", "entropy_p90", "margin_mean", "margin_std"]
    # confidence restricted to speech frames
    n += ["sp_maxpost_mean", "sp_maxpost_std", "sp_entropy_mean",
          "sp_lowconf_frac05", "sp_margin_mean"]
    # silence structure
    n += ["sil_argmax_frac", "sil_post_mean", "sil_post_gt05_frac",
          "sil_runs_per_s", "sil_run_mean_s", "sil_run_median_s", "sil_run_std_s",
          "sil_run_p90_s", "sil_run_max_s", "long_pause_frac",
          "speech_run_mean_s", "speech_run_max_s"]
    # phoneme rate / stability
    n += ["trans_per_s", "dwell_mean_s", "dwell_std_s", "dwell_median_s",
          "dwell_p90_s", "dwell_cv", "sp_trans_per_s", "sp_dwell_mean_s"]
    # broad-class posterior mass
    n += [f"mass_{g}" for g in GROUPS]
    n += ["mass_cons", "mass_voiced_obs", "mass_voiceless_obs",
          "cons_vowel_ratio", "voiced_voiceless_ratio"]
    n += [f"rmass_{g}" for g in GROUPS]
    # dynamics of the posteriorgram
    n += ["dframe_absmean", "dframe_std", "dframe_p05", "dframe_p95"]
    n += [f"sil_bp_{b}" for b in BANDS] + ["sil_peak_freq", "sil_spec_entropy"]
    n += [f"dyn_bp_{b}" for b in BANDS] + ["dyn_peak_freq", "dyn_spec_entropy"]
    # distributional shape
    n += ["avgdist_entropy", "avgdist_entropy_sp", "argmax_entropy",
          "n_phones_1pct", "n_phones_5pct", "top_phone_frac"]
    # duration
    n += ["dur_s", "speech_dur_s"]
    # per-phoneme mean posterior (39 phonemes; silence already covered above)
    n += [f"post_{p}" for p in PHONES[:-1]]
    return [P_ + c for c in n]


FEATURES = _feature_names()
NAN_ROW = {c: np.nan for c in FEATURES}


# ---------------------------------------------------------------- small utils
def _run_lengths(a: np.ndarray):
    """Contiguous-run decomposition of a 1-D integer array -> (values, lengths)."""
    if a.size == 0:
        return np.empty(0, dtype=a.dtype), np.empty(0, dtype=np.int64)
    cuts = np.flatnonzero(np.diff(a)) + 1
    bounds = np.concatenate(([0], cuts, [a.size]))
    return a[bounds[:-1]], np.diff(bounds)


def _safe_ratio(num: float, den: float) -> float:
    if not np.isfinite(num) or not np.isfinite(den) or den < 1e-3:
        return np.nan
    return float(min(num / den, RATIO_CAP))


def _pct(a: np.ndarray, q: float) -> float:
    return float(np.percentile(a, q)) if a.size else np.nan


# ---------------------------------------------------------------- summariser
def summarise(rec: dict) -> dict:
    out = dict(NAN_ROW)
    try:
        return _summarise(rec, out)
    except Exception:
        return out


def _summarise(rec: dict, out: dict) -> dict:
    P = as_2d(rec["value"], expect_channels=N_CLASS)
    if P.ndim != 2 or P.shape[0] < 2 or P.shape[1] != N_CLASS:
        return out

    # scrub and re-normalise each frame to a proper distribution
    P = np.nan_to_num(P, nan=0.0, posinf=0.0, neginf=0.0)
    np.clip(P, 0.0, None, out=P)
    s = P.sum(axis=1)
    good = s > 1e-6
    if good.sum() < 2:
        return out
    P = P[good] / s[good, None]
    T = P.shape[0]
    out[P_ + "dur_s"] = T / FS

    # ---- confidence / precision -------------------------------------------
    part = np.partition(P, N_CLASS - 2, axis=1)
    top1 = part[:, -1]
    top2 = part[:, -2]
    margin = top1 - top2
    ent = -(P * np.log(P + 1e-12)).sum(axis=1) / LOG40

    out[P_ + "maxpost_mean"] = float(top1.mean())
    out[P_ + "maxpost_std"] = float(top1.std())
    out[P_ + "maxpost_p10"] = _pct(top1, 10)
    out[P_ + "maxpost_p50"] = _pct(top1, 50)
    out[P_ + "maxpost_p90"] = _pct(top1, 90)
    out[P_ + "lowconf_frac05"] = float((top1 < 0.5).mean())
    out[P_ + "lowconf_frac03"] = float((top1 < 0.3).mean())
    out[P_ + "highconf_frac08"] = float((top1 > 0.8).mean())
    out[P_ + "entropy_mean"] = float(ent.mean())
    out[P_ + "entropy_std"] = float(ent.std())
    out[P_ + "entropy_p90"] = _pct(ent, 90)
    out[P_ + "margin_mean"] = float(margin.mean())
    out[P_ + "margin_std"] = float(margin.std())

    # ---- silence / speech segmentation ------------------------------------
    am = np.argmax(P, axis=1).astype(np.int64)
    is_sil = (am == SIL)
    sp = ~is_sil
    n_sp = int(sp.sum())
    sil_post = P[:, SIL]

    out[P_ + "sil_argmax_frac"] = float(is_sil.mean())
    out[P_ + "sil_post_mean"] = float(sil_post.mean())
    out[P_ + "sil_post_gt05_frac"] = float((sil_post > 0.5).mean())
    out[P_ + "speech_dur_s"] = n_sp / FS

    vals, lens = _run_lengths(is_sil.astype(np.int64))
    sil_len = lens[vals == 1].astype(np.float64)
    spc_len = lens[vals == 0].astype(np.float64)
    dur_s = T / FS
    if dur_s > 0:
        out[P_ + "sil_runs_per_s"] = float(sil_len.size / dur_s)
    if sil_len.size:
        out[P_ + "sil_run_mean_s"] = float(sil_len.mean() / FS)
        out[P_ + "sil_run_median_s"] = float(np.median(sil_len) / FS)
        out[P_ + "sil_run_std_s"] = float(sil_len.std() / FS)
        out[P_ + "sil_run_p90_s"] = float(np.percentile(sil_len, 90) / FS)
        out[P_ + "sil_run_max_s"] = float(sil_len.max() / FS)
        out[P_ + "long_pause_frac"] = float(sil_len[sil_len >= 0.5 * FS].sum() / T)
    else:
        for k in ("sil_run_mean_s", "sil_run_median_s", "sil_run_std_s",
                  "sil_run_p90_s", "sil_run_max_s"):
            out[P_ + k] = 0.0
        out[P_ + "long_pause_frac"] = 0.0
    if spc_len.size:
        out[P_ + "speech_run_mean_s"] = float(spc_len.mean() / FS)
        out[P_ + "speech_run_max_s"] = float(spc_len.max() / FS)
    else:
        out[P_ + "speech_run_mean_s"] = 0.0
        out[P_ + "speech_run_max_s"] = 0.0

    # ---- phoneme rate and dwell stability ---------------------------------
    if T >= 2 and dur_s > 0:
        out[P_ + "trans_per_s"] = float(np.count_nonzero(np.diff(am)) / dur_s)
    _, dwell = _run_lengths(am)
    if dwell.size:
        d = dwell.astype(np.float64) / FS
        out[P_ + "dwell_mean_s"] = float(d.mean())
        out[P_ + "dwell_std_s"] = float(d.std())
        out[P_ + "dwell_median_s"] = float(np.median(d))
        out[P_ + "dwell_p90_s"] = float(np.percentile(d, 90))
        out[P_ + "dwell_cv"] = float(d.std() / d.mean()) if d.mean() > 1e-9 else np.nan

    # ---- speech-only confidence and rate ----------------------------------
    if n_sp >= 3:
        Ps = P[sp]
        t1s = top1[sp]
        out[P_ + "sp_maxpost_mean"] = float(t1s.mean())
        out[P_ + "sp_maxpost_std"] = float(t1s.std())
        out[P_ + "sp_entropy_mean"] = float(ent[sp].mean())
        out[P_ + "sp_lowconf_frac05"] = float((t1s < 0.5).mean())
        out[P_ + "sp_margin_mean"] = float(margin[sp].mean())

        am_sp = am[sp]
        sp_dur = n_sp / FS
        out[P_ + "sp_trans_per_s"] = float(np.count_nonzero(np.diff(am_sp)) / sp_dur)
        _, dw_sp = _run_lengths(am_sp)
        if dw_sp.size:
            out[P_ + "sp_dwell_mean_s"] = float(dw_sp.mean() / FS)

        # phonetic diversity over speech frames only (silence dim dropped)
        mv = Ps.mean(axis=0)
        mv_sp = np.delete(mv, SIL)
        z = mv_sp.sum()
        if z > 1e-9:
            q = mv_sp / z
            out[P_ + "avgdist_entropy_sp"] = float(-(q * np.log(q + 1e-12)).sum() / LOG39)
        cnt_sp = np.bincount(am_sp, minlength=N_CLASS).astype(np.float64)
        out[P_ + "top_phone_frac"] = float(cnt_sp.max() / n_sp)

    # ---- broad-class posterior mass ---------------------------------------
    mean_post = P.mean(axis=0)
    for g, ix in GROUP_IX.items():
        out[P_ + f"mass_{g}"] = float(mean_post[ix].sum())
    m_cons = float(mean_post[CONS_IX].sum())
    m_vow = float(mean_post[GROUP_IX["vowel"]].sum())
    m_vo = float(mean_post[VOICED_OBS_IX].sum())
    m_uo = float(mean_post[VOICELESS_OBS_IX].sum())
    out[P_ + "mass_cons"] = m_cons
    out[P_ + "mass_voiced_obs"] = m_vo
    out[P_ + "mass_voiceless_obs"] = m_uo
    out[P_ + "cons_vowel_ratio"] = _safe_ratio(m_cons, m_vow)
    out[P_ + "voiced_voiceless_ratio"] = _safe_ratio(m_vo, m_uo)

    # pause-normalised class mass: what the speech itself is made of
    nonsil = 1.0 - float(mean_post[SIL])
    if nonsil > 1e-3:
        for g, ix in GROUP_IX.items():
            out[P_ + f"rmass_{g}"] = float(mean_post[ix].sum() / nonsil)

    for i, p in enumerate(PHONES[:-1]):
        out[P_ + f"post_{p}"] = float(mean_post[i])

    # ---- dynamics ----------------------------------------------------------
    if T >= 3:
        dframe = 0.5 * np.abs(np.diff(P, axis=0)).sum(axis=1)   # TV distance in [0,1]
        out[P_ + "dframe_absmean"] = float(dframe.mean())
        out[P_ + "dframe_std"] = float(dframe.std())
        out[P_ + "dframe_p05"] = _pct(dframe, 5)
        out[P_ + "dframe_p95"] = _pct(dframe, 95)
        out.update(band_power(dframe.astype(np.float64), FS, BANDS, P_ + "dyn"))
    out.update(band_power(sil_post.astype(np.float64), FS, BANDS, P_ + "sil"))

    # ---- distributional shape ---------------------------------------------
    out[P_ + "avgdist_entropy"] = float(
        -(mean_post * np.log(mean_post + 1e-12)).sum() / LOG40)
    cnt = np.bincount(am, minlength=N_CLASS).astype(np.float64) / T
    nz = cnt[cnt > 0]
    out[P_ + "argmax_entropy"] = float(-(nz * np.log(nz)).sum() / LOG40)
    ph_cnt = np.delete(cnt, SIL)
    out[P_ + "n_phones_1pct"] = float((ph_cnt >= 0.01).sum())
    out[P_ + "n_phones_5pct"] = float((ph_cnt >= 0.05).sum())
    return out


# ---------------------------------------------------------------- entrypoint
def main(test: bool = False) -> None:
    src = PARQUET["ppgs"]
    out_path = DATA / (f"dyn_{NAME}_TEST.parquet" if test else f"dyn_{NAME}.parquet")
    print(f"source  {src}")
    print(f"target  {out_path}")
    print(f"{len(FEATURES)} feature columns", flush=True)
    df = extract(src, "ppgs", summarise, out_path,
                 limit_groups=1 if test else None, progress_every=1)

    feat = [c for c in df.columns if c.startswith(P_)]
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        print("MISSING COLUMNS:", missing)
    nanfrac = df[feat].isna().mean().sort_values()
    print(f"\nrows={len(df)}  feature_cols={len(feat)}")
    print(f"NaN fraction: min={nanfrac.min():.4f} max={nanfrac.max():.4f}")
    print("\nmost-NaN columns:")
    print(nanfrac.tail(8).to_string())
    print("\nsample describe:")
    with_pd = df[feat].describe().T[["mean", "std", "min", "max"]]
    print(with_pd.head(30).to_string())


if __name__ == "__main__":
    main(test="--test" in sys.argv)
