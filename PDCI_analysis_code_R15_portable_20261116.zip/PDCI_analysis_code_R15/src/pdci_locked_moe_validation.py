"""Locked shared-control mixture-of-experts refinement for PD versus CI.

This is intentionally a small, predeclared follow-up rather than another broad
leaderboard.  The new model fits two independent acoustic experts inside every
training fold:

* a PD-versus-neither expert (CI rows excluded from that expert's fit), and
* a CI-versus-neither expert (PD rows excluded from that expert's fit).

The difference between their held-out log odds is the PD-versus-CI score.  A
joint three-class PCA-100 model supplies the neurological-screen probability.
All preprocessing and PCA fits are participant-fold internal.

Development uses the historical 750-person complete-11-task cohort and the
same fixed 5x3 repeated folds.  A frozen-model rule is written before a second
command can evaluate a fixed six-task core battery on the 68 previously unused
participants who completed those six tasks but not all eleven.  Task presence
is constant in both training and stress-test matrices; no missingness or task
completion feature is exposed to a model.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_to_baseline as CB  # noqa: E402
import config as C  # noqa: E402
import modeling  # noqa: E402
import pdci_exhaustive as E  # noqa: E402
import pdci_pca_shrinkage_refinement as PS  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")

OUT = C.RESULTS / "pdci_locked_moe"
FOLDS = OUT / "folds"
CORE_FOLDS = OUT / "core6_diagnostic_folds"
OUT.mkdir(parents=True, exist_ok=True)
FOLDS.mkdir(parents=True, exist_ok=True)
CORE_FOLDS.mkdir(parents=True, exist_ok=True)
SEED = C.RANDOM_STATE

# Fixed by overall completion rate before any stress-test outcome is viewed.
CORE_TASKS = PT.GENERAL_TASKS[:6]
MODELS = [
    "anchor_pca50",
    "joint_pca100",
    "pca75_empirical_ridge",
    "shared_ovr_pca100",
    "specialist_moe_pca100",
    "jointscreen_specialistdiff",
    "joint_specialist_blend",
]
CHALLENGERS = MODELS[2:]


@lru_cache(maxsize=1)
def development_data():
    ids = PT.ids_for_design("general")
    y = PT.labels(ids, "multiclass").to_numpy(int)
    x = PT.build_X("general", "per_task_dynamic").reindex(ids)
    return ids, y, x


def core_matrix(ids):
    audio = PT.task_individual(CORE_TASKS, "dynamic", ids)
    co = PT.cohort().loc[ids, ["age", "sex_male"]].astype(np.float32)
    dur = PT.duration_features(ids, CORE_TASKS)
    return pd.concat([audio, co, dur], axis=1).replace(
        [np.inf, -np.inf], np.nan).astype(np.float32)


@lru_cache(maxsize=1)
def stress_data():
    train_ids = PT.ids_for_design("general")
    did = PT.task_presence()
    base = PT.clean_base_mask()
    eligible = PT.cohort().index[base & did[CORE_TASKS].all(axis=1)]
    test_ids = eligible.difference(train_ids)
    if len(test_ids) != 68:
        raise AssertionError(f"core holdout changed: expected 68, got {len(test_ids)}")
    if not bool(did.loc[eligible, CORE_TASKS].all().all()):
        raise AssertionError("core task presence is not constant")
    ids = train_ids.append(test_ids)
    x = core_matrix(ids)
    y = PT.labels(ids, "multiclass").to_numpy(int)
    return train_ids, test_ids, x.loc[train_ids], x.loc[test_ids], \
        y[:len(train_ids)], y[len(train_ids):]


def pca_transform(a, b, k):
    pca = PCA(n_components=min(k, len(a) - 2, a.shape[1]), random_state=SEED)
    return pca.fit_transform(a), pca.transform(b)


def lda_proba(a, y, b):
    est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    est.fit(a, y)
    return PS.aligned(est, b) if len(np.unique(y)) == 3 else \
        est.predict_proba(b)[:, list(est.classes_).index(1)]


def joint_predict(xtr, ytr, xte, k, head="lda"):
    prep = modeling.make_prep()
    a, b = prep.fit_transform(xtr), prep.transform(xte)
    za, zb = pca_transform(a, b, k)
    if head == "lda":
        return lda_proba(za, ytr, zb), (za, zb)
    if head == "empirical_ridge":
        est = make_pipeline(StandardScaler(), LogisticRegression(
            C=0.03, penalty="l2", solver="lbfgs", class_weight=None,
            max_iter=5000, random_state=SEED))
        est.fit(za, ytr)
        return PS.aligned(est, zb), (za, zb)
    raise ValueError(head)


def shared_binary(za, ytr, zb, positive):
    return lda_proba(za, (ytr == positive).astype(int), zb)


def specialist_binary(xtr, ytr, xte, positive):
    keep = (ytr == 0) | (ytr == positive)
    prep = modeling.make_prep()
    a = prep.fit_transform(xtr.iloc[keep])
    b = prep.transform(xte)
    za, zb = pca_transform(a, b, 100)
    return lda_proba(za, (ytr[keep] == positive).astype(int), zb)


def clip(p):
    return np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)


def differential(pd_p, ci_p):
    podds = clip(pd_p) / (1 - clip(pd_p))
    codds = clip(ci_p) / (1 - clip(ci_p))
    return clip(podds / (podds + codds))


def conditional(p):
    return clip(p[:, 1] / np.maximum(1e-12, p[:, 1] + p[:, 2]))


def compose(screen, q):
    s, q = clip(screen), clip(q)
    return np.column_stack([1 - s, s * q, s * (1 - q)])


def fit_candidates(xtr, ytr, xte):
    p50, _ = joint_predict(xtr, ytr, xte, 50)
    p100, (za100, zb100) = joint_predict(xtr, ytr, xte, 100)
    p75, _ = joint_predict(xtr, ytr, xte, 75, "empirical_ridge")

    shared_pd = shared_binary(za100, ytr, zb100, 1)
    shared_ci = shared_binary(za100, ytr, zb100, 2)
    shared_q = differential(shared_pd, shared_ci)
    shared_screen = 1 - (1 - clip(shared_pd)) * (1 - clip(shared_ci))

    specialist_pd = specialist_binary(xtr, ytr, xte, 1)
    specialist_ci = specialist_binary(xtr, ytr, xte, 2)
    specialist_q = differential(specialist_pd, specialist_ci)
    specialist_screen = 1 - ((1 - clip(specialist_pd)) *
                             (1 - clip(specialist_ci)))
    joint_screen, joint_q = p100[:, 1:].sum(axis=1), conditional(p100)

    return {
        "anchor_pca50": p50,
        "joint_pca100": p100,
        "pca75_empirical_ridge": p75,
        "shared_ovr_pca100": compose(shared_screen, shared_q),
        "specialist_moe_pca100": compose(specialist_screen, specialist_q),
        "jointscreen_specialistdiff": compose(joint_screen, specialist_q),
        "joint_specialist_blend": compose(
            joint_screen, 0.5 * joint_q + 0.5 * specialist_q),
    }


def run_fold(oi, splits, repeats):
    path = FOLDS / f"r{oi // splits}_f{oi % splits}.parquet"
    meta = path.with_suffix(".json")
    if path.exists() and meta.exists():
        return json.loads(meta.read_text(encoding="utf-8"))
    t0 = time.time()
    try:
        ids, y, x = development_data()
        folds = list(RepeatedStratifiedKFold(
            n_splits=splits, n_repeats=repeats, random_state=SEED).split(
                np.zeros(len(y)), y))
        tr, te = folds[oi]
        pred = fit_candidates(x.iloc[tr], y[tr], x.iloc[te])
        d = pd.DataFrame({"participant_id": ids[te].astype(str),
                          "y_true": y[te], "repeat": oi // splits,
                          "fold": oi % splits})
        for name, p in pred.items():
            for cls in range(3):
                d[f"{name}_p{cls}"] = p[:, cls].astype(np.float32)
        d.to_parquet(path, index=False)
        rec = {"job_id": path.stem, "status": "ok",
               "seconds": round(time.time() - t0, 2)}
        meta.write_text(json.dumps(rec), encoding="utf-8")
        return rec
    except Exception as exc:
        rec = {"job_id": path.stem, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - t0, 2)}
        meta.write_text(json.dumps(rec), encoding="utf-8")
        return rec


def aggregate():
    files = sorted(FOLDS.glob("r*_f*.parquet"))
    if len(files) != 15:
        raise RuntimeError(f"expected 15 folds, found {len(files)}")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    pcols = [c for c in raw if c.endswith(("_p0", "_p1", "_p2"))]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in pcols}})
    d.to_parquet(OUT / "development_oof_predictions.parquet")
    return raw, d


def score_models(d):
    y = d.y_true.to_numpy(int)
    case = y > 0
    rows, probs = [], {}
    for name in MODELS:
        p = d[[f"{name}_p{i}" for i in range(3)]].to_numpy(float)
        q = conditional(p[case])
        probs[name] = q
        rows.append({
            "model": name,
            "n": len(y), "n_cases": int(case.sum()),
            "pd_vs_ci_auc": roc_auc_score(y[case] == 1, q),
            "three_class_macro_auc": roc_auc_score(
                y, p, multi_class="ovr", average="macro"),
            "neuro_auc": roc_auc_score(y > 0, p[:, 1:].sum(axis=1)),
            "pd_vs_all_auc": roc_auc_score(y == 1, p[:, 1]),
            "ci_vs_all_auc": roc_auc_score(y == 2, p[:, 2]),
        })
    return pd.DataFrame(rows), probs


def development_report(bootstraps=5000):
    raw, d = aggregate()
    metrics, probs = score_models(d)
    metrics.to_csv(OUT / "development_metrics.csv", index=False)
    y = d.y_true.to_numpy(int)
    yy = (y[y > 0] == 1).astype(int)
    comps = []
    for reference in ("anchor_pca50", "joint_pca100"):
        for name in MODELS:
            if name == reference:
                continue
            rec = CB.bootstrap_pair(yy, probs[name], probs[reference],
                                    n_boot=bootstraps)
            delta, pv = CB.delong_test(yy, probs[name], probs[reference])
            comps.append({"model": name, "reference": reference,
                          "delta_delong": delta, "p_delong": pv, **rec})
    comp = pd.DataFrame(comps)
    comp["fdr_q_within_reference"] = comp.groupby("reference").p_delong.transform(
        lambda x: E._bh(x))
    comp.to_csv(OUT / "development_comparisons.csv", index=False)

    repeat_rows = []
    for repeat, g in raw.groupby("repeat"):
        gy = g.y_true.to_numpy(int)
        case = gy > 0
        for name in MODELS:
            p = g[[f"{name}_p{i}" for i in range(3)]].to_numpy(float)
            repeat_rows.append({"repeat": int(repeat), "model": name,
                                "pd_vs_ci_auc": roc_auc_score(
                                    gy[case] == 1, conditional(p[case]))})
    repeats = pd.DataFrame(repeat_rows)
    repeats.to_csv(OUT / "development_repeat_stability.csv", index=False)

    # Predeclared conservative promotion rule.  A challenger must have a
    # positive paired 95% bootstrap lower bound over PCA-100 and preserve both
    # neuro and macro AUC to within 0.01.  Otherwise PCA-100 remains frozen.
    base = metrics.set_index("model").loc["joint_pca100"]
    versus = comp[comp.reference == "joint_pca100"].set_index("model")
    eligible = []
    for name in CHALLENGERS:
        row = metrics.set_index("model").loc[name]
        if (name in versus.index and versus.loc[name, "delta_lo"] > 0
                and row.neuro_auc >= base.neuro_auc - 0.01
                and row.three_class_macro_auc >= base.three_class_macro_auc - 0.01):
            eligible.append(name)
    frozen = (metrics[metrics.model.isin(eligible)].sort_values(
        "pd_vs_ci_auc", ascending=False).iloc[0].model
        if eligible else "joint_pca100")
    freeze = {
        "frozen_model": frozen,
        "eligible_challengers": eligible,
        "rule": "promote only if paired bootstrap delta lower bound > 0 versus "
                "joint_pca100 and neuro/macro AUC each decline by no more than 0.01",
        "core_tasks": CORE_TASKS,
        "development_results_seen": True,
        "holdout_results_seen": False,
    }
    (OUT / "frozen_model.json").write_text(json.dumps(freeze, indent=2),
                                             encoding="utf-8")
    lines = [
        "# Locked shared-control mixture-of-experts development", "",
        "All predictions are participant-held-out on the fixed complete-general "
        "cohort. Candidate architectures and the promotion rule were fixed before "
        "outcomes from this run were aggregated.", "", "## Metrics", "",
        R.markdown_table(metrics.sort_values("pd_vs_ci_auc", ascending=False)
                         .round(4)), "", "## Paired comparisons", "",
        R.markdown_table(comp.round(4)), "", "## Repeat stability", "",
        R.markdown_table(repeats.pivot(index="repeat", columns="model",
                                       values="pd_vs_ci_auc").reset_index()
                         .round(4)), "", "## Frozen decision", "",
        "```json", json.dumps(freeze, indent=2), "```", "",
        "The 68-person core-battery stress test must not be run until this file "
        "exists; the holdout command reports only the frozen model and predeclared "
        "PCA-50/demographic comparators.", "",
    ]
    (OUT / "DEVELOPMENT_REPORT.md").write_text("\n".join(lines),
                                                 encoding="utf-8")
    print(metrics.sort_values("pd_vs_ci_auc", ascending=False).to_string(index=False))
    print(comp.to_string(index=False))
    print(json.dumps(freeze, indent=2))


def fit_demographic(xtr, ytr, xte):
    cols = [c for c in xtr if c in {"age", "sex_male"} or c.startswith("dur_")]
    prep = modeling.make_prep()
    a, b = prep.fit_transform(xtr[cols]), prep.transform(xte[cols])
    est = LogisticRegression(C=1.0, class_weight="balanced", max_iter=5000,
                             random_state=SEED)
    est.fit(a, ytr)
    return PS.aligned(est, b)


def corecv_fold(oi, splits, repeats):
    """Fixed diagnostic: does the six-task battery work in the old cohort?"""
    path = CORE_FOLDS / f"r{oi // splits}_f{oi % splits}.parquet"
    if path.exists():
        return {"job_id": path.stem, "status": "ok", "seconds": 0.0}
    t0 = time.time()
    train_ids, _, x, _, y, _ = stress_data()
    folds = list(RepeatedStratifiedKFold(
        n_splits=splits, n_repeats=repeats, random_state=SEED).split(
            np.zeros(len(y)), y))
    tr, te = folds[oi]
    pred = {
        "core_pca50": joint_predict(x.iloc[tr], y[tr], x.iloc[te], 50)[0],
        "core_pca100": joint_predict(x.iloc[tr], y[tr], x.iloc[te], 100)[0],
        "core_age_sex_duration": fit_demographic(
            x.iloc[tr], y[tr], x.iloc[te]),
    }
    d = pd.DataFrame({"participant_id": train_ids[te].astype(str),
                      "y_true": y[te], "repeat": oi // splits,
                      "fold": oi % splits})
    for name, p in pred.items():
        for cls in range(3):
            d[f"{name}_p{cls}"] = p[:, cls]
    d.to_parquet(path, index=False)
    return {"job_id": path.stem, "status": "ok",
            "seconds": round(time.time() - t0, 2)}


def corecv_report():
    files = sorted(CORE_FOLDS.glob("*.parquet"))
    if len(files) != 15:
        raise RuntimeError(f"expected 15 core diagnostic folds, found {len(files)}")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    pcols = [c for c in raw if c.endswith(("_p0", "_p1", "_p2"))]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in pcols}})
    models = ["core_pca50", "core_pca100", "core_age_sex_duration"]
    rows = []
    y = d.y_true.to_numpy(int)
    case = y > 0
    for name in models:
        p = d[[f"{name}_p{i}" for i in range(3)]].to_numpy(float)
        rows.append({
            "model": name,
            "pd_vs_ci_auc": roc_auc_score(y[case] == 1, conditional(p[case])),
            "three_class_macro_auc": roc_auc_score(
                y, p, multi_class="ovr", average="macro"),
            "neuro_auc": roc_auc_score(y > 0, p[:, 1:].sum(axis=1)),
        })
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / "core6_development_diagnostic.csv", index=False)
    lines = [
        "# Six-task battery diagnostic in the development cohort", "",
        "This fixed post-holdout diagnostic asks whether the failed 68-person "
        "stress test is plausibly explained by removing five tasks. It does not "
        "select or promote a model.", "", R.markdown_table(metrics.round(4)), "",
    ]
    (OUT / "CORE6_DIAGNOSTIC.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))


def holdout_report(bootstraps=10000):
    freeze_path = OUT / "frozen_model.json"
    if not freeze_path.exists():
        raise RuntimeError("development must freeze a model before holdout access")
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if freeze.get("holdout_results_seen"):
        print((OUT / "HOLDOUT_REPORT.md").read_text(encoding="utf-8"))
        return
    train_ids, test_ids, xtr, xte, ytr, yte = stress_data()
    candidates = fit_candidates(xtr, ytr, xte)
    frozen_name = freeze["frozen_model"]
    pred = {
        "frozen": candidates[frozen_name],
        "core_pca50_comparator": candidates["anchor_pca50"],
        "age_sex_duration": fit_demographic(xtr, ytr, xte),
    }
    d = pd.DataFrame({"participant_id": test_ids.astype(str), "y_true": yte})
    rows, q = [], {}
    case = yte > 0
    yy = (yte[case] == 1).astype(int)
    for name, p in pred.items():
        for cls in range(3):
            d[f"{name}_p{cls}"] = p[:, cls]
        qq = conditional(p[case])
        q[name] = qq
        rows.append({
            "model": name, "n": len(yte), "n_pd": int((yte == 1).sum()),
            "n_ci": int((yte == 2).sum()),
            "pd_vs_ci_auc": roc_auc_score(yy, qq),
            "three_class_macro_auc": roc_auc_score(
                yte, p, multi_class="ovr", average="macro"),
            "neuro_auc": roc_auc_score(yte > 0, p[:, 1:].sum(axis=1)),
            "pd_vs_all_auc": roc_auc_score(yte == 1, p[:, 1]),
            "ci_vs_all_auc": roc_auc_score(yte == 2, p[:, 2]),
        })
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / "holdout_metrics.csv", index=False)
    d.to_parquet(OUT / "holdout_predictions.parquet", index=False)
    comparisons = []
    for ref in ("core_pca50_comparator", "age_sex_duration"):
        rec = CB.bootstrap_pair(yy, q["frozen"], q[ref], n_boot=bootstraps)
        delta, pv = CB.delong_test(yy, q["frozen"], q[ref])
        comparisons.append({"model": "frozen", "reference": ref,
                            "delta_delong": delta, "p_delong": pv, **rec})
    comp = pd.DataFrame(comparisons)
    comp.to_csv(OUT / "holdout_comparisons.csv", index=False)

    freeze["holdout_results_seen"] = True
    freeze["holdout_n"] = int(len(yte))
    freeze["holdout_class_counts"] = {
        "neither": int((yte == 0).sum()), "PD": int((yte == 1).sum()),
        "CI": int((yte == 2).sum())}
    freeze_path.write_text(json.dumps(freeze, indent=2), encoding="utf-8")
    lines = [
        "# Previously unused participant core-battery stress test", "",
        f"Frozen development winner: **{frozen_name}**. The test set contains "
        f"{len(yte)} participants ({int((yte == 0).sum())} neither, "
        f"{int((yte == 1).sum())} PD, {int((yte == 2).sum())} CI) who were not "
        "eligible for the complete-11-task development cohort. All completed the "
        "same fixed six tasks, and the model receives no task-presence feature.",
        "", "This is a distribution-shift stress test of the locked architecture, "
        "not external-site validation of the exact 11-task fitted model.", "",
        "## Metrics", "", R.markdown_table(metrics.round(4)), "",
        "## Paired PD-versus-CI comparisons", "",
        R.markdown_table(comp.round(4)), "",
    ]
    (OUT / "HOLDOUT_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))
    print(comp.to_string(index=False))


def audit():
    ids, y, x = development_data()
    train_ids, test_ids, xtr, xte, ytr, yte = stress_data()
    print(pd.Series(y).value_counts().sort_index().to_string())
    print(f"development X={x.shape}")
    print(f"core tasks={CORE_TASKS}")
    print(f"core train={xtr.shape}; holdout={xte.shape}; "
          f"holdout classes={dict(pd.Series(yte).value_counts().sort_index())}")
    print(f"ID overlap={len(train_ids.intersection(test_ids))}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run", "report", "holdout",
                                         "corecv"])
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--bootstraps", type=int, default=5000)
    a = ap.parse_args()
    if a.command == "audit":
        return audit()
    if a.command == "report":
        return development_report(a.bootstraps)
    if a.command == "holdout":
        return holdout_report(max(a.bootstraps, 5000))
    if a.command == "corecv":
        total = a.splits * a.repeats
        todo = [i for i in range(total) if not (
            CORE_FOLDS / f"r{i // a.splits}_f{i % a.splits}.parquet").exists()]
        for start in range(0, len(todo), a.jobs):
            batch = todo[start:start + a.jobs]
            ans = Parallel(n_jobs=a.jobs, prefer="threads", verbose=5)(
                delayed(corecv_fold)(i, a.splits, a.repeats) for i in batch)
            for rec in ans:
                print(rec["job_id"], rec["status"], rec["seconds"], flush=True)
        return corecv_report()
    total = a.splits * a.repeats
    todo = [i for i in range(total) if not (
        FOLDS / f"r{i // a.splits}_f{i % a.splits}.parquet").exists()]
    print(f"Locked MoE development: {len(todo)}/{total} folds pending", flush=True)
    for start in range(0, len(todo), a.jobs):
        batch = todo[start:start + a.jobs]
        ans = Parallel(n_jobs=a.jobs, prefer="threads", verbose=5)(
            delayed(run_fold)(i, a.splits, a.repeats) for i in batch)
        for rec in ans:
            print(rec["job_id"], rec["status"], rec.get("error", ""),
                  rec.get("seconds", ""), flush=True)
    development_report(a.bootstraps)


if __name__ == "__main__":
    main()
