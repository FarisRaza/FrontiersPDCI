"""A8 (AR-29): counts-only recount of the PD/CI cohort flow, category composition and Table 1.

Protocol: results/pdci_a8_cohort_recount_20261007/ANALYSIS_PLAN.md. Aggregates only; no models.
Usage (analysis venv):  python src/pdci_a8_cohort_recount_20261007.py freeze|gate|run
"""
from __future__ import annotations

import hashlib
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import pdci_tasks as PT  # noqa: E402

OUT = C.RESULTS / "pdci_a8_cohort_recount_20261007"
FROZEN_RUN = C.RESULTS / "pdci_demographic_baseline_20260911"
DEMO = C.PHENO / "demographics" / "demographics.tsv"
PD_TSV = C.PHENO / "diagnosis" / "parkinsons_disease.tsv"
CI_TSV = C.PHENO / "diagnosis" / "cognitive_impairment.tsv"
PD_FIELD = "diagnosis_parkinsons_disease_subtype"
CI_FIELD = "diagnosis_alz_dementia_mci_dt"
CLASSES = {0: "neither", 1: "PD", 2: "CI"}
INPUTS = [C.DATA / "cohort.parquet", C.DATA / "static_bytask.parquet", DEMO, PD_TSV, CI_TSV,
          FROZEN_RUN / "INPUT_AUDIT.json",
          Path(PT.__file__), Path(C.__file__)]


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2, default=str) + "\n", encoding="utf-8")


def pad(s: pd.Series | pd.Index):
    return pd.Index(pd.Index(s).astype(str).str.strip().str.zfill(6))


def cohort_and_labels():
    co = PT.cohort()
    audio = co["n_recordings"].gt(0)
    als = co["rare_amyotrophic_lateral_sclerosis"].eq(1)
    overlap = co["parkinsons_disease"].eq(1) & co["cognitive_impairment"].eq(1)
    base = PT.clean_base_mask()
    ids = PT.ids_for_design("general")
    y = PT.labels(ids, "multiclass")
    flow = {
        "audio_cohort": int(audio.sum()),
        "excluded_als": int((audio & als).sum()),
        "excluded_pd_ci_overlap": int((audio & ~als & overlap).sum()),
        "remaining_after_exclusions": int(base.sum()),
        "lacking_general_task_family": int(base.sum() - len(ids)),
        "analysed": int(len(ids)),
        "analysed_neither": int((y == 0).sum()),
        "analysed_PD": int((y == 1).sum()),
        "analysed_CI": int((y == 2).sum()),
    }
    return ids, y, flow


def demographics(ids: pd.Index) -> pd.DataFrame:
    demo = pd.read_csv(DEMO, sep="\t", dtype=str).drop_duplicates("participant_id", keep="first")
    demo = demo.set_index("participant_id")
    demo.index = pad(demo.index)
    assert demo.index.is_unique
    demo = demo.reindex(pad(ids))
    demo.index = ids
    sex = demo["sex_at_birth"].fillna(demo["sex_assigned_at_birth"])
    return pd.DataFrame({
        "age": pd.to_numeric(demo["age"], errors="coerce"),
        "sex": sex.where(sex.isin(["Female", "Male"]), "unavailable"),
        "country": demo["country"].where(demo["country"].isin(["USA", "Canada"]), "unknown"),
    }, index=ids)


def freeze():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / "FROZEN_SPEC.json").exists():
        raise SystemExit("already frozen")
    spec = dict(created=now(), protocol="ANALYSIS_PLAN.md", authority="AR-29 'yes a8'",
                protocol_sha256=sha(OUT / "ANALYSIS_PLAN.md"), script=str(Path(__file__)),
                script_sha256=sha(Path(__file__)),
                inputs={str(p.relative_to(C.ROOT.parent)): sha(p) for p in INPUTS},
                versions=dict(python=platform.python_version(), pandas=pd.__version__, numpy=np.__version__))
    write_json(OUT / "FROZEN_SPEC.json", spec)
    print("frozen")


def check_frozen():
    spec = json.loads((OUT / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    assert spec["protocol_sha256"] == sha(OUT / "ANALYSIS_PLAN.md"), "protocol changed after freeze"
    assert spec["script_sha256"] == sha(Path(__file__)), "script changed after freeze"
    for rel, h in spec["inputs"].items():
        assert sha(C.ROOT.parent / rel) == h, f"input changed: {rel}"
    return spec


def gate():
    check_frozen()
    audit = json.loads((FROZEN_RUN / "INPUT_AUDIT.json").read_text(encoding="utf-8"))
    ids, y, flow = cohort_and_labels()
    d = demographics(ids)
    by_class = {}
    for k, name in zip((0, 1, 2), ("neither", "PD", "cognitive_impairment")):
        c = d.loc[y.index[y == k], "country"].value_counts()
        by_class[name] = {"USA": int(c.get("USA", 0)), "Canada": int(c.get("Canada", 0)),
                          "unknown": int(c.get("unknown", 0))}
    checks = {
        "n_750": flow["analysed"] == audit["n"] == 750,
        "class_counts": [flow["analysed_neither"], flow["analysed_PD"], flow["analysed_CI"]] == audit["class_counts"],
        "missing_age": int(d["age"].isna().sum()) == audit["canonical_demographic_join"]["covariates"]["age"]["new_missing"],
        "missing_sex": int((d["sex"] == "unavailable").sum()) == audit["canonical_demographic_join"]["covariates"]["sex_male"]["new_missing"],
        "country_complete": int((d["country"] == "unknown").sum()) == audit["canonical_demographic_join"]["covariates"]["country_usa"]["new_missing"] == 0,
        "country_by_class": by_class == audit["residence_country_by_class"],
        "audio_833": flow["audio_cohort"] == 833,
    }
    result = dict(time=now(), tolerance="exact integer equality", checks=checks, passed=all(checks.values()),
                  reference="results/pdci_demographic_baseline_20260911/INPUT_AUDIT.json")
    write_json(OUT / "GATE.json", result)
    print(json.dumps(result, indent=1))
    if not result["passed"]:
        raise SystemExit("GATE FAILED: no counts produced")


def paper_values():
    """Published reference values transcribed for the original count reconciliation.
    They are pinned by this script's hash; no private manuscript is needed."""
    return {
        ("flow", "audio_cohort"): 833, ("flow", "excluded_als"): 3, ("flow", "excluded_pd_ci_overlap"): 1,
        ("flow", "remaining_after_exclusions"): 829, ("flow", "lacking_general_task_family"): 79,
        ("flow", "analysed"): 750, ("flow", "analysed_neither"): 598, ("flow", "analysed_PD"): 90,
        ("flow", "analysed_CI"): 62,
        ("neither", "participants"): 598, ("PD", "participants"): 90, ("CI", "participants"): 62,
        ("neither", "age_observed"): 594, ("PD", "age_observed"): 90, ("CI", "age_observed"): 62,
        ("neither", "age_mean"): 55.44, ("PD", "age_mean"): 72.72, ("CI", "age_mean"): 75.06,
        ("neither", "age_sd"): 17.40, ("PD", "age_sd"): 7.20, ("CI", "age_sd"): 7.70,
        ("neither", "female"): 398, ("neither", "male"): 195, ("neither", "sex_unavailable"): 5,
        ("PD", "female"): 39, ("PD", "male"): 50, ("PD", "sex_unavailable"): 1,
        ("CI", "female"): 23, ("CI", "male"): 39, ("CI", "sex_unavailable"): 0,
        ("neither", "USA"): 597, ("neither", "Canada"): 1, ("PD", "USA"): 41, ("PD", "Canada"): 49,
        ("CI", "USA"): 3, ("CI", "Canada"): 59,
        ("PD_subtype", "idiopathic"): 53, ("PD_subtype", "undetermined"): 24,
        ("PD_subtype", "other_or_atypical_parkinsonism"): 9, ("PD_subtype", "DLB"): 3, ("PD_subtype", "PSP"): 1,
        ("CI_subtype", "MCI"): 36, ("CI_subtype", "vascular"): 6, ("CI_subtype", "mixed"): 6,
        ("CI_subtype", "typical_AD"): 4, ("CI_subtype", "other"): 9, ("CI_subtype", "unspecified"): 1,
    }


PAPER_LINE = {"flow": 47, "PD_subtype": 211, "CI_subtype": 211}
PD_MAP = {"Idiopathic Parkinson's Disease (IPD)": "idiopathic", "Not Sure / Undetermined": "undetermined",
          "Other Parkinsonism or Atypical Parkinsonism": "other_or_atypical_parkinsonism",
          "Dementia with Lewy Bodies (DLB)": "DLB", "Progressive Supranuclear Palsy (PSP)": "PSP"}
CI_MAP = {"Mild Cognitive Impairment (MCI)": "MCI", "Vascular Dementia (VaD)": "vascular",
          "Mixed Dementia (e.g., AD and VaD)": "mixed", "Typical Alzheimer's Disease (AD)": "typical_AD",
          "Other": "other", "missing": "unspecified"}


def subtype_counts(ids_cls: pd.Index, path: Path, field: str):
    m = pd.read_csv(path, sep="\t", dtype=str)
    m["pid"] = pad(m["participant_id"])
    assert m["pid"].is_unique
    m = m.set_index("pid")
    want = pad(ids_cls)
    present = want.isin(m.index)
    vals = m.reindex(want[present])[field].fillna("missing")
    raw = vals.value_counts()
    raw.loc["not in module"] = int((~present).sum())
    return raw.astype(int)


def run():
    spec = check_frozen()
    g = json.loads((OUT / "GATE.json").read_text(encoding="utf-8"))
    assert g["passed"], "gate not passed"
    t0 = now()
    ids, y, flow = cohort_and_labels()
    d = demographics(ids)
    pd.DataFrame([flow]).T.rename(columns={0: "n"}).rename_axis("step").to_csv(OUT / "cohort_flow.csv")

    rows = []
    for k, name in CLASSES.items():
        g_ = d.loc[y.index[y == k]]
        age = g_["age"].dropna()
        rows.append(dict(group=name, participants=len(g_), age_observed=int(age.size),
                         age_mean=float(age.mean()), age_sd=float(age.std(ddof=1)),
                         age_sd_population_ddof0=float(age.std(ddof=0)),
                         female=int((g_["sex"] == "Female").sum()), male=int((g_["sex"] == "Male").sum()),
                         sex_unavailable=int((g_["sex"] == "unavailable").sum()),
                         USA=int((g_["country"] == "USA").sum()), Canada=int((g_["country"] == "Canada").sum()),
                         country_unknown=int((g_["country"] == "unknown").sum())))
    t1 = pd.DataFrame(rows).set_index("group")
    t1.to_csv(OUT / "table1_recount.csv", float_format="%.6f")

    pdraw = subtype_counts(y.index[y == 1], PD_TSV, PD_FIELD)
    ciraw = subtype_counts(y.index[y == 2], CI_TSV, CI_FIELD)
    sub = pd.concat([pdraw.rename_axis("raw_value").reset_index(name="n").assign(category="PD"),
                     ciraw.rename_axis("raw_value").reset_index(name="n").assign(category="CI")])
    sub[["category", "raw_value", "n"]].to_csv(OUT / "subtype_recount.csv", index=False)

    # Recounted values in the paper's groupings (raw values outside a mapping stay separate).
    rec = {}
    for key, v in flow.items():
        rec[("flow", key)] = v
    for name in ("neither", "PD", "CI"):
        for col in ("participants", "age_observed", "female", "male", "sex_unavailable", "USA", "Canada"):
            rec[(name, col)] = int(t1.loc[name, col])
        rec[(name, "age_mean")] = round(float(t1.loc[name, "age_mean"]), 2)
        rec[(name, "age_sd")] = round(float(t1.loc[name, "age_sd"]), 2)
    for raw_value, n in pdraw.items():
        rec[("PD_subtype", PD_MAP.get(raw_value, f"UNMAPPED:{raw_value}"))] = rec.get(("PD_subtype", PD_MAP.get(raw_value, f"UNMAPPED:{raw_value}")), 0) + int(n)
    for raw_value, n in ciraw.items():
        rec[("CI_subtype", CI_MAP.get(raw_value, f"UNMAPPED:{raw_value}"))] = rec.get(("CI_subtype", CI_MAP.get(raw_value, f"UNMAPPED:{raw_value}")), 0) + int(n)

    paper = paper_values()
    out = []
    for key in sorted(set(paper) | set(rec), key=lambda k: (k[0], k[1])):
        pv, rv = paper.get(key), rec.get(key)
        if pv is None and rv == 0:
            continue
        if isinstance(pv, float) or isinstance(rv, float):
            status = "match" if pv is not None and rv is not None and abs(pv - rv) < 0.005 else "differ"
        else:
            status = "match" if pv == rv else "differ"
        line = PAPER_LINE.get(key[0], {"participants": 61, "age_observed": 62, "age_mean": 63, "age_sd": 63,
                                        "female": 64, "male": 64, "sex_unavailable": 64,
                                        "USA": 65, "Canada": 65}.get(key[1]))
        out.append(dict(section=key[0], item=key[1], paper_tex=pv, paper_tex_line=line, recount=rv, status=status))
    recon = pd.DataFrame(out)
    recon.to_csv(OUT / "RECONCILIATION.csv", index=False)
    comp = dict(start=t0, end=now(), frozen_spec_sha256=sha(OUT / "FROZEN_SPEC.json"),
                script_sha256=spec["script_sha256"], rows=dict(cohort_flow=len(flow), table1=len(t1),
                subtype=len(sub), reconciliation=len(recon)),
                n_match=int((recon.status == "match").sum()), n_differ=int((recon.status == "differ").sum()),
                versions=spec["versions"])
    write_json(OUT / "COMPLETION.json", comp)
    print(recon.to_string(index=False))
    print(json.dumps(comp, indent=1))


if __name__ == "__main__":
    {"freeze": freeze, "gate": gate, "run": run}[sys.argv[1]]()
