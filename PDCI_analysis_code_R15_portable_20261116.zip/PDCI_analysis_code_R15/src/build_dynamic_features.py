"""Aggregate the per-recording dynamic feature tables to participant level.

Mirrors build_static_features: recording -> (participant x task_group) mean ->
participant blocks, so dynamic and static features are aggregated identically
and can be concatenated without an apples-to-oranges problem.

Blocks (written to analysis/data/dynamic_participant.parquet):
  davg_*  mean across task groups
  dsdt_*  std across task groups
  dt_<task>_*  per-core-task means
  deng_*  cross-modality engineered contrasts
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402

KEY = ["participant_id", "session_id", "task_name"]


def discover() -> list[Path]:
    """Every dyn_*.parquet the extractors produced, ignoring their smoke tests."""
    return sorted(p for p in C.DATA.glob("dyn_*.parquet") if "TEST" not in p.name)

# Per-task dynamic features are the expensive block; restrict them to the
# tasks where each modality is actually informative rather than crossing every
# modality with every task.
DYN_CORE_TASKS = ["prolonged_vowel", "free_speech", "diadochokinesis",
                  "maximum_phonation_time", "rainbow_passage", "picture_description",
                  "glides", "cough_respiration"]

# free-speech and open-response recordings are absent from every content-bearing
# representation (EMA, PPG, MFCC, mel) -- only the SPARC prosody contours were
# released for the two spontaneous tasks, presumably because phoneme
# posteriorgrams and cepstra can be inverted back to identifiable speech.  So
# cross-modality "connected speech" contrasts have to reference a task that all
# five modalities actually cover.
SPEECH_REF = "picture_description"      # connected speech, present in all modalities
READ_REF = "rainbow_passage"            # read speech, present in all modalities

# Columns to drop before modelling, with the reason.  Verified defects, not
# taste: leaving them in would put duration proxies and exact duplicates in
# front of the feature selector.
DROP_EXACT = {
    # Algebraically identical to prosody_f0_st_acc_absmean / 5000.
    "prosody_f0_ppq3_st",
    # ltas_dur_s == ltas_n_frames / 50 exactly.
    "ltas_n_frames",
}
DROP_SUFFIX = (
    # `band_power` argmaxes the raw power spectrum, so the DC leakage skirt
    # wins and these read out 1/duration rather than a dominant modulation
    # frequency.  The bp_* band powers cover the same ground correctly.
    "_peak_freq",
    # Recording length is a task/protocol proxy.  The clinically meaningful
    # durations (maximum phonation time, sustained vowel) are already carried
    # by the static block's `duration` feature.
    "_dur_s",
)


def load_all() -> pd.DataFrame:
    frames = []
    for p in discover():
        d = pd.read_parquet(p).drop_duplicates(subset=KEY, keep="first")
        feats = [c for c in d.columns if c not in KEY]
        print(f"  {p.stem[4:]:10s} {len(d):6d} rows x {len(feats):4d} features")
        frames.append(d.set_index(KEY)[feats])
    if not frames:
        raise SystemExit("no dynamic feature tables found -- run the extractors first")
    out = pd.concat(frames, axis=1, join="outer")
    return out.loc[:, ~out.columns.duplicated()].reset_index()


def main():
    print("loading dynamic feature tables:")
    df = load_all()
    df["task_group"] = df["task_name"].map(C.task_group)

    # Digital-silence recordings: the LTAS floor of 10*log10(1e-10) = -100 dB.
    # Their features are arithmetic artefacts of an all-zero signal, and the
    # extractors' active-frame gate does not catch them, so null them here.
    if "ltas_level_db" in df.columns:
        silent = df["ltas_level_db"] <= -99.0
        n_silent = int(silent.sum())
        if n_silent:
            cols = [c for c in df.columns if c not in KEY + ["task_group"]]
            df.loc[silent, cols] = np.nan
            print(f"  nulled {n_silent} digital-silence recordings")

    # Working space grows with how long someone talked; give the models a
    # duration-normalised version before the raw duration columns are dropped.
    for a in ["td", "tb", "tt", "li", "ul", "ll"]:
        h, d = f"ema_{a}_hull_area", "ema_dur_s"
        if h in df.columns and d in df.columns:
            df[f"ema_{a}_hull_per_s"] = df[h] / df[d].replace(0, np.nan)
    if "ema_hull_area_mean" in df.columns and "ema_dur_s" in df.columns:
        df["ema_hull_mean_per_s"] = df["ema_hull_area_mean"] / df["ema_dur_s"].replace(0, np.nan)

    feats = [c for c in df.columns if c not in KEY + ["task_group"]]
    before = len(feats)
    feats = [f for f in feats if f not in DROP_EXACT and not f.endswith(DROP_SUFFIX)]
    print(f"  dropped {before - len(feats)} duplicate / duration-proxy / "
          f"broken-peak-frequency columns")
    # Columns that are all-NaN or constant carry nothing; drop them once here
    # rather than in every model fit.
    keep = [f for f in feats if df[f].notna().sum() > 200 and df[f].nunique(dropna=True) > 1]
    dropped = len(feats) - len(keep)
    print(f"\nrecordings: {len(df)}   features: {len(feats)} "
          f"({dropped} dropped as all-NaN/constant)   participants: {df.participant_id.nunique()}")
    feats = keep

    bt = df.groupby(["participant_id", "task_group"])[feats].mean()
    index = pd.Index(sorted(df.participant_id.unique()), name="participant_id")
    wide = bt.unstack("task_group")

    avg = wide.T.groupby(level=0).mean().T
    sdt = wide.T.groupby(level=0).std().T
    avg.columns = [f"davg_{c}" for c in avg.columns]
    sdt.columns = [f"dsdt_{c}" for c in sdt.columns]
    avg, sdt = avg.reindex(index), sdt.reindex(index)

    per_task = []
    present = set(wide.columns.get_level_values(1))
    for t in DYN_CORE_TASKS:
        if t in present:
            sub = wide.xs(t, axis=1, level=1)
            sub.columns = [f"dt_{t}_{c}" for c in sub.columns]
            per_task.append(sub.reindex(index))
    per_task = pd.concat(per_task, axis=1) if per_task else pd.DataFrame(index=index)

    # ---- cross-modality engineered contrasts ---------------------------
    eng = pd.DataFrame(index=index)
    nan = pd.Series(np.nan, index=index)

    def tcol(task, name):
        c = f"dt_{task}_{name}"
        return per_task[c] if c in per_task.columns else nan

    def speech(name):
        """Connected-speech reference for a feature, per modality coverage."""
        return tcol("free_speech" if name.startswith("prosody_") else SPEECH_REF, name)

    def acol(name):
        c = f"davg_{name}"
        return avg[c] if c in avg.columns else nan

    # 4-7 Hz is the classic vocal / parkinsonian tremor band.  Every modality
    # measures modulation in it independently, so their mean is a
    # cross-modality tremor index that no single contour gives on its own.
    TREMOR = ["prosody_f0trem_bp_m4_7", "prosody_ldmod_bp_m4_7", "ema_spd_bp_4_7",
              "ema_lipap_bp_4_7", "ppg_dyn_bp_4_7", "mfccdyn_dnormmod_bp_m4_7",
              "ltas_en_bp_4_7", "ltas_cn_bp_4_7"]
    have = [f"davg_{c}" for c in TREMOR if f"davg_{c}" in avg.columns]
    if have:
        z = (avg[have] - avg[have].mean()) / avg[have].std()
        eng["deng_tremor_index"] = z.mean(axis=1)
        eng["deng_tremor_max"] = z.max(axis=1)
        eng["deng_tremor_spread"] = z.std(axis=1)
    # Tremor confined to sustained phonation is laryngeal; tremor that also
    # rides the syllable rate of running speech is speech-motor.
    eng["deng_tremor_vowel_minus_speech"] = (
        tcol("prolonged_vowel", "prosody_f0trem_bp_m4_7")
        - speech("prosody_f0trem_bp_m4_7"))

    # Sustained vowel vs running speech, feature by feature.  A voice that is
    # steady on /a/ but degrades in connected speech implicates neuromotor
    # control rather than the vocal folds themselves.
    VOWEL_SPEECH = [
        ("prosody_f0_jit200_mean", "f0jit"), ("prosody_per_mean", "periodicity"),
        ("prosody_f0_st_std", "f0sd"), ("prosody_ld_db_std", "loudsd"),
        ("ppg_maxpost_mean", "phonconf"), ("ppg_entropy_mean", "phonentropy"),
        ("mfccdyn_dnorm_mean", "cepdelta"), ("mfccdyn_eig_entropy", "cepdiversity"),
        ("ema_spd_mean_all", "artspeed"), ("ema_hull_area_mean", "workspace"),
        ("ltas_flatness", "spectralflatness"), ("ltas_alpha_ratio", "alpharatio"),
        ("ltas_hf4k_prop", "hfnoise"), ("ltas_hammarberg", "hammarberg"),
    ]
    for feat, tag in VOWEL_SPEECH:
        v, s = tcol("prolonged_vowel", feat), speech(feat)
        eng[f"deng_{tag}_vowel_minus_speech"] = v - s
        eng[f"deng_{tag}_vowel_over_speech"] = v / s.replace(0, np.nan)

    # Diadochokinesis pushes the articulators to their rate limit.  Expressing
    # DDK performance relative to the same participant's running speech
    # normalises away habitual speaking style and isolates the rate ceiling.
    DDK_SPEECH = [
        ("ema_spd_mean_all", "artspeed"), ("ema_hull_area_mean", "workspace"),
        ("ema_stroke_rate_hz", "strokerate"), ("ema_stroke_pv_ratio", "stiffness"),
        ("ppg_trans_per_s", "phonrate"), ("ppg_maxpost_mean", "phonconf"),
        ("mfccdyn_dnorm_mean", "cepdelta"), ("prosody_ld_peak_rate", "peakrate"),
    ]
    for feat, tag in DDK_SPEECH:
        d, s = tcol("diadochokinesis", feat), speech(feat)
        eng[f"deng_{tag}_ddk_over_speech"] = d / s.replace(0, np.nan)
        eng[f"deng_{tag}_ddk_minus_speech"] = d - s

    # Reading is externally paced; spontaneous speech adds lexical retrieval
    # and planning.  Pause structure is where that cost shows up first.
    READ_SPONT = [("ppg_sil_run_mean_s", "silrun"), ("ppg_long_pause_frac", "longpause"),
                  ("ppg_trans_per_s", "phonrate"), ("prosody_pause_rate_per_s", "pauserate"),
                  ("prosody_pause_time_frac", "pausefrac"),
                  ("prosody_speech_run_mean_s", "speechrun")]
    for feat, tag in READ_SPONT:
        r = tcol(READ_REF, feat)
        sp = speech(feat)
        eng[f"deng_{tag}_read_minus_spont"] = r - sp

    # Syllabic-rhythm balance: how much of the speech envelope modulation sits
    # at the normal 4-7 Hz syllable rate versus below it.  Slowed, dysrhythmic
    # speech shifts mass downward.
    for mod, tag in [("prosody_ldmod", "loud"), ("ppg_dyn", "phon"),
                     ("mfccdyn_dnormmod", "cep"), ("ltas_en", "energy")]:
        lo = acol(f"{mod}_bp_m2_4") if f"davg_{mod}_bp_m2_4" in avg.columns \
            else acol(f"{mod}_bp_2_4")
        hi = acol(f"{mod}_bp_m4_7") if f"davg_{mod}_bp_m4_7" in avg.columns \
            else acol(f"{mod}_bp_4_7")
        eng[f"deng_rhythm_{tag}_hi_over_lo"] = hi / lo.replace(0, np.nan)

    # Maximum phonation time is where phonatory endurance fails: compare the
    # last quarter of the sustained task with its first.
    for feat, tag in [("prosody_ld_q4q1_db", "loudnessdecay"),
                      ("prosody_f0_q4q1_st", "pitchdecay"),
                      ("mfccdyn_e_q4q1_ratio", "energydecay")]:
        eng[f"deng_{tag}_mpt"] = tcol("maximum_phonation_time", feat)
        eng[f"deng_{tag}_vowel"] = tcol("prolonged_vowel", feat)

    out = pd.concat([avg, sdt, per_task, eng], axis=1)
    out = out.replace([np.inf, -np.inf], np.nan)
    out = out.loc[:, out.notna().sum() >= 100]
    out.to_parquet(C.DATA / "dynamic_participant.parquet")

    print(f"\ndynamic_participant: {out.shape[0]} participants x {out.shape[1]} features")
    print("  blocks:", {"davg": avg.shape[1], "dsdt": sdt.shape[1],
                        "dt": per_task.shape[1], "deng": eng.shape[1]})
    nf = out.isna().mean()
    print(f"  cols >50% NaN: {(nf > .5).sum()}   >20% NaN: {(nf > .2).sum()}")


if __name__ == "__main__":
    main()
