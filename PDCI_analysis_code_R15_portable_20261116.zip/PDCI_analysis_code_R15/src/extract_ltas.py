"""Long-term average spectrum (LTAS) features from the torchaudio mel spectrogram.

The LTAS is the standard clinical description of voice quality: breathiness and
glottal noise raise the high-frequency floor, while a steep spectral tilt and a
large low-vs-high peak difference (Hammarberg index) mark a weak, hypofunctional
or aperiodic source.  Everything here is computed from a single recording in
isolation -- no pooling across recordings, tasks or participants.

Input : features/torchaudio_mel_spectrogram-001.parquet, column
        `mel_spectrogram`, stored CHANNEL-MAJOR as (60 mel bins, T frames),
        power (not dB), 50 frames/s, 16 kHz audio, n_fft 400, n_mels 60.
Output: analysis/data/dyn_ltas.parquet -- one row per recording.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import DATA, PARQUET                      # noqa: E402
from parquet_stream import band_power, extract        # noqa: E402

NAME = "ltas"
P = f"{NAME}_"
FS = 50.0            # mel frame rate, Hz
N_MELS = 60
EPS = 1e-10

# ---------------------------------------------------------------- mel geometry
# torchaudio MelSpectrogram defaults: htk mel scale, f_min 0, f_max sr/2.
def _hz2mel(f: np.ndarray | float) -> np.ndarray:
    return 2595.0 * np.log10(1.0 + np.asarray(f, dtype=np.float64) / 700.0)


def _mel2hz(m: np.ndarray) -> np.ndarray:
    return 700.0 * (10.0 ** (np.asarray(m, dtype=np.float64) / 2595.0) - 1.0)


_pts = _mel2hz(np.linspace(_hz2mel(0.0), _hz2mel(8000.0), N_MELS + 2))
MEL_HZ = _pts[1:-1]                       # (60,) filter centre frequencies, Hz
MEL_KHZ = MEL_HZ / 1000.0
BIN_IDX = np.arange(N_MELS, dtype=np.float64)

LOW = slice(0, 20)                        # bins 0-19  ~ 30-900 Hz
HIGH = slice(40, 60)                      # bins 40-59 ~ 3.1-7.6 kHz
SUB1K = MEL_HZ < 1000.0                   # bins 0-20
HF4K = MEL_HZ >= 4000.0                   # bins 46-59
HF6K = MEL_HZ >= 6000.0                   # bins 54-59
N_BANDS = 10                              # 10 contiguous bands of 6 mel bins
BAND_SL = [slice(6 * i, 6 * i + 6) for i in range(N_BANDS)]

MOD_BANDS = {"2_4": (2.0, 4.0), "4_7": (4.0, 7.0), "7_12": (7.0, 12.0)}
ACTIVE_DROP_DB = 30.0                     # frames within 30 dB of the p95 frame

# ---------------------------------------------------------------- schema
FEATURES: list[str] = (
    [f"{P}band{i:02d}_rel_db" for i in range(N_BANDS)]
    + [f"{P}level_db", f"{P}shape_std_db", f"{P}shape_range_db"]
    + [f"{P}slope_bin", f"{P}slope_bin_r2", f"{P}tilt_db_per_khz",
       f"{P}slope_low", f"{P}slope_high", f"{P}alpha_ratio", f"{P}hammarberg"]
    + [f"{P}centroid_hz", f"{P}spread_hz", f"{P}skew", f"{P}kurt",
       f"{P}rolloff85_hz", f"{P}rolloff95_hz", f"{P}flatness", f"{P}entropy"]
    + [f"{P}hf4k_prop", f"{P}hf6k_prop"]
    + [f"{P}cent_t_mean", f"{P}cent_t_std", f"{P}cent_t_cv", f"{P}cent_t_iqr",
       f"{P}flux_db_mean", f"{P}flux_db_std", f"{P}flux_db_p95",
       f"{P}bin_cv_mean", f"{P}bin_cv_std", f"{P}bin_dbstd_mean",
       f"{P}snr_proxy_db", f"{P}energy_db_std", f"{P}energy_db_range"]
    + [f"{P}en_bp_{b}" for b in MOD_BANDS] + [f"{P}en_peak_freq", f"{P}en_spec_entropy"]
    + [f"{P}cn_bp_{b}" for b in MOD_BANDS] + [f"{P}cn_peak_freq", f"{P}cn_spec_entropy"]
    + [f"{P}act_frac", f"{P}act_level_db", f"{P}act_slope_bin", f"{P}act_alpha_ratio",
       f"{P}act_hammarberg", f"{P}act_centroid_hz", f"{P}act_flatness",
       f"{P}act_rolloff95_hz", f"{P}act_hf4k_prop"]
    + [f"{P}n_frames", f"{P}dur_s"]
)
NAN_ROW = {k: np.nan for k in FEATURES}


# ---------------------------------------------------------------- small helpers
def _slope(y: np.ndarray, x: np.ndarray) -> tuple[float, float]:
    """Least-squares slope of y on x plus R^2; NaN when degenerate."""
    if y.size < 3 or y.size != x.size:
        return np.nan, np.nan
    if not np.all(np.isfinite(y)):
        return np.nan, np.nan
    xc = x - x.mean()
    sxx = float((xc * xc).sum())
    if sxx <= 0:
        return np.nan, np.nan
    yc = y - y.mean()
    b = float((xc * yc).sum() / sxx)
    ss = float((yc * yc).sum())
    r2 = float(1.0 - ((yc - b * xc) ** 2).sum() / ss) if ss > 1e-12 else np.nan
    return b, r2


def _rolloff(p: np.ndarray, frac: float) -> float:
    """Frequency below which `frac` of the total power lies."""
    tot = float(p.sum())
    if not np.isfinite(tot) or tot <= 0:
        return np.nan
    c = np.cumsum(p) / tot
    return float(MEL_HZ[int(np.argmax(c >= frac))])


def _spec_block(p: np.ndarray, db: np.ndarray, pre: str, full: bool) -> dict:
    """Shape / tilt / moment descriptors of one time-averaged spectrum.

    `p`  -- mean power per mel bin (60,)
    `db` -- mean dB per mel bin (60,)
    `full` -- emit the complete block (False -> the compact active-frame block).
    """
    out: dict[str, float] = {}
    tot = float(p.sum())
    ok = np.isfinite(tot) and tot > 0 and np.all(np.isfinite(db))

    lvl = float(db.mean()) if np.all(np.isfinite(db)) else np.nan
    out[f"{pre}level_db"] = lvl
    sl, r2 = _slope(db, BIN_IDX)
    out[f"{pre}slope_bin"] = sl
    if full:
        out[f"{pre}slope_bin_r2"] = r2
        out[f"{pre}tilt_db_per_khz"] = _slope(db, MEL_KHZ)[0]
        out[f"{pre}slope_low"] = _slope(db[LOW], BIN_IDX[LOW])[0]
        out[f"{pre}slope_high"] = _slope(db[HIGH], BIN_IDX[HIGH])[0]
        if np.all(np.isfinite(db)):
            for i, sl_i in enumerate(BAND_SL):
                out[f"{pre}band{i:02d}_rel_db"] = float(db[sl_i].mean() - lvl)
            out[f"{pre}shape_std_db"] = float(db.std())
            out[f"{pre}shape_range_db"] = float(db.max() - db.min())

    # alpha-ratio style contrast: high-frequency power relative to low, in dB
    lo_p, hi_p = float(p[SUB1K].sum()), float(p[~SUB1K].sum())
    out[f"{pre}alpha_ratio"] = (10.0 * np.log10((hi_p + EPS) / (lo_p + EPS))
                                if ok else np.nan)
    out[f"{pre}hammarberg"] = (float(db[LOW].max() - db[HIGH].max())
                               if np.all(np.isfinite(db)) else np.nan)

    if ok:
        w = p / tot
        c = float((w * MEL_HZ).sum())
        var = float((w * (MEL_HZ - c) ** 2).sum())
        sd = float(np.sqrt(var)) if var > 0 else 0.0
        out[f"{pre}centroid_hz"] = c
        if full:
            out[f"{pre}spread_hz"] = sd
            if sd > 1e-6:
                out[f"{pre}skew"] = float((w * (MEL_HZ - c) ** 3).sum() / sd ** 3)
                out[f"{pre}kurt"] = float((w * (MEL_HZ - c) ** 4).sum() / sd ** 4 - 3.0)
            out[f"{pre}rolloff85_hz"] = _rolloff(p, 0.85)
            out[f"{pre}entropy"] = float(-(w * np.log(w + 1e-12)).sum() / np.log(w.size))
            out[f"{pre}hf6k_prop"] = float(p[HF6K].sum() / tot)
        out[f"{pre}rolloff95_hz"] = _rolloff(p, 0.95)
        out[f"{pre}hf4k_prop"] = float(p[HF4K].sum() / tot)
        # flatness: geometric / arithmetic mean of the power spectrum
        gm = float(np.exp(np.log(p + EPS).mean()))
        am = float(p.mean())
        out[f"{pre}flatness"] = gm / am if am > 0 else np.nan
    return out


def _to_time_major(v) -> np.ndarray:
    """Parquet list<list<float16>> -> (T, 60) float32 power matrix."""
    rows = list(v)
    if not rows:
        return np.zeros((0, N_MELS), dtype=np.float32)
    a = np.asarray([np.asarray(r, dtype=np.float32) for r in rows], dtype=np.float32)
    if a.ndim != 2:
        return np.zeros((0, N_MELS), dtype=np.float32)
    if a.shape[0] == N_MELS:          # stored channel-major (60, T)
        a = a.T
    if a.shape[1] != N_MELS:
        return np.zeros((0, N_MELS), dtype=np.float32)
    a = np.where(np.isfinite(a), a, 0.0)
    return np.clip(a, 0.0, None)


# ---------------------------------------------------------------- per recording
def summarise(rec: dict) -> dict:
    out = dict(NAN_ROW)
    try:
        A = _to_time_major(rec["value"])
    except Exception:
        return out
    T = A.shape[0]
    out[f"{P}n_frames"] = float(T)
    out[f"{P}dur_s"] = float(T) / FS
    if T < 2:
        return out

    D = 10.0 * np.log10(A + EPS)                     # (T, 60) dB
    ltas_db = D.mean(axis=0)                         # mean dB per bin
    p_mean = A.mean(axis=0)                          # mean power per bin
    try:
        out.update(_spec_block(p_mean, ltas_db, P, full=True))
    except Exception:
        pass

    # ---- temporal stability of the spectrum ------------------------------
    try:
        e = A.sum(axis=1)                            # per-frame total power
        e_db = 10.0 * np.log10(e + EPS)
        cent = np.full(T, np.nan)
        pos = e > 0
        if pos.any():
            cent[pos] = (A[pos] * MEL_HZ[None, :]).sum(axis=1) / e[pos]
        cv = cent[np.isfinite(cent)]
        if cv.size >= 3:
            m, s = float(cv.mean()), float(cv.std())
            out[f"{P}cent_t_mean"] = m
            out[f"{P}cent_t_std"] = s
            out[f"{P}cent_t_cv"] = s / m if m > 1e-9 else np.nan
            q = np.percentile(cv, [25, 75])
            out[f"{P}cent_t_iqr"] = float(q[1] - q[0])

        if T >= 3:
            flux = np.abs(np.diff(D, axis=0)).mean(axis=1)   # dB per frame step
            if flux.size >= 2:
                out[f"{P}flux_db_mean"] = float(flux.mean())
                out[f"{P}flux_db_std"] = float(flux.std())
                out[f"{P}flux_db_p95"] = float(np.percentile(flux, 95))

        bm = A.mean(axis=0)
        bs = A.std(axis=0)
        good = bm > 1e-9
        if good.sum() >= 3:
            bcv = bs[good] / bm[good]
            out[f"{P}bin_cv_mean"] = float(bcv.mean())
            out[f"{P}bin_cv_std"] = float(bcv.std())
        out[f"{P}bin_dbstd_mean"] = float(D.std(axis=0).mean())
        qb = np.percentile(D, [10, 90], axis=0)
        out[f"{P}snr_proxy_db"] = float((qb[1] - qb[0]).mean())

        if e_db.size >= 3:
            out[f"{P}energy_db_std"] = float(e_db.std())
            qe = np.percentile(e_db, [5, 95])
            out[f"{P}energy_db_range"] = float(qe[1] - qe[0])

        # ---- modulation of the energy and centroid contours ---------------
        out.update(band_power(e_db.astype(np.float64), FS, MOD_BANDS, f"{P}en"))
        if cv.size >= 3:
            cfill = np.where(np.isfinite(cent), cent, float(cv.mean()))
            out.update(band_power(cfill, FS, MOD_BANDS, f"{P}cn"))

        # ---- LTAS restricted to the acoustically active frames ------------
        thr = float(np.percentile(e_db, 95)) - ACTIVE_DROP_DB
        act = e_db >= thr
        out[f"{P}act_frac"] = float(act.mean())
        if int(act.sum()) >= 5:
            Aa = A[act]
            blk = _spec_block(Aa.mean(axis=0),
                              (10.0 * np.log10(Aa + EPS)).mean(axis=0),
                              f"{P}act_", full=False)
            out.update({k: v for k, v in blk.items() if k in NAN_ROW})
    except Exception:
        pass

    return {k: out.get(k, np.nan) for k in FEATURES}


# ---------------------------------------------------------------- driver
def main() -> None:
    limit = None
    if len(sys.argv) > 1 and sys.argv[1] != "full":
        limit = int(sys.argv[1])
    out_path = DATA / f"dyn_{NAME}.parquet"
    if limit is not None:
        out_path = Path(str(out_path).replace(".parquet", "_TEST.parquet"))
    print(f"declared features: {len(FEATURES)}")
    df = extract(PARQUET["mel"], "mel_spectrogram", summarise, out_path,
                 limit_groups=limit)
    import pandas as pd
    pd.set_option("display.width", 220, "display.max_columns", 200)
    print(df.head(3).T.to_string())
    nf = df[[c for c in df.columns if c.startswith(P)]].isna().mean()
    print("\nNaN fraction min/max:", float(nf.min()), float(nf.max()))
    print(nf.sort_values(ascending=False).head(12).to_string())


if __name__ == "__main__":
    main()
