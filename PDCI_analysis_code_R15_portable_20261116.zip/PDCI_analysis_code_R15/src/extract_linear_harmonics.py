"""Fine harmonic and modulation summaries from the linear spectrogram.

The source is a 201-bin one-sided 16-kHz spectrogram stored in dB at 50 Hz.
Every feature is computed within one recording; diagnoses and participant-level
statistics are never loaded.  Row-group parts make the 6.4-GB pass resumable.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from joblib import Parallel, delayed
from scipy.ndimage import uniform_filter1d

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
from parquet_stream import band_power  # noqa: E402

SOURCE = C.PARQUET["spectrogram"]
OUT = C.DATA / "dyn_linear_harmonics.parquet"
PARTS = C.DATA / "linear_harmonic_parts"
NEURO_OUT = C.DATA / "dyn_linear_harmonics_neuro.parquet"
NEURO_PARTS = C.DATA / "linear_harmonic_neuro_parts"
TEST_PARTS = C.DATA / "linear_harmonic_test_parts"
FS_FRAME = 50.0
STRIDE = 2
FS_CONTOUR = FS_FRAME / STRIDE
FS_AUDIO = 16000.0
NFFT = 400
N_BINS = 201
FREQ_HZ = np.arange(N_BINS, dtype=float) * FS_AUDIO / NFFT
FREQ_KHZ = FREQ_HZ / 1000.0
Q_LO = int(np.ceil(FS_AUDIO / 400.0))
Q_HI = min(NFFT // 2, int(np.floor(FS_AUDIO / 80.0)) + 1)
ACTIVE_DROP_DB = 30.0
SVD_FRAME_CAP = 256
MOD_BANDS = {"m0p2_1": (.2, 1.0), "m1_3": (1.0, 3.0),
             "m3_7": (3.0, 7.0), "m7_12": (7.0, 12.0)}
GENERAL_TASKS = {
    "prolonged_vowel", "maximum_phonation_time", "loudness", "glides",
    "free_speech", "diadochokinesis", "picture_description", "breathing",
    "cough_respiration", "story_recall", "rainbow_passage",
}
NEURO_TASKS = {
    "productive_vocabulary", "random_item_generation", "word_color_stroop",
    "cinderella_story",
}

CONTOURS = [
    "level_db", "centroid_hz", "tilt_db_khz", "alpha_db", "hf4k_db",
    "entropy", "flatness", "ripple_db", "cep_cpp", "cep_f0_hz",
    "cep_period2_ratio", "cep_octave_ratio", "spec_periodicity",
    "spec_period_hz",
]
STATS = ["mean", "std", "p10", "p50", "p90", "iqr"]
MOD_CONTOURS = ["level", "cpp", "logf0", "tilt", "periodicity"]
FEATURES = (
    ["lin_n_frames", "lin_dur_s", "lin_active_frac", "lin_f0_cv",
     "lin_cpp_f0_corr", "lin_low_mid_corr", "lin_low_high_corr",
     "lin_mid_high_corr", "lin_flux_mean", "lin_flux_std", "lin_flux_p90",
     "lin_tf_top1_frac", "lin_tf_top3_frac", "lin_tf_entropy",
     "lin_tf_effective_rank"]
    + [f"lin_{name}_{stat}" for name in CONTOURS for stat in STATS]
    + [f"lin_mod_{name}_{suffix}" for name in MOD_CONTOURS
       for suffix in [*(f"bp_{b}" for b in MOD_BANDS),
                      "peak_freq", "spec_entropy"]]
)


def _time_major(value) -> np.ndarray:
    rows = list(value)
    if not rows:
        return np.zeros((0, N_BINS), dtype=np.float32)
    a = np.asarray([np.asarray(r, dtype=np.float32) for r in rows],
                   dtype=np.float32)
    if a.ndim != 2:
        return np.zeros((0, N_BINS), dtype=np.float32)
    if a.shape[0] == N_BINS:
        a = a.T
    if a.shape[1] != N_BINS:
        return np.zeros((0, N_BINS), dtype=np.float32)
    return np.where(np.isfinite(a), a, np.nan).astype(np.float32, copy=False)


def _summary(x: np.ndarray) -> dict[str, float]:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 3:
        return {s: np.nan for s in STATS}
    q = np.percentile(x, [10, 25, 50, 75, 90])
    return {"mean": float(x.mean()), "std": float(x.std()),
            "p10": float(q[0]), "p50": float(q[2]), "p90": float(q[4]),
            "iqr": float(q[3] - q[1])}


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    ok = np.isfinite(a) & np.isfinite(b)
    if int(ok.sum()) < 4 or np.std(a[ok]) < 1e-10 or np.std(b[ok]) < 1e-10:
        return np.nan
    return float(np.corrcoef(a[ok], b[ok])[0, 1])


def _fill_active(x: np.ndarray, active: np.ndarray) -> np.ndarray | None:
    ok = active & np.isfinite(x)
    if int(ok.sum()) < max(5, int(FS_CONTOUR)):
        return None
    t = np.arange(x.size)
    return np.interp(t, t[ok], x[ok]).astype(float)


def _log_band_power(d: np.ndarray, mask: np.ndarray) -> np.ndarray:
    z = d[:, mask]
    mx = np.max(z, axis=1)
    return mx + 10.0 * np.log10(
        np.maximum(np.exp2((z - mx[:, None]) / (10.0 * np.log10(2.0))).sum(axis=1),
                   1e-30))


def summarise(value) -> dict[str, float]:
    out = {name: np.nan for name in FEATURES}
    d0 = _time_major(value)
    t0 = d0.shape[0]
    out["lin_n_frames"] = float(t0)
    out["lin_dur_s"] = float(t0 / FS_FRAME)
    if t0 < 10 or not np.isfinite(d0).all():
        return out

    # A fixed stride retains a uniform 25-Hz contour and a 12.5-Hz Nyquist.
    d = d0[::STRIDE].astype(np.float64)
    t = d.shape[0]
    level = _log_band_power(d, np.ones(N_BINS, dtype=bool))
    active = level >= np.percentile(level, 95) - ACTIVE_DROP_DB
    out["lin_active_frac"] = float(active.mean())
    if int(active.sum()) < 5:
        return out

    # Per-frame normalized power shape.
    mx = d.max(axis=1)
    power = np.power(10.0, (d - mx[:, None]) / 10.0)
    power /= np.maximum(power.sum(axis=1, keepdims=True), 1e-30)
    centroid = (power * FREQ_HZ[None, :]).sum(axis=1)
    entropy = -(power * np.log(power + 1e-30)).sum(axis=1) / np.log(N_BINS)
    flatness = np.exp(np.log(power + 1e-30).mean(axis=1)) / np.maximum(
        power.mean(axis=1), 1e-30)
    lo = FREQ_HZ < 1000.0
    hf = FREQ_HZ >= 4000.0
    alpha = 10.0 * np.log10((power[:, ~lo].sum(axis=1) + 1e-30) /
                             (power[:, lo].sum(axis=1) + 1e-30))
    hf4 = 10.0 * np.log10((power[:, hf].sum(axis=1) + 1e-30) /
                           (power[:, ~hf].sum(axis=1) + 1e-30))

    tilt_mask = (FREQ_HZ >= 80.0) & (FREQ_HZ <= 4000.0)
    tx = FREQ_KHZ[tilt_mask]
    tx = tx - tx.mean()
    tilt = ((d[:, tilt_mask] - d[:, tilt_mask].mean(axis=1, keepdims=True)) @ tx /
            np.sum(tx * tx))
    smooth = uniform_filter1d(d, size=9, axis=1, mode="nearest")
    residual = d - smooth
    ripple = residual[:, 1:].std(axis=1)

    # The real cepstrum resolves 80-400 Hz periods from the fine spectrum.
    cep = np.fft.irfft(d, n=NFFT, axis=1)
    qpart = cep[:, Q_LO:Q_HI]
    qbase = np.median(qpart, axis=1)
    qrel = np.argmax(qpart, axis=1)
    qpeak = qrel + Q_LO
    cpp = qpart[np.arange(t), qrel] - qbase
    f0 = FS_AUDIO / qpeak
    p2 = np.full(t, np.nan)
    octv = np.full(t, np.nan)
    q2 = qpeak * 2
    qh = np.rint(qpeak / 2).astype(int)
    ok2 = q2 < NFFT // 2
    p2[ok2] = (cep[np.arange(t)[ok2], q2[ok2]] - qbase[ok2]) / (
        np.abs(cpp[ok2]) + 1e-8)
    okh = qh >= Q_LO
    octv[okh] = (cep[np.arange(t)[okh], qh[okh]] - qbase[okh]) / (
        np.abs(cpp[okh]) + 1e-8)

    # Frequency-lag autocorrelation is a complementary harmonic-comb proxy.
    rr = residual[:, 1:101]
    rr -= rr.mean(axis=1, keepdims=True)
    den = np.mean(rr * rr, axis=1) + 1e-12
    ac = np.column_stack([
        np.mean(rr[:, :-lag] * rr[:, lag:], axis=1) / den
        for lag in range(2, 11)
    ])
    best_lag = np.argmax(ac, axis=1) + 2
    periodicity = ac[np.arange(t), best_lag - 2]
    spec_period_hz = best_lag * (FS_AUDIO / NFFT)

    contours = {
        "level_db": level, "centroid_hz": centroid,
        "tilt_db_khz": tilt, "alpha_db": alpha, "hf4k_db": hf4,
        "entropy": entropy, "flatness": flatness, "ripple_db": ripple,
        "cep_cpp": cpp, "cep_f0_hz": f0, "cep_period2_ratio": p2,
        "cep_octave_ratio": octv, "spec_periodicity": periodicity,
        "spec_period_hz": spec_period_hz,
    }
    for name, values in contours.items():
        stats = _summary(values[active])
        out.update({f"lin_{name}_{s}": v for s, v in stats.items()})

    fv = f0[active & np.isfinite(f0)]
    if fv.size >= 3 and abs(fv.mean()) > 1e-9:
        out["lin_f0_cv"] = float(fv.std() / abs(fv.mean()))
    out["lin_cpp_f0_corr"] = _corr(cpp[active], f0[active])

    low_db = _log_band_power(d, FREQ_HZ < 1000.0)
    mid_db = _log_band_power(d, (FREQ_HZ >= 1000.0) & (FREQ_HZ < 4000.0))
    high_db = _log_band_power(d, FREQ_HZ >= 4000.0)
    out["lin_low_mid_corr"] = _corr(low_db[active], mid_db[active])
    out["lin_low_high_corr"] = _corr(low_db[active], high_db[active])
    out["lin_mid_high_corr"] = _corr(mid_db[active], high_db[active])

    if t >= 3:
        shape = d - d.mean(axis=1, keepdims=True)
        flux = np.abs(np.diff(shape, axis=0)).mean(axis=1)
        out["lin_flux_mean"] = float(flux.mean())
        out["lin_flux_std"] = float(flux.std())
        out["lin_flux_p90"] = float(np.percentile(flux, 90))

    # Label-blind low-rank time-frequency concentration on active frames.
    ia = np.flatnonzero(active)
    if ia.size > SVD_FRAME_CAP:
        ia = ia[np.linspace(0, ia.size - 1, SVD_FRAME_CAP).round().astype(int)]
    z = d[ia] - d[ia].mean(axis=1, keepdims=True)
    edges = np.linspace(0, N_BINS, 41).round().astype(int)
    z = np.column_stack([z[:, edges[i]:edges[i + 1]].mean(axis=1)
                         for i in range(40)])
    z -= z.mean(axis=0, keepdims=True)
    try:
        sv = np.linalg.svd(z, compute_uv=False)
        ev = sv * sv
        frac = ev / max(ev.sum(), 1e-30)
        nz = frac[frac > 1e-15]
        ent = float(-(nz * np.log(nz)).sum())
        out["lin_tf_top1_frac"] = float(frac[0])
        out["lin_tf_top3_frac"] = float(frac[:3].sum())
        out["lin_tf_entropy"] = float(ent / np.log(max(2, len(frac))))
        out["lin_tf_effective_rank"] = float(np.exp(ent))
    except np.linalg.LinAlgError:
        pass

    mod_values = {"level": level, "cpp": cpp, "logf0": np.log(f0),
                  "tilt": tilt, "periodicity": periodicity}
    for name, values in mod_values.items():
        filled = _fill_active(values, active)
        if filled is None:
            continue
        bp = band_power(filled, FS_CONTOUR, MOD_BANDS, "x")
        for key, value in bp.items():
            suffix = key.removeprefix("x_")
            out[f"lin_mod_{name}_{suffix}"] = value
    return out


def run_group(group_id: int, part_dir: Path,
              allowed_tasks: set[str] = GENERAL_TASKS) -> dict:
    out_path = part_dir / f"group_{group_id:03d}.parquet"
    meta_path = part_dir / f"group_{group_id:03d}.json"
    if out_path.exists() and meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if meta.get("status") == "ok":
                return {**meta, "cached": True}
        except Exception:
            pass
    started = time.time()
    rows = []
    try:
        pf = pq.ParquetFile(SOURCE)
        columns = ["participant_id", "session_id", "task_name", "spectrogram", "n_frames"]
        batch_rows = int(os.environ.get("PDCI_PARQUET_BATCH_ROWS", "0"))
        batches = (pf.iter_batches(batch_size=batch_rows, row_groups=[group_id],
                                  columns=columns, use_threads=False) if batch_rows else
                   [pf.read_row_group(group_id, columns=columns, use_threads=False)])
        for batch in batches:
            frame = batch.to_pandas()
            for row in frame.itertuples(index=False):
                task = C.task_group(row.task_name)
                if task not in allowed_tasks:
                    continue
                rec = {"participant_id": row.participant_id,
                       "session_id": row.session_id,
                       "task_name": row.task_name, "task_group": task}
                rec.update(summarise(row.spectrogram))
                rows.append(rec)
            del frame
        frame = pd.DataFrame.from_records(rows)
        for col in FEATURES:
            frame[col] = pd.to_numeric(frame[col], errors="coerce").astype(np.float32)
        frame.to_parquet(out_path, index=False)
        rec = {"group": group_id, "status": "ok", "rows": len(frame),
               "seconds": round(time.time() - started, 2)}
    except Exception as exc:
        rec = {"group": group_id, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - started, 2)}
    meta_path.write_text(json.dumps(rec), encoding="utf-8")
    return rec


def combine(part_dir: Path, n_groups: int, output: Path) -> pd.DataFrame:
    files = [part_dir / f"group_{i:03d}.parquet" for i in range(n_groups)]
    missing = [str(p) for p in files if not p.exists()]
    if missing:
        raise RuntimeError(f"missing {len(missing)} part files")
    out = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    out = out.sort_values(["participant_id", "session_id", "task_name"])
    out.to_parquet(output, index=False)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["run", "audit"])
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--limit-groups", type=int)
    ap.add_argument("--task-set", choices=["general", "neuro"],
                    default="general")
    args = ap.parse_args()
    pf = pq.ParquetFile(SOURCE)
    n_groups = pf.num_row_groups
    if args.command == "audit":
        print(f"source={SOURCE.name} rows={pf.metadata.num_rows} groups={n_groups}")
        print(f"declared_features={len(FEATURES)} contour_fs={FS_CONTOUR}")
        return
    allowed_tasks = GENERAL_TASKS if args.task_set == "general" else NEURO_TASKS
    if args.limit_groups is not None:
        n_groups = min(n_groups, args.limit_groups)
        part_dir = TEST_PARTS
        output = C.DATA / "dyn_linear_harmonics_TEST.parquet"
    elif args.task_set == "neuro":
        part_dir = NEURO_PARTS
        output = NEURO_OUT
    else:
        part_dir = PARTS
        output = OUT
    part_dir.mkdir(parents=True, exist_ok=True)
    todo = [i for i in range(n_groups) if not (
        part_dir / f"group_{i:03d}.parquet").exists()]
    print(f"linear harmonics: {len(todo)}/{n_groups} groups pending", flush=True)
    for start in range(0, len(todo), args.jobs):
        batch = todo[start:start + args.jobs]
        ans = Parallel(n_jobs=args.jobs, prefer="threads")(
            delayed(run_group)(i, part_dir, allowed_tasks) for i in batch)
        for rec in ans:
            print(json.dumps(rec), flush=True)
    out = combine(part_dir, n_groups, output)
    f = out[FEATURES]
    print(f"wrote {output}: {out.shape}")
    print("nan_min_max", float(f.isna().mean().min()),
          float(f.isna().mean().max()))
    print(f.describe().loc[["mean", "std", "min", "max"]].T.to_string())


if __name__ == "__main__":
    main()
