"""Construct-partitioned ensemble for Parkinson's vs cognitive impairment.

Every earlier ensemble failed for the same reason: the base models all saw the
same feature pool, so they read the same ~20 effective dimensions, their errors
were correlated, and averaging removed almost no variance.

This one partitions the features by **what they measure** and gives each base
model a disjoint slice. Two models that only see pause structure and tremor
respectively cannot make the same mistake for the same reason, which is the
condition under which averaging actually helps.

The partition is **label-blind**: groups are defined by feature-name patterns
corresponding to standard motor-speech constructs from the dysarthria
literature, fixed before any model is fitted. The discriminant analysis
(`pdci_discriminants.py`) independently found these same constructs carry the
PD/CI difference, which is corroboration rather than selection -- but the
groups would be the same either way.

Combination rules, in increasing order of what they learn from labels:

    mean            plain average, learns nothing
    inner_weighted  weights from each base model's inner-fold AUC, computed
                    inside the outer training fold only
    stacked         logistic meta-learner on base probabilities, fitted on
                    inner out-of-fold predictions from the training fold only

All three are evaluated with the base models refitted inside every outer fold,
so nothing here is contaminated by the leaderboard.

Usage:  python src/pdci_informed_ensemble.py [--jobs 6] [--repeats 5]
"""
from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import Pipeline

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import diagnostics as D  # noqa: E402
import modeling  # noqa: E402
import pdci  # noqa: E402

warnings.filterwarnings("ignore")
OUT = C.RESULTS / "pdci" / "informed"
OUT.mkdir(parents=True, exist_ok=True)

# Label-blind partition by measured construct.  Patterns are matched against
# the feature name; a feature joins the first group it matches, so order
# encodes precedence and the slices stay disjoint.
CONSTRUCTS = [
    ("tremor",        ["trem", "_bp_m4_7", "_bp_4_7"]),
    ("pause_silence", ["pause", "sil_", "silrun", "longpause", "_ioi_"]),
    ("voicing_breaks", ["vcd_", "voiced", "unvoiced", "periodicity", "per_",
                        "breaks_per_s", "VoicedSegment", "UnvoicedSegment"]),
    ("phonatory_endurance", ["mpt", "q4q1", "phonation_ratio", "decay",
                             "maximum_phonation"]),
    ("articulatory_space", ["hull", "pca_ev", "pca_elong", "workspace",
                            "lipap", "tngh", "_range", "_iqr"]),
    ("articulator_motion", ["spd_", "_acc_", "jerk", "stroke", "vel_"]),
    ("cepstral_change",   ["mfcc", "dnorm", "ddnorm", "cep", "eig_", "drift"]),
    ("spectral_shape",    ["ltas", "tilt", "slope", "alpha", "hammarberg",
                           "spectral", "hf4k", "rolloff", "flatness",
                           "centroid", "flux"]),
    ("phonatory_quality", ["jitter", "shimmer", "hnr", "HNR", "apq", "ppq",
                           "logRelF0"]),
    ("phonetic_precision", ["maxpost", "entropy", "lowconf", "margin",
                            "dwell", "trans_per_s", "mass_", "rmass_",
                            "post_", "dframe"]),
    ("pitch_control",    ["f0", "F0", "semitone", "glide"]),
    ("loudness_control", ["loud", "ld_", "intensity", "dBp", "equivalentSound"]),
    ("rate_timing",      ["rate", "speaking", "articulation", "peakrate",
                          "sylrate", "duration", "dur_s"]),
    ("coupling",         ["xcoup", "coh_", "plv", "lag_ms", "xcorr", "_mi"]),
    ("nonlinear",        ["rqa", "dfa", "sampen", "permen", "higuchi", "katz",
                          "det", "lam", "trapping"]),
    ("coverage",         ["cov_"]),
]
MIN_FEATURES = 8
COVARIATES = ["age", "sex_male"]


def partition(cols):
    groups, taken = {}, set()
    for name, pats in CONSTRUCTS:
        sel = [c for c in cols
               if c not in taken and any(p in c for p in pats)]
        if len(sel) >= MIN_FEATURES:
            groups[name] = sel
            taken |= set(sel)
    rest = [c for c in cols if c not in taken and c not in COVARIATES]
    if len(rest) >= MIN_FEATURES:
        groups["other"] = rest
    return groups


def _fit(Xtr, ytr, Xte, seed=C.RANDOM_STATE, Cs=(0.003, 0.03, 0.3, 3.0)):
    """Small regularised logistic with C chosen on the training fold only."""
    best, best_auc = None, -1
    inner = StratifiedKFold(3, shuffle=True, random_state=seed)
    for c in Cs:
        oof = np.zeros(len(ytr))
        try:
            for itr, ite in inner.split(Xtr, ytr):
                m = LogisticRegression(C=c, max_iter=4000,
                                       class_weight="balanced",
                                       random_state=seed)
                m.fit(Xtr[itr], ytr.iloc[itr])
                oof[ite] = m.predict_proba(Xtr[ite])[:, 1]
            a = roc_auc_score(ytr, oof)
        except Exception:
            continue
        if a > best_auc:
            best_auc, best = a, c
    if best is None:
        return np.full(len(Xte), 0.5), 0.5
    m = LogisticRegression(C=best, max_iter=4000, class_weight="balanced",
                           random_state=seed)
    m.fit(Xtr, ytr)
    return m.predict_proba(Xte)[:, 1], best_auc


def run(space="acoustic_plus_tr_pm", n_splits=5, n_repeats=5,
        seed=C.RANDOM_STATE):
    X, y3, _ = pdci.build(space)
    m = np.isin(y3.values, [1, 2])
    X = X[m]
    y = pd.Series((y3.values[m] == 1).astype(int), index=X.index)  # 1 = PD
    groups = partition([c for c in X.columns if c not in COVARIATES])
    names = list(groups)
    print(f"{space}: n={len(y)} PD={int(y.sum())} CI={int((y==0).sum())} "
          f"features={X.shape[1]}")
    print(f"{len(names)} construct groups:")
    for n in names:
        print(f"    {n:22s} {len(groups[n]):5d} features")

    outer = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats,
                                    random_state=seed)
    base = {n: np.zeros(len(y)) for n in names}
    ens = {k: np.zeros(len(y)) for k in ["mean", "inner_weighted", "stacked"]}
    full = np.zeros(len(y))
    seen = np.zeros(len(y))
    inner_aucs = {n: [] for n in names}

    for tr, te in outer.split(X, y):
        prep_all = modeling.make_prep()
        prep_all.fit(X.iloc[tr])
        te_pred, w = {}, {}
        meta_tr = {}
        for n in names:
            cols = groups[n] + [c for c in COVARIATES if c in X.columns]
            p = modeling.make_prep()
            Xtr = p.fit_transform(X.iloc[tr][cols])
            Xte = p.transform(X.iloc[te][cols])
            pred, iauc = _fit(Xtr, y.iloc[tr], Xte, seed)
            te_pred[n] = pred
            w[n] = max(iauc - 0.5, 0.0)          # weight by inner-fold lift
            inner_aucs[n].append(iauc)
            base[n][te] += pred
            # inner OOF for the stacker, training fold only
            oof = np.zeros(len(tr))
            k3 = StratifiedKFold(3, shuffle=True, random_state=seed)
            for itr, ite in k3.split(Xtr, y.iloc[tr]):
                sub, _ = _fit(Xtr[itr], y.iloc[tr].iloc[itr], Xtr[ite], seed)
                oof[ite] = sub
            meta_tr[n] = oof

        P = np.column_stack([te_pred[n] for n in names])
        ens["mean"][te] += P.mean(axis=1)
        wv = np.array([w[n] for n in names])
        wv = wv / wv.sum() if wv.sum() > 0 else np.ones(len(names)) / len(names)
        ens["inner_weighted"][te] += P @ wv
        M = np.column_stack([meta_tr[n] for n in names])
        st = LogisticRegression(C=1.0, max_iter=3000, class_weight="balanced",
                                random_state=seed)
        st.fit(M, y.iloc[tr])
        ens["stacked"][te] += st.predict_proba(P)[:, 1]

        # reference: one model on the whole pool
        Xa = prep_all.transform(X.iloc[tr])
        Xb = prep_all.transform(X.iloc[te])
        fp, _ = _fit(Xa, y.iloc[tr], Xb, seed)
        full[te] += fp
        seen[te] += 1

    d = np.maximum(seen, 1)
    for k in base:
        base[k] /= d
    for k in ens:
        ens[k] /= d
    full /= d
    return y, base, ens, full, groups, inner_aucs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--space", type=str, default="acoustic_plus_tr_pm")
    ap.add_argument("--repeats", type=int, default=5)
    args = ap.parse_args()

    y, base, ens, full, groups, inner = run(args.space, 5, args.repeats)
    yv = y.values

    rows = []
    print(f"\n{'=' * 88}\nBASE MODELS (one construct each)\n{'=' * 88}")
    for n, p in sorted(base.items(), key=lambda kv: -roc_auc_score(yv, kv[1])):
        a = roc_auc_score(yv, p)
        rows.append({"model": f"base:{n}", "n_features": len(groups[n]),
                     "roc_auc": a})
        print(f"  {n:22s} {len(groups[n]):5d} feats  AUC={a:.3f}  "
              f"(inner mean {np.mean(inner[n]):.3f})")

    B = np.column_stack([base[n] for n in base])
    corr = np.corrcoef(B.T)
    off = corr[np.triu_indices_from(corr, 1)]
    print(f"\nbase-model prediction correlation: mean {off.mean():.3f}  "
          f"median {np.median(off):.3f}  max {off.max():.3f}")

    print(f"\n{'=' * 88}\nENSEMBLES vs the single full-pool model\n{'=' * 88}")
    a_full = roc_auc_score(yv, full)
    rows.append({"model": "single_full_pool", "n_features": sum(map(len, groups.values())),
                 "roc_auc": a_full})
    print(f"  {'single model on all features':32s} AUC={a_full:.3f}")
    for k, p in ens.items():
        a = roc_auc_score(yv, p)
        rows.append({"model": f"ensemble:{k}", "n_features": np.nan, "roc_auc": a})
        print(f"  {('construct ensemble, ' + k):32s} AUC={a:.3f}  "
              f"({a - a_full:+.3f} vs single)")

    df = pd.DataFrame(rows).sort_values("roc_auc", ascending=False)
    df.to_csv(OUT / "informed_ensemble.csv", index=False)
    np.savez(OUT / "informed_probs.npz", y=yv, full=full,
             **{f"base_{k}": v for k, v in base.items()},
             **{f"ens_{k}": v for k, v in ens.items()})

    best_name = max(ens, key=lambda k: roc_auc_score(yv, ens[k]))
    sw = D.binary_sweep(yv, ens[best_name], label=f"informed_{best_name}")
    sw.to_csv(OUT / "informed_threshold_sweep.csv", index=False)
    print(f"\nthreshold sweep for the best ensemble ({best_name}):")
    print(D.binary_confusions(yv, ens[best_name],
                              thresholds=[0.3, 0.4, 0.5, 0.6, 0.7],
                              label=f"PD vs CI  AUC={sw.roc_auc.iloc[0]:.3f} "
                                    f"PR-AUC={sw.pr_auc.iloc[0]:.3f}"))


if __name__ == "__main__":
    main()
