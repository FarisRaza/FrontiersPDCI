"""Nested PD/CI evaluation of fine linear-spectrogram harmonic features.

See ``results/pdci_linear_harmonics/PRESPECIFICATION.md``.  The innovative
block is diagnosis-blind.  All learned transforms and adaptive choices occur
inside participant-held-out outer folds.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_to_baseline as CB  # noqa: E402
import config as C  # noqa: E402
import extract_linear_harmonics as LH  # noqa: E402
import modeling  # noqa: E402
import pdci_exhaustive as E  # noqa: E402
import pdci_locked_moe_validation as M  # noqa: E402
import pdci_tasks as PT  # noqa: E402
import reporting as R  # noqa: E402

warnings.filterwarnings("ignore")

OUT = C.RESULTS / "pdci_linear_harmonics"
FOLDS = OUT / "folds"
OUT.mkdir(parents=True, exist_ok=True)
FOLDS.mkdir(parents=True, exist_ok=True)
SEED = C.RANDOM_STATE

FIXED_MODELS = [
    "anchor_pca100_lda",
    "harmonic_pca20_lda", "harmonic_pca50_lda",
    "fusion_pca100_lda", "fusion_pca150_lda",
    "block_pca75_25_lda", "block_pca100_25_lda",
    "block_pca100_25_ridge",
    "fusion_pls5_ridge", "fusion_pls10_ridge",
]
ADAPTIVE_POOL = FIXED_MODELS.copy()
MODELS = FIXED_MODELS + ["crossfit_stack", "adaptive_nested"]
SIMPLICITY = {name: i for i, name in enumerate([
    "anchor_pca100_lda", "harmonic_pca20_lda", "harmonic_pca50_lda",
    "block_pca75_25_lda", "block_pca100_25_lda",
    "block_pca100_25_ridge", "fusion_pca100_lda", "fusion_pca150_lda",
    "fusion_pls5_ridge", "fusion_pls10_ridge",
])}


def _aligned(est, x) -> np.ndarray:
    raw = est.predict_proba(x)
    p = np.zeros((len(x), 3), dtype=float)
    for j, cls in enumerate(est.classes_):
        p[:, int(cls)] = raw[:, j]
    return np.clip(p, 1e-7, 1 - 1e-7)


def _prep(a: pd.DataFrame, b: pd.DataFrame):
    prep = modeling.make_prep()
    return prep.fit_transform(a), prep.transform(b)


def _pca(a, b, k):
    kk = min(k, len(a) - 2, a.shape[1])
    est = PCA(n_components=kk, random_state=SEED)
    return est.fit_transform(a), est.transform(b)


def _lda(a, y, b):
    est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    est.fit(a, y)
    return _aligned(est, b)


def _ridge(a, y, b, c=.03):
    scaler = StandardScaler()
    za, zb = scaler.fit_transform(a), scaler.transform(b)
    est = LogisticRegression(C=c, penalty="l2", solver="lbfgs",
                             max_iter=5000, random_state=SEED)
    est.fit(za, y)
    return _aligned(est, zb)


@lru_cache(maxsize=1)
def harmonic_bytask() -> pd.DataFrame:
    d = pd.read_parquet(LH.OUT)
    cols = [c for c in LH.FEATURES if c not in {"lin_n_frames", "lin_dur_s"}]
    d = d[d.task_group.isin(PT.GENERAL_TASKS)].copy()
    d["participant_id"] = d.participant_id.astype(str)
    return d.groupby(["participant_id", "task_group"])[cols].mean()


def _task_geometry(bt: pd.DataFrame, ids: pd.Index, cols: list[str]) -> pd.DataFrame:
    pairs = [(i, j) for i in range(len(PT.GENERAL_TASKS))
             for j in range(i + 1, len(PT.GENERAL_TASKS))]
    names = [f"hgeom_corr__{PT.GENERAL_TASKS[i]}__{PT.GENERAL_TASKS[j]}"
             for i, j in pairs]
    names += ["hgeom_top1_frac", "hgeom_top3_frac", "hgeom_top5_frac",
              "hgeom_entropy", "hgeom_effective_rank"]
    rows = []
    for pid in ids.astype(str):
        a = bt.loc[pid].reindex(PT.GENERAL_TASKS)[cols].to_numpy(float)
        cm = np.nanmean(a, axis=0)
        cm = np.where(np.isfinite(cm), cm, 0.0)
        a = np.where(np.isfinite(a), a, cm[None, :])
        sd = a.std(axis=0)
        keep = sd > 1e-8
        if int(keep.sum()) < 3:
            rows.append([np.nan] * len(names))
            continue
        z = (a[:, keep] - a[:, keep].mean(axis=0)) / sd[keep]
        corr = np.corrcoef(z)
        values = [float(corr[i, j]) for i, j in pairs]
        try:
            sv = np.linalg.svd(z, compute_uv=False)
            ev = sv * sv
            frac = ev / max(ev.sum(), 1e-30)
            nz = frac[frac > 1e-15]
            ent = float(-(nz * np.log(nz)).sum())
            values += [float(frac[:k].sum()) for k in (1, 3, 5)]
            values += [float(ent / np.log(max(2, len(frac)))),
                       float(np.exp(ent))]
        except np.linalg.LinAlgError:
            values += [np.nan] * 5
        rows.append(values)
    return pd.DataFrame(rows, index=ids, columns=names, dtype=np.float32)


@lru_cache(maxsize=1)
def data():
    ids = PT.ids_for_design("general")
    ids = pd.Index(ids.astype(str), name="participant_id")
    y = PT.labels(ids, "multiclass").to_numpy(int)
    bt = harmonic_bytask()
    cols = list(bt.columns)
    full_index = pd.MultiIndex.from_product(
        [ids, PT.GENERAL_TASKS], names=["participant_id", "task_group"])
    bt = bt.reindex(full_index)

    wide = bt[cols].unstack("task_group")
    wide = wide.reindex(columns=pd.MultiIndex.from_product(
        [cols, PT.GENERAL_TASKS]))
    wide.columns = [f"h__{task}__{feat}" for feat, task in wide.columns]
    mean = bt[cols].groupby(level=0).mean()
    mean.columns = [f"hmean__{c}" for c in cols]
    sd = bt[cols].groupby(level=0).std(ddof=0)
    sd.columns = [f"hsd__{c}" for c in cols]

    task_sets = {
        "sustained_minus_connected": (
            ["prolonged_vowel", "maximum_phonation_time", "loudness", "glides"],
            ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "ddk_minus_connected": (["diadochokinesis"],
                                 ["free_speech", "picture_description",
                                  "story_recall", "rainbow_passage"]),
        "resp_minus_connected": (["breathing", "cough_respiration"],
                                  ["free_speech", "picture_description",
                                   "story_recall", "rainbow_passage"]),
        "read_minus_spontaneous": (["rainbow_passage"],
                                    ["free_speech", "picture_description",
                                     "story_recall"]),
    }
    contrasts = []
    for tag, (left, right) in task_sets.items():
        l = bt.loc[(slice(None), left), cols].groupby(level=0).mean()
        r = bt.loc[(slice(None), right), cols].groupby(level=0).mean()
        q = l.reindex(ids) - r.reindex(ids)
        q.columns = [f"hcontrast__{tag}__{c}" for c in cols]
        contrasts.append(q)
    geom = _task_geometry(bt, ids, cols)
    harmonic = pd.concat([wide.reindex(ids), mean.reindex(ids), sd.reindex(ids),
                          *contrasts, geom], axis=1).replace(
                              [np.inf, -np.inf], np.nan).astype(np.float32)
    # The privacy-preserving tensor source uniformly omits free speech.  Drop
    # only globally empty columns without consulting outcomes; partial
    # missingness remains fold-internally imputed by the model preprocessing.
    harmonic = harmonic.loc[:, ~harmonic.isna().all(axis=0)]

    # Split the exact locked input matrix after its dataset-wide, label-blind
    # >=50%-availability and nonconstant filters.  Calling task_individual
    # directly would retain hundreds of columns intentionally removed by
    # build_X and would no longer reproduce the reference model.
    locked = PT.build_X("general", "per_task_dynamic").reindex(ids)
    cov = PT.covariates(ids, "general").reindex(ids).astype(np.float32)
    base = locked.drop(columns=cov.columns).astype(np.float32)
    if not pd.concat([base, cov], axis=1).columns.equals(locked.columns):
        raise AssertionError("locked base/covariate column order changed")
    harmonic = harmonic.loc[:, harmonic.notna().mean(axis=0) >= .50]
    harmonic = harmonic.loc[:, harmonic.nunique(dropna=True) > 1]
    if not bool(PT.task_presence().loc[ids, PT.GENERAL_TASKS].all().all()):
        raise AssertionError("general-task presence is not constant")
    return ids, y, base.reindex(ids), harmonic.reindex(ids), cov.reindex(ids)


def fit_fixed(base_tr, harm_tr, cov_tr, ytr, base_te, harm_te, cov_te):
    pred = {}
    # Locked reference: identical concatenation and preprocessing as build_X.
    ab, bb = _prep(pd.concat([base_tr, cov_tr], axis=1),
                   pd.concat([base_te, cov_te], axis=1))
    zab, zbb = _pca(ab, bb, 100)
    pred["anchor_pca100_lda"] = _lda(zab, ytr, zbb)

    ah, bh = _prep(pd.concat([harm_tr, cov_tr], axis=1),
                   pd.concat([harm_te, cov_te], axis=1))
    zah, zbh = _pca(ah, bh, 50)
    pred["harmonic_pca20_lda"] = _lda(zah[:, :20], ytr, zbh[:, :20])
    pred["harmonic_pca50_lda"] = _lda(zah, ytr, zbh)

    af, bf = _prep(pd.concat([base_tr, harm_tr, cov_tr], axis=1),
                   pd.concat([base_te, harm_te, cov_te], axis=1))
    zaf, zbf = _pca(af, bf, 150)
    pred["fusion_pca100_lda"] = _lda(zaf[:, :100], ytr, zbf[:, :100])
    pred["fusion_pca150_lda"] = _lda(zaf, ytr, zbf)

    ax, bx = _prep(base_tr, base_te)
    ay, by = _prep(harm_tr, harm_te)
    ac, bc = _prep(cov_tr, cov_te)
    zax, zbx = _pca(ax, bx, 100)
    zay, zby = _pca(ay, by, 25)
    block75a = np.column_stack([zax[:, :75], zay, ac])
    block75b = np.column_stack([zbx[:, :75], zby, bc])
    block100a = np.column_stack([zax, zay, ac])
    block100b = np.column_stack([zbx, zby, bc])
    pred["block_pca75_25_lda"] = _lda(block75a, ytr, block75b)
    pred["block_pca100_25_lda"] = _lda(block100a, ytr, block100b)
    pred["block_pca100_25_ridge"] = _ridge(block100a, ytr, block100b)

    onehot = np.eye(3, dtype=float)[ytr]
    nk = min(10, len(af) - 2, af.shape[1])
    pls = PLSRegression(n_components=nk, scale=False, max_iter=500)
    pls.fit(af, onehot)
    paf, pbf = pls.transform(af), pls.transform(bf)
    k5 = min(5, paf.shape[1])
    pred["fusion_pls5_ridge"] = _ridge(paf[:, :k5], ytr, pbf[:, :k5])
    pred["fusion_pls10_ridge"] = _ridge(paf, ytr, pbf)
    return pred


def _choose(y, oof):
    case = y > 0
    scores = {}
    for name in ADAPTIVE_POOL:
        q = M.conditional(oof[name][case])
        scores[name] = float(roc_auc_score(y[case] == 1, q))
    top = max(scores.values())
    eligible = [n for n, score in scores.items() if score >= top - .01]
    chosen = min(eligible, key=lambda n: SIMPLICITY[n])
    return chosen, scores


def run_fold(oi, splits=5, repeats=3):
    path = FOLDS / f"r{oi // splits}_f{oi % splits}.parquet"
    meta = path.with_suffix(".json")
    if path.exists() and meta.exists():
        return json.loads(meta.read_text(encoding="utf-8"))
    started = time.time()
    try:
        ids, y, base, harm, cov = data()
        folds = list(RepeatedStratifiedKFold(
            n_splits=splits, n_repeats=repeats, random_state=SEED).split(
                np.zeros(len(y)), y))
        tr, te = folds[oi]
        full = fit_fixed(base.iloc[tr], harm.iloc[tr], cov.iloc[tr], y[tr],
                         base.iloc[te], harm.iloc[te], cov.iloc[te])

        inner = StratifiedKFold(n_splits=3, shuffle=True,
                               random_state=SEED + 1009 * oi)
        oof = {name: np.zeros((len(tr), 3), dtype=float)
               for name in FIXED_MODELS}
        for it, iv in inner.split(np.zeros(len(tr)), y[tr]):
            p = fit_fixed(base.iloc[tr[it]], harm.iloc[tr[it]], cov.iloc[tr[it]],
                          y[tr[it]], base.iloc[tr[iv]], harm.iloc[tr[iv]],
                          cov.iloc[tr[iv]])
            for name in FIXED_MODELS:
                oof[name][iv] = p[name]
        chosen, scores = _choose(y[tr], oof)
        full["adaptive_nested"] = full[chosen]

        # Stack coefficients see only inner held-out base probabilities.
        stack_x = np.column_stack([
            np.log(np.clip(oof["anchor_pca100_lda"], 1e-6, 1)),
            np.log(np.clip(oof["harmonic_pca50_lda"], 1e-6, 1)),
        ])
        stack_te = np.column_stack([
            np.log(np.clip(full["anchor_pca100_lda"], 1e-6, 1)),
            np.log(np.clip(full["harmonic_pca50_lda"], 1e-6, 1)),
        ])
        meta_est = LogisticRegression(C=.1, penalty="l2", solver="lbfgs",
                                      max_iter=5000, random_state=SEED + oi)
        meta_est.fit(stack_x, y[tr])
        full["crossfit_stack"] = _aligned(meta_est, stack_te)

        out = pd.DataFrame({"participant_id": ids[te].astype(str),
                            "y_true": y[te], "repeat": oi // splits,
                            "fold": oi % splits})
        for name in MODELS:
            for cls in range(3):
                out[f"{name}_p{cls}"] = full[name][:, cls].astype(np.float32)
        out.to_parquet(path, index=False)
        rec = {"job_id": path.stem, "status": "ok", "chosen": chosen,
               "inner_scores": scores,
               "seconds": round(time.time() - started, 2)}
    except Exception as exc:
        rec = {"job_id": path.stem, "status": "error",
               "error": f"{type(exc).__name__}: {exc}",
               "traceback": traceback.format_exc()[-5000:],
               "seconds": round(time.time() - started, 2)}
    meta.write_text(json.dumps(rec), encoding="utf-8")
    return rec


def aggregate():
    files = sorted(FOLDS.glob("r*_f*.parquet"))
    if len(files) != 15:
        raise RuntimeError(f"expected 15 folds, found {len(files)}")
    raw = pd.concat([pd.read_parquet(p) for p in files], ignore_index=True)
    pcols = [c for c in raw if c.endswith(("_p0", "_p1", "_p2"))]
    d = raw.groupby("participant_id").agg(
        {"y_true": "first", **{c: "mean" for c in pcols}})
    d.to_parquet(OUT / "oof_predictions.parquet")
    return raw, d


def _metrics(y, p):
    case = y > 0
    return {
        "pd_vs_ci_auc": roc_auc_score(y[case] == 1, M.conditional(p[case])),
        "three_class_macro_auc": roc_auc_score(
            y, p, multi_class="ovr", average="macro"),
        "neuro_auc": roc_auc_score(y > 0, p[:, 1:].sum(axis=1)),
        "pd_vs_all_auc": roc_auc_score(y == 1, p[:, 1]),
        "ci_vs_all_auc": roc_auc_score(y == 2, p[:, 2]),
    }


def report(bootstraps=5000):
    raw, d = aggregate()
    y = d.y_true.to_numpy(int)
    case = y > 0
    probs, rows = {}, []
    for name in MODELS:
        p = d[[f"{name}_p{i}" for i in range(3)]].to_numpy(float)
        probs[name] = p
        rows.append({"model": name, **_metrics(y, p)})
    metrics = pd.DataFrame(rows).sort_values("pd_vs_ci_auc", ascending=False)
    metrics.to_csv(OUT / "metrics.csv", index=False)

    ref = "anchor_pca100_lda"
    yy = y[case] == 1
    qref = M.conditional(probs[ref][case])
    comps = []
    for name in MODELS:
        if name == ref:
            continue
        q = M.conditional(probs[name][case])
        delta, p_delong = CB.delong_test(yy, q, qref)
        comps.append({"model": name, "reference": ref,
                      "delta_delong": delta, "p_delong": p_delong,
                      **CB.bootstrap_pair(yy, q, qref, n_boot=bootstraps)})
    comp = pd.DataFrame(comps)
    comp["fdr_q"] = E._bh(comp.p_delong)
    base_metrics = metrics.set_index("model").loc[ref]
    mm = metrics.set_index("model")
    comp["macro_loss"] = comp.model.map(
        lambda n: base_metrics.three_class_macro_auc -
        mm.loc[n].three_class_macro_auc)
    comp["neuro_loss"] = comp.model.map(
        lambda n: base_metrics.neuro_auc - mm.loc[n].neuro_auc)
    comp["qualifies"] = ((comp.delta_lo > 0) & (comp.fdr_q < .05) &
                         (comp.macro_loss <= .01) & (comp.neuro_loss <= .01))
    comp.to_csv(OUT / "comparisons.csv", index=False)

    meta = [json.loads(p.read_text(encoding="utf-8"))
            for p in sorted(FOLDS.glob("r*_f*.json"))]
    selected = pd.Series([r.get("chosen") for r in meta], name="count").value_counts()
    selected.rename_axis("model").reset_index().to_csv(
        OUT / "adaptive_selection_counts.csv", index=False)
    promoted = comp.loc[comp.qualifies, "model"].tolist()
    lines = [
        "# Fine linear-spectrogram harmonic PD/CI models", "",
        "All 750 participants completed the same 11 general tasks. The new "
        "harmonic block is computed within recordings without diagnoses; every "
        "learned transform and adaptive choice is outer-fold internal.", "",
        "## Held-out performance", "", R.markdown_table(metrics.round(4)), "",
        "## Paired comparisons with locked PCA-100/LDA", "",
        R.markdown_table(comp.round(4)), "", "## Adaptive selections", "",
        R.markdown_table(selected.rename_axis("model").reset_index()), "",
        "## Decision", "",
        ("Qualifying candidates: " + ", ".join(promoted)
         if promoted else "No candidate met the prespecified promotion rule."),
        "Even a qualifying result is internally selection-informed because this "
        "cohort informed earlier work; it requires new same-protocol external "
        "validation.", "",
    ]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(metrics.to_string(index=False))
    print(comp.to_string(index=False))
    print(selected.to_string())


def audit():
    ids, y, base, harm, cov = data()
    print(f"n={len(ids)} classes={dict(pd.Series(y).value_counts().sort_index())}")
    print(f"base={base.shape} harmonic={harm.shape} cov={cov.shape}")
    print("harmonic_nan", float(harm.isna().mean().min()),
          float(harm.isna().mean().max()))
    print("task_presence_columns", sum(
        "presence" in c or "complete" in c for c in harm.columns))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["audit", "run", "report"])
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--bootstraps", type=int, default=5000)
    args = ap.parse_args()
    if args.command == "audit":
        return audit()
    if args.command == "report":
        return report(args.bootstraps)
    data()
    total = args.splits * args.repeats
    todo = [i for i in range(total) if not (
        FOLDS / f"r{i // args.splits}_f{i % args.splits}.parquet").exists()]
    print(f"linear-harmonic models: {len(todo)}/{total} folds pending", flush=True)
    for start in range(0, len(todo), args.jobs):
        batch = todo[start:start + args.jobs]
        ans = Parallel(n_jobs=args.jobs, prefer="threads")(
            delayed(run_fold)(i, args.splits, args.repeats) for i in batch)
        for rec in ans:
            print(rec["job_id"], rec["status"], rec.get("chosen", ""),
                  rec.get("error", ""), rec.get("seconds", ""), flush=True)
    report(args.bootstraps)


if __name__ == "__main__":
    main()
