"""Threshold sweeps and confusion matrices for binary and multiclass models.

Every operating point a clinician might choose, laid out explicitly, because a
single AUC hides the trade-off that actually decides whether a screener is
usable: at what sensitivity, and at what cost in false positives.

Conventions:
  * AUPRC and ROC-AUC are threshold-free, so they are reported once per contrast
    and repeated down the table for convenience rather than recomputed.
  * `prevalence` is the positive rate in the evaluated sample; PR-AUC must
    always be read against it, since a rare-disease PR-AUC of 0.3 against a 5%
    base rate is a 6x lift, not a failure.
  * For multiclass, a threshold means *abstention*: predict the argmax only when
    its probability clears the threshold, otherwise decline to call. Coverage
    then falls as the threshold rises, and accuracy-on-covered is the number
    that matters alongside it.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, confusion_matrix,
                             roc_auc_score)

THRESHOLDS = np.round(np.arange(0.05, 1.0, 0.05), 2)


def binary_sweep(y, prob, thresholds=THRESHOLDS, label="") -> pd.DataFrame:
    """One row per threshold, with the full confusion matrix and every metric."""
    y = np.asarray(y).astype(int)
    prob = np.asarray(prob, dtype=float)
    n_pos, n_neg = int(y.sum()), int((y == 0).sum())
    auc = roc_auc_score(y, prob) if len(np.unique(y)) > 1 else np.nan
    ap = average_precision_score(y, prob) if len(np.unique(y)) > 1 else np.nan

    rows = []
    for t in thresholds:
        pred = (prob >= t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
        sens = tp / (tp + fn) if (tp + fn) else np.nan          # recall / TPR
        spec = tn / (tn + fp) if (tn + fp) else np.nan          # TNR
        prec = tp / (tp + fp) if (tp + fp) else np.nan          # PPV
        npv = tn / (tn + fn) if (tn + fn) else np.nan
        f1 = (2 * prec * sens / (prec + sens)
              if prec and sens and (prec + sens) > 0 else 0.0)
        bacc = np.nanmean([sens, spec])
        denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        mcc = ((tp * tn - fp * fn) / denom) if denom > 0 else 0.0
        rows.append({
            "contrast": label, "threshold": t,
            "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp),
            "accuracy": (tp + tn) / len(y),
            "balanced_accuracy": bacc,
            "precision_PPV": prec, "sensitivity_recall": sens,
            "specificity": spec, "NPV": npv, "f1": f1, "mcc": mcc,
            "predicted_positive_rate": pred.mean(),
            "roc_auc": auc, "pr_auc": ap, "prevalence": y.mean(),
            "n": len(y), "n_pos": n_pos, "n_neg": n_neg,
        })
    return pd.DataFrame(rows)


def best_operating_points(sweep: pd.DataFrame) -> pd.DataFrame:
    """The thresholds a reader will actually want to quote."""
    out = []
    d = sweep.dropna(subset=["sensitivity_recall", "specificity"])
    if not len(d):
        return pd.DataFrame()
    picks = {
        "max_balanced_accuracy": d.balanced_accuracy.idxmax(),
        "max_f1": d.f1.idxmax(),
        "max_mcc": d.mcc.idxmax(),
        "max_youden": (d.sensitivity_recall + d.specificity - 1).idxmax(),
    }
    # Screening-style operating points: fix sensitivity, read off the cost.
    for target in (0.80, 0.90, 0.95):
        ok = d[d.sensitivity_recall >= target]
        if len(ok):
            picks[f"sensitivity>={target:.2f}"] = ok.specificity.idxmax()
    for target in (0.90, 0.95):
        ok = d[d.specificity >= target]
        if len(ok):
            picks[f"specificity>={target:.2f}"] = ok.sensitivity_recall.idxmax()
    for name, idx in picks.items():
        r = d.loc[idx].to_dict()
        r["criterion"] = name
        out.append(r)
    cols = ["contrast", "criterion", "threshold", "TN", "FP", "FN", "TP",
            "accuracy", "balanced_accuracy", "precision_PPV",
            "sensitivity_recall", "specificity", "NPV", "f1", "mcc",
            "roc_auc", "pr_auc", "prevalence"]
    return pd.DataFrame(out)[cols]


def multiclass_sweep(y, proba, classes, thresholds=THRESHOLDS,
                     label="") -> tuple[pd.DataFrame, dict]:
    """Abstention sweep: call the argmax only when it clears the threshold.

    Returns a per-threshold summary and, keyed by threshold, the confusion
    matrix with an extra `abstain` column.
    """
    y = np.asarray(y)
    proba = np.asarray(proba, dtype=float)
    top = proba.max(axis=1)
    arg = np.asarray(classes)[proba.argmax(axis=1)]

    rows, mats = [], {}
    for t in thresholds:
        covered = top >= t
        pred = np.where(covered, arg, -1)
        cm = np.zeros((len(classes), len(classes) + 1), dtype=int)
        for i, c in enumerate(classes):
            m = y == c
            for j, cc in enumerate(classes):
                cm[i, j] = int(((pred == cc) & m).sum())
            cm[i, -1] = int(((pred == -1) & m).sum())
        mats[float(t)] = cm

        cov = covered.mean()
        acc_cov = ((pred == y) & covered).sum() / max(1, covered.sum())
        recalls, precs = [], []
        for c in classes:
            t_mask, p_mask = (y == c), (pred == c)
            recalls.append((t_mask & p_mask).sum() / max(1, t_mask.sum()))
            precs.append((t_mask & p_mask).sum() / max(1, p_mask.sum()))
        rows.append({
            "contrast": label, "threshold": t, "coverage": cov,
            "accuracy_on_covered": acc_cov,
            "accuracy_overall": ((pred == y).sum() / len(y)),
            "balanced_accuracy_on_covered": float(np.mean(recalls)),
            "macro_precision": float(np.mean(precs)),
            **{f"recall_{c}": r for c, r in zip(classes, recalls)},
            **{f"precision_{c}": p for c, p in zip(classes, precs)},
            **{f"abstain_{c}": int(mats[float(t)][i, -1])
               for i, c in enumerate(classes)},
        })
    return pd.DataFrame(rows), mats


def format_confusion(cm, classes, title="") -> str:
    names = [str(c)[:18] for c in classes]
    has_abstain = cm.shape[1] == len(classes) + 1
    head = names + (["abstain"] if has_abstain else [])
    w = max(12, max(len(h) for h in head) + 2)
    out = [title] if title else []
    out.append(" " * 20 + "".join(f"{h:>{w}s}" for h in head))
    for i, n in enumerate(names):
        out.append(f"  {n:<18s}" + "".join(f"{v:>{w}d}" for v in cm[i]))
    return "\n".join(out)


def binary_confusions(y, prob, thresholds=THRESHOLDS, label="") -> str:
    """Readable confusion matrices at every threshold."""
    y = np.asarray(y).astype(int)
    lines = [f"{label}  (n={len(y)}, positives={int(y.sum())})", ""]
    lines.append(f"{'thr':>5s} {'TN':>6s} {'FP':>6s} {'FN':>6s} {'TP':>6s}   "
                 f"{'sens':>6s} {'spec':>6s} {'PPV':>6s} {'NPV':>6s} {'F1':>6s}")
    for t in thresholds:
        pred = (np.asarray(prob) >= t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
        sens = tp / (tp + fn) if (tp + fn) else float("nan")
        spec = tn / (tn + fp) if (tn + fp) else float("nan")
        prec = tp / (tp + fp) if (tp + fp) else float("nan")
        npv = tn / (tn + fn) if (tn + fn) else float("nan")
        f1 = (2 * prec * sens / (prec + sens)
              if prec and sens and (prec + sens) > 0 else 0.0)
        lines.append(f"{t:5.2f} {tn:6d} {fp:6d} {fn:6d} {tp:6d}   "
                     f"{sens:6.3f} {spec:6.3f} {prec:6.3f} {npv:6.3f} {f1:6.3f}")
    return "\n".join(lines)
