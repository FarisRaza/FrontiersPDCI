"""Isolated, strictly fold-internal two-stage PD/cognitive-impairment study.

Run only with analysis/.venv/Scripts/python.exe. Prior results are read-only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
import traceback
import warnings
from pathlib import Path

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_name] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import joblib
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.feature_selection import f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (balanced_accuracy_score, confusion_matrix,
                             roc_auc_score)
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import pdci_tasks as PT
import pdci_linear_harmonics as H

OUT = C.RESULTS / "pdci_fully_nested_20260911"
LOCAL = OUT / "local_only"
FOLDS = LOCAL / "folds"
SEED = C.RANDOM_STATE
SPACES = ("mean", "mean_sd", "individual", "individual_mean_sd")
SCREEN = [dict(mode=m, target=t, k=k, c=c, weight=w)
          for m in ("base", "fusion") for t in ("onehot", "neuro")
          for k in (5, 10, 20) for c in (.003, .03)
          for w in ("empirical", "balanced")]
STAGE2 = []
for _space in SPACES:
    STAGE2 += [dict(space=_space, family="pca_lda", k=k, c=0.)
               for k in (5, 10, 20, 40, 75, 100)]
    STAGE2 += [dict(space=_space, family="pca_ridge", k=k, c=c)
               for k in (10, 40) for c in (.01, .1, 1.)]
    STAGE2 += [dict(space=_space, family="elastic", k=k, c=c)
               for k in (20, 60) for c in (.03, .3)]
    STAGE2 += [dict(space=_space, family=f, k=40, c=c)
               for f, cs in (("linear_svm", (.01, .1)), ("rbf_svm", (.1, 1.)))
               for c in cs]
SECONDARY = [dict(space="individual", family=f, k=k, c=c)
             for k in (20, 50, 75, 100)
             for f, c in (("pca_lda", 0.), ("pca_ridge", .1))]
BASELINES = [dict(c=c, weight=w) for c in (.01, .1, 1., 10.)
             for w in ("empirical", "balanced")]
NAMES = ("neither", "PD", "cognitive_impairment")
BASELINE_KEYS = {"agesex": "agesex", "cov": "agesexduration",
                 "covcountry": "agesexdurationcountry"}


def stamp():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def json_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False, default=str), encoding="utf-8")
    os.replace(temp, path)


def ident(spec):
    return "__".join(f"{key}-{value}" for key, value in spec.items())


class Prep:
    """Every data-derived rule is estimated on this fit's training rows only."""
    def fit_transform(self, x):
        x = np.asarray(x, dtype=float).copy()
        x[~np.isfinite(x)] = np.nan
        self.available = np.mean(np.isfinite(x), axis=0) >= .5
        z = x[:, self.available]
        self.lo, self.hi = np.nanquantile(z, [.005, .995], axis=0)
        same = self.hi <= self.lo
        self.lo[same], self.hi[same] = -np.inf, np.inf
        z = np.clip(z, self.lo, self.hi)
        self.med = np.nanmedian(z, axis=0)
        z = np.where(np.isfinite(z), z, self.med)
        self.mean, self.sd = z.mean(axis=0), z.std(axis=0)
        self.vary = self.sd > 1e-8
        if not self.vary.any():
            raise ValueError("no nonconstant training features")
        return ((z - self.mean)[:, self.vary] / self.sd[self.vary])

    def transform(self, x):
        z = np.asarray(x, dtype=float)[:, self.available]
        z = np.where(np.isfinite(z), z, np.nan)
        z = np.clip(z, self.lo, self.hi)
        z = np.where(np.isfinite(z), z, self.med)
        return (z - self.mean)[:, self.vary] / self.sd[self.vary]


def prep_pair(x, z):
    obj = Prep()
    return obj.fit_transform(x), obj.transform(z)


def p_aligned(est, x, nclasses):
    got = est.predict_proba(x)
    out = np.zeros((len(x), nclasses))
    for i, cls in enumerate(est.classes_):
        out[:, int(cls)] = got[:, i]
    return np.clip(out, 1e-8, 1 - 1e-8)


def conditional(p):
    return p[:, 1] / (p[:, 1] + p[:, 2])


def compose(s, q):
    s, q = np.clip(s, 1e-8, 1 - 1e-8), np.clip(q, 1e-8, 1 - 1e-8)
    return np.column_stack((1 - s, s * q, s * (1 - q)))


def ridge_prediction(a, y, b, c, weight="empirical", nclasses=2):
    scaler = StandardScaler()
    aa, bb = scaler.fit_transform(a), scaler.transform(b)
    est = LogisticRegression(C=c, penalty="l2", solver="lbfgs", max_iter=5000,
                             class_weight="balanced" if weight == "balanced" else None,
                             random_state=SEED)
    est.fit(aa, y)
    return p_aligned(est, bb, nclasses)


def stage2_bank(matrices, tr, te, ytrain, configs, nclasses=2):
    result = {}
    for space in sorted({c["space"] for c in configs}):
        selected = [c for c in configs if c["space"] == space]
        a, b = prep_pair(matrices[space][tr], matrices[space][te])
        dims = [c["k"] for c in selected if c["family"].startswith("pca")]
        if dims:
            # Fixed maximum also during selected-only refits: randomized PCA
            # approximation must not depend on which other heads are requested.
            max_k = min(100, len(a) - 2, a.shape[1])
            pca = PCA(n_components=max_k, svd_solver="randomized", iterated_power=4,
                      random_state=SEED)
            pa, pb = pca.fit_transform(a), pca.transform(b)
        if any(not c["family"].startswith("pca") for c in selected):
            scores = np.nan_to_num(f_classif(a, ytrain)[0], nan=-np.inf,
                                   posinf=np.finfo(float).max)
            ranking = np.argsort(-scores, kind="stable")
        for cfg in selected:
            if cfg["family"].startswith("pca"):
                k = min(cfg["k"], pa.shape[1])
                aa, bb = pa[:, :k], pb[:, :k]
            else:
                k = min(cfg["k"], a.shape[1], len(a) - 2)
                aa, bb = a[:, ranking[:k]], b[:, ranking[:k]]
            family = cfg["family"]
            if family == "pca_lda":
                est = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
                est.fit(aa, ytrain)
                p = p_aligned(est, bb, nclasses)
            elif family == "pca_ridge":
                p = ridge_prediction(aa, ytrain, bb, cfg["c"], nclasses=nclasses)
            else:
                if family == "elastic":
                    est = LogisticRegression(C=cfg["c"], penalty="elasticnet", l1_ratio=.5,
                                             solver="saga", max_iter=5000, tol=1e-4,
                                             random_state=SEED)
                else:
                    est = SVC(C=cfg["c"], kernel="linear" if family == "linear_svm" else "rbf",
                              gamma="scale", probability=True, cache_size=256,
                              random_state=SEED)
                est.fit(aa, ytrain)
                p = p_aligned(est, bb, nclasses)
            result[ident(cfg)] = conditional(p) if nclasses == 3 else p[:, 1]
    return result


def screen_bank(data, tr, te, configs):
    out = {}
    cov_a, cov_b = prep_pair(data["covcountry"][tr], data["covcountry"][te])
    base_a, base_b = prep_pair(data["base"][tr], data["base"][te])
    harm_a, harm_b = (None, None)
    if any(c["mode"] == "fusion" for c in configs):
        harm_a, harm_b = prep_pair(data["harm"][tr], data["harm"][te])
    for mode in sorted({c["mode"] for c in configs}):
        a = np.column_stack([base_a, cov_a] if mode == "base" else [base_a, harm_a, cov_a])
        b = np.column_stack([base_b, cov_b] if mode == "base" else [base_b, harm_b, cov_b])
        for target in sorted({c["target"] for c in configs if c["mode"] == mode}):
            yy = data["y"][tr]
            response = np.eye(3)[yy] if target == "onehot" else (yy > 0).astype(float)[:, None]
            # Always the declared maximum; candidate subset cannot change latent fitting.
            pls = PLSRegression(n_components=min(20, len(a) - 2, a.shape[1]),
                                scale=False, max_iter=500, tol=1e-6)
            pls.fit(a, response)
            pa, pb = pls.transform(a), pls.transform(b)
            for cfg in configs:
                if cfg["mode"] != mode or cfg["target"] != target:
                    continue
                k = min(cfg["k"], pa.shape[1])
                p = ridge_prediction(pa[:, :k], yy if target == "onehot" else (yy > 0).astype(int),
                                     pb[:, :k], cfg["c"], cfg["weight"],
                                     nclasses=3 if target == "onehot" else 2)
                out[ident(cfg)] = p[:, 1:].sum(axis=1)
    return out


def baseline_bank(x, tr, te, ytrain, configs):
    a, b = prep_pair(x[tr], x[te])
    return {ident(c): ridge_prediction(a, ytrain, b, c["c"], c["weight"])[:, 1]
            for c in configs}


def complexity(c):
    if "family" in c:
        families = {"pca_lda": 0, "pca_ridge": 1, "elastic": 2, "linear_svm": 3, "rbf_svm": 4}
        return (c["k"], SPACES.index(c["space"]), families[c["family"]], c["c"])
    if "mode" in c:
        return (c["k"], int(c["mode"] != "base"), int(c["target"] != "neuro"),
                c["c"], int(c["weight"] != "empirical"))
    return (c["c"], int(c["weight"] != "empirical"))


def choose(y, oof, configs, margin=.005):
    scores = {key: float(roc_auc_score(y, value)) for key, value in oof.items()}
    best = max(scores.values())
    eligible = [c for c in configs if scores[ident(c)] >= best - margin]
    picked = min(eligible, key=lambda c: (*complexity(c), ident(c)))
    return picked, scores


def threshold(y, p, target):
    # Largest threshold satisfying requested empirical training-OOF sensitivity.
    candidates = np.unique(np.r_[0., p, 1.])
    positive = p[np.asarray(y, dtype=bool)]
    good = [v for v in candidates if np.mean(positive >= v) >= target]
    return float(max(good))


def harmonic_raw(ids):
    bt = H.harmonic_bytask()
    cols = list(bt.columns)
    bt = bt.reindex(pd.MultiIndex.from_product([ids, PT.GENERAL_TASKS],
                                              names=["participant_id", "task_group"]))
    wide = bt.unstack("task_group").reindex(columns=pd.MultiIndex.from_product([cols, PT.GENERAL_TASKS]))
    wide.columns = [f"h__{task}__{feat}" for feat, task in wide.columns]
    mean, sd = bt.groupby(level=0).mean(), bt.groupby(level=0).std(ddof=0)
    mean.columns, sd.columns = [f"hmean__{c}" for c in cols], [f"hsd__{c}" for c in cols]
    task_sets = {
        "sustained_minus_connected": (["prolonged_vowel", "maximum_phonation_time", "loudness", "glides"],
                                      ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "ddk_minus_connected": (["diadochokinesis"], ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "resp_minus_connected": (["breathing", "cough_respiration"], ["free_speech", "picture_description", "story_recall", "rainbow_passage"]),
        "read_minus_spontaneous": (["rainbow_passage"], ["free_speech", "picture_description", "story_recall"]),
    }
    parts = [wide.reindex(ids), mean.reindex(ids), sd.reindex(ids)]
    for tag, (left, right) in task_sets.items():
        q = (bt.loc[(slice(None), left), cols].groupby(level=0).mean().reindex(ids)
             - bt.loc[(slice(None), right), cols].groupby(level=0).mean().reindex(ids))
        q.columns = [f"hcontrast__{tag}__{c}" for c in cols]
        parts.append(q)
    parts.append(H._task_geometry(bt, ids, cols))
    return pd.concat(parts, axis=1).replace([np.inf, -np.inf], np.nan).astype(np.float32)


PLAN = """# Fully nested PD/cognitive-impairment stagewise study

This new analysis was specified before viewing its new outer-fold outcomes. It uses
the existing 750-person complete-11-general-task cohort (598 neither, 90 Parkinson's
disease, 62 cognitive impairment); ALS and PD/cognitive-impairment overlap are
excluded. Neither means neither target, not healthy. Prior studies/results remain
unchanged. The same cohort informed earlier scientific choices: this is internal
validation of a newly declared algorithm, not independent external validation.

Before fitting, a source audit identified68 historical participant IDs with missing
literal demographic joins. Canonical matching (strip whitespace and left-zero-pad
to six characters) linked all750 uniquely to raw demographic records, recovered
67 ages,68 sexes and68 countries, and changed no previously observed values or
diagnosis labels. The new run uses corrected raw age/sex/country everywhere while
preserving historical acoustic IDs,750 physical people,598/90/62 labels and splits.
Age and sex retain4 and6 genuinely missing values, respectively, imputed within
training folds. Country has no missing values after this repair. Historical
processed files and model results are not rewritten.

## Primary algorithm and fixed comparison family

The exact original seed and stratified 5-fold x3-repeat participant partitions are
verified against every historical PLS outer-fold checkpoint. Both stages are now
freshly fitted. Stage 1 selects from 48 compact PLS/ridge configurations: dynamic
per-task versus dynamic-plus-harmonic fusion, binary neurologic versus three-class
one-hot PLS response, 5/10/20 latent components, ridge C=.003/.03, and empirical or
balanced weights. All acoustic configurations use age, sex, 14 log-duration
covariates and residence country (USA/Canada/unknown), with unknown represented
explicitly. Residence country is not recording site.
The harmonic summaries/contrasts/within-person geometry are diagnosis-blind fixed
transformations; no population-learned feature eligibility is applied upstream.

Dedicated stage 2 selects from 80 configurations, trained exclusively on true PD
and cognitive-impairment cases in each outer-training set. Four acoustic spaces
are per-task dynamics, cross-task means, means+sample SD, and per-task+mean+SD.
All include age, sex, 14 log-duration covariates and residence country eligible
for selection.
Per space: six PCA/auto-shrinkage LDA dimensions (5/10/20/40/75/100); PCA/ridge
(10/40 PCs, C=.01/.1/1); F-filtered elastic net (20/60 features, C=.03/.3,
l1_ratio=.5); F-filtered linear SVM (40 features, C=.01/.1); and F-filtered RBF
SVM (40 features, C=.1/1, gamma=scale). SVM probability calibration is fitted by
libsvm solely inside each estimator's training rows; inner/outer validation rows
are never supplied to calibration. No task-presence/missingness indicators enter.

Every availability (>=50%), winsorization (.5/99.5 percentiles), median imputation,
standardization, nonconstant filter, supervised F score, PCA and PLS projection,
classifier and candidate selection is refitted inside three-fold inner CV.
PCA/selected-feature dimensions are capped by training rows minus2 and available
width. Shared transforms within the same inner-training split avoid duplicate work
without crossing any split. The chosen candidate is refitted on all outer-training
rows appropriate to its stage and predicts every outer-test participant.
Candidate choice maximizes inner OOF AUROC; within .005, the fixed complexity
order favors fewer dimensions/features, simpler representations and model heads,
and stronger regularization. Full candidate definitions are in candidate_grid.json.

A secondary, predeclared all-three-class conditional discriminator uses per-task
dynamics and eight PCA/head configurations (20/50/75/100 PCs; auto-LDA or ridge
C=.1). It trains on all outer-training classes but selects only by conditional
PD-versus-cognitive-impairment inner AUROC, with the same strict preprocessing.
It is secondary regardless of its performance and does not replace the primary.

Matched stagewise age+sex, age+sex+duration and age+sex+duration+country baseline
systems tune ridge
C=.01/.1/1/10 and empirical/balanced weighting within the same three-fold inner
partitions. Their screens train on all training participants; their discriminators
train only on case participants. The richest baseline matches all covariates
and estimates the acoustic pipeline's increment over tuned-ridge covariates;
it does not isolate feature effects independently of the differing model
architectures. Comparisons with lower baselines also add covariate information.
No comparison against chance is used.

## Predictions, operating points, and inference

For each outer fold, s=P(neurologic) and q=P(PD|PD or cognitive impairment) give
three-class probabilities (1-s, s*q, s*(1-q)) BEFORE averaging repeats. Each person's
three held-out vectors are then averaged once for primary AUROCs. Stage 2 AUROC is
calculated among all152 actual cases, independent of the screening gate; its mean
q is used, not the ratio of separately averaged composed probabilities. End-to-end
macro AUROC is the unweighted mean of three one-versus-rest AUROCs on750 people.
Report repeat-level AUROCs and all15 fold metrics as stability descriptions.

Default calls use screen>=.5, then q>=.5 for PD. Two prespecified screening gates
target90% and95% sensitivity: choose the largest threshold meeting the target on
the selected screen's inner OOF predictions from that outer-training set only.
No outer test labels or other outer folds' OOF scores select thresholds. Stage2
threshold remains.5. Aggregate each person's three outer-held-out calls by majority
vote, with a three-way tie resolved neither, then PD, then cognitive impairment.
Publish each repeat's confusion matrix as well as the one-person-one-vote matrix;
do not treat2250 repeated records as independent observations.

Primary uncertainty is5000 class-stratified paired participant bootstrap resamples
of the already cross-fitted scores, giving AUROC and paired-difference percentile
95% intervals. These are conditional on fitted predictions and do not account for
retraining or development-history selection. Interval exclusion of zero is nominal,
not FDR-corrected. The declared nine baseline comparisons are three endpoints
(screen, case discriminator, three-class macro) x three baseline systems.
As a separately labeled sensitivity, paired fold AUROC differences use a
two-sided overlap-corrected repeated-CV t test: SE=sqrt((1/15+mean(test/train))*s2),
df14; Benjamini-Hochberg across exactly these nine tests. Its effect is mean fold
gain, not the pooled OOF gain. No secondary comparisons are promoted into that
family. This approximate correction and bootstrap answer different questions.

Old .9299 nested-screen and .8559 fixed-discriminator scores are contextual
references only; the new screen also corrects legacy population-derived acoustic
eligibility, repairs demographic joins, and adds residence country. A difference
from historical AUROCs therefore cannot be attributed solely to nesting. No favorable new outer result
changes specifications. All schemas,
source/input hashes, exact partitions, choices, inner scores, predictions and audit
records are retained. Publication exports contain aggregates, never participant IDs.
"""


def prepare():
    if (OUT / "FROZEN_SPEC.json").exists():
        raise RuntimeError("already frozen; use run to resume")
    OUT.mkdir(parents=True, exist_ok=True)
    LOCAL.mkdir(exist_ok=True)
    FOLDS.mkdir(exist_ok=True)
    ids = pd.Index(PT.ids_for_design("general").astype(str), name="participant_id")
    y = PT.labels(ids, "multiclass").to_numpy(int)
    assert np.bincount(y).tolist() == [598, 90, 62]
    canonical = ids.str.strip().str.zfill(6)
    assert canonical.nunique() == len(ids)
    demographic_path = C.ROOT / "phenotype/demographics/demographics.tsv"
    demographic = pd.read_csv(demographic_path,sep="\t",dtype=str).drop_duplicates("participant_id",keep="first").set_index("participant_id")
    literal_missing = int((~ids.isin(demographic.index)).sum())
    demographic.index = demographic.index.astype(str).str.strip().str.zfill(6)
    assert demographic.index.is_unique
    assert canonical.isin(demographic.index).all()
    demographic = demographic.reindex(canonical)
    demographic.index = ids
    corrected = pd.DataFrame({"age": pd.to_numeric(demographic.age,errors="coerce"),
        "sex_male": demographic.sex_at_birth.fillna(demographic.sex_assigned_at_birth).map({"Male":1.,"Female":0.}),
        "country_usa": demographic.country.map({"USA":1.,"Canada":0.})},index=ids)
    old_cov = PT.cohort().loc[ids,["age","sex_male","country_usa"]]
    repair = {}
    for column in corrected:
        both = old_cov[column].notna() & corrected[column].notna()
        assert np.allclose(old_cov.loc[both,column],corrected.loc[both,column])
        assert not (old_cov[column].notna() & corrected[column].isna()).any()
        repair[column] = dict(old_missing=int(old_cov[column].isna().sum()),
                              new_missing=int(corrected[column].isna().sum()),
                              recovered=int((old_cov[column].isna() & corrected[column].notna()).sum()),
                              observed_values_changed=0)
    assert literal_missing == 68
    assert [repair[c]["recovered"] for c in corrected] == [67,68,68]
    label_sources = []
    for target,stem,label in (("parkinsons_disease","parkinsons_disease",1),
                              ("cognitive_impairment","cognitive_impairment",2),
                              ("rare_amyotrophic_lateral_sclerosis","amyotrophic_lateral_sclerosis",-1)):
        path = C.ROOT / "phenotype/diagnosis" / f"{stem}.tsv"
        source_ids = pd.read_csv(path,sep="\t",dtype=str).participant_id.str.strip().str.zfill(6)
        membership = canonical.isin(source_ids)
        assert np.array_equal(membership,PT.cohort().loc[ids,target].eq(1).to_numpy())
        assert np.array_equal(membership,y==label)
        label_sources.append(path)
    assert PT.task_presence().loc[ids, PT.GENERAL_TASKS].all().all()
    raw = pd.read_parquet(C.DATA / "dynamic_bytask.parquet")
    raw = raw[[c for c in raw if c not in {"prosody_f0_ppq3_st", "ltas_n_frames"}
               and not c.endswith("_dur_s")]].copy()
    raw.columns = [f"dy__{c}" for c in raw]
    raw = raw.reindex(pd.MultiIndex.from_product([ids, PT.GENERAL_TASKS], names=["participant_id", "task_group"]))
    individual = raw.unstack("task_group")
    individual.columns = [f"task__{task}__{feat}" for feat, task in individual]
    mean, sd = raw.groupby(level=0).mean().reindex(ids), raw.groupby(level=0).std().reindex(ids)
    mean.columns, sd.columns = [f"mean__{c}" for c in mean], [f"sd__{c}" for c in sd]
    individual = individual.reindex(ids)
    cov = PT.covariates(ids, "general").reindex(ids)
    # Replace both legacy demographic columns before any acoustic matrix is built.
    cov[["age","sex_male"]] = corrected[["age","sex_male"]]
    residence = corrected["country_usa"]
    assert set(residence.dropna().unique()).issubset({0.,1.})
    country = pd.DataFrame({"residence_country_USA": residence.fillna(0).astype(float),
                            "residence_country_unknown": residence.isna().astype(float)}, index=ids)
    covcountry = pd.concat([cov,country],axis=1)
    harm = harmonic_raw(ids).reindex(ids)
    spaces = {"mean": mean, "mean_sd": pd.concat([mean, sd], axis=1),
              "individual": individual,
              "individual_mean_sd": pd.concat([individual, mean, sd], axis=1)}
    matrices = {name: pd.concat([value, covcountry], axis=1).to_numpy(np.float32) for name, value in spaces.items()}
    splits = list(RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED).split(np.zeros(len(y)), y))
    protected = [Path(__file__), Path(C.__file__), Path(PT.__file__), Path(H.__file__),
                 C.DATA / "cohort.parquet", C.DATA / "static_bytask.parquet", C.DATA / "dynamic_bytask.parquet",
                 H.LH.OUT, demographic_path, *label_sources]
    fold_audit, manifest = [], []
    for oi, (tr, te) in enumerate(splits):
        # Release copy: regenerate the specified partitions directly. The original
        # study additionally checked historical exploratory fold files, not distributed.
        assert set(tr).isdisjoint(te)
        fold_audit.append(dict(outer_fold=oi, historical_fold_files_checked=False,
                               partition_source="specified RepeatedStratifiedKFold",
                               train_n=len(tr), test_n=len(te),
                               train_class_counts=np.bincount(y[tr], minlength=3).tolist(),
                               test_class_counts=np.bincount(y[te], minlength=3).tolist()))
        manifest.append(dict(outer_fold=oi, train=tr.tolist(), test=te.tolist()))
    payload = dict(ids=ids.to_numpy(str), y=y, matrices=matrices, base=individual.to_numpy(np.float32),
                   harm=harm.to_numpy(np.float32), cov=cov.to_numpy(np.float32), covcountry=covcountry.to_numpy(np.float32),
                   agesex=cov[["age", "sex_male"]].to_numpy(np.float32), splits=splits)
    joblib.dump(payload, LOCAL / "input_payload.joblib", compress=3)
    json_write(LOCAL / "split_manifest.json", dict(ids=ids.tolist(), splits=manifest))
    (OUT / "ANALYSIS_PLAN.md").write_text(PLAN, encoding="utf-8")
    json_write(OUT / "candidate_grid.json", dict(screen=SCREEN, stage2=STAGE2,
                                                  secondary_threeclass=SECONDARY, baselines=BASELINES))
    json_write(OUT / "INPUT_AUDIT.json", dict(status="PASS", n=750, class_counts=[598, 90, 62],
             general_tasks=PT.GENERAL_TASKS, raw_widths={k: int(v.shape[1]) for k,v in matrices.items()},
             screen_base_width=individual.shape[1], screen_harmonic_width=harm.shape[1], covariates=list(covcountry.columns),
             residence_country_by_class={NAMES[c]: {"USA":int((residence[y==c]==1).sum()),
                 "Canada":int((residence[y==c]==0).sum()), "unknown":int(residence[y==c].isna().sum())} for c in range(3)},
             canonical_demographic_join=dict(canonical_physical_people=750,literal_missing_rows=literal_missing,
                 unmatched_after_canonicalization=0,label_changes=0,covariates=repair),
             fold_checks=fold_audit, no_task_presence_features=True, all_raw_feature_columns_retained_before_folds=True))
    schemas = {k: list(v.columns) + list(covcountry.columns) for k,v in spaces.items()}
    schemas["screen_harmonic"] = list(harm.columns)
    json_write(OUT / "feature_schemas.json", schemas)
    protected += [OUT / "ANALYSIS_PLAN.md", OUT / "candidate_grid.json", OUT / "feature_schemas.json",
                  LOCAL / "input_payload.joblib", LOCAL / "split_manifest.json"]
    hashes = {str(p.resolve()): digest(p) for p in protected}
    json_write(OUT / "FROZEN_SPEC.json", dict(created_utc=stamp(), seed=SEED, source_sha256=digest(Path(__file__)),
                                              screen_candidates=len(SCREEN), stage2_candidates=len(STAGE2),
                                              secondary_candidates=len(SECONDARY), protected_sha256=hashes))
    print("PREPARED AND FROZEN", len(SCREEN), len(STAGE2), len(SECONDARY), flush=True)


def verify_frozen():
    spec = json.loads((OUT / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    wrong = [p for p, value in spec["protected_sha256"].items() if digest(Path(p)) != value]
    if wrong:
        raise RuntimeError(f"frozen source/input changed: {wrong}")
    return spec


def fit_fold(oi):
    checkpoint = FOLDS / f"fold_{oi:02d}.parquet"
    receipt = FOLDS / f"fold_{oi:02d}.json"
    if checkpoint.exists() and receipt.exists():
        saved = json.loads(receipt.read_text(encoding="utf-8"))
        assert digest(checkpoint) == saved["prediction_sha256"]
        return saved
    started = time.time()
    data = joblib.load(LOCAL / "input_payload.joblib")
    y, matrices = data["y"], data["matrices"]
    tr, te = data["splits"][oi]
    inner = list(StratifiedKFold(3, shuffle=True, random_state=SEED + oi*1009).split(np.zeros(len(tr)), y[tr]))
    banks = {"screen": {ident(c): np.zeros(len(tr)) for c in SCREEN},
             "stage2": {ident(c): np.full(len(tr), np.nan) for c in STAGE2},
             "secondary": {ident(c): np.zeros(len(tr)) for c in SECONDARY}}
    for baseline in BASELINE_KEYS:
        banks[f"{baseline}_screen"] = {ident(c): np.zeros(len(tr)) for c in BASELINES}
        banks[f"{baseline}_stage2"] = {ident(c): np.full(len(tr), np.nan) for c in BASELINES}
    trace = []
    with threadpool_limits(1), warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for inner_i, (it, iv) in enumerate(inner):
            train, valid = tr[it], tr[iv]
            case_train = train[y[train] > 0]
            case_valid_local = iv[y[valid] > 0]
            case_valid = tr[case_valid_local]
            got = screen_bank(data, train, valid, SCREEN)
            for name, value in got.items(): banks["screen"][name][iv] = value
            got = stage2_bank(matrices, case_train, case_valid, (y[case_train] == 1).astype(int), STAGE2)
            for name, value in got.items(): banks["stage2"][name][case_valid_local] = value
            got = stage2_bank(matrices, train, valid, y[train], SECONDARY, nclasses=3)
            for name, value in got.items(): banks["secondary"][name][iv] = value
            for baseline in BASELINE_KEYS:
                got = baseline_bank(data[baseline], train, valid, (y[train] > 0).astype(int), BASELINES)
                for name,value in got.items(): banks[f"{baseline}_screen"][name][iv] = value
                got = baseline_bank(data[baseline], case_train, case_valid, (y[case_train] == 1).astype(int), BASELINES)
                for name,value in got.items(): banks[f"{baseline}_stage2"][name][case_valid_local] = value
            trace.append(dict(inner_fold=inner_i, train_n=len(train), valid_n=len(valid),
                              train_cases=len(case_train), valid_cases=len(case_valid),
                              disjoint=bool(set(train).isdisjoint(valid) and set(train).isdisjoint(te))))
            print(f"fold{oi:02d} inner{inner_i} complete {time.time()-started:.1f}s", flush=True)
        case = y[tr] > 0
        choices, inner_scores, inner_selected = {}, {}, {}
        for name, bank in banks.items():
            cfgs = SCREEN if name == "screen" else STAGE2 if name == "stage2" else SECONDARY if name == "secondary" else BASELINES
            selection_case = (name == "stage2" or name == "secondary" or name.endswith("_stage2"))
            target = (y[tr][case] == 1).astype(int) if selection_case else (y[tr] > 0).astype(int)
            used = {k: v[case] for k,v in bank.items()} if selection_case else bank
            assert all(np.isfinite(v).all() for v in used.values())
            selected, scores = choose(target, used, cfgs)
            choices[name], inner_scores[name] = selected, scores
            inner_selected[name] = bank[ident(selected)]
        case_train = tr[y[tr] > 0]
        s = screen_bank(data, tr, te, [choices["screen"]])[ident(choices["screen"])]
        q = stage2_bank(matrices, case_train, te, (y[case_train] == 1).astype(int), [choices["stage2"]])[ident(choices["stage2"])]
        qs = stage2_bank(matrices, tr, te, y[tr], [choices["secondary"]], nclasses=3)[ident(choices["secondary"])]
        pred = pd.DataFrame(dict(participant_id=data["ids"][te], y_true=y[te], repeat=oi//5, fold=oi%5))
        scores_out = {"primary": (s,q), "secondary_threeclass": (s,qs)}
        for baseline in BASELINE_KEYS:
            bs = baseline_bank(data[baseline], tr, te, (y[tr] > 0).astype(int), [choices[f"{baseline}_screen"]])[ident(choices[f"{baseline}_screen"])]
            bq = baseline_bank(data[baseline], case_train, te, (y[case_train] == 1).astype(int), [choices[f"{baseline}_stage2"]])[ident(choices[f"{baseline}_stage2"])]
            scores_out[BASELINE_KEYS[baseline]] = (bs,bq)
        operating = {}
        for name,(ss,qq) in scores_out.items():
            pred[f"{name}_screen"], pred[f"{name}_q"] = ss, qq
            pp = compose(ss,qq)
            for cls in range(3): pred[f"{name}_p{cls}"] = pp[:,cls]
            key = "screen" if name in ("primary","secondary_threeclass") else next(k for k,v in BASELINE_KEYS.items() if v==name)+"_screen"
            thresholds = {"default": .5, "sens90": threshold(y[tr]>0,inner_selected[key],.90),
                          "sens95": threshold(y[tr]>0,inner_selected[key],.95)}
            operating[name] = thresholds
            for gate,tv in thresholds.items():
                pred[f"{name}_call_{gate}"] = np.where(ss < tv,0,np.where(qq >= .5,1,2))
        for name in scores_out:
            assert np.isfinite(pred[[f"{name}_p{i}" for i in range(3)]]).all().all()
            assert np.allclose(pred[[f"{name}_p{i}" for i in range(3)]].sum(axis=1),1)
        pred.to_parquet(checkpoint, index=False)
        inner_frame = pd.DataFrame(dict(participant_id=data["ids"][tr], y_true=y[tr], **inner_selected))
        inner_frame.to_parquet(FOLDS / f"fold_{oi:02d}_selected_inner.parquet", index=False)
        rec = dict(status="COMPLETE", outer_fold=oi, repeat=oi//5, fold=oi%5,
                   train_n=len(tr), test_n=len(te), train_cases=len(case_train),
                   test_cases=int((y[te]>0).sum()), inner_partition_audit=trace, choices=choices,
                   inner_scores=inner_scores, thresholds=operating,
                   warning_count=len(caught), warning_examples=sorted({str(w.message) for w in caught})[:15],
                   elapsed_seconds=round(time.time()-started,2), prediction_sha256=digest(checkpoint), completed_utc=stamp())
        json_write(receipt,rec)
    print(f"fold{oi:02d} COMPLETE {time.time()-started:.1f}s", flush=True)
    return rec


def metrics(y, s, q, p):
    case = y>0
    return dict(screen=roc_auc_score(case,s), stage2=roc_auc_score(y[case]==1,q[case]),
                macro=roc_auc_score(y,p,multi_class="ovr",average="macro"),
                pd_vs_all=roc_auc_score(y==1,p[:,1]), ci_vs_all=roc_auc_score(y==2,p[:,2]))


def weighted_auc_factory(y, p):
    order = np.argsort(p,kind="stable")
    sorted_p = p[order]
    starts = np.r_[0, np.flatnonzero(np.diff(sorted_p))+1]
    positive = np.asarray(y,dtype=bool)[order]
    def score(w):
        ww = w[order]
        pos = np.add.reduceat(ww*positive,starts)
        neg = np.add.reduceat(ww*(~positive),starts)
        return float(np.dot(pos,np.cumsum(neg)-.5*neg)/(pos.sum()*neg.sum()))
    return score


def bh(p):
    p=np.asarray(p,float); order=np.argsort(p); n=len(p)
    adjusted=np.minimum.accumulate((p[order]*n/np.arange(1,n+1))[::-1])[::-1]
    answer=np.empty(n); answer[order]=np.minimum(1,adjusted)
    return answer


def table(frame,digits=4):
    def text_cell(value):
        return f"{value:.{digits}f}" if isinstance(value,(float,np.floating)) else str(value)
    return "\n".join(["| "+" | ".join(frame.columns)+" |", "| "+" | ".join(["---"]*len(frame.columns))+" |"]+
                     ["| "+" | ".join(text_cell(v) for v in row)+" |" for row in frame.itertuples(index=False,name=None)])


def report():
    verify_frozen()
    payload=joblib.load(LOCAL/"input_payload.joblib")
    yall=payload["y"]
    chunks=[]; records=[]
    for oi in range(15):
        fp=FOLDS/f"fold_{oi:02d}.parquet"; rp=fp.with_suffix(".json")
        rec=json.loads(rp.read_text(encoding="utf-8")); assert rec["status"]=="COMPLETE"
        assert digest(fp)==rec["prediction_sha256"]
        d=pd.read_parquet(fp); tr,te=payload["splits"][oi]
        assert d.participant_id.tolist()==payload["ids"][te].tolist()
        assert d.y_true.tolist()==yall[te].tolist()
        assert all(row["disjoint"] for row in rec["inner_partition_audit"])
        for name,thresholds in rec["thresholds"].items():
            inner=pd.read_parquet(FOLDS/f"fold_{oi:02d}_selected_inner.parquet")
            key="screen" if name in ("primary","secondary_threeclass") else next(k for k,v in BASELINE_KEYS.items() if v==name)+"_screen"
            for gate,target in (("sens90",.9),("sens95",.95)):
                assert abs(threshold(inner.y_true.to_numpy()>0,inner[key].to_numpy(),target)-thresholds[gate])<1e-12
        records.append(rec); chunks.append(d)
    raw=pd.concat(chunks,ignore_index=True)
    assert len(raw)==2250 and raw.groupby("participant_id").size().eq(3).all()
    assert not raw.duplicated(["participant_id","repeat"]).any()
    models=("primary","agesex","agesexduration","agesexdurationcountry","secondary_threeclass")
    numeric=[c for c in raw if c.endswith(("_screen","_q","_p0","_p1","_p2"))]
    pooled=raw.groupby("participant_id").agg({"y_true":"first",**{c:"mean" for c in numeric}}).reindex(payload["ids"])
    pooled.to_parquet(LOCAL/"participant_oof_predictions.parquet")
    raw.to_parquet(LOCAL/"all_fold_predictions.parquet",index=False)
    yy=pooled.y_true.to_numpy(int)
    point={}; rows=[]; repeat_rows=[]; fold_rows=[]
    for name in models:
        point[name]=metrics(yy,pooled[f"{name}_screen"].to_numpy(),pooled[f"{name}_q"].to_numpy(),pooled[[f"{name}_p{i}" for i in range(3)]].to_numpy())
        rows.append(dict(model=name,n=750,n_PD=90,n_cognitive_impairment=62,**point[name]))
        for repeat,g in raw.groupby("repeat"):
            repeat_rows.append(dict(model=name,repeat=int(repeat),**metrics(g.y_true.to_numpy(),g[f"{name}_screen"].to_numpy(),g[f"{name}_q"].to_numpy(),g[[f"{name}_p{i}" for i in range(3)]].to_numpy())))
        for (repeat,fold),g in raw.groupby(["repeat","fold"]):
            fold_rows.append(dict(model=name,repeat=int(repeat),fold=int(fold),**metrics(g.y_true.to_numpy(),g[f"{name}_screen"].to_numpy(),g[f"{name}_q"].to_numpy(),g[[f"{name}_p{i}" for i in range(3)]].to_numpy())))
    metric_frame=pd.DataFrame(rows); repeat_frame=pd.DataFrame(repeat_rows); fold_frame=pd.DataFrame(fold_rows)
    metric_frame.to_csv(OUT/"pooled_oof_metrics.csv",index=False)
    repeat_frame.to_csv(OUT/"repeat_metrics.csv",index=False); fold_frame.to_csv(OUT/"fold_metrics.csv",index=False)
    # One paired, class-stratified participant draw is shared by every endpoint/model.
    score_funcs={}
    for name in models:
        score_funcs[(name,"screen")]=[weighted_auc_factory(yy>0,pooled[f"{name}_screen"].to_numpy())]
        case=yy>0
        basefun=weighted_auc_factory(yy[case]==1,pooled.loc[case,f"{name}_q"].to_numpy())
        score_funcs[(name,"stage2")]=[lambda w,f=basefun,mask=case: f(w[mask])]
        score_funcs[(name,"macro")]=[weighted_auc_factory(yy==cls,pooled[f"{name}_p{cls}"].to_numpy()) for cls in range(3)]
    boot={key:np.zeros(5000) for key in score_funcs}
    rng=np.random.default_rng(SEED+9911); classes=[np.flatnonzero(yy==cls) for cls in range(3)]
    for b in range(5000):
        w=np.zeros(len(yy))
        for ix in classes: w[ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)))
        for key,funcs in score_funcs.items(): boot[key][b]=np.mean([f(w) for f in funcs])
    intervals=[]; comparisons=[]
    for (name,endpoint),values in boot.items():
        lo,hi=np.quantile(values,[.025,.975])
        intervals.append(dict(model=name,endpoint=endpoint,auc=point[name][endpoint],ci_low=lo,ci_high=hi,n_boot=5000))
    for endpoint in ("screen","stage2","macro"):
        for base in BASELINE_KEYS.values():
            delta=boot[("primary",endpoint)]-boot[(base,endpoint)]
            lo,hi=np.quantile(delta,[.025,.975])
            a=fold_frame[fold_frame.model=="primary"].sort_values(["repeat","fold"])[endpoint].to_numpy()
            b=fold_frame[fold_frame.model==base].sort_values(["repeat","fold"])[endpoint].to_numpy()
            fold_delta=a-b
            ratios=[r["test_cases"]/r["train_cases"] if endpoint=="stage2" else r["test_n"]/r["train_n"] for r in records]
            se=math.sqrt((1/15+np.mean(ratios))*np.var(fold_delta,ddof=1))
            mean=float(np.mean(fold_delta)); p=float(2*student_t.sf(abs(mean/se),14)) if se>0 else (0. if mean else 1.)
            cvlo,cvhi=mean-student_t.ppf(.975,14)*se,mean+student_t.ppf(.975,14)*se
            comparisons.append(dict(candidate="primary",baseline=base,endpoint=endpoint,
                candidate_auc=point["primary"][endpoint],baseline_auc=point[base][endpoint],
                pooled_oof_gain=point["primary"][endpoint]-point[base][endpoint],bootstrap95_low=lo,bootstrap95_high=hi,
                nominal_bootstrap_positive=bool(lo>0),mean_fold_gain=mean,corrected_cv95_low=cvlo,corrected_cv95_high=cvhi,
                corrected_cv_p=p,corrected_cv_se=se,n_folds=15,n_boot=5000))
    comparison_frame=pd.DataFrame(comparisons)
    comparison_frame["corrected_cv_q_BH9"]=bh(comparison_frame.corrected_cv_p)
    comparison_frame.to_csv(OUT/"primary_baseline_comparisons.csv",index=False)
    interval_frame=pd.DataFrame(intervals); interval_frame.to_csv(OUT/"auc_intervals.csv",index=False)
    # Calls are generated using that participant's own outer-training threshold.
    cms=[]; ops=[]
    def append_calls(name,gate,scope,gy,pred):
        cm=confusion_matrix(gy,pred,labels=[0,1,2]); cases=gy>0; called=pred>0
        tp=int((called&cases).sum()); fp=int((called&~cases).sum()); tn=int((~called&~cases).sum()); fn=int((~called&cases).sum())
        ops.append(dict(model=name,gate=gate,scope=scope,n=len(gy),sensitivity=tp/(tp+fn),specificity=tn/(tn+fp),
                        ppv=tp/(tp+fp) if tp+fp else np.nan,npv=tn/(tn+fn) if tn+fn else np.nan,
                        balanced_accuracy=balanced_accuracy_score(gy,pred),PD_recall=cm[1,1]/cm[1].sum(),
                        cognitive_impairment_recall=cm[2,2]/cm[2].sum(),screen_positive=int(called.sum())))
        for true in range(3):
            for predicted in range(3): cms.append(dict(model=name,gate=gate,scope=scope,true_class=NAMES[true],predicted_class=NAMES[predicted],n=int(cm[true,predicted])))
    for name in models:
        for gate in ("default","sens90","sens95"):
            column=f"{name}_call_{gate}"
            calls=raw.pivot(index="participant_id",columns="repeat",values=column).reindex(pooled.index).to_numpy(int)
            counts=np.column_stack([(calls==cls).sum(axis=1) for cls in range(3)])
            append_calls(name,gate,"participant_majority",yy,np.argmax(counts,axis=1))
            for repeat,g in raw.groupby("repeat"): append_calls(name,gate,f"repeat_{repeat}",g.y_true.to_numpy(),g[column].to_numpy(int))
    pd.DataFrame(cms).to_csv(OUT/"confusion_matrices.csv",index=False)
    op_frame=pd.DataFrame(ops); op_frame.to_csv(OUT/"operating_points.csv",index=False)
    selected=[]
    for r in records:
        for procedure,cfg in r["choices"].items():
            selected.append(dict(repeat=r["repeat"],fold=r["fold"],procedure=procedure,candidate=ident(cfg),inner_auc=r["inner_scores"][procedure][ident(cfg)]))
    selected_frame=pd.DataFrame(selected); selected_frame.to_csv(OUT/"fold_selections.csv",index=False)
    selected_frame.groupby(["procedure","candidate"]).size().rename("fold_count").reset_index().to_csv(OUT/"selection_counts.csv",index=False)
    thresholds=[]
    for r in records:
        for name,values in r["thresholds"].items(): thresholds.append(dict(repeat=r["repeat"],fold=r["fold"],model=name,**values))
    pd.DataFrame(thresholds).to_csv(OUT/"training_only_thresholds.csv",index=False)
    # Numerical and provenance audit. Equal-score paired gain must be exactly zero.
    for name in models:
        for endpoint in ("screen","stage2","macro"):
            expected=point[name][endpoint]
            observed=np.mean([f(np.ones(len(yy))) for f in score_funcs[(name,endpoint)]])
            assert abs(expected-observed)<1e-12
    assert (np.bincount(yy)==[598,90,62]).all()
    verify_frozen()
    audit=dict(status="PASS",created_utc=stamp(),outer_folds=15,participants=750,cases=152,
               exact_historical_outer_membership=True,all_task_presence_constant=True,
               all_data_derived_preprocessing_inner_fitted=True,dedicated_stage2_case_training_only=True,
               primary_q_averaged_separately=True,composition_before_repeat_averaging=True,
               participant_bootstrap_draws=5000,all_thresholds_reconstructed_from_own_training_oof=True,
               weighted_auc_matches_sklearn=True,protected_source_inputs_unchanged=True,
               warning_count=sum(r["warning_count"] for r in records),
               total_fold_seconds=sum(r["elapsed_seconds"] for r in records))
    json_write(OUT/"AUDIT.json",audit)
    report_text=["# Fully nested PD/cognitive-impairment stagewise study", "",f"Completed {stamp()}. Audit PASS. 750 people:598 neither,90 PD,62 cognitive impairment.","",
        "Both stages were newly fit with strictly inner-fold preprocessing and configuration selection. Acoustic models included age, sex, duration and residence country. A verified canonical-ID demographic join repaired67 missing ages,68 sexes and68 countries without changing750 physical participants or diagnosis labels; country was complete afterward. Stage2 trained only on actual PD/cognitive-impairment cases and predicted every outer-test participant. The original15 outer partitions were matched exactly; the previous0.9299 screener was not substituted. This remains internal validation on a previously explored cohort; changes from historical scores also reflect demographic repair and added country, not solely nesting.","",
        "## Participant-level held-out performance", "",table(interval_frame),"",
        "## Nine paired primary comparisons", "",table(comparison_frame[["baseline","endpoint","candidate_auc","baseline_auc","pooled_oof_gain","bootstrap95_low","bootstrap95_high","mean_fold_gain","corrected_cv_p","corrected_cv_q_BH9"]]),"",
        "Bootstrap intervals are conditional5000-resample paired participant intervals, not retraining intervals or multiplicity-adjusted intervals. Corrected-CV q-values form a separate approximate repeated-CV sensitivity across nine comparisons; mean-fold and pooled-OOF gains are distinct estimands. The richest age+sex+duration+country baseline matches covariates, but its tuned-ridge model differs from the acoustic search architectures; the comparison is between predictive procedures, not an architecture-independent acoustic effect.","",
        "## Training-only screening gates; participant-majority calls", "",table(op_frame[(op_frame.model=="primary")&(op_frame.scope=="participant_majority")]),"",
        "Rows in confusion_matrices.csv are true classes; columns are predicted classes. Separate matrices and operating points are provided for each repeat. The90/95% labels specify training sensitivity targets, not guarantees of achieved test sensitivity. Every stage2 decision usedq>=.5. All publication-facing files are aggregate and contain no participant IDs; individual predictions and exact partitions are local_only.","",
        "## Repeat-level stability", "",table(repeat_frame),"",
        "The secondary_threeclass discriminator was prespecified, used only the individual dynamic representation, and selected eight PCA/head candidates on a conditional case objective while training all three classes. It is not substituted for the primary result. See ANALYSIS_PLAN.md, candidate_grid.json, fold_selections.csv, training_only_thresholds.csv and AUDIT.json for full specifications and provenance.",""]
    (OUT/"REPORT.md").write_text("\n".join(report_text),encoding="utf-8")
    outputs={str(p.relative_to(OUT)):digest(p) for p in OUT.glob("*") if p.is_file() and p.name not in {"COMPLETION.json","RUN_STATUS.json"}}
    json_write(OUT/"COMPLETION.json",dict(status="COMPLETE",completed_utc=stamp(),audit="PASS",outputs_sha256=outputs))
    print("FINALIZATION COMPLETE",flush=True)


def selftest():
    rng=np.random.default_rng(SEED)
    y=np.repeat([0,1,2],15); n=len(y)
    x=rng.normal(size=(n,125)); x[:5,0]=np.nan; x[:,1]=np.nan; x[:,2]=1
    data=dict(y=y,base=x,harm=x[:,:90],cov=x[:,:16],covcountry=x[:,:18],matrices={s:x for s in SPACES})
    tr=np.r_[0:10,15:25,30:40]; te=np.setdiff1d(np.arange(n),tr)
    with threadpool_limits(1),warnings.catch_warnings():
        warnings.simplefilter("ignore")
        got=screen_bank(data,tr,te,SCREEN); assert len(got)==48
        case=tr[y[tr]>0]
        got2=stage2_bank(data["matrices"],case,te,(y[case]==1).astype(int),STAGE2); assert len(got2)==80
        got3=stage2_bank(data["matrices"],tr,te,y[tr],SECONDARY,3); assert len(got3)==8
        assert all(np.isfinite(v).all() for v in [*got.values(),*got2.values(),*got3.values()])
        selected = [SCREEN[7]]
        alone = screen_bank(data,tr,te,selected)
        assert np.allclose(alone[ident(selected[0])],got[ident(selected[0])],rtol=0,atol=1e-12)
        # Training rank above100 verifies that requesting fewer candidates
        # cannot alter the shared randomized PCA basis.
        large=rng.normal(size=(180,125)); labels=np.repeat([0,1],90)
        ltr=np.r_[0:80,90:170]; lte=np.setdiff1d(np.arange(180),ltr)
        configs=[dict(space="mean",family="pca_ridge",k=10,c=.1),
                 dict(space="mean",family="pca_lda",k=100,c=0.)]
        bank=stage2_bank({"mean":large},ltr,lte,labels[ltr],configs)
        alone=stage2_bank({"mean":large},ltr,lte,labels[ltr],configs[:1])
        assert np.allclose(bank[ident(configs[0])],alone[ident(configs[0])],rtol=0,atol=1e-12)
        assert np.allclose(compose(np.array([.2,.8]),np.array([.3,.7])).sum(axis=1),1)
        p=np.round(rng.uniform(size=n),1); f=weighted_auc_factory(y==1,p)
        assert abs(f(np.ones(n))-roc_auc_score(y==1,p))<1e-12
        assert np.allclose(bh([.01,.02,.5]),[.03,.03,.5])
    print("SYNTHETIC SELFTEST PASS",flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=["selftest","prepare","run","report"])
    parser.add_argument("--jobs",type=int,default=2)
    args=parser.parse_args()
    if args.command=="selftest": return selftest()
    if args.command=="prepare": return prepare()
    if args.command=="report": return report()
    verify_frozen()
    import msvcrt
    run_lock = open(LOCAL / "RUN.lock", "a+b")
    if run_lock.tell() == 0:
        run_lock.write(b"0")
        run_lock.flush()
    run_lock.seek(0)
    try:
        msvcrt.locking(run_lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise RuntimeError("another worker already holds this analysis run lock")
    pending=[oi for oi in range(15) if not (FOLDS/f"fold_{oi:02d}.json").exists()]
    json_write(OUT/"RUN_STATUS.json",dict(status="RUNNING",started_utc=stamp(),pending=len(pending)))
    print(f"RUN {len(pending)} folds; workers={args.jobs}",flush=True)
    try:
        results=joblib.Parallel(n_jobs=args.jobs,backend="loky",verbose=10)(joblib.delayed(fit_fold)(oi) for oi in pending)
        report()
        json_write(OUT/"RUN_STATUS.json",dict(status="COMPLETE",completed_utc=stamp()))
    except Exception as exc:
        json_write(OUT/"RUN_STATUS.json",dict(status="FAILED",time_utc=stamp(),error=str(exc),traceback=traceback.format_exc()))
        raise
    finally:
        run_lock.seek(0)
        msvcrt.locking(run_lock.fileno(), msvcrt.LK_UNLCK, 1)
        run_lock.close()


if __name__=="__main__":
    main()
