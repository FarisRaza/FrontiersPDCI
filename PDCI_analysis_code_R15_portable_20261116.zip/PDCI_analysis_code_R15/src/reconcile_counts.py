"""Reconcile every reported n+ against the raw phenotype files.

Answers "why does this number differ from the count on the data portal?" by
walking the count down step by step:

    rows in the diagnosis TSV
      -> unique participant_ids            (some people have several sessions)
      -> of those, have usable audio        (833 of 905 participants do)
      -> meet the label definition          (screeners are scored, not assumed)
      -> in the modelling cohort            (single-category / vs-control subset)

Writes analysis/results/count_reconciliation.csv.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import datasets  # noqa: E402

REASON = {
    "membership": "listed in the module = diagnosed",
    "field": "listed AND the diagnosis field says Yes",
    "screener": "questionnaire SCORED to a cut-off (module was given to controls too)",
    "composite": "positive on any member disease",
}


def main():
    cohort = pd.read_parquet(C.DATA / "cohort.parquet")
    with_audio = set(cohort.index[cohort.n_recordings > 0])

    rows = []
    for name, spec in C.TARGETS.items():
        tsv = C.PHENO / "diagnosis" / f"{spec['file']}.tsv"
        raw = pd.read_csv(tsv, sep="\t", dtype=str)
        uniq = set(raw["participant_id"])

        lab = cohort[name]
        pos_all = set(lab.index[lab == 1])
        pos_audio = pos_all & with_audio

        r = {
            "target": name,
            "source_file": f"diagnosis/{spec['file']}.tsv",
            "rows_in_tsv": len(raw),
            "unique_participants": len(uniq),
            "unique_with_audio": len(uniq & with_audio),
            "label_positive": len(pos_all),
            "label_positive_with_audio": len(pos_audio),
            "n_plus_cohort_all": int((cohort.loc[sorted(with_audio), name] == 1).sum()),
            "label_rule": REASON[spec["kind"]],
            "excluded_as_unknown": int(lab.isna().sum()),
        }
        for ch in ["single_category", "vs_control"]:
            try:
                _, y, m = datasets.build(name, ch, "static_avg")
                r[f"n_plus_{ch}"] = m["n_pos"]
            except Exception:
                r[f"n_plus_{ch}"] = np.nan

        deltas = []
        if r["rows_in_tsv"] != r["unique_participants"]:
            deltas.append(f"{r['rows_in_tsv'] - r['unique_participants']} duplicate "
                          f"session rows collapsed to one per participant")
        if r["unique_participants"] != r["unique_with_audio"]:
            deltas.append(f"{r['unique_participants'] - r['unique_with_audio']} listed "
                          f"participants have no usable audio")
        if r["unique_with_audio"] != r["n_plus_cohort_all"]:
            d = r["unique_with_audio"] - r["n_plus_cohort_all"]
            if spec["kind"] == "screener":
                deltas.append(f"{d} were given the questionnaire but score BELOW the "
                              f"clinical cut-off, so they are not cases")
            elif spec["kind"] == "field":
                deltas.append(f"{d} are listed but the diagnosis field is not Yes")
            else:
                deltas.append(f"{d} otherwise excluded")
        r["why_it_differs"] = "; ".join(deltas) if deltas else "no change"
        rows.append(r)

    for name, members in C.CATEGORY_TARGETS.items():
        lab = cohort[name]
        rows.append({
            "target": name, "source_file": "composite of " + ", ".join(members),
            "rows_in_tsv": np.nan, "unique_participants": np.nan,
            "unique_with_audio": np.nan,
            "label_positive": int((lab == 1).sum()),
            "label_positive_with_audio": int(
                (cohort.loc[sorted(with_audio), name] == 1).sum()),
            "n_plus_cohort_all": int((cohort.loc[sorted(with_audio), name] == 1).sum()),
            "label_rule": REASON["composite"],
            "excluded_as_unknown": int(lab.isna().sum()),
            "n_plus_single_category": datasets.build(name, "single_category",
                                                     "static_avg")[2]["n_pos"],
            "n_plus_vs_control": datasets.build(name, "vs_control",
                                                "static_avg")[2]["n_pos"],
            "why_it_differs": "union of member diseases; a person counted once",
        })

    out = pd.DataFrame(rows)
    out.to_csv(C.RESULTS / "count_reconciliation.csv", index=False)

    print(f"participants enrolled: {len(cohort)}   with usable audio: {len(with_audio)}\n")
    show = out[out.source_file.str.startswith("diagnosis")]
    print(f"{'target':<32s}{'tsv':>5s}{'uniq':>6s}{'audio':>6s}{'n+':>5s}   rule")
    for _, r in show.iterrows():
        print(f"{r.target:<32s}{int(r.rows_in_tsv):5d}{int(r.unique_participants):6d}"
              f"{int(r.unique_with_audio):6d}{int(r.n_plus_cohort_all):5d}   {r.label_rule}")
    print("\nwhere the numbers move:")
    for _, r in out.iterrows():
        if r.why_it_differs not in ("no change",):
            print(f"  {r.target:<32s} {r.why_it_differs}")
    print(f"\nwrote {C.RESULTS / 'count_reconciliation.csv'}")


if __name__ == "__main__":
    main()
