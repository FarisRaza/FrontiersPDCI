"""Three-class model: Parkinson's vs cognitive impairment vs neither.

The problem decomposes into an easy half and a hard half, and conflating them
hides everything interesting:

  PD/CI vs neither   largely age.  Cases are 73-76 years old against a median
                     58 for everyone else and 38 for the disease-free controls.
  PD vs CI           genuinely acoustic.  Age alone gives only ROC-AUC 0.585
                     here, so this contrast is where voice has to do the work.

Every result therefore reports **macro one-vs-rest AUC** *and* the **PD-vs-CI
AUC computed inside the three-class model**, each against an age+sex baseline.
The second number is the one that matters.

Feature selection, hyperparameter search and any label-aware transform happen
strictly inside training folds.  The unsupervised prefix (winsorise, impute,
scale, variance filter) is fitted once per outer training fold, which never
sees y and never sees the test fold.

Usage:
    python src/pdci.py screen  [--jobs 8]
    python src/pdci.py stack   [--jobs 6]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.base import clone
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import (ExtraTreesClassifier, GradientBoostingClassifier,
                              RandomForestClassifier)
from sklearn.feature_selection import (RFE, SelectFromModel, SelectKBest,
                                       f_classif, mutual_info_classif)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, roc_auc_score
from sklearn.model_selection import (GridSearchCV, RepeatedStratifiedKFold,
                                     StratifiedKFold, cross_val_predict)
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C  # noqa: E402
import datasets  # noqa: E402
import modeling  # noqa: E402

warnings.filterwarnings("ignore")

CLASSES = ["neither", "parkinsons", "cognitive"]
OUT = C.RESULTS / "pdci"
OUT.mkdir(parents=True, exist_ok=True)
PRED = OUT / "oof"
PRED.mkdir(parents=True, exist_ok=True)

COVARIATES = ["age", "sex_male"]

# Recording length correlates with the new coupling features up to |rho| = 0.62,
# so a time-resolved model has to beat age + sex + duration, not just age + sex.
DURATION_COLS = ["avg_duration", "qc_total_duration"]

FEATURE_SPACES = {
    "demographics": [],
    "demographics_duration": ["__DURATION__"],
    "static": ["avg_", "sdt_", "t_", "eng_"],
    "dynamic": ["davg_", "dsdt_", "dt_", "deng_"],
    "timeresolved": ["xavg_", "xsdt_", "xt_"],
    "composed": ["cmp_", "var_"],
    "acoustic": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_", "dt_", "deng_"],
    "acoustic_plus_tr": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_", "dt_",
                         "deng_", "xavg_", "xsdt_", "xt_"],
    "everything_engineered": ["avg_", "sdt_", "t_", "eng_", "davg_", "dsdt_",
                              "dt_", "deng_", "xavg_", "xsdt_", "xt_", "cmp_",
                              "var_", "ix_"],
}


# ------------------------------------------------------------------ data
PROTOCOL_MATCHED = False   # set by build(); see FEATURE_SPACES `_pm` variants


def load_all(matched: bool = False) -> pd.DataFrame:
    """All participant blocks.

    With `matched=True`, the static / dynamic / time-resolved blocks are the
    protocol-matched rebuilds -- aggregated only over the 11 task groups that
    >=90% of every diagnostic class performed.  Task assignment in this cohort
    is strongly diagnosis-dependent (the cognitive battery went to 83-99% of
    PD/CI and 3-4% of everyone else), so an unmatched cross-task mean is partly
    a readout of which battery someone was given.
    """
    df = datasets.load_blocks()
    if matched:
        base = [c for c in df.columns
                if not c.startswith(("avg_", "sdt_", "t_", "davg_", "dsdt_",
                                     "dt_", "deng_", "eng_"))]
        df = df[base]
        for name in ["static_participant_pm", "dynamic_participant_pm"]:
            p = C.DATA / f"{name}.parquet"
            if p.exists():
                d = pd.read_parquet(p).reindex(df.index)
                num = d.select_dtypes("number").columns
                d[num] = d[num].astype(np.float32)
                df = pd.concat([df, d], axis=1)
        df = df.loc[:, ~df.columns.duplicated()]
    extra = []
    names = (["xdyn_participant_pm"] if matched else ["xdyn_participant"])
    names += ["composed_participant"] if not matched else []
    for name in names:
        p = C.DATA / f"{name}.parquet"
        if p.exists():
            d = pd.read_parquet(p).reindex(df.index)
            num = d.select_dtypes("number").columns
            d[num] = d[num].astype(np.float32)
            extra.append(d)
    if extra:
        df = pd.concat([df] + extra, axis=1)
    return df.loc[:, ~df.columns.duplicated()]


def build(space: str):
    """Return (X, y, meta).  y: 0 neither, 1 parkinsons, 2 cognitive."""
    matched = space.endswith("_pm")
    if matched:
        space = space[:-3]
    df = load_all(matched=matched)
    co = df[df.n_recordings > 0]
    pdd = co.parkinsons_disease == 1
    ci = co.cognitive_impairment == 1
    # The single participant carrying both diagnoses cannot serve as a clean
    # example of either class.
    keep = co.index[~(pdd & ci)]
    co = co.loc[keep]
    y = pd.Series(0, index=co.index, dtype=int)
    y[co.parkinsons_disease == 1] = 1
    y[co.cognitive_impairment == 1] = 2

    prefixes = FEATURE_SPACES[space]
    if "__DURATION__" in prefixes:
        cols = [c for c in DURATION_COLS if c in df.columns]
        prefixes = [p for p in prefixes if p != "__DURATION__"]
    else:
        cols = []
    cols += [c for c in df.columns if any(c.startswith(p) for p in prefixes)]
    # Coverage indicators travel with the time-resolved spaces: the pattern of
    # which recordings were computable encodes pause structure.
    if any(p.startswith("x") for p in prefixes):
        cols += [c for c in df.columns if c.startswith("cov_")]
    cols += [c for c in COVARIATES if c in df.columns]
    banned = set(C.TARGETS) | set(C.CATEGORY_TARGETS) | {
        "is_control", "any_disease", "n_categories", "n_diagnoses",
        "single_category", "has_voice", "has_neuro", "has_respiratory",
        "has_mood_psych", "adhd_partA_hits", "adhd_total_score",
        "ptsd_total_score", "adhd_inattention_score", "adhd_hyperactivity_score",
    } | {f"rare_{r}" for r in C.RARE_DIAGNOSES}
    cols = [c for c in dict.fromkeys(cols) if c not in banned]

    X = co[cols].astype(np.float32)
    X = X.loc[:, X.notna().mean() >= 0.5]
    X = X.loc[:, X.nunique(dropna=True) > 1]
    X = X.replace([np.inf, -np.inf], np.nan)
    meta = {"space": space + ("_pm" if matched else ""),
            "n": int(len(y)), "n_features": int(X.shape[1]),
            "n_neither": int((y == 0).sum()), "n_parkinsons": int((y == 1).sum()),
            "n_cognitive": int((y == 2).sum())}
    return X, y, meta


# ------------------------------------------------------------------ models
def make_selector(name, k=60, seed=C.RANDOM_STATE):
    if name == "none":
        return "passthrough"
    if name == "kbest_f":
        return SelectKBest(f_classif, k=k)
    if name == "kbest_mi":
        return SelectKBest(mutual_info_classif, k=k)
    if name == "l1":
        # liblinear cannot do multiclass, and saga on 15k columns is far too
        # slow for a sweep this size.  LinearSVC with an L1 penalty gives the
        # same sparse-selection behaviour, handles three classes via one-vs-rest
        # and keeps the fast liblinear backend.
        from sklearn.svm import LinearSVC
        return SelectFromModel(
            LinearSVC(penalty="l1", dual=False, C=0.05, max_iter=4000,
                      class_weight="balanced", random_state=seed),
            max_features=k, threshold=-np.inf)
    if name == "trees":
        return SelectFromModel(
            ExtraTreesClassifier(n_estimators=200, random_state=seed, n_jobs=1),
            max_features=k, threshold=-np.inf)
    if name == "rfe":
        return RFE(LogisticRegression(max_iter=1500, random_state=seed),
                   n_features_to_select=k, step=0.25)
    if name == "pca":
        return PCA(n_components=min(k, 50), random_state=seed)
    raise ValueError(name)


def make_clf(name, seed=C.RANDOM_STATE):
    if name == "logreg":
        return LogisticRegression(max_iter=5000, class_weight="balanced",
                                  C=1.0, random_state=seed)
    if name == "logreg_en":
        return LogisticRegression(penalty="elasticnet", solver="saga",
                                  l1_ratio=0.5, C=0.5, max_iter=6000,
                                  class_weight="balanced", random_state=seed)
    if name == "rf":
        return RandomForestClassifier(n_estimators=400, min_samples_leaf=2,
                                      class_weight="balanced_subsample",
                                      n_jobs=1, random_state=seed)
    if name == "et":
        return ExtraTreesClassifier(n_estimators=400, min_samples_leaf=2,
                                    class_weight="balanced", n_jobs=1,
                                    random_state=seed)
    if name == "gb":
        return GradientBoostingClassifier(n_estimators=200, learning_rate=0.06,
                                          max_depth=3, random_state=seed)
    if name == "xgb":
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=300, learning_rate=0.06, max_depth=3,
                             subsample=0.8, colsample_bytree=0.8, n_jobs=1,
                             objective="multi:softprob", num_class=3,
                             eval_metric="mlogloss", tree_method="hist",
                             random_state=seed)
    if name == "lgbm":
        from lightgbm import LGBMClassifier
        return LGBMClassifier(n_estimators=300, learning_rate=0.06,
                              num_leaves=15, subsample=0.8,
                              colsample_bytree=0.8, class_weight="balanced",
                              n_jobs=1, verbose=-1, random_state=seed)
    if name == "svm_rbf":
        return SVC(kernel="rbf", C=2.0, probability=True,
                   class_weight="balanced", random_state=seed)
    if name == "svm_lin":
        return SVC(kernel="linear", C=0.5, probability=True,
                   class_weight="balanced", random_state=seed)
    if name == "mlp":
        return MLPClassifier(hidden_layer_sizes=(64, 32), alpha=1e-2,
                             max_iter=1200, early_stopping=True,
                             random_state=seed)
    if name == "knn":
        return KNeighborsClassifier(n_neighbors=15, weights="distance")
    if name == "lda":
        return LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    if name == "nb":
        return GaussianNB()
    raise ValueError(name)


SELECTORS = ["kbest_f", "kbest_mi", "l1", "trees", "rfe", "pca", "none"]
CLASSIFIERS = ["logreg", "logreg_en", "rf", "et", "gb", "xgb", "lgbm",
               "svm_rbf", "svm_lin", "mlp", "knn", "lda", "nb"]
# Learners that cannot cope with thousands of raw columns need a selector.
NEEDS_SELECTION = {"knn", "lda", "nb", "mlp", "svm_rbf", "svm_lin", "gb",
                   "logreg_en"}


# ------------------------------------------------------------------ scoring
def score3(y, proba, classes=(0, 1, 2)):
    """Macro OvR AUC plus the PD-vs-CI contrast inside the 3-class model."""
    y = np.asarray(y)
    out = {}
    aucs = []
    for i, c in enumerate(classes):
        yi = (y == c).astype(int)
        if yi.min() == yi.max():
            continue
        a = roc_auc_score(yi, proba[:, i])
        out[f"ovr_auc_{CLASSES[i]}"] = float(a)
        aucs.append(a)
    out["macro_ovr_auc"] = float(np.mean(aucs)) if aucs else np.nan

    # PD vs CI restricted to those two classes, scored by the model's own
    # relative preference between them.  This is the number that says whether
    # the model can do differential diagnosis rather than just detect illness.
    m = (y == 1) | (y == 2)
    if m.sum() > 20 and len(np.unique(y[m])) == 2:
        num = proba[m, 1]
        den = proba[m, 1] + proba[m, 2]
        rel = np.divide(num, den, out=np.full(m.sum(), 0.5), where=den > 0)
        out["pd_vs_ci_auc"] = float(roc_auc_score((y[m] == 1).astype(int), rel))
    else:
        out["pd_vs_ci_auc"] = np.nan

    pred = np.asarray(classes)[proba.argmax(axis=1)]
    out["accuracy"] = float((pred == y).mean())
    rec, prec = [], []
    for c in classes:
        t = (y == c)
        p = (pred == c)
        rec.append((p & t).sum() / max(1, t.sum()))
        prec.append((p & t).sum() / max(1, p.sum()))
    out["balanced_accuracy"] = float(np.mean(rec))
    out["macro_precision"] = float(np.mean(prec))
    for i, c in enumerate(classes):
        out[f"recall_{CLASSES[i]}"] = float(rec[i])
        out[f"precision_{CLASSES[i]}"] = float(prec[i])
    out["confusion_matrix"] = confusion_matrix(y, pred, labels=list(classes)).tolist()
    return out


# ------------------------------------------------------------------ evaluate
def oof_proba(X, y, selector, clf, k=60, n_splits=5, n_repeats=3,
              seed=C.RANDOM_STATE):
    """Out-of-fold 3-class probabilities, averaged over repeats."""
    outer = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats,
                                    random_state=seed)
    acc = np.zeros((len(y), 3))
    seen = np.zeros(len(y))
    for tr, te in outer.split(X, y):
        prep = modeling.make_prep()
        Xtr = prep.fit_transform(X.iloc[tr])
        Xte = prep.transform(X.iloc[te])
        kk = min(k, Xtr.shape[1])
        steps = []
        sel = make_selector(selector, kk, seed)
        if sel != "passthrough":
            steps.append(("sel", sel))
        steps.append(("clf", make_clf(clf, seed)))
        pipe = Pipeline(steps)
        pipe.fit(Xtr, y.iloc[tr])
        p = pipe.predict_proba(Xte)
        cls = list(pipe.classes_)
        for j, c in enumerate(cls):
            acc[te, int(c)] += p[:, j]
        seen[te] += 1
    acc /= np.maximum(seen, 1)[:, None]
    s = acc.sum(axis=1, keepdims=True)
    return acc / np.maximum(s, 1e-9)


def run_config(space, selector, clf, k, n_splits, n_repeats, save=True):
    cid = f"{space}|{selector}|{clf}|k{k}"
    t0 = time.time()
    try:
        X, y, meta = build(space)
        if selector == "none" and clf in NEEDS_SELECTION and X.shape[1] > 300:
            return {"config_id": cid, "status": "skipped_needs_selection", **meta}
        proba = oof_proba(X, y, selector, clf, k, n_splits, n_repeats)
        m = score3(y, proba)
        cm = m.pop("confusion_matrix")
        rec = {"config_id": cid, "status": "ok", "space": space,
               "selector": selector, "clf": clf, "k": k, **meta, **m,
               "confusion": json.dumps(cm), "seconds": round(time.time() - t0, 1)}
        if save:
            np.save(PRED / f"{cid.replace('|', '__')}.npy",
                    proba.astype(np.float32))
        return rec
    except Exception as e:
        return {"config_id": cid, "status": "error", "space": space,
                "selector": selector, "clf": clf, "k": k,
                "error": f"{type(e).__name__}: {e}",
                "traceback": traceback.format_exc()[-900:],
                "seconds": round(time.time() - t0, 1)}


# ------------------------------------------------------------------ driver
def cmd_screen(args):
    metrics = OUT / "screen.jsonl"
    done = set()
    if metrics.exists():
        for line in open(metrics):
            try:
                done.add(json.loads(line)["config_id"])
            except Exception:
                pass

    grid = []
    for space in args.spaces.split(","):
        for clf in args.clfs.split(","):
            for selector in args.selectors.split(","):
                for k in [int(v) for v in args.ks.split(",")]:
                    if selector == "none" and k != int(args.ks.split(",")[0]):
                        continue          # k is meaningless without a selector
                    grid.append((space, selector, clf, k))
    todo = [g for g in grid
            if f"{g[0]}|{g[1]}|{g[2]}|k{g[3]}" not in done]
    print(f"{len(grid)} configurations, {len(done)} done, {len(todo)} to run "
          f"on {args.jobs} workers")
    if not todo:
        return

    t0 = time.time()
    with open(metrics, "a") as fh:
        batch = 4 * args.jobs
        for i in range(0, len(todo), batch):
            chunk = todo[i:i + batch]
            res = Parallel(n_jobs=args.jobs, verbose=5)(
                delayed(run_config)(s, sel, c, k, args.splits, args.repeats)
                for s, sel, c, k in chunk)
            for r in res:
                fh.write(json.dumps(r, default=float) + "\n")
            fh.flush()
            n = i + len(chunk)
            el = time.time() - t0
            print(f"  {n}/{len(todo)}  {el/60:.1f} min elapsed, "
                  f"~{el/n*(len(todo)-n)/60:.1f} min left", flush=True)

    df = pd.read_json(metrics, lines=True)
    ok = df[df.status == "ok"]
    print(f"\n{len(ok)} ok, {(df.status == 'error').sum()} errors, "
          f"{(df.status.str.startswith('skipped')).sum()} skipped")
    if len(ok):
        cols = ["space", "selector", "clf", "k", "macro_ovr_auc", "pd_vs_ci_auc",
                "balanced_accuracy", "seconds"]
        print("\ntop 20 by PD-vs-CI AUC:")
        print(ok.nlargest(20, "pd_vs_ci_auc")[cols].round(3).to_string(index=False))
        print("\ntop 10 by macro OvR AUC:")
        print(ok.nlargest(10, "macro_ovr_auc")[cols].round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["screen", "stack"])
    ap.add_argument("--jobs", type=int, default=8)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--spaces", type=str, default=",".join(FEATURE_SPACES))
    ap.add_argument("--clfs", type=str, default=",".join(CLASSIFIERS))
    ap.add_argument("--selectors", type=str, default=",".join(SELECTORS))
    ap.add_argument("--ks", type=str, default="20,60,150")
    ap.add_argument("--no-nested", action="store_true")
    ap.add_argument("--stack-repeats", type=int, default=2)
    args = ap.parse_args()
    if args.command == "screen":
        cmd_screen(args)
    else:
        from pdci_stack import cmd_stack
        cmd_stack(args)


if __name__ == "__main__":
    main()
