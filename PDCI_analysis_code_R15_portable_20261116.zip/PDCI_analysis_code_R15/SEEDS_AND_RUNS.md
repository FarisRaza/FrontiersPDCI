# Seeds and run order

All paths are relative to this archive (`src/`, `results/`, `figures/`), which mirrors `DATA_ROOT/analysis/` (see README.md). Line numbers below refer to the historical scripts copied on 26 October, before the portability edits in this release. Use the named constants/functions and source diffs to locate them in this copy. No seed changed.

## Seeds

| Seed | Value | Where it is set (file:line) | What it controls |
|---|---|---|---|
| Run seed | 20260725 | `src/config.py:39` (`RANDOM_STATE`); taken over as `SEED` at `src/pdci_fully_nested_20260911.py:47`, `src/pdci_demographic_baseline_20260911.py:47` and `src/pdci_pls10_refinement.py:42` | Outer partitions; estimator seeds; base of the inner-fold seeds |
| Outer partitions | run seed | `src/pdci_fully_nested_20260911.py:469` (generated and saved in the input payload); regenerated and asserted equal at `src/pdci_demographic_baseline_20260911.py:516` and `:521-522`; same call at `src/pdci_pls10_refinement.py:187-188` | `RepeatedStratifiedKFold(n_splits=5, n_repeats=3)` on the three-class label: 15 outer fits |
| Inner folds | run seed + outer fit index x 1009 | `src/pdci_demographic_baseline_20260911.py:594` (also `src/pdci_fully_nested_20260911.py:532`, `src/pdci_pls10_refinement.py:201-202`) | `StratifiedKFold(3, shuffle=True)` within each outer training set. The outer fit index `oi` runs 0 to 14 in repeat-major order: repeat = `oi // 5`, fold = `oi % 5` (`src/pdci_demographic_baseline_20260911.py:639`), so the inner seeds are 20260725, 20261734, ..., 20274851 |
| Estimator seeds | run seed | `src/pdci_demographic_baseline_20260911.py:156` (ridge logistic regression), `:173` (randomized PCA), `:197` (elastic net, saga), `:201` (SVC with probability calibration) | Solver and SVD randomness of the candidate models |
| F1 bootstrap | 20270636 = run seed + 9911 | `src/pdci_demographic_baseline_20260911.py:755` (`default_rng(SEED+9911)`); 5,000 draws at `:754` and `:756` | Class-stratified paired participant bootstrap of the saved out-of-fold scores (AUROC intervals and paired gains) |
| F1 bootstrap replay | 20270636 | `results/pdci_demographic_baseline_20260911/support/audit_saved_bootstrap.py:15` (`20260725 + 9911`), used at `:51` | Independent replay of the F1 bootstrap with scikit-learn |
| F5 bootstrap | 20260912 | `src/pdci_sensitivity_policy_20260912.py:22` (`SEED`), 5,000 draws at `:23` (`NBOOT`), used at `:266` | Class-stratified participant bootstrap of the fixed policy decisions |
| F5 independent audit | 20260912 | `results/pdci_sensitivity_policy_20260912/support/independent_policy_audit.py:17`, used at `:244`; the frozen seed is asserted at `:115` | Independent reconstruction of the F5 bootstrap |
| A5 bootstrap | 20261001 | `src/pdci_a5_matched_policy_20261001.py:21` (`SEED`), 5,000 draws at `:20` (`NBOOT`), used at `:270` | Paired voice-minus-baseline intervals at the primary policy |
| Reviewer analyses | 20261026 | `src/pdci_review_analyses_20261026.py:29` (`SEED`), 5,000 draws at `:30` (`B`); used as `SEED` for the within-country analysis (`:139`), `SEED + 1` for the subtype analyses (`:150`) and `SEED + 2` for average precision (`:186`) | Paired class-stratified bootstrap of the saved stage-2 scores |
| Synthetic self-test | run seed | `src/pdci_demographic_baseline_20260911.py:852` | Synthetic data for `selftest` only; no result depends on it |

No other step draws random numbers: the label, feature and descriptor builders, the cohort recount (A8), the Hoehn and Yahr counts and the figure scripts are deterministic (the Figure 2 point spread is a deterministic beeswarm).

Threads: every numerical library is limited to one thread (`src/pdci_demographic_baseline_20260911.py:18-20` and `threadpool_limits(1)` at `:602`; `src/pdci_a5_matched_policy_20261001.py:359`); the baseline run used two joblib (loky) worker processes (`--jobs 2`, the default at `:902`).

## Historical chronology (not the fresh-rerun command list)

Times are as recorded in each run's receipts (UTC, Z) or file times (US Pacific). Output folders are under `DATA_ROOT/analysis/`. Files under `data/` and every `local_only/` folder are participant-level and are not part of this archive; the other outputs named here are aggregate.

| Step | Script and command | Date | Output folder (aggregate outputs) |
|---|---|---|---|
| 1 | `src/build_labels.py` | 2026-07-25 | `data/cohort.parquet` (participant-level) |
| 2 | `src/build_static_features.py` | 2026-07-25 | `data/static_bytask.parquet` (participant-level) |
| 3 | `src/extract_prosody.py`, `src/extract_ema.py`, `src/extract_ppg.py`, `src/extract_mfccdyn.py`, `src/extract_ltas.py` | 2026-07-25 | `data/dyn_prosody.parquet`, `dyn_ema`, `dyn_ppg`, `dyn_mfccdyn`, `dyn_ltas` (participant-level) |
| 4 | `src/build_dynamic_features.py` | 2026-07-25 | `data/dynamic_participant.parquet` (participant-level; read by `src/datasets.py`, not by the PD/CI runs) |
| 5 | `src/significance_sweep.py` (its `dynamic_bytask()` writes the per-task dynamic table on first use; the sweep's own counts are not used in the paper), then `src/reconcile_counts.py` (count cross-check) | 2026-07-25; 2026-07-26 | `data/dynamic_bytask.parquet` (participant-level; it concatenates every `data/dyn_*.parquet` present, so it must run before step 6); `results/count_reconciliation.csv` |
| 6 | `src/extract_linear_harmonics.py run --jobs 2` (task set `general`, the default) | 2026-08-23 | `data/dyn_linear_harmonics.parquet` (participant-level) |
| 7 | `src/pdci_tasks.py audit` (cohort-count cross-check) | 2026-08-25 | `results/pdci_tasks/cohort_counts.csv`, `ci_subtypes.csv` |
| 8 | `src/pdci_pls10_refinement.py run --jobs 2` (earlier exploratory run; its outer-fold files are read only to assert that later runs use the same 15 outer partitions) | 2026-08-25 | `results/pdci_pls10_refinement/folds/` (participant-level) |
| 9 | `src/pdci_fully_nested_20260911.py prepare` (builds the input payload and partitions; its `run` step produced an earlier analysis that is superseded and not reported) | frozen 2026-09-11T08:31:02Z | `results/pdci_fully_nested_20260911/` |
| 10 | `src/pdci_demographic_baseline_20260911.py selftest`, `prepare`, `run --jobs 2` (`run` ends with `report`) | frozen 2026-09-11T09:04:03Z; fits 09:04:39Z to 09:12:07Z | `results/pdci_demographic_baseline_20260911/` (source run: result families F1 to F4) |
| 11 | `results/pdci_demographic_baseline_20260911/support/summarize_selection_and_warnings.py`; `results/pdci_demographic_baseline_20260911/support/audit_saved_bootstrap.py` | 2026-09-11 (replay PASS 09:13:40Z) | `.../support/SELECTION_WARNINGS.json`, `.../support/INDEPENDENT_BOOTSTRAP_AUDIT.json` |
| 12 | `src/pdci_sensitivity_policy_20260912.py freeze`, `run` | frozen 2026-09-13T01:07:32Z (2026-09-12 US Pacific); complete 01:07:50Z | `results/pdci_sensitivity_policy_20260912/` (F5: nine training-only policies) |
| 13 | `results/pdci_sensitivity_policy_20260912/support/independent_policy_audit.py` | 2026-09-12 (US Pacific) | `.../support/independent_policy_audit_receipt.json` |
| 14 | `figures/pdci/support/build_pdci_assets.py` | 2026-09-13T01:40Z | `figures/pdci/figures/Figure_1_stage_ROC.png` (source of Supplementary Figure S1) and the aggregate tables of that package |
| 15 | `src/pdci_a5_matched_policy_20261001.py freeze`, `gate`, `run` | frozen 2026-10-01T07:55:54Z; run 07:56:32Z to 07:56:34Z | `results/pdci_a5_matched_policy_20261001/` (F8-A5: matched post hoc policy comparison) |
| 16 | `src/pdci_a8_cohort_recount_20261007.py freeze`, `gate`, `run` | frozen 2026-10-07T02:58:47-07:00; run 02:59 | `results/pdci_a8_cohort_recount_20261007/` (family F7: cohort flow, Table 1, subtypes) |
| 17 | `src/pdci_hy_counts_20261007.py freeze`, `gate`, `run` | frozen 2026-10-07T12:16:18-07:00; run 12:16 | `results/pdci_hy_counts_20261007/` (family F7-HY: Hoehn and Yahr counts) |
| 18 | `figures/source/build_figures.py`, then `figures/scripts/build_frontiers_figures_20261007.py` | drawings 2026-10-07; journal export last run 2026-10-26 | `figures/figures/` (Figures 1 to 4 and Supplementary Figure S1 files, figure provenance JSON) |
| 19 | `src/pdci_review_analyses_20261026.py freeze`, `gate`, `run` | frozen 2026-10-26T10:20:53-07:00; run 10:21 to 10:22 | `results/pdci_review_analyses_20261026/` (post hoc reviewer-requested analyses) |

Each `freeze` step records SHA256 hashes of its script, its protocol file (`ANALYSIS_PLAN.md` in the output folder) and its inputs before any outcome is computed; `gate` re-derives known counts or AUROCs and must pass before `run`. The hashes are those of the files on the machine where the step runs, so a rerun creates its own frozen specification.

For a fresh rerun follow README.md: the cache-only helper replaces the unrelated sweep; historical exploratory fits are not required; public protocol copies are supplied; private document hashes are removed. Do not run the historical table mechanically. September environment versions were reconstructed, whereas the October receipts recorded core versions directly.
