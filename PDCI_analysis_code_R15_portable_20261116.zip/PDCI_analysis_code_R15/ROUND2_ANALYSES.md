# R15 reviewer-requested analyses

These two separately labelled post hoc analyses extend the original study. They preserve the original age/sex/country comparison and BH3 family. Read their ANALYSIS_PLAN.md files, the F12 implementation amendment and REPRODUCTION_STATUS.json before using their results. Code preparation is not evidence of execution.

After recreating the original canonical outputs and A5 comparison using REPRODUCE_FROM_FEATURES.md, the init step has copied these scripts/protocols into the new workspace. Set the two existing roots explicitly in PowerShell:

    $env:PDCI_DATA_ROOT = $data_root
    $env:PDCI_ANALYSIS_ROOT = $work

F12-MM: common ridge family, eight-candidate tuning grid and matched folds; four fixed arms D, D+A, D+M+T and D+M+T+A. The microphone/gain metadata also require the released phenotype/task/recording.tsv and recording.json files. The six contrast/endpoints form their own exploratory BH6 family.

    python -B "$work/results/pdci_round2_20261116/matched_models/matched_models.py" selftest
    python -B "$work/results/pdci_round2_20261116/matched_models/matched_models.py" freeze
    python -B "$work/results/pdci_round2_20261116/matched_models/matched_models.py" preflight
    python -B "$work/results/pdci_round2_20261116/matched_models/matched_models.py" run

F13-OP: the original saved voice and demographic procedures compared at seven common training referral budgets. Thresholds use selected inner-held-out training scores only; held-out referral counts need not equal training budgets. All seven budgets are reported; no budget is selected by outcome. Fixed-prediction paired intervals are pointwise and exploratory.

    python -B "$work/results/pdci_round2_20261116/operating_points/operating_points.py" selftest
    python -B "$work/results/pdci_round2_20261116/operating_points/operating_points.py" freeze
    python -B "$work/results/pdci_round2_20261116/operating_points/operating_points.py" gate
    python -B "$work/results/pdci_round2_20261116/operating_points/operating_points.py" run

The portable edits change top-level path configuration only. R15_REVIEWER_CODE_PROVENANCE.json records original/portable hashes and exact equality of every function/class AST. Diffs redact the original private absolute path; no scientific line is redacted. The protocols retain their historical authority labels only as provenance.

Do not copy original FROZEN_SPEC.json into a new run: each freeze command hashes its actual inputs/code. Original aggregate reference tables are kept under reference_aggregates where supplied; they do not feed the analysis. Original local_only score checkpoints and participant tables are never included.

These Windows scripts check memory before fitting and pause if necessary. They run one process and one BLAS thread, keeping checkpoint files under local_only. Those generated files remain controlled participant derivatives. Completion status and independent-verification status must be reported separately. Do not describe pending verification as a pass.

## Independent F13 verification and optional replay

The original F13 implementation passed blind protocol-based replication: all 1,638 rows and 5,376 common numeric cells matched exactly (tolerance 1e-12; maximum difference zero). See R15_INDEPENDENT_VERIFICATION.json and results/pdci_round2_20261116/matched_models/f13_op_replication/reference_verification/RECONCILIATION.json. That receipt comes from the original local replication at matched_models/f13_op_replication/RECONCILIATION.json. It supersedes the earlier pending status without modifying the frozen owner completion report.

The package includes the independently developed script and aggregate reconciliation code. After the core/A5 and F13 owner workflows above complete in the fresh workspace, replay it with:

    python -B "$work/results/pdci_round2_20261116/matched_models/f13_op_replication/freeze_replay.py"
    python -B "$work/results/pdci_round2_20261116/matched_models/f13_op_replication/independent_operating_points.py" selftest
    python -B "$work/results/pdci_round2_20261116/matched_models/f13_op_replication/independent_operating_points.py" run
    python -B "$work/results/pdci_round2_20261116/matched_models/f13_op_replication/reconcile_results.py"

freeze_replay.py hashes the actual newly reconstructed inputs and records the actual environment. It is a new provenance wrapper; all statistical functions in the independent implementation and reconciliation script remain unchanged. reference_verification contains historical receipts only and never acts as a new-run completion or input. Independent refers to how the original implementation was developed and frozen before owner outcomes were read; replaying the public code does not establish a new blind implementation. The portable command sequence itself is not claimed executed until the corresponding current execution receipt records it.

## Independent F12 replay preparation

A path-only copy of the guarded V2 independent matched-model implementation is included. Its original numerical run and reconciliation passed; the portable copy has not been refit. Consult R15_INDEPENDENT_VERIFICATION.json for the final verified status. After the original core outputs and the F12 owner workflow are complete in the new workspace:

    python -B "$work/results/pdci_round2_20261116/matched_replication/v2/independent_matched_models.py" selftests
    python -B "$work/results/pdci_round2_20261116/matched_replication/v2/independent_matched_models.py" freeze
    python -B "$work/results/pdci_round2_20261116/matched_replication/v2/independent_matched_models.py" verify
    python -B "$work/results/pdci_round2_20261116/matched_replication/v2/independent_matched_models.py" run

This duplicates the matched-model fitting work for independent numerical checking; run it sequentially, never concurrently with extraction or another fitting process. It has its own canonical D gate and participant-derived local_only checkpoints. A later reconciliation step must pass before the replay can be called verified; completion alone is not sufficient. Current portable-source provenance records the frozen raw-byte SHA256. The earlier pre-execution guard audit used LF-normalized text; its different digest is explained by Windows CRLF line endings, with no scientific source change.
