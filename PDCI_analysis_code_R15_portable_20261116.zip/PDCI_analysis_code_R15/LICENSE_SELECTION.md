# Code licence pending author choice

{{AUTHOR: choose the licence for the analysis code and insert the approved licence text before publication.}}

No open-source licence is asserted by this candidate. The agent has not selected a licence or granted permissions on behalf of the authors. Any licences governing third-party software continue to apply. The source dataset is not included and remains subject to its own controlled-access agreement.
