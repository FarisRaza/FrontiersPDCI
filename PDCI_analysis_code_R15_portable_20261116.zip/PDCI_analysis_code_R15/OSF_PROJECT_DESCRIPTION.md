# Draft OSF project description

**OSF notice — verified 16 November 2026.** New Projects and components can no longer be created; existing Projects become read-only on 19 February 2027. [OSF Projects transition](https://help.osf.io/article/727-osf-projects-transition). This archive can go to an appropriate existing Project while uploads remain enabled. [Read-only Project guidance](https://help.osf.io/article/711-read-only-project-access). If no suitable Project exists, hosting and project type remain author decisions. This completed study has not been converted into a preregistration.

Title: Analysis code for Voice-based differentiation of Parkinson's disease and cognitive impairment in Bridge2AI-Voice

Authors, in manuscript order: Faris Raza; Yicheng Peng; Nithila Sadheesh.
Yicheng Peng and Nithila Sadheesh: Writing - review and editing (author-confirmed).
Other roles and author declarations are carried by the manuscript and must not be inferred from this code archive.

This repository contains analysis scripts, software/version and seed records, protocols, reproduction instructions and aggregate verification receipts for Frontiers in Digital Health manuscript 2021657. The study compares voice-based Parkinson's disease versus cognitive impairment discrimination with an age, sex and residence-country baseline using repeated nested cross-validation in Bridge2AI-Voice adult v3.0.0.

The archive contains no recordings, released feature tables, participant labels, feature caches, model payloads, participant predictions or credentials. Data must be obtained separately through credentialed PhysioNet access under the applicable agreement (dataset DOI 10.13026/k81f-qr68). Generated participant derivatives remain in each authorized user's local workspace.

Read REPRODUCE_FROM_FEATURES.md for the input-to-result workflow and REPRODUCTION_STATUS.json for exactly what was executed and verified. Historical cache-to-result verification is distinguished from newly attempted raw-feature reconstruction. A clean-install or cross-platform result is not claimed.

Licence: {{AUTHOR: choose a code licence before publication}}.
OSF project URL: {{AUTHOR: insert the actual project or view-only reviewer URL after author-controlled upload to the chosen existing Project}}.
Persistent identifier/DOI: {{AUTHOR: insert only if actually assigned}}.

Status: prepared for author-controlled upload to an appropriate existing editable OSF Project, if available. This draft has not been uploaded or published.
