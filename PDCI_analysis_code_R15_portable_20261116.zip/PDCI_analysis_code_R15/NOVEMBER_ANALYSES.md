# November reviewer analyses

These scripts extend the original code package with the primary post hoc analyses used in the revision. Copy this package into a new DATA_ROOT/analysis layout described in README.md. The downloaded credentialed adult phenotype and feature tables belong in DATA_ROOT/phenotype and DATA_ROOT/features. Do not copy participant data into a public code archive or overwrite a frozen analysis workspace.

## Inputs and ordering

First reproduce the canonical core through README steps 1-4. The November scripts read its generated local_only/input_payload.joblib, participant_oof_predictions.parquet, split_manifest.json and per-fold predictions/receipts, together with feature_schemas.json, candidate_grid.json, INPUT_AUDIT.json and aggregate AUROC receipts. They also require locally downloaded demographics and diagnosis TSV/JSON files and, for clinical/device work, the relevant phenotype dictionaries and task/recording.tsv. None of these data, caches or historical manifests is supplied in this code package. Credentialed existing caches may be read in a separately configured local workflow; the archive does not authorize redistribution.

All paths are relative to the package's expected DATA_ROOT/analysis layout. Keep results/<dated-folder>/ scripts and protocols in their supplied paths. Empty output folders already contain scripts/protocols; their freeze commands create fresh local receipts. Refuse overwrite checks intentionally stop existing runs. Freeze files will record local input paths and therefore must stay local.

## N1/N2: new case-only nested refits

From DATA_ROOT/analysis:

```
python results/pdci_reviewer_extension_20261104/pdci_subgroup_analysis_20261104.py freeze
python results/pdci_reviewer_extension_20261104/pdci_subgroup_analysis_20261104.py gate
python results/pdci_reviewer_extension_20261104/pdci_subgroup_analysis_20261104.py run
```

The first population is Canadian PD/CI cases (49/59); the second is idiopathic PD versus MCI (53/36). Both retain the original 160 discriminator candidates, eight demographic candidates and nested preprocessing/selection. Thirty outer fits are run in total; pooled predictions stay in memory. Bootstrap seeds are 20261104 and 20261105, with 5000 paired class-stratified draws. The two corrected-CV comparisons form the separately labelled exploratory BH2 family. See the subgroup protocol for all settings.

## Clinical availability, retained timing and recording metadata

```
python results/pdci_clinical_timing_20261104/pdci_clinical_timing_audit_v2.py freeze
python results/pdci_clinical_timing_20261104/pdci_clinical_timing_audit_v2.py run
python results/pdci_clinical_timing_20261104/pdci_semantic_followup.py freeze
python results/pdci_clinical_timing_20261104/pdci_semantic_followup.py run
python results/pdci_clinical_timing_20261104/pdci_exact_device_feasibility.py freeze
python results/pdci_clinical_timing_20261104/pdci_exact_device_feasibility.py run
```

These audits do not fit models. Clinical v2's current input hashing omits failed-v1 artifacts. The numeric semantic decoder is unchanged. Publication CSV exports suppress CDR severity categories and vocabulary-difficulty categories while keeping availability. The superseded broad generic microphone branch/table is omitted. Exact-string device feasibility uses anonymous A/B/... labels ordered by SHA256, never exporting the raw strings or their hashes. Its scope is all released recording rows for the canonical people, including rows outside the eleven model task families. Generic metadata labels do not establish hardware or site identity. Retained timing columns indicate preprocessing/selection inclusion, not feature importance.

## D2: Canadian single recorded microphone category

Run N1/N2 freeze and gate first; the D2 code relies on that canonical gate. The D2 model does not depend computationally on clinical audit output tables; it reconstructs its own population from credentialed recording metadata.

```
python results/pdci_device_matched_refit_20261104/pdci_device_matched_refit.py freeze
python results/pdci_device_matched_refit_20261104/pdci_device_matched_refit.py run
```

The prespecified descriptive selection rule chooses the largest minimum PD/CI count among Canadian exact-single-string categories having at least ten per class, with total count then hash-order tie breaks. The canonical population is 38 PD and 46 CI. Fifteen outer fits use the original candidate grid and nested selection. Bootstrap seed 20261106, 5000 paired class-stratified draws. This additional comparison is outside the original BH3 and N1/N2 BH2 families; its corrected-CV p value is unadjusted and exploratory. No raw microphone string or token hash is printed or saved.

## What was executed and what was adapted

N1/N2, D2 and exact-device scripts are byte-identical to the primary executed scripts. Clinical v2 and the numeric followup have only the adaptations itemized in NOVEMBER_SOURCE_MANIFEST.json and november_source_diffs/. All retained scientific functions and the complete clinical-recount prefix are AST-identical to their executed counterparts. The original 46 core Python files are unchanged.

The primary November analyses were executed locally during the revision and separately checked in their scientific workstreams. Packaging did not repeat them. This publication copy was checked by static compilation, dependency imports and synthetic tests only. Adapted clinical exports were not regenerated from participant data during packaging. The earlier core cache-to-result execution receipt applies to the unchanged core, not to a claim that this whole extended archive was executed end to end. Raw feature extraction, clean installation and a full fresh-download reproduction remain untested. Public publication/DOI/licence remain author actions.

To run the synthetic checks without reading study data, use `python validation/check_november_extensions.py` from DATA_ROOT/analysis. The check rejects phenotype/cache reads and uses only artificial examples. It does not call any study freeze, gate or run command.
