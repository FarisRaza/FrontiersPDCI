# Released feature tables to Tables 2, 4 and calibration

This is the R15 reproduction entry point for manuscript 2021657. The package is a code-only local release candidate. It has no public URL, DOI or selected licence. R14 cache-to-result execution is historical evidence; R15 execution status is recorded separately in REPRODUCTION_STATUS.json. A script's presence does not mean that it was executed.

## Inputs and environment

Use credentialed Bridge2AI-Voice adult **v3.0.0**, DOI 10.13026/k81f-qr68, under its access agreement. The required inputs are phenotype TSVs, static_features.tsv, SPARC pitch/periodicity/loudness/EMA, PPGs, MFCC, mel-spectrogram and linear-spectrogram Parquet tables. torchaudio_pitch is unused. The eight trajectory files total about 12.81 GiB on this installation. Reading only ID or frame-count columns cannot reconstruct numeric acoustic descriptors.

Use Python 3.13.5 on Windows and requirements.txt. Core versions: numpy 2.4.6, pandas 2.3.3, scipy 1.18.0, scikit-learn 1.9.0, pyarrow 25.0.0, joblib 1.5.3, threadpoolctl 3.6.0. September versions were retrospectively reconstructed; November receipts record the running versions. A clean installation has not been verified. No dependency download is performed by this driver.

The R15 option uses 32-row Arrow batches instead of complete row groups, retaining the original summary mathematics, source row order, orientation, numeric casts and aggregation. This is an I/O change, documented in r15_source_diffs. Batch size is not a hard memory cap because Arrow decodes nested pages. Actual execution footprint is reported separately. One process and one BLAS thread are used; reserve about 1–2 GiB for new derived outputs and checkpoints. No raw copies or filesystem links are needed.

## Exact commands

Run from the code-release directory. Set data_root to the existing adult download and work to a **new** local analysis folder. Never point work at the original analysis folder. These paths are examples, not required locations.

    $data_root = "D:/credentialed/bridge2ai-voice-v3/adult"
    $work = "D:/local-analysis/pdci-reproduction"
    python -B reproduce_from_features.py init --data-root $data_root --workspace $work
    python -B reproduce_from_features.py inventory --data-root $data_root --workspace $work
    python -B reproduce_from_features.py freeze --data-root $data_root --workspace $work

An optional footprint/throughput pilot reads the first eight records from each of five numeric modalities and emits aggregate timings; it is not full reproduction:

    python -B reproduce_from_features.py pilot --data-root $data_root --workspace $work

Then execute each full step in order:

    python -B reproduce_from_features.py labels --data-root $data_root --workspace $work
    python -B reproduce_from_features.py static --data-root $data_root --workspace $work
    python -B reproduce_from_features.py prosody --data-root $data_root --workspace $work
    python -B reproduce_from_features.py ema --data-root $data_root --workspace $work
    python -B reproduce_from_features.py ppg --data-root $data_root --workspace $work
    python -B reproduce_from_features.py mfcc --data-root $data_root --workspace $work
    python -B reproduce_from_features.py mel --data-root $data_root --workspace $work
    python -B reproduce_from_features.py dynamic --data-root $data_root --workspace $work
    python -B reproduce_from_features.py harmonics --data-root $data_root --workspace $work
    python -B reproduce_from_features.py prepare --data-root $data_root --workspace $work
    python -B reproduce_from_features.py compare-inputs --data-root $data_root --workspace $work
    python -B reproduce_from_features.py fits --data-root $data_root --workspace $work
    python -B reproduce_from_features.py policies --data-root $data_root --workspace $work
    python -B reproduce_from_features.py calibration --data-root $data_root --workspace $work

Without historical caches, compare-inputs checks population counts, unique participants, the specified splitter and disjoint partitions. It explicitly records that it did not compare feature values to historical caches. Reviewers can therefore run the full chain using the controlled-access release alone.

For local author validation, supply --canonical-analysis $canonical already at the freeze step as well as compare-inputs/reconcile. The root and reference hashes are frozen; the driver refuses later root or batch-size changes. It reads canonical caches in place, never copies them:

    python -B reproduce_from_features.py compare-inputs --data-root $data_root --workspace $work --canonical-analysis $canonical
    python -B reproduce_from_features.py reconcile --data-root $data_root --workspace $work --canonical-analysis $canonical

An exact canonical input comparison must pass before local validation fits. Any mismatch stops the chain; investigate and record it. The optional --batch-rows defaults to 32. --min-commit-gib optionally enforces a Windows resource guard; local validation follows the machine budget. Code/input changes after freezing require a new workspace. Completed outputs are not overwritten. Harmonic groups and outer fits resume from new local checkpoints.

## Reconstruction rules

1. Diagnosis-module membership defines the PD/CI groups; ALS and PD/CI overlap are excluded. Static task presence defines the original 11-general-task eligibility. There are 833 people with features and 750 analyzed (598 neither, 90 PD, 62 CI), after the stated exclusions.
2. Read string IDs as released. The historical cohort table has separate stripped/padded representations; do not silently rewrite it. Preparation normalizes demographic IDs with strip().zfill(6), keeps the first released demographic record and asserts unique normalized IDs. Nonnumeric top-coded age is missing; sex uses sex_at_birth with sex_assigned_at_birth fallback; USA/Canada maps to 1/0. The linked 750-person block has 4 missing ages, 6 missing sexes and complete country.
3. Pitch and periodicity streams align by participant/session/task keys. Dynamic recording caches preserve source order. Aggregation keeps the first duplicate participant/session/task record, joins the five modalities, removes duplicate column names and averages within participant and task group.
4. Build dynamic_bytask before harmonics so harmonics are not inadvertently included among the five dynamic caches. The exact cache set is checked. No unrelated significance sweep is run. The separate dynamic_participant convenience matrix is unused by this paper; its distinct silence/filter rules must not replace dynamic_bytask.
5. General-task harmonic summaries use the unchanged extract_linear_harmonics.summarise function. The resulting features are float32 and combined rows are sorted by participant/session/task. Free speech lacks the content-bearing spectrogram structurally.
6. Preparation determines participant/column order with the original cohort/feature code and regenerates RepeatedStratifiedKFold(5,3,20260725). The final payload has eight timing-off/on dynamic matrices, screening acoustic/harmonic blocks and a 3-column age/sex/country baseline. Duration/frame counts remain optional voice features; task-completion and recording-count indicators are excluded.
7. Availability checks, winsorization, imputation, scaling, filtering/projection and candidate selection remain inside training folds. Grids remain 96 screening, 160 dedicated discriminator, 16 secondary discriminator and 8 baseline candidates. Seeds, the 0.005 tie rule, preprocessing and probability composition are unchanged.
8. pdci_fully_nested_20260911.py is called for **prepare only**. Its superseded model evaluation is never rerun. The reported evaluation is pdci_demographic_baseline_20260911.
9. Seeds: outer 20260725; inner 20260725 + outer index * 1009; F1 bootstrap 20270636; F5 20260912; A5 20261001; F11-CAL 20261107/08/09. Each bootstrap uses 5000 prescribed draws. Original BH3 is retained. Calibration uses fixed held-out probabilities without model updating.

## Outputs and expected checks

All data/ files and every local_only/ directory are controlled participant derivatives and excluded from this release. Logs remain local. Only aggregate tables/receipts should be shared.

| Requested result | New workspace output |
|---|---|
| Table 2 | results/pdci_demographic_baseline_20260911/auc_intervals.csv and primary_baseline_comparisons.csv |
| Table 4 | results/pdci_a5_matched_policy_20261001/policy_comparison.csv and paired_primary_voice_minus_baseline.csv |
| Calibration | results/pdci_calibration_hardened_20261104/probability_scores.csv, calibration_diagnostics.csv, repeat_probability_scores.csv, repeat_calibration_diagnostics.csv |
| Input gate | qa/INPUTS_GATE.json |
| Complete local comparison | qa/RESULT_RECONCILIATION.json |

Canonical stage-2 AUROCs are voice 0.8204301075 and baseline 0.6874551971; gain 0.1329749104, BH3 adjusted p approximately 0.308. Table 4 voice/baseline primary-policy PD correctly assigned is 84/90 versus 74/90; CI is 22/62 versus 19/62; referrals are 366 versus 421. Original inferential families are preserved.

Local validation requires exact strings, IDs/order, integer decisions, feature arrays and missingness masks. Aggregate tables use absolute tolerance 1e-9 with rtol=0. Parquet byte hashes may differ due to metadata and local paths; value-level equality is the scientific gate. Report every mismatch instead of rounding it away.

Local reproduction alone does not establish clean installation, public hosting, a licence or a DOI. Those remain explicitly reported statuses.


## Portable-copy execution qualification

See [PORTABLE_CHANGES.md](PORTABLE_CHANGES.md). The frozen-plus-runtime-adapter chain passed released-feature-to-result reconciliation. This portable source copy incorporates the path correction and has separate AST/path smoke tests; no clean-install or repeated full-chain validation is claimed. Historical manifests retain their original scope; PORTABLE_MANIFEST.json is current.
