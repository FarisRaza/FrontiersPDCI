R15 command update: use the calibration step in REPRODUCE_FROM_FEATURES.md. It creates a new FROZEN_SPEC.json from the reconstructed local predictions and current script/protocol hashes. Do not copy historical frozen hashes to a different rerun. The following paragraphs describe the original R14 diagnostic.

# F11-CAL diagnostic reproduction

The 4 November R14 addition evaluates unchanged original held-out probabilities. It adds binary/multiclass Brier and natural-log losses and binary weak-calibration diagnostics, without predictive refitting, model updating or threshold selection. The protocol, seeds, numerical conventions, audit amendment and aggregate results are in results/pdci_calibration_hardened_20261104.

Use the recorded scientific environment in requirements.txt. After reproducing the canonical September11 output as described in README.md, choose a NEW folder inside your local analysis project's results directory. Copy ANALYSIS_PLAN.md and FROZEN_SPEC.json from this diagnostic receipt folder into that new folder. Run:

    python src/pdci_calibration_20261104_v2.py --analysis-root <your-analysis-root> --output <your-analysis-root>/results/<new-diagnostic-run>

The script reads the original participant_oof_predictions.parquet, all_fold_predictions.parquet and auc_intervals.csv in place at the protocol's canonical relative locations. These participant-level files are not distributed here and require authorized local reconstruction. It checks all input and code hashes, passes synthetic and canonical gates, then writes only aggregate tables. Existing result files are never overwritten. Self-tests without study-data access:

    python src/pdci_calibration_20261104_v2.py --analysis-root <your-analysis-root> --self-test-only

The audit-hardened implementation adds explicit complete/quasi separation detection after an artificial edge-case failure was found in the initial code audit. No study/bootstrap fit was affected. Its full rerun reproduced all six diagnostic output files byte-for-byte. A blind, separately coded implementation matched all 58 aggregate rows and 310 numeric values; the code audit and repair were reviewed separately. The constant-risk diagnostic API rejects the unidentified slope; an offset intercept alone could be calculated in that hypothetical case. No actual diagnostic had a constant predictor.

Internal fixed-prediction intervals omit development/retraining and overlapping-training-set uncertainty. Binary intercept/slope assessment and multiclass losses do not establish full multiclass calibration, external transportability or clinical net benefit. The original BH3 and subgroup BH2 families remain unchanged.

Final verification closure is recorded in results/pdci_calibration_hardened_20261104/INDEPENDENT_AUDIT_ADDENDUM.json (PASS). The earlier COMPLETION.json is preserved as a historical run receipt; its pending-verification status is superseded by this independent closure, not silently rewritten.
