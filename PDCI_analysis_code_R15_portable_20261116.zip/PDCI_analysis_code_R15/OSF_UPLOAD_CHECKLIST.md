# Author-controlled OSF upload checklist

The supplied ZIP is prepared locally. No upload, publication, registration, DOI request or external contact has been performed.

**OSF notice — verified 16 November 2026.** New Projects and components can no longer be created; existing Projects become read-only on 19 February 2027. [OSF Projects transition](https://help.osf.io/article/727-osf-projects-transition). This archive can go to an appropriate existing Project while uploads remain enabled. [Read-only Project guidance](https://help.osf.io/article/711-read-only-project-access). If no suitable Project exists, hosting and project type remain author decisions. This completed study has not been converted into a preregistration.

1. Review REPRODUCTION_STATUS.json and the verification receipts. They distinguish completed cached execution, attempted/full feature reconstruction and untested clean installation.
2. Choose a code licence and replace LICENSE_SELECTION.md with the actual approved licence text. No licence has been selected by the agent.
3. Review the project description and manuscript author order. Yicheng Peng and Nithila Sadheesh remain Writing - review and editing.
4. Select an appropriate existing OSF Project that you control and whose scope fits this archive. Confirm that it is still editable, that you have upload permission, and which files reviewers can access. If none is suitable, decide hosting/project type before uploading; this package does not choose another host or create a registration.
5. Upload only PDCI_analysis_code_R15_20261116.zip (or its validated extracted contents), not the project analysis folders. Verify the ZIP SHA256 against ARCHIVE_VALIDATION.json.
6. Confirm that no features/, phenotype/, data/, local_only/, credentials, raw recordings, participant tables or private local paths were added. The local allowlist/credential audit is in ARCHIVE_VALIDATION.json.
7. Obtain the actual reviewer-accessible OSF project or view-only URL and test that access works for the intended reviewer. Supply that URL for the response/manuscript; no placeholder is a usable link.
8. Add a DOI only if actually issued; if it remains pending, the verified reviewer URL can be reported with the true DOI status.
9. Update the code-availability statement with the real URL, archive version/date and chosen licence. Submission and forum posting remain author actions.

Do not upload this checklist's parent local working directory. New derived participant data are outside this ZIP and remain controlled.
