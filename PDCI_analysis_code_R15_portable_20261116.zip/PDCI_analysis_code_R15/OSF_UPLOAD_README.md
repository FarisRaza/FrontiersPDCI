# OSF code archive handoff

**OSF notice — verified 16 November 2026.** New Projects and components can no longer be created; existing Projects become read-only on 19 February 2027. [OSF Projects transition](https://help.osf.io/article/727-osf-projects-transition). This archive can go to an appropriate existing Project while uploads remain enabled. [Read-only Project guidance](https://help.osf.io/article/711-read-only-project-access). If no suitable Project exists, hosting and project type remain author decisions. This completed study has not been converted into a preregistration.

The proposed upload is PDCI_analysis_code_R15_20261116.zip. Use ARCHIVE_VALIDATION.json beside the ZIP to verify its current SHA256 and audited contents. The archive is portable code, documentation and aggregate reference evidence. It contains no controlled feature tables, participant records, predictions or credentials.

Read OSF_UPLOAD_CHECKLIST.md before author-controlled upload and review OSF_PROJECT_DESCRIPTION.md as draft metadata. Nithila Sadheesh and Yicheng Peng retain Writing - review and editing; manuscript author order is unchanged. The author still selects the licence and supplies an actual reviewer-accessible URL and any issued DOI. No licence, hosting alternative, registration type or persistent identifier has been chosen by the agent.

REPRODUCTION_STATUS.json and R15_INDEPENDENT_VERIFICATION.json distinguish completed checks from pending work. An upload-ready file layout does not establish clean installation or completion of the raw-feature reproduction. No upload, publication, submission or external contact has occurred.
