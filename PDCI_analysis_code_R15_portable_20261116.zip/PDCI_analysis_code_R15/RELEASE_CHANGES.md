# Release changes and provenance

Prepared 3 November 2026 in a separate code-only candidate. The previous prepared release and all historical analysis scripts/results remain untouched. This is not a published archive. Licence and DOI await the author. No model, bootstrap, participant-file read, clean install, or figure execution was performed.

## Code changes from the 26 October prepared copy

- `src/pdci_fully_nested_20260911.py`: Remove the exploratory script from the input hash list; no computational dependency remains.
- `src/pdci_fully_nested_20260911.py`: Remove the need to fit an exploratory model just to recover partition audit files. The same splitter, seed, participant order and labels remain unchanged; the receipt no longer claims historical comparison.
- `src/pdci_demographic_baseline_20260911.py`: Retain exact equality to independently regenerated partitions; remove the additional unavailable historical-fold check and label the receipt accurately.
- `src/pdci_demographic_baseline_20260911.py`: Remove hashes of the unavailable exploratory fold files.
- `src/pdci_demographic_baseline_20260911.py`: Exclude noncomputational private manuscript hashing.
- `src/pdci_demographic_baseline_20260911.py`: Do not claim verification of undistributed manuscripts.
- `src/pdci_sensitivity_policy_20260912.py`: Freeze the analysis sources and receipts, without walking private manuscripts or summaries.
- `src/pdci_a5_matched_policy_20261001.py`: Remove noncomputational private manuscript hashing.
- `src/pdci_a5_matched_policy_20261001.py`: Keep hashes for every computational input, with no manuscript prerequisite.
- `src/pdci_a5_matched_policy_20261001.py`: Verify the actual release input set.
- `src/pdci_a5_matched_policy_20261001.py`: Do not claim verification of undistributed manuscripts.
- `src/pdci_a8_cohort_recount_20261007.py`: Remove two private working documents that were only hash-pinned, never read to compute counts.
- `src/pdci_a8_cohort_recount_20261007.py`: Remove absent private documents from required inputs; published reference constants remain unchanged.
- `src/pdci_a8_cohort_recount_20261007.py`: Explain that the unchanged reference constants are protected by the script hash.
- `requirements.txt`: Qualify retrospective September environment provenance without changing any pin.
- `figures/scripts/build_frontiers_figures_20261007.py`: Replace historical/private provenance prose with the actual public-reproduction source graphic and formatting helper.
- `figures/scripts/build_frontiers_figures_20261007.py`: Do not carry a historical raster-font measurement forward as if it measured a future public rerun.

Two new entry points call existing operations without changing their mathematics: `src/build_pdci_dynamic_bytask.py` calls only the original cache builder after a cache-inventory check; `figures/scripts/prepare_supplementary_figures.py` performs the documented image-format conversions. Neither was executed here.

Exact code diffs are in `source_diffs/`. `SOURCE_MANIFEST.json` records every archived file's hash, the predecessor code hashes and the original protocol hashes. `STATIC_VALIDATION.json` lists syntax and AST checks. All code functions not explicitly listed as changed are AST-identical to the previous prepared copy after removal of docstrings. Changed function bodies are restricted to preparation/provenance and receipt labels, not fit, selection, prediction, threshold, metric or bootstrap calculations. Static comparison is not evidence of an executed rerun.

## Public protocols and documentation

Five public reproduction protocols and the sensitivity-policy execution note are supplied. They remove private coordination material and noncomputational document requirements. The reviewer protocol includes the documented section-seed clarification and correctly describes the fixed, full-cohort-trained demographic comparator. They are explicitly adapted documents, not the original frozen bytes, and a future rerun must freeze new hashes. The original A8 reference numbers remain in its script unchanged; no placeholder private files are needed.

The README describes the fresh execution sequence, environmental provenance, Windows limitation, restricted-data outputs, lack of end-to-end testing, and pending publication/licence. The historical chronology remains separately labelled. The old availability-statement draft was not copied because its public-release claims are premature.

## Relationship to the originally run code

The prior prepared copy already changed five files for portable paths and comment cleanup. Its documented original hashes are carried as provenance only; this release does not claim that edited scripts have the original historical hashes. In particular, Supplementary Table S3's hash prefixes identify the analysis scripts as run, not these portable copies. No old frozen receipt is supplied as though it certified this new source.

## Material limits

Publication and author-selected licence/DOI remain outstanding. A clean, credentialed Windows rerun remains unperformed. September software versions were inferred retrospectively; October receipts directly recorded core runtime versions. Independent historical implementations for A5/A8/stages/reviewer analyses are not bundled. Future S1/S2 raster exports need visual font/line inspection. Runtime freeze receipts contain the rerun user's local input paths and participant-level outputs remain under the original data-use agreement; do not redistribute either indiscriminately.

## 4 November 2026: cached execution verification

All 15 canonical outer fits were executed in an isolated copy in the recorded existing Windows environment, following exact cache reconstruction. All 75 choices, 4320 candidate inner AUROCs, continuous outer scores and selected inner scores matched exactly. F1/F5/A5 aggregate comparisons and the bundled independent F1/F5 audits passed. No scientific source code changed in this update. README execution status, CACHE_EXECUTION.md, EXECUTION_VERIFICATION.json and this manifest were updated. Raw trajectory feature extraction, clean installation and figure export remain untested. The author still controls the licence and public archive/DOI.
