# Cached execution verification

A separate copy of this prepared release was tested locally using credentialed frozen feature caches, without copying those caches into the archive. The existing Windows/Python environment was used. The canonical 750-person feature payload was reconstructed and compared exactly, followed by all 15 fresh nested outer fits and the original policy/A5 calculations. The aggregate receipt is EXECUTION_VERIFICATION.json.

The local harness routed config input paths to the authorized caches, kept output paths under a new workspace, and supplied the preceding frozen payload as a reconstruction input. The unchanged fit_fold functions ran in two isolated single-thread processes. No scientific function, grid, seed, threshold or inferential calculation was changed. This check exercised the functions through a local path-routing harness; it did not test the entire README command sequence from a new data download.

To repeat the published raw-data workflow, follow README.md in an empty analysis workspace with credentialed data. The archive does not supply feature caches or participant predictions. Never overlay it onto an existing frozen run. A cache-based execution requires those authorized caches separately and explicit read-only input/new-output path routing; the local execution harness is not part of the public release because it contains project-specific paths.

Limitations: clean installation, raw trajectory feature extraction and figure export were not rerun. A static syntax/import receipt describes preparation; it is not a replacement for the execution receipt. The public archive and licence still require author action.
