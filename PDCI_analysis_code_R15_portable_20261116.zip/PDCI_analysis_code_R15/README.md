# PD CI manuscript analysis code R15

Analysis code for **Voice-based differentiation of Parkinson's disease and cognitive impairment in Bridge2AI-Voice**, Frontiers in Digital Health manuscript 2021657.

Authors: Faris Raza; Yicheng Peng; Nithila Sadheesh. Yicheng Peng and Nithila Sadheesh are credited with Writing - review and editing, as confirmed by the author. This repository does not add other author declarations.

## Start here

- [REPRODUCE_FROM_FEATURES.md](REPRODUCE_FROM_FEATURES.md): reconstruct analytic inputs from the controlled-access adult v3.0.0 feature tables, then reproduce Tables 2 and 4 and the calibration summaries.
- [ROUND2_ANALYSES.md](ROUND2_ANALYSES.md): run the separate F12 matched-model and F13 common-training-budget analyses.
- [REPRODUCTION_STATUS.json](REPRODUCTION_STATUS.json): exact executed/verified scope and remaining limits.
- [R15_INDEPENDENT_VERIFICATION.json](R15_INDEPENDENT_VERIFICATION.json): separate F12/F13 numerical verification status.
- [OSF_UPLOAD_README.md](OSF_UPLOAD_README.md): dated OSF availability and archive handoff guidance.
- [OSF_UPLOAD_CHECKLIST.md](OSF_UPLOAD_CHECKLIST.md): author-controlled archive upload steps and remaining metadata choices.

The software reads an existing controlled dataset in place and writes to a separate new analysis workspace. No raw data copying or linking is required. Do not overlay the scripts or outputs onto frozen study runs.

## Contents

| Path | Purpose |
|---|---|
| reproduce_from_features.py | Explicit initialization, freeze, extraction, input gate, fitting, policy, calibration and reconciliation stages |
| src/ | Original scientific modules with documented I/O-only portability changes |
| results/*/ANALYSIS_PLAN.md | Public protocols for new local reruns |
| results/*/support/ | Independent original bootstrap/policy audit code |
| results/pdci_round2_20261116/ | Portable F12/F13 scripts, protocols and aggregate references where available |
| figures/ | Original figure-generation code; figure export execution status is separate |
| requirements.txt | Pinned recorded scientific environment, with provenance notes |
| SEEDS_AND_RUNS.md | Seeds and historical run chronology |
| r15_source_diffs/ | Exact R15 portability changes; original private paths are redacted in path-only diffs |
| R15_SOURCE_MANIFEST.json | Current R15 file hashes; earlier SOURCE_MANIFEST files are historical provenance |
| R15_REVIEWER_CODE_PROVENANCE.json | Source hashes and function/class equality for F12/F13 portable copies |

Only the code, protocols, documentation and aggregate references/verification receipts are distributed. The archive does not contain controlled feature tables, recordings, phenotype tables, participant labels, caches, fitted payloads, participant predictions or credentials. The local reproduction workspace's data/ and local_only/ directories must stay under controlled access.

## Data and environment

Obtain **Bridge2AI-Voice adult v3.0.0**, dataset DOI **10.13026/k81f-qr68**, through credentialed PhysioNet access under the applicable agreement. The dataset is not redistributed.

Use Windows and Python 3.13.5 with requirements.txt. The core versions are numpy 2.4.6, pandas 2.3.3, scipy 1.18.0, scikit-learn 1.9.0, pyarrow 25.0.0, joblib 1.5.3 and threadpoolctl 3.6.0. Use one process and one numerical-library thread. A clean installation and execution on other operating systems have not been verified.

The original demographic comparison and BH3 inference family are retained. The new matched-ridge comparison is separately labelled F12-MM with exploratory BH6; the operating-budget analysis is F13-OP with pointwise fixed-prediction intervals. Neither replaces the original analysis.

## Verification and provenance

The earlier R14 cache-to-result execution reconstructed the 750-person payload exactly and reproduced all 15 nested outer fits, 75 selected configurations and 4,320 candidate inner AUROCs, plus the original policies and matched comparison. It did not rerun the original raw trajectory extraction or a clean installation. CACHE_EXECUTION.md and EXECUTION_VERIFICATION.json describe that historical check.

The original F13 common-training-budget analysis has passed independent verification of all 1,638 rows and 5,376 numeric cells, exactly. Its frozen completion report remains unchanged; the separate verification receipt records that later pass. F12 independent reconciliation passed for the original frozen implementations: 120 selected candidates and 60 selected-inner probability blocks across four arms and 15 outer folds, with 3,000 fits per implementation. See validation/F12_RECONCILIATION.json. The portable source copy has not been refit.

The R15 driver adds a controlled-release-to-input path, small-batch extraction and exact optional comparison against local canonical caches. The original per-recording summary and model-fit functions remain unchanged. Read REPRODUCTION_STATUS.json and current receipts for what actually completed; preparation and static checks alone are not numerical reproduction.

Public reruns require only the controlled release. Private historical caches are optional for a stricter local equality check; they are not supplied in the archive. Local verification freezes all input/code/protocol hashes, checks dtypes and values, and stops on a failed input gate.

## Licence and availability

**OSF notice — verified 16 November 2026.** New Projects and components can no longer be created; existing Projects become read-only on 19 February 2027. [OSF Projects transition](https://help.osf.io/article/727-osf-projects-transition). This archive can go to an appropriate existing Project while uploads remain enabled. [Read-only Project guidance](https://help.osf.io/article/711-read-only-project-access). If no suitable Project exists, hosting and project type remain author decisions. This completed study has not been converted into a preregistration.

**Licence remains an author choice.** See LICENSE_SELECTION.md. No public OSF URL or DOI is claimed by this prepared package. OSF_PROJECT_DESCRIPTION.md is a metadata draft; replace placeholders only with the actual licence and reviewer-accessible URL after the author selects an appropriate existing Project and uploads the archive. No upload, publication or submission has been performed by the agent.


## Portable-copy execution qualification

See [PORTABLE_CHANGES.md](PORTABLE_CHANGES.md). The frozen-plus-runtime-adapter chain passed released-feature-to-result reconciliation. This portable source copy incorporates the path correction and has separate AST/path smoke tests; no clean-install or repeated full-chain validation is claimed. Historical manifests retain their original scope; PORTABLE_MANIFEST.json is current.
