"""Shared paths, a path guard and a small Markdown reader from the journal build of the PD/CI manuscript (2026-10-07).

Only ROOT, FIG, SRC, guard(), rel() and sha256() are used by scripts/build_frontiers_figures_20261007.py. The
Markdown reader (blocks and inline runs) and the word-count, citation and display helpers served the manuscript
document build, which is not part of this code archive.

Path guard: the figure build reads only the figure code, the figure files and named aggregate result files. Any
participant-level path (local_only/ folders, analysis/data/, the dataset's features/ and phenotype/ folders,
.parquet files) or a folder this paper does not use raises before the file is touched.

ROOT is the figure folder (the figures/ folder of the code archive, copied to DATA_ROOT/analysis/<figure
folder>/); ANALYSIS is DATA_ROOT/analysis.

Standard library only, so every interpreter can import it.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # the figure folder
ANALYSIS = ROOT.parent                               # DATA_ROOT/analysis
RESULTS = ANALYSIS / 'results'
SRC = ROOT / 'source'
FIG = ROOT / 'figures'
BUILD = ROOT / 'build'
OUT = ROOT / 'deliverables'
QA = ROOT / 'qa'
TABLES = ROOT / 'tables'
NOTES = ROOT / 'notes'
MAN_MD = SRC / 'manuscript.md'
SUP_MD = SRC / 'supplementary.md'
MANIFEST = ROOT / 'supplementary_data' / 'descriptor_name_manifest.csv'
REFERENCE_DOCX = BUILD / 'reference_frontiers.docx'
DOC_PY = 'python'               # interpreter of the document build steps (not part of this archive)
ANALYSIS_PY = 'python'          # interpreter of the analysis environment (requirements.txt)

FORBIDDEN_PARTS = ('local_only', '.secrets', 'features', 'phenotype', 'data')
FORBIDDEN_SUBSTRINGS = (
    'pdci_restricted_task_nested_20260914', 'followups_20260914_task_battery',   # not an input of this paper
    'publication_polish_20260915',                                               # not an input of this paper
    'pdci_fully_nested_20260911',                                                # not read by the figure build
    'pd_stage',                                                                  # not an input of this paper
)
FORBIDDEN_SUFFIXES = ('.parquet', '.env')


def guard(path) -> Path:
    """Raise if a path is participant-level, secret, or excluded; return the resolved path otherwise."""
    p = Path(path).resolve()
    s = str(p).replace('\\', '/')
    rel_parts = p.relative_to(ANALYSIS.parent.parent).parts if str(p).startswith(str(ANALYSIS.parent.parent)) else p.parts
    for bad in FORBIDDEN_PARTS:
        if bad in rel_parts and bad != 'data':
            raise PermissionError(f'forbidden path component {bad!r}: {s}')
    if 'analysis/data/' in s or s.endswith('analysis/data'):
        raise PermissionError(f'participant-level derived data folder: {s}')
    for bad in FORBIDDEN_SUBSTRINGS:
        if bad in s:
            raise PermissionError(f'excluded input: {s}')
    if p.suffix.lower() in FORBIDDEN_SUFFIXES:
        raise PermissionError(f'forbidden file type: {s}')
    return p


def sha256(path) -> str:
    h = hashlib.sha256()
    with open(guard(path), 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def rel(path) -> str:
    """Path relative to adult/analysis/, forward slashes (no local drive letters in outputs)."""
    p = Path(path).resolve()
    try:
        return str(p.relative_to(ANALYSIS)).replace('\\', '/')
    except ValueError:
        return p.name


def read_md(path) -> str:
    return guard(path).read_text(encoding='utf-8')


# ------------------------------------------------------------------ Markdown blocks
HEADING = re.compile(r'^(#{1,6})\s+(.*?)\s*$')
IMAGE = re.compile(r'^!\[([^\]]*)\]\(([^)]+)\)(\{[^}]*\})?\s*$')
LIST_ITEM = re.compile(r'^(\d+)(?:\\)?\.\s+(.*)$')      # "12. text" or "40\. text" (escaped in the supplement)
SEP_CELL = re.compile(r'^:?-{3,}:?$')


def split_row(line: str) -> list[str]:
    s = line.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|') and not s.endswith('\\|'):
        s = s[:-1]
    return [c.strip() for c in re.split(r'(?<!\\)\|', s)]


def parse_blocks(text: str) -> list[dict]:
    """Split clean Markdown into blocks: heading, para, item (numbered reference), table, image.

    Each block keeps its 1-based source line numbers. Paragraphs are runs of consecutive non-blank lines that are
    not headings, table rows, images or numbered items (the clean files hold one paragraph per line)."""
    lines = text.split('\n')
    blocks, i = [], 0
    while i < len(lines):
        raw = lines[i]
        s = raw.strip()
        if not s:
            i += 1
            continue
        if s.startswith('<!--'):
            raise ValueError(f'HTML comment left in a clean file at line {i + 1}')
        h = HEADING.match(s)
        if h:
            blocks.append({'type': 'heading', 'level': len(h.group(1)), 'text': h.group(2), 'line': i + 1})
            i += 1
            continue
        if s.startswith('|'):
            start, rows = i, []
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append(split_row(lines[i]))
                i += 1
            if len(rows) < 2 or not all(SEP_CELL.match(c) for c in rows[1]):
                raise ValueError(f'table at line {start + 1} lacks a header separator row')
            header, body = rows[0], rows[2:]
            ncol = len(header)
            bad = [k for k, r in enumerate(body) if len(r) != ncol]
            if bad:
                raise ValueError(f'table at line {start + 1}: rows {bad} do not have {ncol} cells')
            blocks.append({'type': 'table', 'header': header, 'rows': body, 'line': start + 1, 'end': i})
            continue
        m = IMAGE.match(s)
        if m:
            blocks.append({'type': 'image', 'alt': m.group(1), 'src': m.group(2), 'attrs': m.group(3) or '',
                           'line': i + 1})
            i += 1
            continue
        m = LIST_ITEM.match(s)
        if m:
            blocks.append({'type': 'item', 'number': int(m.group(1)), 'text': m.group(2), 'line': i + 1})
            i += 1
            continue
        start, buf = i, [s]
        i += 1
        while i < len(lines) and lines[i].strip():
            t = lines[i].strip()
            if HEADING.match(t) or t.startswith('|') or IMAGE.match(t) or LIST_ITEM.match(t) or t.startswith('<!--'):
                break
            buf.append(t)
            i += 1
        blocks.append({'type': 'para', 'text': ' '.join(buf), 'line': start + 1})
    annotate(blocks)
    return blocks


TABLE_CAPTION = re.compile(r'^\*\*(?:Supplementary )?Table (S?\d+)\.\*\*')
FIGURE_LEGEND = re.compile(r'^\*\*(?:Supplementary )?Figure (S?\d+)\.\*\*')
SUBCAPTION = re.compile(r'^\*([A-D])\.\s.*\*$')


def annotate(blocks: list[dict]) -> None:
    """Mark table captions, sub-captions, figure legends, the top-level section of every block, and give each
    table its label (Table 1, Table S18A, ...)."""
    top, current_caption = '', None
    for k, b in enumerate(blocks):
        if b['type'] == 'heading' and b['level'] == 1:
            top = b['text']
        b['section'] = top
        if b['type'] == 'para':
            m = TABLE_CAPTION.match(b['text'])
            if m:
                b['role'] = 'table_caption'
                b['label'] = 'Table ' + m.group(1)
                current_caption = b
                continue
            m = FIGURE_LEGEND.match(b['text'])
            if m:
                b['role'] = 'figure_legend'
                b['label'] = 'Figure ' + m.group(1)
                continue
            m = SUBCAPTION.match(b['text'])
            if m and k + 1 < len(blocks) and blocks[k + 1]['type'] == 'table':
                b['role'] = 'table_subcaption'
                b['panel'] = m.group(1)
                continue
            if k > 0 and blocks[k - 1]['type'] == 'table' and top == 'Tables':
                b['role'] = 'table_note'
                b['label'] = blocks[k - 1].get('label')
        if b['type'] == 'table':
            if current_caption is None:
                raise ValueError(f'table at line {b["line"]} has no caption before it')
            prev = blocks[k - 1]
            panel = prev.get('panel') if prev.get('role') == 'table_subcaption' else ''
            b['label'] = current_caption['label'] + (panel or '')
            b['caption_line'] = current_caption['line']


# ------------------------------------------------------------------ inline runs
ESCAPES = {'\\<': '<', '\\>': '>', '\\.': '.', '\\*': '\x01', '\\_': '_', '\\|': '|', '\\[': '[', '\\]': ']'}
PLACEHOLDER = re.compile(r'\{\{AUTHOR:.*?\}\}', re.S)
TOKENS = [
    ('ph', PLACEHOLDER),
    ('b', re.compile(r'\*\*(.+?)\*\*')),
    ('i', re.compile(r'(?<![\w*])\*(?![\s*])(.+?)(?<![\s*])\*(?![\w*])')),
    ('sup', re.compile(r'\^([^\^\s]+)\^')),
]


def unescape(text: str) -> str:
    for a, b in ESCAPES.items():
        text = text.replace(a, b)
    return text


def runs(text: str, fmt: dict | None = None) -> list[tuple[str, dict]]:
    """Inline Markdown to a list of (text, format) runs; format keys b, i, sup, ph."""
    fmt = dict(fmt or {})
    text = unescape(text)
    out = []
    pos = 0
    while pos < len(text):
        best = None
        for kind, rx in TOKENS:
            m = rx.search(text, pos)
            if m and (best is None or m.start() < best[1].start()):
                best = (kind, m)
        if best is None:
            out.append((text[pos:], fmt))
            break
        kind, m = best
        if m.start() > pos:
            out.append((text[pos:m.start()], fmt))
        if kind == 'ph':
            out.extend(runs(m.group(0), dict(fmt, ph=True)) if '**' in m.group(0) else [(m.group(0), dict(fmt, ph=True))])
        elif kind == 'sup':
            out.append((m.group(1), dict(fmt, sup=True)))
        else:
            out.extend(runs(m.group(1), dict(fmt, **{kind: True})))
        pos = m.end()
    return [(t.replace('\x01', '*'), f) for t, f in out if t]


def plain(text: str, sup_style: str = 'plain') -> str:
    """Plain text of inline Markdown. sup_style 'plain' keeps superscripts as letters; 'bracket' writes [a]."""
    parts = []
    for t, f in runs(text):
        parts.append(f'[{t}]' if (f.get('sup') and sup_style == 'bracket') else t)
    return ''.join(parts)


# Frontiers in Digital Health uses the Frontiers Vancouver (numbered) style, whose
# in-text citations are Arabic numerals in parentheses (Frontiers author guidelines and journal style table, both
# read 2026-10-07). The clean Markdown keeps square brackets; only the DOCX prints [n] as (n).
CITATION = re.compile(r'\[(\d+(?:\s*[-,]\s*\d+)*)\]')


def docx_citations(text: str) -> str:
    """Numbered citations [n], [n, m], [n-m] of the clean Markdown as printed in the DOCX: (n), (n, m), (n-m)."""
    return CITATION.sub(r'(\1)', text)


def count_words(text: str) -> int:
    """Word-count rule: whitespace tokens that contain a letter or digit."""
    return sum(1 for tok in text.split() if any(ch.isalnum() for ch in tok))


REF_PATTERN = re.compile(
    r'\b(Supplementary\s+)?(Tables?|Figures?)\s+'
    r'((?:S?\d+[A-D]?)(?:\s*(?:,|and|to|-|or)\s*(?:S?\d+[A-D]?))*)')


def cited_displays(text: str) -> list[str]:
    """Display labels cited in text: 'Table 3', 'Table S8', 'Figure 2' (ranges 'S8 to S15' expanded)."""
    found = []
    for m in REF_PATTERN.finditer(text):
        kind = 'Table' if m.group(2).startswith('Table') else 'Figure'
        toks = re.findall(r'S?\d+[A-D]?|to|-', m.group(3))
        prev = None
        k = 0
        while k < len(toks):
            t = toks[k]
            if t in ('to', '-') and prev is not None and k + 1 < len(toks):
                a, b = prev, toks[k + 1]
                pa, pb = a.startswith('S'), b.startswith('S')
                na, nb = int(re.sub(r'\D', '', a)), int(re.sub(r'\D', '', b))
                for n in range(na + 1, nb + 1):
                    found.append(f'{kind} {"S" if pb else ""}{n}')
                prev = b
                k += 2
                continue
            if t not in ('to', '-'):
                label = re.sub(r'[A-D]$', '', t) if kind == 'Figure' else t
                found.append(f'{kind} {label}')
                prev = t
            k += 1
    return found
