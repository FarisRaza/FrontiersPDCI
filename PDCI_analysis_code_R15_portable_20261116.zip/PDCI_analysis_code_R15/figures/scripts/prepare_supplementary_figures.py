"""Format existing supplementary figure outputs; computes no analysis or new plot.

Run from DATA_ROOT/analysis after the ROC builder and reviewer analyses.
"""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT.parent
FIG = ROOT / "figures"

def export(source, stem):
    with Image.open(source) as original:
        rgba = original.convert("RGBA")
        rgb = Image.new("RGB", rgba.size, "white")
        rgb.paste(rgba, mask=rgba.getchannel("A"))
        width = 2126
        height = round(rgb.height * width / rgb.width)
        rgb = rgb.resize((width, height), Image.Resampling.LANCZOS)
        rgb.save(FIG / (stem + ".png"), dpi=(300, 300))
        rgb.save(FIG / (stem + ".tif"), dpi=(300, 300), compression="tiff_lzw")

if __name__ == "__main__":
    FIG.mkdir(parents=True, exist_ok=True)
    export(ROOT / "pdci/figures/Figure_1_stage_ROC.png", "figureS1_roc_curves")
    export(ANALYSIS / "results/pdci_review_analyses_20261026/s4_score_distributions.png", "FigureS2")
