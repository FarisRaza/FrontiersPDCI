"""Journal figure files: figures/Figure1-4.tif and FigureS1.tif (RGB, LZW, 300 dpi, 2126 px = 180 mm wide),
with PNG previews (Figure1-4.png, FigureS1.png) and figures/figure_provenance_20261007.json.

Figures 1-4 are drawn by source/build_figures.py (the PNG and SVG sources in figures/), whose drawings are 157
to 185 mm wide at 300 dpi because they are saved with a tight bounding box. This script re-renders exactly
those drawings from the same figure code, unchanged, at the resolution that makes each figure 2126 px wide,
then tags the file 300 dpi, so every figure is 180 mm wide at 300 dpi without resampling the 300-dpi raster.
The figure code re-reads only the aggregate result files named in its docstring and re-runs its own
assertions. Nothing is written to source/ and the 300-dpi figure files (figures/figure*_*.png|svg|tif) are
not modified; the drawings are replaced in memory by patching the module's save() function.

A content check compares each new figure, downsampled to the size of the 300-dpi PNG, with that PNG.
Supplementary Figure S1 (figures/figureS1_roc_curves.tif and .png, already 2126 px, RGB, LZW, 300 dpi) is
copied byte for byte. It is the ROC figure drawn by pdci/support/build_pdci_assets.py (Figure_1_stage_ROC.png),
flattened on white and resampled (Lanczos) to 2126 px wide, saved as an LZW TIFF and a PNG at 300 dpi.

Smallest text: the journal asks that the smallest visible text be at least 8 pt at actual size. The smallest
text is measured on the text elements drawn in the final export render (tick labels included) and multiplied
by the export scale; a rounding difference of a few pixels in the tight-cropped width is removed by cropping
or padding white edge columns, so no resampling changes the scale (if resampling were needed, its factor
would enter the font size); the build stops if any figure's smallest text is below MIN_PT at 180 mm.

Thinnest line: the journal asks that any line in a graphic be at least 2 pt wide. The export render also
records the width of every stroked element it draws (lines, marker edges, patch edges, collection lines;
zero-width, fully transparent and zero-length tick marks draw no line and are skipped), and the build stops
if the thinnest, times the export scale and any resampling factor, is below MIN_LINE_PT at 180 mm.

Location: this file is expected at DATA_ROOT/analysis/<figure folder>/scripts/, next to common_20261007.py,
with source/build_figures.py in the same figure folder.
Run (from the figure folder): python scripts/build_frontiers_figures_20261007.py
"""
from __future__ import annotations

import importlib.util
import io
import json
import shutil
import sys
from pathlib import Path

import matplotlib

matplotlib.use('Agg')
import matplotlib.collections as mcoll  # noqa: E402
import matplotlib.figure as mfigure  # noqa: E402
import matplotlib.lines as mlines  # noqa: E402
import matplotlib.patches as mpatches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.text as mtext  # noqa: E402
from matplotlib.colors import to_rgba, to_rgba_array  # noqa: E402
from PIL import Image, ImageChops, ImageStat  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common_20261007 import FIG, ROOT, SRC, guard, rel, sha256  # noqa: E402

DPI = 300
W_PX = 2126                      # 180 mm at 300 dpi
MIN_PT = 8.0                     # Frontiers: smallest visible text at least 8 pt at actual size
MIN_LINE_PT = 2.0                # Frontiers: any line at least 2 pt wide at actual size
DRAWN: list = []                 # text elements drawn in the current render pass
LINES: list = []                 # (width pt, kind) of stroked elements drawn in the current pass
_text_draw, _fig_draw = mtext.Text.draw, mfigure.Figure.draw
_line_draw, _patch_draw, _coll_draw = mlines.Line2D.draw, mpatches.Patch.draw, mcoll.Collection.draw
_arrow_draw = mpatches.FancyArrowPatch.draw   # overrides Patch.draw without calling it (arrows, leaders)
NO_LINE = (None, 'None', 'none', '', ' ')


def _record_text(self, renderer):
    _text_draw(self, renderer)
    if self.get_visible() and self.get_text().strip():
        DRAWN.append((self.get_fontsize(), self.get_text()))


def _new_pass(self, renderer):
    DRAWN.clear()                # a tight-bbox save draws twice; keep the final pass only
    LINES.clear()
    return _fig_draw(self, renderer)


def _seen(c) -> bool:
    return c is not None and not (isinstance(c, str) and c.lower() == 'none') and to_rgba(c)[3] > 0


def _record_line(self, renderer):
    _line_draw(self, renderer)
    if not self.get_visible():
        return
    xs = self.get_xydata()
    name = type(self).__name__ + (f' {self.get_label()}' if not str(self.get_label()).startswith('_') else '')
    if (self.get_linestyle() not in NO_LINE and self.get_linewidth() > 0 and _seen(self.get_color())
            and len(xs) >= 2):
        LINES.append((self.get_linewidth(), f'line: {name}'))
    if (self.get_marker() not in NO_LINE and self.get_markersize() > 0 and self.get_markeredgewidth() > 0
            and _seen(self.get_markeredgecolor()) and len(xs) >= 1):
        LINES.append((self.get_markeredgewidth(), f'marker edge: {name} ({self.get_marker()})'))


def _record_patch(self, renderer):
    _patch_draw(self, renderer)
    if self.get_visible() and self.get_linewidth() > 0 and _seen(self.get_edgecolor()):
        LINES.append((self.get_linewidth(), f'patch edge: {type(self).__name__}'))


def _record_arrow(self, renderer):
    _arrow_draw(self, renderer)
    if self.get_visible() and self.get_linewidth() > 0 and _seen(self.get_edgecolor()):
        LINES.append((self.get_linewidth(), f'arrow: {type(self).__name__}'))


def _record_collection(self, renderer):
    _coll_draw(self, renderer)
    if not self.get_visible() or len(self.get_paths()) == 0:
        return
    ec = self.get_edgecolor()
    if isinstance(ec, str):
        if ec.lower() in ('none', 'face'):
            ec = self.get_facecolor() if ec.lower() == 'face' else []
    ec = to_rgba_array(ec) if len(ec) else []
    widths = [w for w in self.get_linewidths() if w > 0]
    if widths and len(ec) and max(c[3] for c in ec) > 0:
        LINES.append((min(widths), f'collection: {type(self).__name__}'))


mtext.Text.draw = _record_text
mfigure.Figure.draw = _new_pass
mlines.Line2D.draw = _record_line
mpatches.Patch.draw = _record_patch
mcoll.Collection.draw = _record_collection
mpatches.FancyArrowPatch.draw = _record_arrow
STEMS = {'figure1_study_design': 'Figure1', 'figure2_paired_gains': 'Figure2',
         'figure3_policy_tradeoff': 'Figure3', 'figure4_decision_matrices': 'Figure4'}
PROV = {'built_by': 'scripts/build_frontiers_figures_20261007.py',
        'figure_code': {'path': 'source/build_figures.py', 'sha256': None},
        'receipts_read_by_figure_code': {}, 'outputs': {}, 'method': None}


def load_module():
    path = guard(SRC / 'build_figures.py')
    PROV['figure_code']['sha256'] = sha256(path)
    spec = importlib.util.spec_from_file_location('pdci_build_figures', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    orig_read = mod.read_csv

    def recording_read_csv(p):
        g = guard(p)
        PROV['receipts_read_by_figure_code'][rel(g)] = sha256(g)
        return orig_read(g)
    mod.read_csv = recording_read_csv
    for name in ('INPUT_AUDIT.json', 'FROZEN_SPEC.json', 'AUDIT.json'):   # read by figure1() with read_text
        g = guard(mod.BASE_RUN / name)
        PROV['receipts_read_by_figure_code'][rel(g)] = sha256(g)
    return mod


def flatten(im: Image.Image) -> Image.Image:
    if im.mode == 'RGB':
        return im
    im = im.convert('RGBA')
    bg = Image.new('RGB', im.size, (255, 255, 255))
    bg.paste(im, mask=im.split()[-1])
    return bg


def render(fig, dpi: float) -> Image.Image:
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight', pad_inches=0.05)
    buf.seek(0)
    im = Image.open(buf)
    im.load()
    return flatten(im)


def make_save(mod):
    def save(fig, stem):
        name = STEMS[stem]
        at300 = render(fig, DPI)
        scale = W_PX / at300.size[0]
        im = render(fig, DPI * scale)
        drawn = list(DRAWN)                          # texts of the final export render pass
        lines = list(LINES)                          # stroked elements of the same pass
        min_lw = min(w for w, _ in lines)
        thinnest = sorted({k for w, k in lines if w == min_lw})[:12]
        min_pt = min(s for s, _ in drawn)
        smallest = sorted({txt.replace(chr(10), ' / ')[:40] for s, txt in drawn if s == min_pt})
        adjust, resample = None, 1.0
        if im.size[0] != W_PX:                       # tight-bbox rounding can leave a pixel or two
            adjust = {'rendered_px': list(im.size)}
            d = im.size[0] - W_PX
            left = d // 2
            edges = ([im.crop((0, 0, left, im.size[1])), im.crop((im.size[0] - (d - left), 0, im.size[0], im.size[1]))]
                     if d > 0 else [])
            if d > 0 and all(e.size[0] == 0 or e.convert('L').getextrema() == (255, 255) for e in edges):
                im = im.crop((left, 0, left + W_PX, im.size[1]))   # only pure-white edge columns are removed
                adjust['method'] = f'cropped {d} white edge column(s); no resampling'
            elif -10 <= d < 0:                       # pad with white columns
                canvas = Image.new('RGB', (W_PX, im.size[1]), (255, 255, 255))
                canvas.paste(im, (-d // 2, 0))
                im = canvas
                adjust['method'] = f'padded {-d} white edge column(s); no resampling'
            else:
                resample = W_PX / im.size[0]
                im = im.resize((W_PX, round(im.size[1] * resample)), Image.LANCZOS)
                adjust['method'] = f'resampled by {resample:.5f} (included in min_font_pt_at_180mm)'
        min_at_180 = min_pt * scale * resample
        assert min_at_180 >= MIN_PT, (name, min_pt, scale, resample)
        min_lw_at_180 = min_lw * scale * resample
        assert min_lw_at_180 >= MIN_LINE_PT, (name, min_lw, scale, resample, thinnest)
        plt.close(fig)
        tif, png = FIG / f'{name}.tif', FIG / f'{name}.png'
        im.save(tif, compression='tiff_lzw', dpi=(DPI, DPI))
        im.save(png, dpi=(DPI, DPI), optimize=True)
        # content check against the 300-dpi PNG drawn by source/build_figures.py
        src_png = guard(FIG / f'{stem}.png')
        ref = flatten(Image.open(src_png))
        same_size = ref.size == at300.size
        small = im.resize(ref.size, Image.LANCZOS)
        diff = ImageChops.difference(small, ref).convert('L')
        mean_abs = sum(ImageStat.Stat(diff).mean) / len(ImageStat.Stat(diff).mean)
        hist = diff.histogram()
        frac_gt64 = sum(hist[65:]) / (ref.size[0] * ref.size[1])
        chk = Image.open(tif)
        PROV['outputs'][name] = {
            'tif': f'figures/{name}.tif', 'tif_sha256': sha256(tif), 'png_preview': f'figures/{name}.png',
            'png_sha256': sha256(png), 'size_px': list(chk.size), 'mode': chk.mode,
            'compression': chk.info.get('compression'), 'dpi': [round(float(x), 1) for x in chk.info.get('dpi')],
            'width_mm': round(chk.size[0] / DPI * 25.4, 1), 'height_mm': round(chk.size[1] / DPI * 25.4, 1),
            'drawn_from': f'source/build_figures.py, same drawing as figures/{stem}.png and figures/{stem}.svg',
            'implementer_png': {'path': f'figures/{stem}.png', 'sha256': sha256(src_png), 'size_px': list(ref.size)},
            'render_dpi': round(DPI * scale, 2), 'scale_vs_300dpi_drawing': round(scale, 4),
            'pixel_resize_after_render': adjust,
            'min_font_pt_in_drawing': round(min_pt, 2), 'min_font_pt_at_180mm': round(min_at_180, 2),
            'min_font_rule': 'Frontiers: smallest visible text at least 8 pt at actual size; size = drawn font size x '
                             'export scale x any resampling factor; measured on the text elements of the final render',
            'min_font_pt_required': MIN_PT, 'smallest_text_elements': smallest, 'n_text_elements_drawn': len(drawn),
            'min_line_pt_in_drawing': round(min_lw, 2), 'min_line_pt_at_180mm': round(min_lw_at_180, 2),
            'min_line_rule': 'Frontiers: any line at least 2 pt wide; width = drawn stroke width x export scale x any '
                             'resampling factor; measured on every stroked element of the final render (lines, '
                             'marker edges, patch edges, collection lines; zero-width or transparent strokes skipped)',
            'min_line_pt_required': MIN_LINE_PT, 'thinnest_line_elements': thinnest,
            'n_line_elements_drawn': len(lines),
            'content_check': {'same_size_at_300dpi_as_implementer_png': same_size,
                              'mean_abs_channel_difference_0_255': round(mean_abs, 3),
                              'fraction_pixels_differing_over_64': round(frac_gt64, 5)},
        }
        assert chk.mode == 'RGB' and chk.size[0] == W_PX and chk.info.get('compression') == 'tiff_lzw', name
        assert same_size, (name, ref.size, at300.size)
        print(f'{name}: {chk.size} px, render dpi {DPI * scale:.1f}, min font {min_at_180:.2f} pt at 180 mm, '
              f'min line {min_lw_at_180:.2f} pt at 180 mm ({len(lines)} stroked elements), '
              f'mean diff {mean_abs:.3f}')
    return save


def copy_s1():
    src_tif, src_png = guard(FIG / 'figureS1_roc_curves.tif'), guard(FIG / 'figureS1_roc_curves.png')
    tif, png = FIG / 'FigureS1.tif', FIG / 'FigureS1.png'
    shutil.copyfile(src_tif, tif)
    shutil.copyfile(src_png, png)
    chk = Image.open(tif)
    PROV['outputs']['FigureS1'] = {
        'tif': 'figures/FigureS1.tif', 'tif_sha256': sha256(tif), 'png_preview': 'figures/FigureS1.png',
        'png_sha256': sha256(png), 'size_px': list(chk.size), 'mode': chk.mode,
        'compression': chk.info.get('compression'), 'dpi': [round(float(x), 1) for x in chk.info.get('dpi')],
        'width_mm': round(chk.size[0] / DPI * 25.4, 1), 'height_mm': round(chk.size[1] / DPI * 25.4, 1),
        'drawn_from': 'copy of figures/figureS1_roc_curves.tif and .png, prepared from '
                      'pdci/figures/Figure_1_stage_ROC.png by scripts/prepare_supplementary_figures.py', 
        'copied_from_sha256': {'tif': sha256(src_tif), 'png': sha256(src_png)},
        'min_font_pt_at_180mm': None,
        'min_font_note': ('Not measured by this release exporter for the newly generated S1 raster; '
                          'inspect font size and line width at final publication size before use.'),
        'min_font_pt_required': MIN_PT,
    }
    assert chk.mode == 'RGB' and chk.size[0] == W_PX and chk.info.get('compression') == 'tiff_lzw'
    assert sha256(tif) == sha256(src_tif) and sha256(png) == sha256(src_png)


if __name__ == '__main__':
    mod = load_module()
    mod.save = make_save(mod)
    mod.figure1()
    mod.figure2()
    mod.figure3()
    mod.figure4()
    copy_s1()
    PROV['method'] = ('Figures 1-4 re-rendered from source/build_figures.py (not modified by this export step; its '
                      'save() replaced in memory) '
                      'at the resolution that makes the tight-cropped drawing 2126 px wide, saved as RGB TIFF with LZW '
                      'compression and a 300-dpi tag (180 mm wide), plus an RGB PNG preview with the same pixels. '
                      'Figure S1 copied unchanged. Implementer files figures/figure*_*.{png,svg,tif} untouched.')
    (FIG / 'figure_provenance_20261007.json').write_text(json.dumps(PROV, indent=1), encoding='utf-8')
    print(json.dumps({k: {kk: v[kk] for kk in ('size_px', 'width_mm', 'height_mm')} for k, v in PROV['outputs'].items()},
                     indent=1))
