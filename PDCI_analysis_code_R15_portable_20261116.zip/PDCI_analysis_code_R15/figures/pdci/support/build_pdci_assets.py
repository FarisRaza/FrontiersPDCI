"""Publication figures and aggregate CSVs from unchanged audited PD/CI records.

No models, thresholds, intervals or p/q values are fitted or estimated here.
ROC curves and count ratios are deterministic renderings of saved predictions.
"""
from __future__ import annotations

import os
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"

from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from sklearn.metrics import roc_auc_score, roc_curve

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/pdci_demographic_baseline_20260911"
POL = ROOT / "results/pdci_sensitivity_policy_20260912"
FIG = OUT / "figures"
TAB = OUT / "tables"
for folder in (FIG, TAB):
    folder.mkdir(parents=True, exist_ok=True)

INPUTS = {}
OUTPUTS = []
CHECKS = {}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def record(path):
    INPUTS[str(path.relative_to(ROOT)).replace("\\", "/")] = digest(path)
    return path

def read_csv(folder, name):
    return pd.read_csv(record(folder / name))

def read_json(folder, name):
    return json.loads(record(folder / name).read_text(encoding="utf-8"))

def export(frame, name):
    # These are plain aggregate scientific result exports, not a workbook.
    assert not any(x.lower() in {"participant_id", "record_id", "id", "subject_id"} for x in frame.columns)
    dest = TAB / name
    frame.to_csv(dest, index=False, float_format="%.17g")
    OUTPUTS.append(dest)
    check = pd.read_csv(dest)
    pd.testing.assert_frame_equal(frame.reset_index(drop=True), check, check_dtype=False, check_exact=False, rtol=1e-13, atol=1e-15)

def save_figure(fig, name):
    for extension in ("png", "svg"):
        dest = FIG / f"{name}.{extension}"
        kwargs = {"dpi": 300} if extension == "png" else {"metadata": {"Date": None}}
        fig.savefig(dest, bbox_inches="tight", facecolor="white", **kwargs)
        OUTPUTS.append(dest)
    plt.close(fig)

assert read_json(BASE, "AUDIT.json")["status"] == "PASS"
assert read_json(POL, "AUDIT.json")["status"] == "PASS"
assert read_json(POL / "support", "independent_policy_audit_receipt.json")["status"] == "PASS"
record(BASE / "ANALYSIS_PLAN.md")
record(POL / "ANALYSIS_PLAN.md")
record(BASE / "REPORT.md")
record(POL / "REPORT.md")
auc = read_csv(BASE, "auc_intervals.csv")
paired = read_csv(BASE, "primary_baseline_comparisons.csv")
selection = read_csv(BASE, "selection_counts.csv")
policy = read_csv(POL, "policy_summary.csv")
ops = read_csv(POL, "operating_points.csv")
cm = read_csv(POL, "confusion_matrices.csv")
boot = read_csv(POL, "nominal_bootstrap_intervals.csv")
wilson = read_csv(POL, "wilson_binomial_reference_intervals.csv")
policy_delta = read_csv(POL, "paired_primary_minus_legacy95.csv")
thresholds = read_csv(POL, "threshold_summary.csv")
repeat = read_csv(BASE, "repeat_metrics.csv")
pred = pd.read_parquet(record(BASE / "local_only/participant_oof_predictions.parquet"))
y = pred.y_true.to_numpy()
assert len(y) == 750 and np.array_equal(np.bincount(y), [598, 90, 62])
CHECKS["participants_by_class"] = [598, 90, 62]

# Numerical tables: retain underlying precision and distinct uncertainty methods.
main_auc = paired.copy()
main_auc.insert(1, "n", [750, 152, 750])
for model, prefix in (("primary", "candidate"), ("agesexcountry", "baseline")):
    mapped = auc.query("model == @model").set_index("endpoint")
    for bound in ("ci_low", "ci_high"):
        main_auc[f"{prefix}_nominal_auc_{bound}"] = main_auc.endpoint.map(mapped[bound])
export(main_auc, "Table_1_primary_AUROC.csv")
export(auc, "Table_S4_all_AUROC_intervals.csv")

selected_ops = ops.query("scope == 'participant_majority' and policy in ['legacy95', 'separate98_pd95']")
primary_table = []
metric_names = ["screen_sensitivity", "screen_PD_sensitivity", "screen_CI_sensitivity", "screen_specificity", "screen_PPV", "screen_NPV", "referral_fraction", "end_to_end_PD_recall", "end_to_end_CI_recall", "end_to_end_PD_PPV_vs_rest", "conditional_all_PD_sensitivity", "conditional_all_CI_specificity", "conditional_referred_PD_sensitivity", "conditional_referred_CI_specificity"]
for metric in metric_names:
    row = {"metric": metric}
    for name, prefix in (("legacy95", "legacy95"), ("separate98_pd95", "primary98_95")):
        item = selected_ops.query("policy == @name").iloc[0]
        for field in ("", "_numerator", "_denominator"):
            row[prefix + field] = item[metric + field]
    primary_table.append(row)
export(pd.DataFrame(primary_table), "Table_2_primary_policy.csv")
nine = policy[policy.policy.str.startswith("separate")].copy()
nine.insert(1, "screen_training_target", nine.policy.str.extract(r"separate(\d+)")[0].astype(int) / 100)
nine.insert(2, "PD_training_target", nine.policy.str.extract(r"_pd(\d+)")[0].astype(int) / 100)
nine.insert(3, "prespecified_primary", nine.policy.eq("separate98_pd95"))
assert len(nine) == 9
export(nine, "Table_S1_all_nine_policies.csv")
uncertainty = boot.merge(wilson[["policy", "metric", "wilson95_low", "wilson95_high"]], on=["policy", "metric"], how="left", validate="one_to_one")
export(uncertainty, "Table_S2_policy_uncertainty.csv")
export(selection, "Table_S3_selected_model_counts.csv")
export(policy_delta, "Table_S5_paired_policy_differences.csv")
export(ops, "Table_S6_all_policy_operating_points.csv")
export(cm, "Table_S7_all_confusion_matrices.csv")
export(thresholds, "Table_S8_training_threshold_ranges.csv")
export(repeat, "Table_S9_repeat_AUROCs.csv")

# Reconcile every participant-level policy matrix against its reported rates.
classes = ["Neither", "PD", "CI"]
matrices = {}
for name in policy.policy:
    d = cm.query("policy == @name and scope == 'participant_majority'")
    a = d.pivot(index="true_class", columns="predicted_class", values="n").loc[classes, classes].to_numpy(dtype=int)
    assert np.array_equal(a.sum(axis=1), [598, 90, 62])
    p = policy.query("policy == @name").iloc[0]
    expected = {
        "screen_sensitivity": a[1:, 1:].sum() / 152,
        "screen_PD_sensitivity": a[1, 1:].sum() / 90,
        "screen_CI_sensitivity": a[2, 1:].sum() / 62,
        "screen_specificity": a[0, 0] / 598,
        "end_to_end_PD_recall": a[1, 1] / 90,
        "end_to_end_CI_recall": a[2, 2] / 62,
        "referrals": a[:, 1:].sum(),
        "PD_to_neither": a[1, 0],
        "PD_to_CI": a[1, 2],
        "CI_to_neither": a[2, 0],
        "CI_to_PD": a[2, 1],
    }
    for key, value in expected.items():
        assert np.isclose(value, p[key], atol=1e-14), (name, key)
    matrices[name] = a
CHECKS["policy_matrix_metrics_reconciled"] = 13 * 11

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 10, "axes.labelsize": 10, "axes.spines.top": False, "axes.spines.right": False, "svg.fonttype": "none"})
blue, orange, grey = "#1D547A", "#B66128", "#5B6268"

# Figure 1: same endpoint definitions as the prior audited plotting source.
fig, axes = plt.subplots(1, 2, figsize=(7.5, 3.3), layout="constrained")
roc_checks = []
for ax, endpoint, title in zip(axes, ["screen", "q"], ["A  PD or CI versus neither (n = 750)", "B  PD versus CI (n = 152)"]):
    mask = np.ones(len(y), dtype=bool) if endpoint == "screen" else y > 0
    truth = (y[mask] > 0).astype(int) if endpoint == "screen" else (y[mask] == 1).astype(int)
    for model, color, label, ls in (("primary", blue, "Voice + demographics", "-"), ("agesexcountry", orange, "Age + sex + country", "--")):
        values = pred.loc[mask, f"{model}_{endpoint}"].to_numpy()
        score = roc_auc_score(truth, values)
        target_ep = "screen" if endpoint == "screen" else "stage2"
        expected = auc.query("model == @model and endpoint == @target_ep").auc.item()
        assert np.isclose(score, expected, atol=1e-14)
        fpr, tpr, _ = roc_curve(truth, values)
        ax.plot(fpr, tpr, color=color, ls=ls, lw=1.65, label=f"{label}: {score:.3f}")
        roc_checks.append({"model": model, "endpoint": target_ep, "auc": score})
    ax.set(xlim=(0, 1), ylim=(0, 1.02), xlabel="False-positive rate", ylabel="True-positive rate", title=title)
    ax.grid(alpha=.18, lw=.5)
    ax.legend(loc="lower right", frameon=False, fontsize=9.5)
save_figure(fig, "Figure_1_stage_ROC")
CHECKS["four_ROC_AUROCs_match_source"] = roc_checks

# Figure 2: display every frozen combination, not an outer-selected winner.
fig, axes = plt.subplots(2, 2, figsize=(7.2, 6), layout="constrained")
heat_metrics = [("screen_sensitivity", "A  Screening sensitivity"), ("screen_specificity", "B  Screening specificity"), ("end_to_end_PD_recall", "C  End-to-end PD sensitivity"), ("end_to_end_CI_recall", "D  End-to-end CI sensitivity")]
for ax, (metric, title) in zip(axes.flat, heat_metrics):
    a = nine.pivot(index="screen_training_target", columns="PD_training_target", values=metric).loc[[.95, .98, 1], [.90, .95, .98]].to_numpy()
    im = ax.imshow(a, cmap="Blues", vmin=0, vmax=1, aspect="auto")
    for r in range(3):
        for c in range(3):
            ax.text(c, r, f"{a[r,c]*100:.1f}%", ha="center", va="center", color="white" if a[r,c] > .65 else "#162431", fontsize=11)
    ax.add_patch(Rectangle((.5, .5), 1, 1, fill=False, lw=2, edgecolor="#E49A38"))
    ax.set(xticks=[0, 1, 2], xticklabels=["90%", "95%", "98%"], yticks=[0, 1, 2], yticklabels=["95%", "98%", "100%"], xlabel="Stage 2 PD training target", ylabel="Stage 1 training target", title=title)
    ax.tick_params(length=0)
fig.suptitle("Held-out operating points for all nine frozen policies", fontsize=12)
fig.colorbar(im, ax=axes, fraction=.03, pad=.025, label="Held-out proportion", ticks=[0, .25, .5, .75, 1])
save_figure(fig, "Figure_2_policy_tradeoffs")

# Figure 3: counts and within-recorded-class percentages, shared color scale.
fig, axes = plt.subplots(1, 2, figsize=(7.5, 3.6), layout="constrained")
for ax, name, title in zip(axes, ["legacy95", "separate98_pd95"], ["A  Original 95% screening policy", "B  Primary 98% / 95% policy"]):
    a = matrices[name]
    rowp = a / a.sum(axis=1, keepdims=True)
    im = ax.imshow(rowp, cmap="Blues", vmin=0, vmax=1)
    for r in range(3):
        for c in range(3):
            ax.text(c, r, f"{a[r,c]}\n({100*rowp[r,c]:.1f}%)", ha="center", va="center", color="white" if rowp[r,c] > .65 else "#162431", fontsize=10)
    ax.set(xticks=[0, 1, 2], xticklabels=classes, yticks=[0, 1, 2], yticklabels=["Neither (598)", "PD (90)", "CI (62)"], xlabel="Assigned class", ylabel="Recorded class (n)", title=title)
    ax.tick_params(length=0)
fig.colorbar(im, ax=axes, fraction=.025, pad=.025, label="Proportion within recorded class", ticks=[0, .25, .5, .75, 1])
save_figure(fig, "Figure_3_confusion_matrices")

# Supplementary design: logical dependence, not a flow of all cases through fitting.
fig, ax = plt.subplots(figsize=(7, 6.8))
ax.set_position([.02, .04, .96, .92])
ax.set(xlim=(0, 10), ylim=(0, 8.3))
ax.axis("off")
def box(x, yy, w, h, text, fill="#EDF2F6", fs=9.5):
    ax.add_patch(FancyBboxPatch((x, yy), w, h, boxstyle="round,pad=.08,rounding_size=.07", linewidth=.8, edgecolor="#657480", facecolor=fill))
    ax.text(x+w/2, yy+h/2, text, ha="center", va="center", fontsize=fs)
def arrow(start, end, label=None):
    ax.annotate("", xy=end, xytext=start, arrowprops={"arrowstyle": "->", "color": grey, "lw": 1})
    if label:
        ax.text((start[0]+end[0])/2, (start[1]+end[1])/2+.12, label, fontsize=8, ha="center")
box(1.7, 6.9, 6.6, .8, "750 adults: neither 598, PD 90, CI 62\n11 general task families\nALS and recorded PD + CI overlap excluded")
ax.text(5, 8.02, "Participant-level outer CV: five folds × three repeats", ha="center", fontsize=10)
box(.35, 5.3, 6.1, .8, "Outer-training participants\nAll data-dependent choices remain inside this set")
box(7.05, 5.3, 2.6, .8, "Outer-test participants\nNever used for choices", fill="#F6EEDD")
arrow((3.9, 6.8), (3.4, 6.15))
arrow((7.5, 6.8), (8.3, 6.15))
box(.35, 3.45, 2.9, 1.3, "Stage 1: PD/CI screen\n96 PLS/ridge candidates\nThree inner folds\nTraining-only transforms")
box(3.55, 3.45, 2.9, 1.3, "Stage 2: PD versus CI\n160 dedicated candidates\nThree inner folds\nCases only; training-only\ntransforms")
arrow((1.8, 5.2), (1.8, 4.82))
arrow((5, 5.2), (5, 4.82))
box(.35, 1.7, 6.1, 1.1, "Select by inner AUROC; refit on outer-training rows\nThresholds: own inner-held-out scores\nPrimary training targets: 98% per disease at stage 1;\n95% PD sensitivity at stage 2")
arrow((1.8, 3.35), (1.8, 2.86))
arrow((5, 3.35), (5, 2.86))
box(7.05, 2.1, 2.6, 1.65, "Held-out scores\nand decisions\nScreen s; subtype q\nThree-class probabilities:\n(1 − s, s q, s (1 − q))\nBoth stages evaluated", fill="#F6EEDD")
arrow((8.35, 5.2), (8.35, 3.84))
arrow((6.52, 2.4), (6.97, 2.4))
box(.7, .15, 8.6, 1, "One participant-level evaluation after three held-out repeats\nAUROC: averaged held-out scores. Decisions: majority screen,\nthen subtype vote among positive-screen repeats (PD/CI tie → PD).\nMatched age + sex + country baseline. No policy-stage model refitting.", fill="#F1F1F1")
arrow((8.35, 2), (8.35, 1.23))
save_figure(fig, "Figure_S1_nested_design")

# Check protected inputs after writing only the new package.
for relative, sha in INPUTS.items():
    assert digest(ROOT / relative) == sha
CHECKS["source_files_unchanged"] = len(INPUTS)
CHECKS["no_model_refitting_or_new_inference"] = True
CHECKS["no_participant_level_export"] = True
CHECKS["CSV_roundtrip_checks"] = 11
receipt = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": "NUMERICAL_CHECKS_PASS_VISUAL_REVIEW_PENDING",
    "source_sha256": INPUTS,
    "outputs": {str(p.relative_to(OUT)).replace("\\", "/"): digest(p) for p in OUTPUTS},
    "checks": CHECKS,
    "versions": {"python": sys.version.split()[0], "numpy": np.__version__, "pandas": pd.__version__, "matplotlib": matplotlib.__version__},
    "new_inference": False,
    "prior_results_modified": False,
    "privacy": "Only aggregate tables and figures exported. Participant predictions were read locally for ROC rendering only.",
}
(OUT / "ASSET_PROVENANCE.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"figures": 4, "CSV_tables": 11, "checks": CHECKS}, indent=2))
