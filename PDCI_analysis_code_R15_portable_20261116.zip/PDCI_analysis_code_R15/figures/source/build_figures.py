"""Build Figures 1-4 of the PD-versus-CI manuscript from aggregate result files.

Figure 1: study design and participant flow; the counts are read from INPUT_AUDIT.json,
AUDIT.json and FROZEN_SPEC.json of the source run, and the flow counts before the
analysed cohort are fixed in the code and checked against the analysed n.
Figure 2: paired AUROC gains of the voice procedure over the age, sex and
residence-country baseline (pooled out-of-fold and mean-fold estimates), with the
15 outer-fold differences drawn as a strip below each mean-fold row.
Figure 3: referrals and end-to-end PD and CI sensitivity for the nine training-only
sensitivity policies and their comparators, in two stacked panels; points that share
a value are offset so that every policy and comparator stays distinguishable (the
figure legend states the offsets).
Figure 4: participant-level decision matrices in three panels (baseline original
rule, voice original rule, voice primary policy); each cell's text colour is the
choice of white or ink with the higher WCAG contrast.

Journal figure rules applied in the drawing: every text element is at least 8 pt and
every stroked line at least MIN_LW = 2.0 pt at actual size, and every drawing is at
most 180 mm wide (export scale at least 1). Thin marker outlines and white marker
halos are omitted rather than thickened (filled markers carry no edge line).
Drawing changes never change a plotted value.

Inputs are aggregate result files only (no participant-level files, no local_only/
folders, no .parquet files):
  results/pdci_demographic_baseline_20260911/  INPUT_AUDIT.json, FROZEN_SPEC.json,
      AUDIT.json, auc_intervals.csv, primary_baseline_comparisons.csv,
      fold_metrics.csv (per-outer-fit AUROCs), confusion_matrices.csv
  results/pdci_sensitivity_policy_20260912/  operating_points.csv,
      nominal_bootstrap_intervals.csv, confusion_matrices.csv

Location: this file is expected at DATA_ROOT/analysis/<figure folder>/source/
(the figures/ folder of the code archive copied into DATA_ROOT/analysis/); result
files are read from DATA_ROOT/analysis/results/, the aggregate outputs of the
analysis scripts in src/.

Outputs (PNG at 300 dpi, TIFF at 300 dpi and SVG) go to <figure folder>/figures/.
Run with (from the figure folder): python source/build_figures.py
The journal-size TIFF files are written afterwards by
scripts/build_frontiers_figures_20261007.py, which re-renders these drawings.

Each figure asserts that the values it draws equal the values reported in the
manuscript (written into the assertions), so a changed result file stops the
build instead of drawing silently. No model is fitted here; values are read,
checked and drawn.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

PACKAGE = Path(__file__).resolve().parents[1]
ANALYSIS = PACKAGE.parent
BASE_RUN = ANALYSIS / "results" / "pdci_demographic_baseline_20260911"
POLICY_RUN = ANALYSIS / "results" / "pdci_sensitivity_policy_20260912"
OUT = PACKAGE / "figures"

# Palette (light mode): categorical slots 1 and 2,
# an ordinal blue ramp for ordered targets, text and hairline tokens.
VOICE = "#2a78d6"  # slot 1, blue
BASELINE = "#eb6834"  # slot 2, orange
U_COLORS = {0.90: "#86b6ef", 0.95: "#2a78d6", 0.98: "#104281"}  # blue steps 250/450/650
GREY = "#8a8984"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#ecebe7"  # one step lighter, since gridlines are 2 pt wide
SURFACE = "#ffffff"
BOX_FILL = "#f0efec"
BOX_EDGE = "#b9b8b2"
SEQ_STEPS = ["#f5f9fe", "#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
MIN_LW = 2.0  # pt; Frontiers: any line at least 2 pt wide at actual size; export scale >= 1

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
        "font.size": 8,
        "axes.titlesize": 9,
        "axes.labelsize": 8.5,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "axes.edgecolor": INK2,
        "axes.linewidth": MIN_LW,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "xtick.major.width": MIN_LW,
        "ytick.major.width": MIN_LW,
        "xtick.minor.width": MIN_LW,
        "ytick.minor.width": MIN_LW,
        "xtick.major.size": 4.0,
        "ytick.major.size": 4.0,
        "grid.linewidth": MIN_LW,
        "lines.linewidth": MIN_LW,
        "patch.linewidth": MIN_LW,
        "lines.markeredgewidth": 0.0,  # filled markers carry no edge line unless one is set
        "axes.labelcolor": INK,
        "text.color": INK,
        "svg.fonttype": "none",
        "savefig.facecolor": SURFACE,
        "figure.facecolor": SURFACE,
    }
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def close(a: float, b: float, tol: float = 1e-9) -> bool:
    return abs(a - b) <= tol


def fmt(x: float, nd: int = 3) -> str:
    """Format a number with a typographic minus sign."""
    return f"{x:.{nd}f}".replace("-", "−")


def tidy_axes(ax, grid_axis: str = "x") -> None:
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=MIN_LW, linestyle="-")
    ax.set_axisbelow(True)


def save(fig, stem: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{stem}.png", dpi=300, bbox_inches="tight", pad_inches=0.05)
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight", pad_inches=0.05)
    fig.savefig(OUT / f"{stem}.tif", dpi=300, bbox_inches="tight", pad_inches=0.05,
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    # Journal upload copy: flatten to RGB on the white surface, keep 300 dpi.
    from PIL import Image  # noqa: E402  (Pillow ships with matplotlib)
    with Image.open(OUT / f"{stem}.tif") as im:
        rgb = Image.new("RGB", im.size, (255, 255, 255))
        rgb.paste(im, mask=im.split()[-1] if im.mode == "RGBA" else None)
    rgb.save(OUT / f"{stem}.tif", dpi=(300, 300), compression="tiff_lzw")
    print(f"wrote {stem}.png, {stem}.tif and {stem}.svg")


# ---------------------------------------------------------------- Figure 1
FIG1_W, FIG1_H = 6.9, 5.25          # inches; 8-pt text at the 180-mm export (drawing <= 180 mm wide)
LINE_PT, PAD_PT = 8 * 1.35, 8.0     # one 8-pt text line at linespacing 1.35; vertical padding inside a box


def figure1() -> None:
    audit_in = json.loads((BASE_RUN / "INPUT_AUDIT.json").read_text(encoding="utf-8"))
    spec = json.loads((BASE_RUN / "FROZEN_SPEC.json").read_text(encoding="utf-8"))
    audit = json.loads((BASE_RUN / "AUDIT.json").read_text(encoding="utf-8"))
    n = audit_in["n"]
    n_neither, n_pd, n_ci = audit_in["class_counts"]
    n_tasks = len(audit_in["general_tasks"])
    cases = audit["cases"]
    outer_fits = audit["outer_folds"]
    # Flow counts before the analysed cohort. No aggregate CSV holds them;
    # they are fixed here and checked against the analysed n from INPUT_AUDIT.json.
    with_audio, als, overlap, lacking_tasks = 833, 3, 1, 79
    remaining = with_audio - als - overlap
    assert remaining == 829
    assert remaining - lacking_tasks == n == 750
    assert (n_neither, n_pd, n_ci) == (598, 90, 62) and cases == 152
    assert n_tasks == 11 and outer_fits == 15
    assert (spec["screen_candidates"], spec["stage2_candidates"], spec["baseline_candidates"]) == (96, 160, 8)

    fig = plt.figure(figsize=(FIG1_W, FIG1_H))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    H = FIG1_H * 72.0

    def y(pt_from_top: float) -> float:
        return 1 - pt_from_top / H

    def bh(nlines: int) -> float:
        return nlines * LINE_PT + PAD_PT

    fits = []  # (patch, text) pairs checked after drawing: every text must lie inside its box

    def box(x0, top, w, text, fill=SURFACE, edge=INK2, weight="normal", lw=MIN_LW):
        """Box from `top` (points from the figure top) sized to its number of text lines; returns its bottom."""
        h = bh(text.count("\n") + 1)
        p = FancyBboxPatch((x0, y(top + h)), w, h / H, boxstyle="round,pad=0,rounding_size=0.012",
                           linewidth=lw, edgecolor=edge, facecolor=fill)
        ax.add_patch(p)
        t = ax.text(x0 + w / 2, y(top + h / 2), text, ha="center", va="center", fontsize=8,
                    fontweight=weight, linespacing=1.35)
        fits.append((p, t))
        return top + h

    def arrow(x0, y0, x1, y1):
        ax.add_patch(
            FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=10,
                            linewidth=MIN_LW, color=INK2, shrinkA=0, shrinkB=0)
        )

    # Panel A: cohort flow
    ax.text(0.012, y(4), "A", fontsize=10.5, fontweight="bold", va="top")
    ax.text(0.042, y(5), "Cohort flow", fontsize=9, va="top", color=INK2)
    mx, mw = 0.02, 0.17   # main column
    ex, ew = 0.235, 0.15  # exclusion column
    cx = mx + mw / 2
    b1 = box(mx, 30, mw, f"{with_audio} participants\nwith derived\naudio data")
    t2 = b1 + 62
    b2 = box(mx, t2, mw, f"{remaining} remaining")
    t3 = b2 + 62
    b3 = box(mx, t3, mw, f"{n} analysed\n(all {n_tasks} task\nfamilies)", weight="bold")
    for top_gap, bottom_gap, txt in ((b1, t2, f"Excluded:\n{als} with ALS;\n{overlap} with both PD\nand CI records"),
                                     (b2, t3, f"Excluded: {lacking_tasks}\nlacking ≥1 of\nthe {n_tasks} general\ntask families")):
        mid = (top_gap + bottom_gap) / 2
        box(ex, mid - bh(4) / 2, ew, txt, fill=BOX_FILL, edge=BOX_EDGE)
        arrow(cx, y(mid), ex, y(mid))
    arrow(cx, y(b1), cx, y(t2))
    arrow(cx, y(b2), cx, y(t3))
    # class boxes
    gw, gap, gx0 = 0.105, 0.02, 0.02
    ct = b3 + 30
    for i, txt in enumerate((f"Neither\nn = {n_neither}", f"PD\nn = {n_pd}", f"CI\nn = {n_ci}")):
        x = gx0 + i * (gw + gap)
        cb = box(x, ct, gw, txt, fill=BOX_FILL, edge=BOX_EDGE)
        arrow(cx, y(b3), x + gw / 2, y(ct))
    # bracket under the PD and CI boxes, with the case count centred on it
    bl, br, by = gx0 + gw + gap, gx0 + 3 * gw + 2 * gap, y(cb + 9)
    ax.plot([bl, bl, br, br], [y(cb + 4), by, by, y(cb + 4)], color=INK2, linewidth=MIN_LW)
    ax.text((bl + br) / 2, y(cb + 19), f"{cases} cases (PD or CI)", ha="center", va="center", fontsize=8, color=INK2)
    ax.text(gx0 + 1.5 * gw + gap, y(cb + 44), "Neither: no PD or CI label;\nother diagnoses allowed",
            ha="center", va="center", fontsize=8, color=INK2, linespacing=1.35)

    # divider
    ax.plot([0.40, 0.40], [y(H - 8), y(8)], color=GRID, linewidth=MIN_LW)

    # Panel B: design
    bx0, bx1 = 0.42, 0.99
    bw = bx1 - bx0
    ax.text(bx0 - 0.008, y(4), "B", fontsize=10.5, fontweight="bold", va="top")
    ax.text(bx0 + 0.022, y(5), "Two-stage procedure and evaluation", fontsize=9, va="top", color=INK2)
    bi = box(bx0, 26, bw,
             f"Inputs: voice descriptors from {n_tasks} task families\n"
             "(optional timing summaries) plus age, recorded sex\n"
             "and residence country")
    sw = (bw - 0.02) / 2
    s1x, s2x = bx0, bx0 + sw + 0.02
    st = bi + 16
    bs = box(s1x, st, sw,
             f"Stage 1: screening\ns = P(PD or CI)\nPLS + ridge logistic\n{spec['screen_candidates']} candidates;\n"
             f"all {n} participants", lw=2.5, edge=VOICE)
    box(s2x, st, sw,
        f"Stage 2: PD versus CI\nq = P(PD | case)\ntrained on PD and CI only\n{spec['stage2_candidates']} candidates;\n"
        f"all {cases} cases", lw=2.5, edge=VOICE)
    for xx in (s1x + sw / 2, s2x + sw / 2):
        arrow(xx, y(bi), xx, y(st))
    tt = bs + 16
    bt = box(bx0, tt, bw, "Three-class vector (1 − s, s × q, s × (1 − q))\n→ macro AUROC")
    for xx in (s1x + sw / 2, s2x + sw / 2):
        arrow(xx, y(bs), xx, y(tt))
    bb = box(bx0, bt + 10, bw,
             "Demographic baseline: ridge logistic regression of age,\n"
             f"recorded sex and residence country only ({spec['baseline_candidates']} candidates\n"
             "per stage), same folds and selection rule", lw=2.5, edge=BASELINE)
    bn = box(bx0, bb + 10, bw,
             f"Nested cross-validation: 5 outer folds × 3 repeats = {outer_fits}\n"
             "outer fits; 3 inner folds; each candidate scored by one\n"
             "AUROC over its pooled inner-held-out predictions;\n"
             "AUROCs average 3 held-out predictions",
             fill=BOX_FILL, edge=BOX_EDGE)
    bo = box(bx0, bn + 10, bw,
             "Operating decisions, with estimated cutoffs from the\n"
             "inner-held-out scores of training cases: original rule\n"
             "and primary policy for both procedures (primary policy\n"
             "post hoc for the baseline); other 8 sensitivity policies\n"
             "for the voice procedure only",
             fill=BOX_FILL, edge=BOX_EDGE)
    assert bo <= H - 4 and cb + 56 <= H, (bo, cb, H)
    fig.canvas.draw()   # every box text must lie inside its box at the drawn size
    for p, t in fits:
        pb, tb = p.get_window_extent(), t.get_window_extent()
        m = p.get_linewidth() / 2 * fig.dpi / 72   # clear of the inner half of the box edge
        assert (pb.x0 + m + 2 <= tb.x0 and tb.x1 <= pb.x1 - m - 2 and pb.y0 + m + 1 <= tb.y0
                and tb.y1 <= pb.y1 - m - 1), t.get_text()
    save(fig, "figure1_study_design")


# ---------------------------------------------------------------- Figure 2
LABEL_BOX = dict(boxstyle="square,pad=0.15", facecolor=SURFACE, edgecolor="none")  # labels drawn over gridlines
STRIP_DROP = 0.25            # fold-difference strip sits this far below the mean-fold row
FOLD_S = 9                   # marker area (pt^2) of the outer-fold points
FOLD_GREY = "#b3b2a8"


def swarm_offsets(xs: list[float], dx: float, dy: float, n_side: int = 2) -> list[float]:
    """Deterministic one-dimensional beeswarm: in order of x, each point takes the first vertical level
    (0, +dy, -dy, +2dy, -2dy, ...) on which no earlier point lies within dx; if every level is taken, the
    level whose nearest point is farthest away. Only the vertical drawing position changes; x is the value."""
    levels = [0.0]
    for k in range(1, n_side + 1):
        levels += [k * dy, -k * dy]
    placed: dict[float, list[float]] = {lev: [] for lev in levels}
    out = [0.0] * len(xs)
    for i in sorted(range(len(xs)), key=lambda k: (xs[k], k)):
        x = xs[i]
        free = [lev for lev in levels if all(abs(x - p) >= dx for p in placed[lev])]
        lev = free[0] if free else max(levels, key=lambda lv: min(abs(x - p) for p in placed[lv]))
        placed[lev].append(x)
        out[i] = lev
    return out
ENDPOINTS = [("stage2", "PD versus CI\n(152 cases)"), ("screen", "Screening\n(750)"), ("macro", "Three-class\nmacro (750)")]


def figure2() -> None:
    auc = {(r["model"], r["endpoint"]): r for r in read_csv(BASE_RUN / "auc_intervals.csv")}
    comp = {r["endpoint"]: r for r in read_csv(BASE_RUN / "primary_baseline_comparisons.csv")}
    folds = read_csv(BASE_RUN / "fold_metrics.csv")
    # Reported values (PD versus CI)
    assert close(float(auc[("primary", "stage2")]["auc"]), 0.8204301075268817)
    assert close(float(auc[("agesexcountry", "stage2")]["auc"]), 0.6874551971326165)
    assert close(float(comp["stage2"]["pooled_oof_gain"]), 0.13297491039426523)
    assert close(float(comp["stage2"]["mean_fold_gain"]), 0.08317901234567901)
    assert close(float(comp["stage2"]["corrected_cv_q_BH3"]), 0.30832434418541443)

    fold_diffs: dict[str, list[float]] = {}
    voice = {(r["repeat"], r["fold"]): r for r in folds if r["model"] == "primary"}
    base = {(r["repeat"], r["fold"]): r for r in folds if r["model"] == "agesexcountry"}
    assert len(voice) == len(base) == 15
    for ep, _ in ENDPOINTS:
        d = [float(voice[k][ep]) - float(base[k][ep]) for k in sorted(voice)]
        assert close(sum(d) / len(d), float(comp[ep]["mean_fold_gain"]), 1e-12)
        fold_diffs[ep] = d
    # Tallies of fits where voice was higher
    assert [sum(x > 0 for x in fold_diffs[e]) for e in ("stage2", "screen", "macro")] == [10, 9, 2]

    fig, (axa, axb) = plt.subplots(1, 2, figsize=(7.2, 3.1), gridspec_kw={"width_ratios": [1, 1.25], "wspace": 0.08})
    ys = [2, 1, 0]
    off = 0.17
    for y, (ep, _) in zip(ys, ENDPOINTS):
        for model, color, marker, dy in (("primary", VOICE, "o", off), ("agesexcountry", BASELINE, "s", -off)):
            r = auc[(model, ep)]
            est, lo, hi = float(r["auc"]), float(r["ci_low"]), float(r["ci_high"])
            axa.errorbar(est, y + dy, xerr=[[est - lo], [hi - est]], fmt=marker, color=color, ms=5.5,
                         mew=0, elinewidth=MIN_LW, capsize=0, zorder=3)
            axa.text(hi + 0.008, y + dy, fmt(est), va="center", fontsize=8, color=INK2, bbox=LABEL_BOX)
    axa.set_yticks(ys)
    axa.set_yticklabels([lab for _, lab in ENDPOINTS])
    axa.set_ylim(-0.6, 2.6)
    axa.set_xlim(0.58, 1.03)
    axa.set_xlabel("AUROC (95% bootstrap interval)")
    axa.set_title("A  Discrimination", loc="left", fontweight="bold")
    tidy_axes(axa)
    axa.legend(
        handles=[
            Line2D([], [], marker="o", color=VOICE, mew=0, ls="", ms=6, label="Voice procedure (with age, sex, country)"),
            Line2D([], [], marker="s", color=BASELINE, mew=0, ls="", ms=6, label="Baseline (age, sex, country only)"),
        ],
        loc="upper left", bbox_to_anchor=(-0.02, -0.2), frameon=False, handletextpad=0.3, borderaxespad=0.0,
    )

    # data units of one fold-point diameter, from the fixed axes geometry (no tight layout is used)
    lo_all = min(min(v) for v in fold_diffs.values())
    xlim_b = (min(-0.12, lo_all - 0.03), 0.56)
    pos = axb.get_position()
    diam_pt = FOLD_S ** 0.5
    dx_unit = diam_pt / (pos.width * fig.get_figwidth() * 72) * (xlim_b[1] - xlim_b[0])
    dy_unit = diam_pt / (pos.height * fig.get_figheight() * 72) * 3.2
    for y, (ep, _) in zip(ys, ENDPOINTS):
        c = comp[ep]
        pe, plo, phi = float(c["pooled_oof_gain"]), float(c["bootstrap95_low"]), float(c["bootstrap95_high"])
        me, mlo, mhi = float(c["mean_fold_gain"]), float(c["corrected_cv95_low"]), float(c["corrected_cv95_high"])
        q = float(c["corrected_cv_q_BH3"])
        axb.errorbar(pe, y + off, xerr=[[pe - plo], [phi - pe]], fmt="o", color=INK, ms=5.5,
                     mew=0, elinewidth=MIN_LW, capsize=0, zorder=3)
        # 15 outer-fold differences as a strip below the mean-fold row, spread vertically by a
        # deterministic beeswarm so that points closer than one marker width do not overlap
        jit = swarm_offsets(fold_diffs[ep], dx_unit * 1.05, dy_unit * 0.8)
        axb.scatter(fold_diffs[ep], [y - off - STRIP_DROP + j for j in jit], s=FOLD_S, color=FOLD_GREY,
                    linewidth=0, zorder=2)
        axb.errorbar(me, y - off, xerr=[[me - mlo], [mhi - me]], fmt="D", color=INK2, mfc=SURFACE, ms=6.5,
                     mew=MIN_LW, elinewidth=MIN_LW, capsize=0, zorder=3)
        axb.text(phi + 0.012, y + off, fmt(pe), va="center", fontsize=8, color=INK2, bbox=LABEL_BOX)
        right = max(mhi, max(fold_diffs[ep]))
        axb.text(right + 0.03, y - off, f"{fmt(me)}; adj. p = {q:.3f}" if abs(me) >= 0.001 else f"{fmt(me, 4)}; adj. p = {q:.3f}",
                 va="center", fontsize=8, color=INK2, bbox=LABEL_BOX)
    axb.axvline(0, color=INK2, linewidth=MIN_LW, zorder=1)
    axb.set_yticks(ys)
    axb.set_yticklabels([])
    axb.set_ylim(-0.6, 2.6)
    axb.set_xlim(*xlim_b)
    axb.set_xlabel("AUROC gain, voice procedure minus baseline")
    axb.set_title("B  Paired gain: two estimands", loc="left", fontweight="bold")
    tidy_axes(axb)
    axb.legend(
        handles=[
            Line2D([], [], marker="o", color=INK, mew=0, ls="", ms=6, label="Pooled held-out gain, nominal 95% interval (F1)"),
            Line2D([], [], marker="D", color=INK2, mfc=SURFACE, mew=MIN_LW, ls="", ms=6.5, label="Mean-fold gain, corrected 95% interval (F2)"),
            Line2D([], [], marker="o", color=FOLD_GREY, mew=0, ls="", ms=4, label="15 outer-fold differences"),
        ],
        loc="upper left", bbox_to_anchor=(-0.02, -0.2), frameon=False, handletextpad=0.3, borderaxespad=0.0,
    )
    save(fig, "figure2_paired_gains")


# ---------------------------------------------------------------- Figure 3
# Offsets: points that share a value are shifted so that every policy and
# comparator stays visible.  Panel A: within one screening target the three
# discrimination targets share one referral count; u = 0.90 and u = 0.98 are drawn
# DODGE_REF referrals left and right of the true count, u = 0.95 at the true count.
# Panel B: the 100% screening target equals the 98% target at every u, and each
# voting-only comparator equals its original rule; the second member of each pair
# is drawn DODGE_PP points to the right.  The figure note states both offsets.
DODGE_REF = 6.0
DODGE_PP = 0.9


def figure3() -> None:
    ops = {r["policy"]: r for r in read_csv(POLICY_RUN / "operating_points.csv") if r["scope"] == "participant_majority"}
    boot = {(r["policy"], r["metric"]): r for r in read_csv(POLICY_RUN / "nominal_bootstrap_intervals.csv")}

    def pt(pol):
        r = ops[pol]
        return (int(r["referrals"]), int(r["end_to_end_PD_recall_numerator"]), int(r["end_to_end_CI_recall_numerator"]))

    # Reported values: primary policy; original 95% rule; voting-only 95% comparator
    assert pt("separate98_pd95") == (366, 84, 22)
    assert pt("legacy95") == (266, 65, 29)
    assert pt("voting_only95") == (271, 65, 29)
    assert pt("legacy90") == (227, 60, 29) and pt("voting_only90") == (236, 60, 29)
    assert all(int(ops[p]["end_to_end_PD_recall_denominator"]) == 90 for p in ops)
    assert all(int(ops[p]["end_to_end_CI_recall_denominator"]) == 62 for p in ops)
    # The coincidences the offsets resolve: one referral count per
    # screening target; identical PD and CI counts for t = 0.98 and t = 1.00 at each u.
    for tl in ("95", "98", "100"):
        assert len({pt(f"separate{tl}_pd{ul}")[0] for ul in ("90", "95", "98")}) == 1
    for ul in ("90", "95", "98"):
        assert pt(f"separate98_pd{ul}")[1:] == pt(f"separate100_pd{ul}")[1:]

    us = [(0.90, "90"), (0.95, "95"), (0.98, "98")]
    shapes = {"95": ("o", 6.5), "98": ("s", 6.1), "100": ("D", 5.9)}   # +0.5 pt for the removed 0.5-pt edge
    dodge_u = {"90": -DODGE_REF, "95": 0.0, "98": DODGE_REF}

    fig, (axa, axb) = plt.subplots(2, 1, figsize=(7.2, 7.6), gridspec_kw={"hspace": 0.34})

    def pdp(n):
        return 100 * n / 90

    def cip(n):
        return 100 * n / 62

    # intervals first (behind markers), for the primary policy and the original 95% rule only
    for pol, col in (("separate98_pd95", U_COLORS[0.95]), ("legacy95", GREY)):
        ref, pd_n, ci_n = pt(pol)
        rb, pb, cb = (boot[(pol, m)] for m in ("referral_fraction", "end_to_end_PD_recall", "end_to_end_CI_recall"))
        x, y = ref, pdp(pd_n)
        axa.errorbar(x, y, xerr=[[x - 750 * float(rb["ci_low"])], [750 * float(rb["ci_high"]) - x]],
                     yerr=[[y - 100 * float(pb["ci_low"])], [100 * float(pb["ci_high"]) - y]],
                     fmt="none", ecolor=col, elinewidth=MIN_LW, capsize=0, zorder=2, alpha=0.75)
        x2, y2 = pdp(pd_n), cip(ci_n)
        axb.errorbar(x2, y2, xerr=[[x2 - 100 * float(pb["ci_low"])], [100 * float(pb["ci_high"]) - x2]],
                     yerr=[[y2 - 100 * float(cb["ci_low"])], [100 * float(cb["ci_high"]) - y2]],
                     fmt="none", ecolor=col, elinewidth=MIN_LW, capsize=0, zorder=2, alpha=0.75)

    for tlab in ("95", "98", "100"):
        for uval, ulab in us:
            ref, pd_n, ci_n = pt(f"separate{tlab}_pd{ulab}")
            mk, ms = shapes[tlab]
            kw = dict(marker=mk, ls="", ms=ms, color=U_COLORS[uval], mew=0, zorder=4)
            axa.plot(ref + dodge_u[ulab], pdp(pd_n), **kw)
            xb = pdp(pd_n) + (DODGE_PP if tlab == "100" else 0.0)
            axb.plot(xb, cip(ci_n), **kw)

    comps = (("legacy95", "X", 0.0), ("voting_only95", "^", DODGE_PP), ("legacy90", "P", 0.0), ("voting_only90", "v", DODGE_PP))
    for pol, mk, dx in comps:
        ref, pd_n, ci_n = pt(pol)
        kw = dict(marker=mk, ls="", ms=6.5, color=GREY, mew=0, zorder=4)
        axa.plot(ref, pdp(pd_n), **kw)
        axb.plot(pdp(pd_n) + dx, cip(ci_n), **kw)

    ref, pd_n, ci_n = pt("separate98_pd95")
    for ax, (x, y) in ((axa, (ref, pdp(pd_n))), (axb, (pdp(pd_n), cip(ci_n)))):
        ax.plot(x, y, marker="o", ls="", ms=13, mfc="none", mec=INK, mew=MIN_LW, zorder=5)
    axa.annotate("Primary policy", (ref, pdp(pd_n)), xytext=(330, 99.0), fontsize=8, color=INK,
                 ha="center", va="center", arrowprops=dict(arrowstyle="-", color=INK2, lw=MIN_LW, shrinkB=6))
    r95, p95, c95 = pt("legacy95")
    axa.annotate("Original rule 95%", (r95, pdp(p95)), xytext=(240, 78.0), fontsize=8, color=INK,
                 ha="center", va="center", arrowprops=dict(arrowstyle="-", color=INK2, lw=MIN_LW, shrinkB=4))
    axb.annotate("Primary policy", (pdp(pd_n), cip(ci_n)), xytext=(86.0, 24.0), fontsize=8,
                 ha="center", va="center", arrowprops=dict(arrowstyle="-", color=INK2, lw=MIN_LW, shrinkB=6))
    axb.annotate("Original rule 95% and\nvoting-only 95%", (pdp(p95) + DODGE_PP / 2, cip(c95)), xytext=(79.0, 56.0),
                 fontsize=8, ha="center", va="center", arrowprops=dict(arrowstyle="-", color=INK2, lw=MIN_LW, shrinkB=4))

    axa.set_xlabel("Referrals (of 750 participants)")
    axa.set_ylabel("End-to-end PD sensitivity, % (of 90)")
    axa.set_xlim(205, 420)
    axa.set_ylim(57, 101)
    axa.set_title("A  PD sensitivity against referrals", loc="left", fontweight="bold")
    tidy_axes(axa, "both")
    axb.set_xlabel("End-to-end PD sensitivity, % (of 90)")
    axb.set_ylabel("End-to-end CI sensitivity, % (of 62)")
    axb.set_xlim(61, 99)   # lower limit below the original rule's PD interval end, 62.2
    axb.set_ylim(5, 62)
    axb.set_title("B  CI against PD sensitivity", loc="left", fontweight="bold")
    tidy_axes(axb, "both")

    handles = [Line2D([], [], ls="", label="Screening target:")]
    for tlab in ("95", "98", "100"):
        mk, ms = shapes[tlab]
        handles.append(Line2D([], [], marker=mk, ls="", ms=6.5, color=INK2, mew=0, label=f"{tlab}%"))
    handles.append(Line2D([], [], ls="", label="   PD discrimination target:"))
    for uval, ulab in us:
        handles.append(Line2D([], [], marker="s", ls="", ms=6.5, color=U_COLORS[uval], mew=0, label=f"{ulab}%"))
    handles2 = [
        Line2D([], [], marker="o", ls="", ms=11, mfc="none", mec=INK, mew=MIN_LW, label="Primary policy (98%, 95%)"),
        Line2D([], [], marker="X", ls="", ms=6.5, color=GREY, mew=0, label="Original rule 95%"),
        Line2D([], [], marker="P", ls="", ms=6.5, color=GREY, mew=0, label="Original rule 90%"),
        Line2D([], [], marker="^", ls="", ms=6.5, color=GREY, mew=0, label="Voting-only 95%"),
        Line2D([], [], marker="v", ls="", ms=6.5, color=GREY, mew=0, label="Voting-only 90%"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=len(handles), frameon=False, bbox_to_anchor=(0.5, 0.052),
               handletextpad=0.2, columnspacing=0.9)
    blank = Line2D([], [], ls="", label=" ")
    grid2 = [handles2[0], blank, handles2[1], handles2[2], handles2[3], handles2[4]]  # column-major fill
    fig.legend(handles=grid2, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 0.0),
               handletextpad=0.2, columnspacing=1.0)
    # The offsets (DODGE_REF, DODGE_PP) are stated in the Figure 3 legend of the manuscript.
    fig.subplots_adjust(bottom=0.15, top=0.97)
    save(fig, "figure3_policy_tradeoff")


# ---------------------------------------------------------------- Figure 4
def _luminance(rgb) -> float:
    def lin(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(c) for c in rgb[:3])
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _contrast(l1: float, l2: float) -> float:
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def text_colour(rgba) -> str:
    """White or ink, whichever has the higher WCAG contrast ratio against the cell colour."""
    cell = _luminance(rgba)
    ink = _luminance(tuple(int(INK[k:k + 2], 16) / 255 for k in (1, 3, 5)))
    return SURFACE if _contrast(cell, 1.0) > _contrast(cell, ink) else INK


def figure4() -> None:
    order = ["Neither", "PD", "CI"]
    base_order = ["neither", "PD", "cognitive_impairment"]
    f4 = read_csv(BASE_RUN / "confusion_matrices.csv")
    f5 = [r for r in read_csv(POLICY_RUN / "confusion_matrices.csv") if r["scope"] == "participant_majority"]

    def matrix_f4(model):
        cells = {(r["true_class"], r["predicted_class"]): int(r["n"]) for r in f4
                 if r["model"] == model and r["gate"] == "sens95" and r["scope"] == "participant_majority"}
        return [[cells[(t, p)] for p in base_order] for t in base_order]

    def matrix_f5(pol):
        cells = {(r["true_class"], r["predicted_class"]): int(r["n"]) for r in f5 if r["policy"] == pol}
        return [[cells[(t, p)] for p in order] for t in order]

    base95 = matrix_f4("agesexcountry")   # results/pdci_demographic_baseline_20260911/confusion_matrices.csv:182-190
    voice95 = matrix_f4("primary")        # same file :74-82
    prim = matrix_f5("separate98_pd95")   # results/pdci_sensitivity_policy_20260912/confusion_matrices.csv:146-154
    assert base95 == [[487, 110, 1], [17, 56, 17], [0, 45, 17]]
    assert voice95 == [[471, 113, 14], [13, 65, 12], [0, 33, 29]]
    assert voice95 == matrix_f5("legacy95")  # original rule reproduced in the policy run
    assert prim == [[381, 210, 7], [3, 84, 3], [0, 40, 22]]
    assert [sum(r) for r in prim] == [sum(r) for r in voice95] == [sum(r) for r in base95] == [598, 90, 62]

    cmap = LinearSegmentedColormap.from_list("seqblue", SEQ_STEPS)
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.75), gridspec_kw={"wspace": 0.10})
    titles = ["A  Baseline, original rule", "B  Voice, original rule", "C  Voice, primary policy"]
    row_labels = ["Neither\n(n = 598)", "PD\n(n = 90)", "CI\n(n = 62)"]
    im = None
    for ax, mat, title in zip(axes, (base95, voice95, prim), titles):
        props = [[c / sum(r) for c in r] for r in mat]
        im = ax.imshow(props, cmap=cmap, vmin=0, vmax=1, aspect="equal")
        for i in range(3):
            for j in range(3):
                p = props[i][j]
                color = text_colour(cmap(p))   # higher WCAG contrast of white and ink
                ax.text(j, i - 0.13, f"{mat[i][j]}", ha="center", va="center", fontsize=9, fontweight="bold", color=color)
                ax.text(j, i + 0.2, f"{100 * p:.1f}%", ha="center", va="center", fontsize=8, color=color)
        ax.set_xticks(range(3))
        ax.set_xticklabels(order)
        ax.set_yticks(range(3))
        ax.set_yticklabels(row_labels if ax is axes[0] else [])
        ax.set_xlabel("Assigned class")
        if ax is axes[0]:
            ax.set_ylabel("Recorded class")
        ax.set_title(title, loc="left", fontweight="bold", fontsize=9)
        ax.tick_params(length=0)
        for s in ax.spines.values():
            s.set_visible(False)
        ax.set_xticks([x + 0.5 for x in range(2)], minor=True)
        ax.set_yticks([y + 0.5 for y in range(2)], minor=True)
        ax.grid(which="minor", color=SURFACE, linewidth=2)
        ax.tick_params(which="minor", length=0)
    cbar = fig.colorbar(im, ax=list(axes), fraction=0.02, pad=0.02)
    cbar.set_label("Share of recorded class")
    cbar.set_ticks([0, 0.25, 0.5, 0.75, 1.0])
    cbar.set_ticklabels(["0%", "25%", "50%", "75%", "100%"])
    cbar.outline.set_visible(False)
    save(fig, "figure4_decision_matrices")


if __name__ == "__main__":
    figure1()
    figure2()
    figure3()
    figure4()
