"""Reproduce the released-feature to Tables 2/4/calibration chain locally.

No participant data are included. Each step is explicit and resumable. Use a fresh
workspace; keep its data/ and all local_only/ outputs under controlled access.
"""
from __future__ import annotations
import os
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
import argparse
import ast
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

CORE = "pdci_demographic_baseline_20260911"
F5 = "pdci_sensitivity_policy_20260912"
A5 = "pdci_a5_matched_policy_20261001"
CAL = "pdci_calibration_hardened_20261104"
CACHE_NAMES = ("cohort.parquet", "static_bytask.parquet", "dyn_prosody.parquet",
               "dyn_ema.parquet", "dyn_ppg.parquet", "dyn_mfccdyn.parquet",
               "dyn_ltas.parquet", "dynamic_bytask.parquet", "dyn_linear_harmonics.parquet")
STEPS = ("init", "inventory", "freeze", "pilot", "labels", "static", "prosody", "ema", "ppg",
         "mfcc", "mel", "dynamic", "harmonics", "prepare", "compare-inputs",
         "fits", "policies", "calibration", "reconcile")

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(2**20), b""):
            h.update(block)
    return h.hexdigest()

def write(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False, default=str) + "\n", encoding="utf-8")

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def versions():
    out = {"python": platform.python_version(), "platform": platform.platform()}
    for package in ("numpy", "pandas", "scipy", "scikit-learn", "joblib", "pyarrow", "threadpoolctl"):
        out[package] = importlib.metadata.version(package)
    return out

def memory_gate(minimum_gib=3.0):
    """Portable default is no enforced gate; Windows local runner can enable it."""
    requested = float(os.environ.get("PDCI_MIN_COMMIT_GIB", "0"))
    if os.name != "nt" or requested <= 0:
        return
    import ctypes
    class Status(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
            (name, ctypes.c_ulonglong) for name in ("total_phys", "avail_phys",
             "total_page", "avail_page", "total_virtual", "avail_virtual", "avail_extended")]
    status = Status()
    status.length = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("GlobalMemoryStatusEx failed")
    headroom = status.avail_page / 2**30
    if headroom < max(minimum_gib, requested):
        raise MemoryError("Commit-headroom gate; rerun this checkpointed step later")

def setup(args):
    workspace = args.workspace.resolve()
    data_root = args.data_root.resolve()
    roots = {data_root / "analysis"}
    if args.canonical_analysis is not None:
        roots.add(args.canonical_analysis.resolve())
    protected = [data_root/"features", data_root/"phenotype", Path(__file__).resolve().parent]
    for root in roots:
        if workspace == root or root.is_relative_to(workspace):
            raise ValueError("Workspace overlaps an original analysis root")
        protected += [root/"data", root/"src"]
        protected += [root/"results"/run for run in
                      ("pdci_fully_nested_20260911", CORE, F5, A5, CAL)]
    if workspace == data_root or data_root.is_relative_to(workspace):
        raise ValueError("Workspace overlaps the controlled release root")
    for source in protected:
        source = source.resolve()
        if workspace == source or workspace.is_relative_to(source) or source.is_relative_to(workspace):
            raise ValueError("Workspace overlaps a protected input/source folder")
    # A separate dated result subtree under the common analysis root is allowed.
    os.environ["PDCI_DATA_ROOT"] = str(data_root)
    os.environ["PDCI_ANALYSIS_ROOT"] = str(workspace)
    os.environ["PDCI_PARQUET_BATCH_ROWS"] = str(args.batch_rows)
    os.environ["PDCI_MIN_COMMIT_GIB"] = str(args.min_commit_gib)
    sys.path.insert(0, str(workspace / "src"))
    return workspace, data_root

def initialize(args, workspace):
    if (workspace / "src").exists():
        raise FileExistsError("Workspace already initialized; resume another explicit step")
    release = Path(__file__).resolve().parent
    workspace.mkdir(parents=True, exist_ok=True)
    shutil.copytree(release / "src", workspace / "src")
    for source in (release / "results").rglob("*"):
        # Only runnable support code and public protocol documents, never result tables.
        if source.is_file() and source.suffix in {".py", ".md"}:
            target = workspace / "results" / source.relative_to(release / "results")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    for name in ("requirements.txt", "SEEDS_AND_RUNS.md", "REPRODUCE_FROM_FEATURES.md"):
        shutil.copyfile(release / name, workspace / name)
    write(workspace / "qa" / "INITIALIZED.json",
          dict(status="PASS", created=now(), data_copied=False, source_release_sha256={
              str(p.relative_to(release)): sha(p) for p in release.rglob("*") if p.is_file()}))

def load_config():
    import config
    import parquet_stream
    original = parquet_stream.iter_row_groups
    def guarded(*args, **kwargs):
        for frame in original(*args, **kwargs):
            memory_gate()
            yield frame
    parquet_stream.iter_row_groups = guarded
    return config

def inventory(config):
    import pyarrow.parquet as pq
    rows = []
    for name, path in config.PARQUET.items():
        f = pq.ParquetFile(path)
        rows.append(dict(modality=name, file=path.name, bytes=path.stat().st_size,
                         rows=f.metadata.num_rows, row_groups=f.num_row_groups,
                         max_row_group_bytes=max(f.metadata.row_group(i).total_byte_size
                                                 for i in range(f.num_row_groups)),
                         columns=f.schema_arrow.names))
    return rows

def freeze(workspace, config, canonical=None):
    target = workspace / "qa" / "FEATURE_FREEZE.json"
    if target.exists():
        raise FileExistsError("Already frozen")
    paths = [config.STATIC_TSV, *config.PARQUET.values(),
             *(config.PHENO.rglob("*.tsv"))]
    scripts = [p for p in workspace.rglob("*.py")] + [Path(__file__).resolve()]
    canonical_files = []
    if canonical is not None:
        canonical_files += [canonical/"data"/name for name in CACHE_NAMES]
        for run in ("pdci_fully_nested_20260911", CORE, F5, A5, CAL):
            canonical_files += [p for p in (canonical/"results"/run).rglob("*")
                                if p.is_file() and p.suffix in {".csv",".json",".parquet",".joblib",".npz",".py"}]
    protocol = workspace / ("ANALYSIS_PLAN.md" if (workspace/"ANALYSIS_PLAN.md").exists() else "REPRODUCE_FROM_FEATURES.md")
    write(target, dict(status="FROZEN", created=now(), versions=versions(),
                       data_root=str(config.ROOT),analysis_root=str(workspace),
                       canonical_analysis=str(canonical) if canonical is not None else None,
                       protocols={str(protocol):sha(protocol)},
                       canonical_sources={str(p):sha(p) for p in sorted(set(canonical_files))},
                       sources={str(p): sha(p) for p in sorted(set(paths))},
                       scripts={str(p): sha(p) for p in sorted(scripts)},
                       inventory=inventory(config), batch_rows=int(os.environ["PDCI_PARQUET_BATCH_ROWS"]),
                       rule="Original per-recording mathematics, float32 casts and source order"))

def verify_code(workspace):
    frozen = read(workspace / "qa" / "FEATURE_FREEZE.json")
    for p, expected in {**frozen["scripts"], **frozen["protocols"]}.items():
        if sha(p) != expected:
            raise RuntimeError("Frozen code changed; stop and use a new workspace")


def verify_inputs(workspace, config, step):
    """Hash every original input actually used by a step immediately before use."""
    spec = read(workspace/"qa"/"FEATURE_FREEZE.json")
    raw = spec["sources"]
    modalities = {
        "prosody": ("sparc_pitch","sparc_periodicity","sparc_loudness"),
        "ema": ("sparc_ema",), "ppg": ("ppgs",), "mfcc": ("mfcc",),
        "mel": ("mel",), "harmonics": ("spectrogram",),
        "pilot": ("sparc_ema","ppgs","mfcc","mel","spectrogram")}
    if step in modalities:
        used = {str(config.PARQUET[key]) for key in modalities[step]}
    elif step == "static":
        used = {str(config.STATIC_TSV)}
    elif step == "labels":
        used = {str(config.STATIC_TSV)} | {str(p) for p in config.PHENO.rglob("*.tsv")}
    elif step in ("prepare","reconcile"):
        used = set(raw)
    else:
        used = set()
    for p in sorted(used):
        if p not in raw or sha(p) != raw[p]:
            raise RuntimeError("Released input changed or was not frozen; stop")
    if step in ("compare-inputs","reconcile"):
        for p,expected in spec.get("canonical_sources",{}).items():
            if sha(p) != expected:
                raise RuntimeError("Canonical reference input changed; stop")
    # Newly reconstructed inputs are also immutable between completed stages.
    for receipt in sorted((workspace/"qa").glob("STEP_*.json")):
        for rel,expected in read(receipt).get("output_sha256",{}).items():
            if sha(workspace/rel) != expected:
                raise RuntimeError("Previously reconstructed output changed; stop")

def call_step(workspace, script, *arguments):
    # Logs remain local and must not be included in any code archive.
    tag = hashlib.sha256(json.dumps([script, *arguments]).encode()).hexdigest()[:12]
    log = workspace / "local_only" / "logs" / (Path(script).stem + "_" + tag + ".log")
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("a", encoding="utf-8") as handle:
        subprocess.run([sys.executable, "-B", str(workspace / script), *arguments],
                       cwd=workspace, stdout=handle, stderr=subprocess.STDOUT, check=True)


def pilot(workspace, config):
    """Small deterministic raw I/O pilot; aggregate timing/memory only, no fitting."""
    import numpy as np
    import pyarrow.parquet as pq
    from parquet_stream import KEYS
    import ctypes
    started = time.time()
    records = []
    # Eight first-source-order recordings per modality; fixed before inspection.
    for module, source, column in (
            ("extract_ema","sparc_ema","ema"), ("extract_ppg","ppgs","ppgs"),
            ("extract_mfccdyn","mfcc","mfcc"), ("extract_ltas","mel","mel_spectrogram"),
            ("extract_linear_harmonics","spectrogram","spectrogram")):
        memory_gate()
        t = time.time()
        pf = pq.ParquetFile(config.PARQUET[source])
        batch = next(pf.iter_batches(batch_size=8,row_groups=[0],
                       columns=KEYS+[column,"n_frames"],use_threads=False))
        frame = batch.to_pandas()
        summarise = importlib.import_module(module).summarise
        count = 0
        for row in frame.itertuples(index=False):
            value = getattr(row,column)
            summary = summarise(value) if source=="spectrogram" else summarise(dict(value=value,n_frames=row.n_frames))
            assert isinstance(summary,dict) and len(summary)>0
            count += 1
        records.append(dict(modality=source,recordings=count,seconds=time.time()-t))
        del batch,frame,pf,summary
    memory = {}
    if os.name == "nt":
        class Counters(ctypes.Structure):
            _fields_=[("cb",ctypes.c_ulong),("faults",ctypes.c_ulong)]+[(n,ctypes.c_size_t)
                 for n in ("peak_ws","ws","peak_paged","paged","peak_nonpaged","nonpaged",
                           "pagefile","peak_pagefile","private")]
        c=Counters();c.cb=ctypes.sizeof(c)
        ctypes.windll.kernel32.GetCurrentProcess.restype = ctypes.c_void_p
        process=ctypes.windll.kernel32.GetCurrentProcess()
        get_memory=ctypes.windll.psapi.GetProcessMemoryInfo
        get_memory.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_ulong]
        get_memory.restype=ctypes.c_int
        if get_memory(process,ctypes.byref(c),c.cb):
            memory=dict(peak_working_set_bytes=c.peak_ws,peak_commit_bytes=c.peak_pagefile,
                        ending_private_bytes=c.private)
    write(workspace/"qa"/"RAW_PILOT.json",dict(status="PASS",records=records,
          elapsed_seconds=time.time()-started,memory=memory,scientific_fits=0,
          all_recordings_reproduced=False,scope="small deterministic throughput/footprint pilot only"))

def compare_inputs(workspace, canonical=None):
    import numpy as np
    import pandas as pd
    import joblib
    from sklearn.model_selection import RepeatedStratifiedKFold
    got = joblib.load(workspace / "results" / CORE / "local_only/input_payload.joblib")
    assert len(got["ids"]) == len(set(got["ids"])) == 750
    assert np.bincount(got["y"]).tolist() == [598,90,62]
    expected_splits = list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=20260725).split(
        np.zeros(750), got["y"]))
    assert len(got["splits"]) == 15
    coverage = np.zeros(750, int)
    for (tr,te),(a,b) in zip(got["splits"], expected_splits):
        assert np.array_equal(tr,a) and np.array_equal(te,b) and not set(tr)&set(te)
        coverage[te] += 1
    assert np.all(coverage == 3) and got["asc"].shape == (750,3)
    if canonical is None:
        write(workspace/"qa"/"INPUTS_GATE.json", dict(status="PASS", created=now(),
              scope="structure/counts/partition gate only; no canonical caches supplied",
              canonical_cache_comparison=False, participants=750, class_counts=[598,90,62],
              partitions_exact=15))
        return
    report = []
    for name in CACHE_NAMES:
        a = pd.read_parquet(workspace / "data" / name)
        b = pd.read_parquet(canonical / "data" / name)
        # Local-only values never leave the process or get serialized in the receipt.
        keys = [key for key in ("participant_id", "session_id", "task_name") if key in a.columns]
        if keys:
            a = a.sort_values(keys, kind="stable").reset_index(drop=True)
            b = b.sort_values(keys, kind="stable").reset_index(drop=True)
        else:
            a, b = a.sort_index(), b.sort_index()
        assert list(a.columns) == list(b.columns) and a.shape == b.shape, name + ": schema/shape"
        pd.testing.assert_index_equal(a.index, b.index)
        assert a.dtypes.equals(b.dtypes), name + ": dtype mismatch"
        numeric, exact, maximum = 0, True, 0.0
        for col in a.columns:
            if pd.api.types.is_numeric_dtype(a[col]) and pd.api.types.is_numeric_dtype(b[col]):
                x = a[col].to_numpy(dtype=float, na_value=np.nan)
                y = b[col].to_numpy(dtype=float, na_value=np.nan)
                good = np.isfinite(x) & np.isfinite(y)
                assert np.array_equal(np.isnan(x), np.isnan(y)), name + ": missingness"
                assert np.array_equal(np.isposinf(x), np.isposinf(y)) and np.array_equal(np.isneginf(x), np.isneginf(y)), name + ": infinity"
                delta = float(np.max(np.abs(x[good].astype(float) - y[good].astype(float)))) if good.any() else 0.0
                maximum = max(maximum, delta)
                exact &= bool(np.array_equal(x, y, equal_nan=True))
                numeric += int(good.sum())
            else:
                assert a[col].astype("string").fillna("<NA>").equals(b[col].astype("string").fillna("<NA>")), name + ": keys/text"
        report.append(dict(file=name, rows=len(a), columns=len(a.columns), numeric_values=numeric,
                           exact=bool(exact), max_abs_difference=maximum))
        if not exact:
            write(workspace / "qa" / "INPUTS_GATE.json", dict(status="FAIL", cache_comparisons=report))
            raise AssertionError(name + ": numeric cache mismatch; no model fits authorized by gate")
    got = joblib.load(workspace / "results" / CORE / "local_only/input_payload.joblib")
    ref = joblib.load(canonical / "results" / CORE / "local_only/input_payload.joblib")
    assert got.keys() == ref.keys()
    def equality(x, y):
        if isinstance(x, dict):
            return x.keys() == y.keys() and all(equality(x[k], y[k]) for k in x)
        if isinstance(x, (list, tuple)):
            return len(x) == len(y) and all(equality(a, b) for a, b in zip(x, y))
        x, y = np.asarray(x), np.asarray(y)
        return x.shape == y.shape and x.dtype == y.dtype and (np.array_equal(x, y, equal_nan=True)
            if np.issubdtype(x.dtype, np.number) else np.array_equal(x, y))
    assert equality(got, ref), "Final input payload mismatch"
    for name in ("candidate_grid.json", "feature_schemas.json"):
        assert read(workspace/"results"/CORE/name) == read(canonical/"results"/CORE/name), name
    write(workspace/"qa"/"INPUTS_GATE.json", dict(status="PASS", created=now(), cache_comparisons=report,
        canonical_cache_comparison=True, payload_arrays_exact=True, schemas_and_grids_exact=True, partitions_exact=15,
        participants=750, class_counts=[598,90,62], canonical_data_copied=False))

def table_comparison(a, b, tolerance=1e-9):
    import numpy as np
    import pandas as pd
    x, y = pd.read_csv(a, float_precision="round_trip"), pd.read_csv(b, float_precision="round_trip")
    assert list(x.columns) == list(y.columns) and x.shape == y.shape, a.name
    count, maximum = 0, 0.0
    for col in x:
        if pd.api.types.is_numeric_dtype(x[col]) and pd.api.types.is_numeric_dtype(y[col]):
            aa, bb = x[col].to_numpy(float), y[col].to_numpy(float)
            assert np.array_equal(np.isnan(aa), np.isnan(bb)), a.name
            assert np.allclose(aa, bb, rtol=0, atol=tolerance, equal_nan=True), a.name + ": numeric"
            finite = np.isfinite(aa) & np.isfinite(bb)
            if finite.any():
                maximum = max(maximum, float(np.max(np.abs(aa[finite]-bb[finite]))))
            count += int(finite.sum())
        else:
            assert x[col].fillna("<NA>").astype(str).equals(y[col].fillna("<NA>").astype(str)), a.name + ": text"
    return dict(file=a.name, rows=len(x), numeric_values=count, max_abs_difference=maximum, status="PASS")

def reconcile(workspace, canonical):
    tables = {
        CORE: ("auc_intervals.csv", "primary_baseline_comparisons.csv", "pooled_oof_metrics.csv",
               "repeat_metrics.csv", "fold_metrics.csv", "operating_points.csv",
               "confusion_matrices.csv", "training_only_thresholds.csv", "selection_counts.csv"),
        F5: ("operating_points.csv", "policy_summary.csv", "confusion_matrices.csv",
             "training_thresholds.csv", "nominal_bootstrap_intervals.csv"),
        A5: ("policy_comparison.csv", "paired_primary_voice_minus_baseline.csv",
             "operating_points.csv", "confusion_matrices.csv", "nominal_bootstrap_intervals.csv"),
        CAL: ("probability_scores.csv", "calibration_diagnostics.csv", "repeat_probability_scores.csv",
              "repeat_calibration_diagnostics.csv", "clipping_counts.csv")}
    results = {}
    for run, names in tables.items():
        results[run] = [table_comparison(workspace/"results"/run/name, canonical/"results"/run/name) for name in names]
    frozen = read(workspace/"qa"/"FEATURE_FREEZE.json")
    for p, expected in frozen["sources"].items():
        assert sha(p) == expected, "Original released input changed"
    write(workspace/"qa"/"RESULT_RECONCILIATION.json", dict(status="PASS", created=now(),
         tolerance=1e-9, tables=results, released_inputs_unchanged=True, scope="released-feature-to-result",
         clean_install_tested=False, public_archive_published=False))

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("step", choices=STEPS)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--workspace", type=Path, required=True)
    ap.add_argument("--canonical-analysis", type=Path)
    ap.add_argument("--batch-rows", type=int, default=32)
    ap.add_argument("--min-commit-gib", type=float, default=0)
    args = ap.parse_args()
    if args.batch_rows < 1:
        raise ValueError("batch rows must be positive")
    workspace, _ = setup(args)
    start = time.time()
    if args.step == "init":
        initialize(args, workspace)
        print("Initialized code-only workspace")
        return
    config = load_config()
    if args.step == "inventory":
        print(json.dumps(inventory(config)))
        return
    memory_gate()
    if args.step == "freeze":
        freeze(workspace, config, args.canonical_analysis.resolve() if args.canonical_analysis else None)
        print("Frozen released input and code hashes")
        return
    verify_code(workspace)
    frozen = read(workspace/"qa"/"FEATURE_FREEZE.json")
    if frozen["data_root"] != str(args.data_root.resolve()) or frozen["analysis_root"] != str(workspace):
        raise RuntimeError("Input/output root differs from the frozen configuration")
    if frozen["batch_rows"] != args.batch_rows:
        raise RuntimeError("Batch size differs from frozen configuration")
    if args.canonical_analysis is not None and frozen.get("canonical_analysis") != str(args.canonical_analysis.resolve()):
        raise RuntimeError("Canonical input root was not frozen for this run")
    if (workspace/"qa"/("STEP_"+args.step+".json")).exists():
        raise FileExistsError("Step already complete; refusing to overwrite its outputs")
    verify_inputs(workspace, config, args.step)
    target_names = dict(labels="cohort.parquet", static="static_bytask.parquet",
                        prosody="dyn_prosody.parquet", ema="dyn_ema.parquet",
                        ppg="dyn_ppg.parquet", mfcc="dyn_mfccdyn.parquet",
                        mel="dyn_ltas.parquet", dynamic="dynamic_bytask.parquet")
    if args.step in target_names and (config.DATA / target_names[args.step]).exists():
        raise FileExistsError("Step output already exists; do not overwrite")
    if args.step == "pilot":
        pilot(workspace, config)
    elif args.step in ("labels", "static"):
        importlib.import_module("build_labels" if args.step == "labels" else "build_static_features").main()
    elif args.step == "prosody":
        import extract_prosody
        extract_prosody.main()
    elif args.step in ("ema", "ppg", "mfcc", "mel"):
        from parquet_stream import extract
        module, source, column = {
            "ema": ("extract_ema", "sparc_ema", "ema"), "ppg": ("extract_ppg", "ppgs", "ppgs"),
            "mfcc": ("extract_mfccdyn", "mfcc", "mfcc"),
            "mel": ("extract_ltas", "mel", "mel_spectrogram")}[args.step]
        extract(config.PARQUET[source], column, importlib.import_module(module).summarise,
                config.DATA / target_names[args.step])
    elif args.step == "dynamic":
        call_step(workspace, "src/build_pdci_dynamic_bytask.py")
    elif args.step == "harmonics":
        import extract_linear_harmonics as H
        import pyarrow.parquet as pq
        if H.OUT.exists():
            raise FileExistsError("Harmonic output already complete")
        H.PARTS.mkdir(parents=True, exist_ok=True)
        groups = pq.ParquetFile(H.SOURCE).num_row_groups
        for group in range(groups):
            memory_gate()
            record = H.run_group(group, H.PARTS, H.GENERAL_TASKS)
            print(json.dumps(record), flush=True)
            assert record["status"] == "ok", "Harmonic chunk failed; checkpoint retained"
        H.combine(H.PARTS, groups, H.OUT)
    elif args.step == "prepare":
        if not (workspace/"results/pdci_fully_nested_20260911/FROZEN_SPEC.json").exists():
            call_step(workspace, "src/pdci_fully_nested_20260911.py", "prepare")
        call_step(workspace, "src/pdci_demographic_baseline_20260911.py", "selftest")
        if not (workspace/"results"/CORE/"FROZEN_SPEC.json").exists():
            call_step(workspace, "src/pdci_demographic_baseline_20260911.py", "prepare")
    elif args.step == "compare-inputs":
        compare_inputs(workspace, args.canonical_analysis.resolve() if args.canonical_analysis else None)
    elif args.step == "fits":
        assert read(workspace/"qa"/"INPUTS_GATE.json")["status"] == "PASS"
        import pdci_demographic_baseline_20260911 as N
        from threadpoolctl import threadpool_limits
        with threadpool_limits(1):
            for outer in range(15):
                memory_gate()
                N.fit_fold(outer)
            N.report()
        call_step(workspace, "results/"+CORE+"/support/audit_saved_bootstrap.py")
    elif args.step == "policies":
        for cmd in ("freeze", "run"):
            call_step(workspace, "src/"+F5+".py", cmd)
        call_step(workspace, "results/"+F5+"/support/independent_policy_audit.py")
        for cmd in ("freeze", "gate", "run"):
            call_step(workspace, "src/"+A5+".py", cmd)
    elif args.step == "calibration":
        out = workspace/"results"/CAL
        spec = out/"FROZEN_SPEC.json"
        if spec.exists():
            raise FileExistsError("Calibration specification already frozen")
        rels = [f"results/{CORE}/local_only/participant_oof_predictions.parquet",
                f"results/{CORE}/local_only/all_fold_predictions.parquet",
                f"results/{CORE}/auc_intervals.csv"]
        write(spec, dict(family="F11-CAL", authority="local reproduction", frozen=now(),
              script_sha256=sha(workspace/"src/pdci_calibration_20261104_v2.py"),
              protocol_sha256=sha(out/"ANALYSIS_PLAN.md"),
              inputs={p:sha(workspace/p) for p in rels}, versions=versions(),
              seeds=dict(screen=20261107,stage2=20261108,threeclass=20261109), bootstrap=5000))
        call_step(workspace, "src/pdci_calibration_20261104_v2.py",
                  "--analysis-root", str(workspace), "--output", str(out))
    elif args.step == "reconcile":
        if args.canonical_analysis is None:
            raise ValueError("Canonical aggregate location required")
        reconcile(workspace, args.canonical_analysis.resolve())
    outputs = {}
    if args.step in target_names:
        q = config.DATA/target_names[args.step]
        outputs[str(q.relative_to(workspace))] = sha(q)
    if args.step == "harmonics":
        q = config.DATA/"dyn_linear_harmonics.parquet"
        outputs[str(q.relative_to(workspace))] = sha(q)
    if args.step == "prepare":
        for run in ("pdci_fully_nested_20260911", CORE):
            for relative in ("local_only/input_payload.joblib","feature_schemas.json","candidate_grid.json"):
                q=workspace/"results"/run/relative
                outputs[str(q.relative_to(workspace))] = sha(q)
    write(workspace/"qa"/("STEP_"+args.step+".json"), dict(status="PASS", completed=now(),
          step=args.step, elapsed_seconds=round(time.time()-start,3),output_sha256=outputs))
    print(json.dumps(dict(step=args.step,status="PASS",elapsed_seconds=round(time.time()-start,3))), flush=True)

if __name__ == "__main__":
    main()
