"""Import and synthetic checks only; participant-data reads are rejected."""
from pathlib import Path
import os,sys
sys.dont_write_bytecode=True
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
import importlib.util,json,tempfile,shutil
ANALYSIS=Path(__file__).resolve().parents[1]
BLOCKED=[]
def data_guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(args[0])
        if p.suffix.casefold() in {'.parquet','.tsv','.joblib','.npz'}:
            BLOCKED.append(p.name)
            raise RuntimeError('Study-data reads are forbidden during synthetic/import checks')
sys.addaudithook(data_guard)
def load(name,relative):
    p=ANALYSIS/relative
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m
n=load('portable_subgroups','results/pdci_reviewer_extension_20261104/pdci_subgroup_analysis_20261104.py')
d=load('portable_device','results/pdci_device_matched_refit_20261104/pdci_device_matched_refit.py')
c=load('portable_clinical','results/pdci_clinical_timing_20261104/pdci_clinical_timing_audit_v2.py')
s=load('portable_semantic','results/pdci_clinical_timing_20261104/pdci_semantic_followup.py')
e=load('portable_exact_device','results/pdci_clinical_timing_20261104/pdci_exact_device_feasibility.py')
checks={}
checks['subgroup_known_cases']=n.known_case_tests()['status']=='PASS'
checks['device_missing_tokens']=all(d.missing(x) for x in ['', 'NA','n/a',' NaN ','none','NULL']) and not d.missing('synthetic populated value')
checks['numeric_checkbox_decoder']=s.decoded('1.0',{},True)=='Recorded selected' and s.decoded('0.0',{},True)=='Recorded unselected'
checks['numeric_dictionary_decoder']=s.decoded('2.0',{'choices':[{'value':2,'name':{'en':'synthetic code two'}}]},False)=='synthetic code two'
checks['unknown_clinical_token_withheld']=s.decoded('synthetic unexpected token',{},False)=='Other populated token (withheld)'
checks['generic_device_branch_removed']=not hasattr(s,'generic')
checks['exact_device_generic_recognition']=e.semantic('USB microphone')['safe_generic_label']=='USB microphone'
checks['identifier_style_token_withheld']=e.semantic('serial 123456789')['potential_identifier_pattern']
checks['unknown_device_token_withheld']=e.semantic('synthetic-unrecognized-description')['safe_generic_label']=='Unresolved populated label (withheld)'
scratch=Path(tempfile.mkdtemp(prefix='synthetic_',dir=ANALYSIS/'validation')).resolve()
assert scratch.is_relative_to(ANALYSIS.resolve())
try:
    c.OUT=scratch
    c.tests();checks['clinical_synthetic_prep']=json.loads((scratch/'qa/tests.json').read_text())['status']=='PASS'
    rows=[{'field':'diagnosis_alz_dementia_mci_ds_cdr','category':'synthetic category','participants':1},
          {'field':'vocabulary_item_difficulty_1','category':'synthetic category','participants':1},
          {'field':'synthetic_retained_field','category':'synthetic category','participants':10}]
    for name in ('clinical_categories.csv','clinical_categories_decoded.csv'):
        c.write_csv(name,rows)
        out=c.pd.read_csv(scratch/name)
        checks[name+'_suppression']=out.field.tolist()==['synthetic_retained_field']
    avail=[{'field':'diagnosis_alz_dementia_mci_ds_cdr','observed':1,'missing':9},
           {'field':'vocabulary_item_difficulty_1','observed':10,'missing':0}]
    c.write_csv('clinical_availability.csv',avail)
    checks['availability_not_suppressed']=c.pd.read_csv(scratch/'clinical_availability.csv').field.tolist()==[r['field'] for r in avail]
    assert all(checks.values()),'Synthetic check failed'
    assert not BLOCKED
finally:
    assert scratch.is_relative_to((ANALYSIS/'validation').resolve())
    shutil.rmtree(scratch)
result={'status':'PASS','scope':'Imports and artificial synthetic examples only','checks':checks,'study_data_reads':0,'study_models_fitted':0,'study_commands_executed':[]}
print(json.dumps(result,indent=2))
