"""Additive F5 path-only adapter; original frozen scripts are unchanged."""
from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys
from datetime import datetime, timezone
R=Path(__file__).resolve().parent
A=R.parents[2]
C=A/'manuscript_frontiers_pdci_revision_r15_20261116/code_release'
W=R/'workspace'
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
spec=importlib.util.spec_from_file_location('reproduction',C/'reproduce_from_features.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify_code(W)
m.memory_gate(5)
receipt=R/'POLICY_PATH_ADAPTER.json'
record={'created':datetime.now(timezone.utc).isoformat(),'scope':'F5 path constants only; no scientific function, threshold, seed, data, or frozen file modified','reason':'F5 historical ROOT/analysis layout differs from isolated workspace','adapter_sha256':m.sha(__file__),'original_driver_sha256':m.sha(C/'reproduce_from_features.py'),'original_F5_sha256':m.sha(W/'src'/f'{m.F5}.py'),'frozen_manifest_sha256':m.sha(W/'qa/FEATURE_FREEZE.json'),'completed_fit_receipt_sha256':m.sha(W/'qa/STEP_fits.json'),'corrected_constants':{'ROOT':str(A.parent),'ANALYSIS':str(W),'SOURCE':str(W/'results'/m.CORE),'OUT':str(W/'results'/m.F5),'LOCAL':str(W/'results'/m.F5/'local_only')},'fits_rerun':False}
if receipt.exists():
    old=json.loads(receipt.read_text());assert all(old[k]==v for k,v in record.items() if k!='created')
else: receipt.write_text(json.dumps(record,indent=2)+'\n')
original=m.call_step
def adapted(workspace,script,*arguments):
    if script != 'src/'+m.F5+'.py':
        return original(workspace,script,*arguments)
    code="import importlib.util,sys;from pathlib import Path;p=Path(sys.argv[1]);w=Path(sys.argv[2]);s=importlib.util.spec_from_file_location('f5',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=Path(sys.argv[3]);m.ANALYSIS=w;m.SOURCE=w/'results/pdci_demographic_baseline_20260911';m.OUT=w/'results/pdci_sensitivity_policy_20260912';m.LOCAL=m.OUT/'local_only';sys.argv=[str(p),*sys.argv[4:]];m.main()"
    log=workspace/'local_only/logs/F5_path_adapter.log'
    with log.open('a',encoding='utf-8') as h:
        subprocess.run([sys.executable,'-B','-c',code,str(workspace/script),str(workspace),str(A.parent),*arguments],cwd=workspace,stdout=h,stderr=subprocess.STDOUT,check=True)
m.call_step=adapted
sys.argv=[str(C/'reproduce_from_features.py'),'policies','--data-root',str(A.parent),'--workspace',str(W),'--batch-rows','32','--min-commit-gib','3']
m.main()
