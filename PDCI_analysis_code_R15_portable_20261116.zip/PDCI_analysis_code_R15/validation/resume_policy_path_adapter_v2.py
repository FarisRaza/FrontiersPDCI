"""Resume A5 with F5 imported-module path correction; preserve frozen files."""
from pathlib import Path
import importlib.util,json,os,subprocess,sys
from datetime import datetime,timezone
R=Path(__file__).resolve().parent;A=R.parents[2];W=R/'workspace';C=A/'manuscript_frontiers_pdci_revision_r15_20261116/code_release'
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['PDCI_MIN_COMMIT_GIB']='5'
s=importlib.util.spec_from_file_location('repro',C/'reproduce_from_features.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.memory_gate(5);m.verify_code(W)
f5=W/'results'/m.F5
for name,key in [('FROZEN_SPEC.json','protected_sha256'),('AUDIT.json','output_sha256')]:
    for p,h in m.read(f5/name)[key].items():assert m.sha(p)==h,(name,p)
assert (f5/'COMPLETE.json').exists()
record={'created':datetime.now(timezone.utc).isoformat(),'scope':'Correct imported F5 path constants for A5; verify and reuse completed F5 results and existing A5 freeze','adapter_sha256':m.sha(__file__),'previous_adapter_receipt_sha256':m.sha(R/'POLICY_PATH_ADAPTER.json'),'original_A5_sha256':m.sha(W/'src'/f'{m.A5}.py'),'F5_AUDIT_sha256':m.sha(f5/'AUDIT.json'),'A5_frozen_sha256':m.sha(W/'results'/m.A5/'FROZEN_SPEC.json'),'frozen_manifest_sha256':m.sha(W/'qa/FEATURE_FREEZE.json'),'fits_rerun':False,'frozen_sources_modified':False}
receipt=R/'POLICY_PATH_ADAPTER_V2.json';assert not receipt.exists();m.write(receipt,record)
original=m.call_step
def adapted(workspace,script,*arguments):
    if script=='src/'+m.F5+'.py':return
    if script!='src/'+m.A5+'.py':return original(workspace,script,*arguments)
    code="import importlib.util,sys;from pathlib import Path;p=Path(sys.argv[1]);w=Path(sys.argv[2]);s=importlib.util.spec_from_file_location('a5',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.P.ROOT=Path(sys.argv[3]);m.P.ANALYSIS=w;m.P.SOURCE=w/'results/pdci_demographic_baseline_20260911';m.P.OUT=w/'results/pdci_sensitivity_policy_20260912';m.P.LOCAL=m.P.OUT/'local_only';cmd=sys.argv[4];m.verify() if cmd=='freeze' else getattr(m,cmd)()"
    with (workspace/'local_only/logs/A5_path_adapter.log').open('a',encoding='utf-8') as h:subprocess.run([sys.executable,'-B','-c',code,str(workspace/script),str(workspace),str(A.parent),*arguments],cwd=workspace,stdout=h,stderr=subprocess.STDOUT,check=True)
m.call_step=adapted
sys.argv=[str(C/'reproduce_from_features.py'),'policies','--data-root',str(A.parent),'--workspace',str(W),'--batch-rows','32','--min-commit-gib','3'];m.main()
