"""Post hoc subgroup nested refits; all participant data stay in memory."""
from __future__ import annotations
import os, sys
sys.dont_write_bytecode = True
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import argparse, hashlib, json, platform, time, warnings
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import joblib
import numpy as np
import pandas as pd
import scipy, sklearn
from scipy.stats import t
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from threadpoolctl import threadpool_limits

OUT = Path(__file__).resolve().parent
ANALYSIS = OUT.parents[1]
SRC = ANALYSIS/'src'
sys.path.insert(0, str(SRC))
import pdci_demographic_baseline_20260911 as core
import pdci_review_analyses_20261026 as review
SOURCE = ANALYSIS/'results/pdci_demographic_baseline_20260911'
SEED = 20260725
B = 5000

def now(): return datetime.now(timezone.utc).isoformat()
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()
def write_json(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def inputs():
    paths = set(review.INPUTS)
    paths.update([SOURCE/'local_only/input_payload.joblib', SOURCE/'local_only/split_manifest.json',
                  SOURCE/'feature_schemas.json', SOURCE/'candidate_grid.json'])
    paths.update((SOURCE/'local_only/folds').glob('fold_*.json'))
    paths.update([SOURCE/'local_only/folds/fold_00.parquet'])
    for module in [core, review, core.C, core.PT, core.H, core.H.LH, review.A8]: paths.add(Path(module.__file__))
    for p in [review.A8.PD_TSV,review.A8.CI_TSV]: paths.add(p.with_suffix('.json'))
    return sorted(paths)

def freeze():
    assert not (OUT/'FROZEN_SPEC.json').exists(), 'Already frozen'
    write_json('FROZEN_SPEC.json', dict(family='F10-R13', authority='AR-45', frozen=now(),
        protocol_sha256=sha(OUT/'ANALYSIS_PLAN.md'), script_sha256=sha(__file__),
        inputs={str(p):sha(p) for p in inputs()},
        versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                      scipy=scipy.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__),
        seeds=dict(outer=SEED, inner='20260725+1009*outer_fit',bootstrap=[20261104,20261105]),
        bootstrap=B,workers=2,participant_output=False))
    print('Protocol, script and inputs frozen.', flush=True)

def verify():
    spec=json.loads((OUT/'FROZEN_SPEC.json').read_text(encoding='utf-8'))
    assert spec['script_sha256']==sha(__file__)
    assert spec['protocol_sha256']==sha(OUT/'ANALYSIS_PLAN.md')
    for p,h in spec['inputs'].items(): assert sha(p)==h, 'Input changed: '+p
    return spec

def known_case_tests():
    y=np.array([0,0,1,1]); p=np.array([.1,.2,.8,.9])
    assert roc_auc_score(y,p)==1 and roc_auc_score(y,1-p)==0
    assert roc_auc_score(y,np.ones(4))==.5
    assert average_precision_score(y,p)==1
    assert average_precision_score(y,np.ones(4))==.5
    for s in [p,1-p,np.ones(4),np.array([.2,.2,.8,.8])]:
        calc=weighted_metrics(y,s)
        for w in [np.ones(4),np.array([2,0,1,1]),np.array([1,2,2,1])]:
            auc,ap=calc(w)
            assert abs(auc-roc_auc_score(y,s,sample_weight=w))<1e-12
            assert abs(ap-average_precision_score(y,s,sample_weight=w))<1e-12
    a=np.array([[0.,np.nan,1.],[1.,1.,1.],[2.,3.,1.],[3.,5.,1.]])
    prep=core.Prep();z=prep.fit_transform(a)
    assert np.isfinite(z).all() and not prep.vary[-1]
    assert np.isfinite(prep.transform(np.array([[999.,np.inf,1.]]))).all()
    return dict(status='PASS',known_auc_ap=True,ties_and_weights=True,training_nan_handling=True)

def gate():
    verify(); tests=known_case_tests()
    data=joblib.load(SOURCE/'local_only/input_payload.joblib')
    y=np.asarray(data['y']); ids=pd.Index(data['ids']).astype(str).str.strip().str.zfill(6)
    assert ids.is_unique and len(ids)==750 and np.bincount(y).tolist()==[598,90,62]
    pred=pd.read_parquet(SOURCE/'local_only/participant_oof_predictions.parquet')
    pred.index=pred.index.astype(str).str.strip().str.zfill(6);pred=pred.reindex(ids)
    assert np.array_equal(pred.y_true.to_numpy(),y)
    ref=pd.read_csv(SOURCE/'auc_intervals.csv');checks=[]
    for model in ['primary','agesexcountry']:
        vals=core.metrics(y,pred[model+'_screen'].to_numpy(),pred[model+'_q'].to_numpy(),
                          pred[[model+'_p'+str(i) for i in range(3)]].to_numpy())
        for endpoint in ['screen','stage2','macro']:
            target=float(ref[(ref.model==model)&(ref.endpoint==endpoint)].auc.iloc[0])
            err=abs(vals[endpoint]-target); assert err<1e-9
            checks.append(dict(model=model,endpoint=endpoint,expected=target,observed=vals[endpoint],error=err))
    held=np.zeros(len(y),int)
    for tr,te in data['splits']:
        assert not set(tr)&set(te);assert len(tr)+len(te)==len(y);held[te]+=1
    assert (held==3).all()
    tr,te=data['splits'][0];tr=tr[y[tr]>0]
    choice=json.loads((SOURCE/'local_only/folds/fold_00.json').read_text())['choices']['stage2']
    with threadpool_limits(1),warnings.catch_warnings():
        warnings.simplefilter('ignore')
        q=core.stage2_bank(data['matrices'],tr,te,(y[tr]==1).astype(int),[choice])[core.ident(choice)]
    saved=pd.read_parquet(SOURCE/'local_only/folds/fold_00.parquet')
    assert np.array_equal(saved.participant_id.astype(str).str.zfill(6).to_numpy(),ids[te].to_numpy())
    err=float(np.max(np.abs(q-saved.primary_q.to_numpy())))
    assert err<=1e-7, f'Canonical selected fit mismatch {err}'
    write_json('GATE.json',dict(passed=True,time=now(),class_counts=[598,90,62],unique_participants=750,
        auroc_checks=checks,selected_fold0_prediction_max_error=err,disjoint_original_folds=15,
        heldout_predictions_per_participant=3,tests=tests))
    print('Canonical reproduction gate passed; max selected-fit error',err,flush=True)

def weighted_metrics(y,score):
    order=np.argsort(-score,kind='stable'); yy=np.asarray(y)[order].astype(float)
    cut=np.r_[np.flatnonzero(np.diff(np.asarray(score)[order])!=0),len(y)-1]
    def calculate(weights):
        w=np.asarray(weights)[order]
        tp=np.cumsum(w*yy)[cut];fp=np.cumsum(w*(1-yy))[cut]
        assert tp[-1]>0 and fp[-1]>0
        dt=np.diff(np.r_[0.,tp]); df=np.diff(np.r_[0.,fp])
        auc=np.sum(df*(tp+np.r_[0.,tp[:-1]])*.5)/(tp[-1]*fp[-1])
        den=tp+fp; precision=np.divide(tp,den,out=np.zeros_like(tp),where=den>0)
        ap=np.sum(dt*precision)/tp[-1]
        return float(auc),float(ap)
    return calculate

def select(y,bank,configs):
    scores={k:roc_auc_score(y,v) for k,v in bank.items()}
    best=max(scores.values()); feasible=[c for c in configs if scores[core.ident(c)]>=best-.005]
    return min(feasible,key=lambda c:(*core.complexity(c),core.ident(c)))

def fit_one(data,outer,subset_name):
    oi,tr,te=outer; y=data['y'];start=time.time()
    assert len(np.unique(y[tr]))==2 and len(np.unique(y[te]))==2 and not set(tr)&set(te)
    vbank={core.ident(c):np.full(len(tr),np.nan) for c in core.STAGE2}
    bbank={core.ident(c):np.full(len(tr),np.nan) for c in core.BASELINES}
    inner=StratifiedKFold(3,shuffle=True,random_state=SEED+1009*oi)
    for it,iv in inner.split(np.zeros(len(tr)),y[tr]):
        train,valid=tr[it],tr[iv]
        assert not set(train)&set(valid) and not set(train)&set(te)
        vb=core.stage2_bank(data['matrices'],train,valid,y[train],core.STAGE2)
        bb=core.baseline_bank(data['asc'],train,valid,y[train],core.BASELINES)
        for key,p in vb.items():vbank[key][iv]=p
        for key,p in bb.items():bbank[key][iv]=p
    assert all(np.isfinite(p).all() for p in [*vbank.values(),*bbank.values()])
    vc=select(y[tr],vbank,core.STAGE2);bc=select(y[tr],bbank,core.BASELINES)
    vp=core.stage2_bank(data['matrices'],tr,te,y[tr],[vc])[core.ident(vc)]
    bp=core.baseline_bank(data['asc'],tr,te,y[tr],[bc])[core.ident(bc)]
    for p in [vp,bp]:assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
    va=roc_auc_score(y[te],vp);ba=roc_auc_score(y[te],bp)
    row=dict(analysis=subset_name,outer_fold=oi,repeat=oi//5,fold=oi%5,train_n=len(tr),test_n=len(te),
        train_pd=int(y[tr].sum()),test_pd=int(y[te].sum()),voice_auc=va,baseline_auc=ba,gain=va-ba,
        voice_config=core.ident(vc),baseline_config=core.ident(bc),elapsed_seconds=time.time()-start)
    print(subset_name,'fold',oi,'complete',round(row['elapsed_seconds'],1),'s',flush=True)
    return te,vp,bp,row

def summarize(y,voice,baseline,name,seed):
    calculators=[weighted_metrics(y,voice),weighted_metrics(y,baseline),
                 weighted_metrics(1-y,1-voice),weighted_metrics(1-y,1-baseline)]
    def metrics(weights):
        v=calculators[0](weights);b=calculators[1](weights)
        vc=calculators[2](weights);bc=calculators[3](weights)
        return np.array([[v[0],b[0],v[0]-b[0]], [v[1],b[1],v[1]-b[1]], [vc[1],bc[1],vc[1]-bc[1]]])
    point=metrics(np.ones(len(y)));rng=np.random.default_rng(seed);draws=np.empty((B,3,3))
    pos=np.flatnonzero(y==1);neg=np.flatnonzero(y==0)
    for i in range(B):
        idx=np.r_[rng.choice(pos,len(pos),replace=True),rng.choice(neg,len(neg),replace=True)]
        draws[i]=metrics(np.bincount(idx,minlength=len(y)))
    bounds=np.quantile(draws,[.025,.975],axis=0);rows=[]
    for j,metric in enumerate(['auroc','average_precision_PD','average_precision_CI']):
        row=dict(analysis=name,metric=metric,n=len(y),n_PD=len(pos),n_CI=len(neg),bootstrap_seed=seed)
        for k,key in enumerate(['voice','baseline','difference']):
            row[key]=point[j,k];row[key+'_low']=bounds[0,j,k];row[key+'_high']=bounds[1,j,k]
        rows.append(row)
    return rows

def run():
    spec=verify(); assert json.loads((OUT/'GATE.json').read_text())['passed']
    assert not (OUT/'COMPLETION.json').exists(), 'Run already completed; no overwrite'
    started=now();data=joblib.load(SOURCE/'local_only/input_payload.joblib')
    ids=pd.Index(data['ids']).astype(str).str.strip().str.zfill(6)
    labels=review.load().reindex(ids);assert not labels.y_true.isna().any()
    assert np.array_equal(labels.y_true.to_numpy(),data['y'])
    masks=[(labels.y_true.isin([1,2])&(labels.country=='Canada')).to_numpy(),
           (((labels.y_true==1)&(labels.pd_subtype=="Idiopathic Parkinson's Disease (IPD)"))|
            ((labels.y_true==2)&(labels.ci_subtype=='Mild Cognitive Impairment (MCI)'))).to_numpy()]
    allrows=[];points=[];repeats=[];corrected=[]
    for subset_i,(name,mask,counts) in enumerate(zip(['Canada','idiopathic_PD_vs_MCI'],masks,[(49,59),(53,36)])):
        sub=dict(y=(data['y'][mask]==1).astype(int),asc=data['asc'][mask],
                 matrices={k:v[mask] for k,v in data['matrices'].items()})
        y=sub['y']; assert (int(y.sum()),int((1-y).sum()))==counts
        splitter=RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=SEED)
        outer=[(i,tr,te) for i,(tr,te) in enumerate(splitter.split(np.zeros(len(y)),y))]
        vs=np.full((3,len(y)),np.nan);bs=vs.copy();seen=np.zeros((3,len(y)),int);foldrows=[]
        with threadpool_limits(1),warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with ThreadPoolExecutor(max_workers=2) as pool:
                for te,v,b,row in pool.map(lambda z:fit_one(sub,z,name),outer):
                    repeat=row['repeat'];vs[repeat,te]=v;bs[repeat,te]=b;seen[repeat,te]+=1
                    foldrows.append(row)
        assert (seen==1).all() and np.isfinite(vs).all() and np.isfinite(bs).all()
        allrows.extend(foldrows);points.extend(summarize(y,vs.mean(0),bs.mean(0),name,20261104+subset_i))
        for i in range(3):
            va=roc_auc_score(y,vs[i]);ba=roc_auc_score(y,bs[i])
            repeats.append(dict(analysis=name,repeat=i,voice_auc=va,baseline_auc=ba,difference=va-ba))
        frame=pd.DataFrame(foldrows);d=frame.gain.to_numpy();m=d.mean()
        ratio=(frame.test_n/frame.train_n).mean();se=np.sqrt((1/15+ratio)*d.var(ddof=1))
        p=float(2*t.sf(abs(m/se),14)) if se>0 else float(m==0)
        corrected.append(dict(analysis=name,mean_fold_gain=m,corrected_se=se,test_train_ratio=ratio,
            ci_low=m-t.ppf(.975,14)*se,ci_high=m+t.ppf(.975,14)*se,p=p,df=14))
    ps=np.array([r['p'] for r in corrected]);order=np.argsort(ps);q=np.empty(2)
    q[order]=np.minimum.accumulate((ps[order]*2/np.arange(1,3))[::-1])[::-1].clip(0,1)
    for r,val in zip(corrected,q):r['BH2_q']=val
    for filename,rows in [('subgroup_metrics.csv',points),('subgroup_fold_metrics.csv',allrows),
                          ('subgroup_repeat_metrics.csv',repeats),('subgroup_corrected_cv.csv',corrected)]:
        pd.DataFrame(rows).to_csv(OUT/filename,index=False)
    choices=pd.DataFrame(allrows)
    for col in ['voice_config','baseline_config']:
        choices.groupby(['analysis',col]).size().reset_index(name='outer_fits').to_csv(OUT/(col+'_selection_counts.csv'),index=False)
    verify()
    write_json('COMPLETION.json',dict(status='COMPLETE_REQUIRES_INDEPENDENT_RECONCILIATION',started=started,
        ended=now(),family='F10-R13',outer_fits=30,original_input_hashes_unchanged=True,
        script_sha256=sha(__file__),protocol_sha256=spec['protocol_sha256'],versions=spec['versions'],
        participant_rows_written=False,original_primary_results_replaced=False))
    print('All subgroup refits and aggregate summaries complete.',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','gate','run'])
    globals()[parser.parse_args().action]()
