"""Independent saved-score bootstrap replay with sklearn; no fitting or result edits."""
import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
import hashlib
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.metrics import roc_auc_score

OUT = Path(__file__).resolve().parents[1]
SEED = 20260725 + 9911
MODELS = ("primary", "agesexcountry", "secondary_threeclass")
ENDPOINTS = ("screen", "stage2", "macro")


def sha(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def block(start, end, y, scores, draws):
    result = np.empty((end-start, len(MODELS), 3))
    case = y > 0
    for row, b in enumerate(range(start, end)):
        weight = draws[b]
        for i, model in enumerate(MODELS):
            s, q, p = scores[model]
            result[row, i, 0] = roc_auc_score(case, s, sample_weight=weight)
            result[row, i, 1] = roc_auc_score(y[case] == 1, q[case], sample_weight=weight[case])
            result[row, i, 2] = roc_auc_score(y, p, multi_class="ovr", average="macro", sample_weight=weight)
    print(f"bootstrap audit {start}:{end} complete", flush=True)
    return result


def main():
    paths = [OUT/"local_only/participant_oof_predictions.parquet", OUT/"auc_intervals.csv",
             OUT/"primary_baseline_comparisons.csv", OUT/"FROZEN_SPEC.json"]
    before = {str(path): sha(path) for path in paths}
    data = pd.read_parquet(paths[0])
    y = data.y_true.to_numpy(int)
    assert len(y) == 750 and np.bincount(y).tolist() == [598, 90, 62]
    scores = {name: (data[f"{name}_screen"].to_numpy(), data[f"{name}_q"].to_numpy(),
                     data[[f"{name}_p{c}" for c in range(3)]].to_numpy()) for name in MODELS}
    rng = np.random.default_rng(SEED)
    groups = [np.flatnonzero(y == c) for c in range(3)]
    draws = np.zeros((5000, len(y)), dtype=np.uint16)
    for b in range(5000):
        for indices in groups:
            draws[b, indices] = rng.multinomial(len(indices), np.full(len(indices), 1/len(indices)))
    results = Parallel(n_jobs=2, backend="loky", verbose=5)(
        delayed(block)(start, min(start+250, 5000), y, scores, draws)
        for start in range(0, 5000, 250))
    values = np.concatenate(results, axis=0)
    expected = pd.read_csv(paths[1]).set_index(["model", "endpoint"])
    expected_gain = pd.read_csv(paths[2]).set_index(["baseline", "endpoint"])
    checks = []
    for i, name in enumerate(MODELS):
        for j, endpoint in enumerate(ENDPOINTS):
            low, high = np.quantile(values[:, i, j], [.025, .975])
            saved = expected.loc[(name, endpoint)]
            error = max(abs(low-saved.ci_low), abs(high-saved.ci_high))
            checks.append(dict(kind="AUROC_interval", model=name, endpoint=endpoint, max_absolute_error=error))
            assert error < 1e-12
    for j, endpoint in enumerate(ENDPOINTS):
        low, high = np.quantile(values[:, 0, j]-values[:, 1, j], [.025, .975])
        saved = expected_gain.loc[("agesexcountry", endpoint)]
        error = max(abs(low-saved.bootstrap95_low), abs(high-saved.bootstrap95_high))
        checks.append(dict(kind="paired_gain_interval", model="agesexcountry", endpoint=endpoint, max_absolute_error=error))
        assert error < 1e-12
    assert before == {str(path): sha(path) for path in paths}
    output = dict(status="PASS", completed_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                  method="Independent sklearn.roc_auc_score(sample_weight) replay; no import of runner weighted-AUC code",
                  refits=0, bootstrap_draws=5000, AUROC_intervals_checked=9, paired_gain_intervals_checked=3,
                  max_absolute_error=max(c["max_absolute_error"] for c in checks),
                  source_results_unchanged=True, input_sha256=before, checks=checks)
    (OUT/"support/INDEPENDENT_BOOTSTRAP_AUDIT.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in output.items() if k not in {"checks", "input_sha256"}}, indent=2), flush=True)


if __name__ == "__main__":
    main()
