"""Descriptive audit of frozen-run choices and warnings; no fitting or testing."""
import json
from collections import Counter
from pathlib import Path
import pandas as pd

OUT = Path(__file__).resolve().parents[1]


def main():
    records = [json.loads((OUT/f"local_only/folds/fold_{i:02d}.json").read_text()) for i in range(15)]
    assert all(record["status"] == "COMPLETE" for record in records)
    summary = {}
    for stage in ("screen", "stage2", "secondary", "asc_screen", "asc_stage2"):
        choices = [record["choices"][stage] for record in records]
        configurations = Counter(json.dumps(choice, sort_keys=True) for choice in choices)
        fields = sorted(set().union(*(choice.keys() for choice in choices)))
        summary[stage] = {
            "selected_configuration_counts": [dict(configuration=json.loads(choice), count=count)
                                               for choice, count in configurations.most_common()],
            "marginal_counts": {field: dict(Counter(str(choice.get(field)) for choice in choices)) for field in fields}}
    saved = pd.read_parquet(OUT/"local_only/participant_oof_predictions.parquet")
    descriptive = []
    for label, group in saved.groupby("y_true"):
        values = group.primary_screen
        descriptive.append(dict(class_label=int(label), n=len(group), minimum=float(values.min()),
                                q25=float(values.quantile(.25)), median=float(values.median()),
                                q75=float(values.quantile(.75)), maximum=float(values.max()),
                                n_pooled_screen_ge_half=int((values >= .5).sum())))
    output = dict(status="COMPLETE", fits_or_tests_added=0, selected=summary,
                  warning_count=sum(record["warning_count"] for record in records),
                  retained_distinct_warning_examples=sorted({message for record in records for message in record["warning_examples"]}),
                  all_fold_receipts_complete=True, primary_pooled_screen_descriptives=descriptive,
                  primary_training_only_threshold_ranges={gate: dict(
                      minimum=min(record["thresholds"]["primary"][gate] for record in records),
                      maximum=max(record["thresholds"]["primary"][gate] for record in records)) for gate in ("sens90", "sens95")},
                  caution="Pooled-score descriptions are not the majority-vote decision rule; no threshold was changed.")
    (OUT/"support/SELECTION_WARNINGS.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
