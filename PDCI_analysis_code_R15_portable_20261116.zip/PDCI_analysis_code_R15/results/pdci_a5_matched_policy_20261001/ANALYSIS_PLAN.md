# Public reproduction protocol

This release copy documents the original calculation and the release-only portability changes. It is not the historically frozen protocol; a future rerun records a new hash and timestamp. No results were recomputed when preparing this copy.

# A5: matched primary-policy voice versus demographic baseline
Status: post hoc descriptive policy comparison, originally run 2026-10-01.

## Question and analysis family
F8-A5: compare the archived voice procedure with the archived age/sex/residence-country-only procedure under the SAME September 12 separate98_pd95 operating policy. Population: 750 participants (598 neither, 90 PD, 62 CI), the original 15 outer folds (five folds, three repeats). Unit: participant after repeated held-out decision aggregation. A5 changes thresholds and voting for the baseline, not its fitted models. It is not an external validation or a feature-causality analysis.

## Inputs and provenance
All paths relative to DATA_ROOT/analysis.
- results/pdci_demographic_baseline_20260911/local_only/split_manifest.json: ordered ids and 15 train/test index lists.
- For each fold 00..14, local_only/folds/fold_NN.json, fold_NN.parquet, fold_NN_selected_inner.parquet in that same run.
- Inner columns: participant_id, y_true, screen, stage2, asc_screen, asc_stage2. The first pair belongs to voice; asc pair to the baseline. Stage2 values exist only for true training cases. All selected inner scores were produced on held-out inner partitions within their own outer-training fold after training-only preprocessing; selection follows the archived search, not a newly nested threshold search.
- Outer columns: participant_id, y_true, repeat, fold; primary_screen/primary_q and agesexcountry_screen/agesexcountry_q, corresponding class probabilities and archived call_sens95.
- Source aggregate metrics, original operating points/confusion matrices, audit/completion and feature schema receipts.
- results/pdci_sensitivity_policy_20260912: ANALYSIS_PLAN.md, FROZEN_SPEC.json, AUDIT.json, COMPLETE.json, training_thresholds.csv, operating_points.csv, confusion_matrices.csv, local_only/participant_decisions.parquet.
- Canonical policy implementation: src/pdci_sensitivity_policy_20260912.py. Baseline provenance: src/pdci_demographic_baseline_20260911.py.
No joblib/raw data or model training is needed. Inputs and scripts are SHA256 frozen before computing new outcomes; relevant source hashes are checked against archived September 12 protection receipts. The release copy does not require or hash private working manuscripts.

## Exact decision rules
For each procedure and outer fold use ONLY its own saved inner-held-out training scores.
Primary screening: largest cutoff satisfying >=98% sensitivity separately among PD and CI training cases. Equivalently minimum of the two class-specific admissible cutoffs. For n positive scores and target t choose sorted score at n-ceil(t*n-1e-12). Equality is positive.
Primary discriminator: largest cutoff with >=95% sensitivity among ALL true training PD cases, independent of screening. Do not gate training PD by referral.
For each outer-test row, screen positive iff screen_score >= screen_cutoff; PD subtype iff q >= PD_cutoff.
Aggregate primary: referral iff >=2/3 screens positive. Among referred participants, PD/CI votes use only screen-positive repeats, with a tied PD/CI vote assigned PD. Screen-negative means neither. Separately compute subtype performance on all true cases using >=2/3 PD subtype calls regardless of referral.
Original95 comparator: pooled PD+CI training target95%, q cutoff0.5, majority of three three-class calls with tie order neither,PD,CI. Original95 is reproduced for both procedures as audit/context; no A6 inferential comparison is added.
No held-out labels tune thresholds; no new policy search.

## Outcomes and contrasts
Primary presentation reports BOTH end-to-end PD sensitivity (correct PD/90) and CI sensitivity (correct CI/62), alongside screening specificity (correct neither/598), case referrals, total referrals and false referrals among neither. Report full 3x3 counts (true rows neither,PD,CI; predicted columns neither,PD,CI), PD/CI screening sensitivities, all-case and among-referred discriminator metrics, PPV/NPV and each error destination; per-repeat tables supplement participant summaries.
Primary paired contrast: voice minus baseline at separate98_pd95. No single winner is selected from one sensitivity alone. Positive sensitivity/PPV/specificity differences favor voice; positive referral/false-referral/misclassification differences indicate more burden/errors, not a benefit.
Metrics: all 20 ratio definitions in the canonical September12 ratio_masks function plus screen_false_positive_rate (neither referred/neither), end_to_end_CI_PPV_vs_rest, end_to_end_CI_specificity_vs_rest, correct_case_assignment (correct PD+correct CI/all cases), overall_accuracy, and each class's two wrong-destination rates. Total-referral count difference and neither-referral count difference are also reported.
Original95 outcomes are archived context and reproduction checks only, without new intervals.

## Uncertainty and decision rule
5000 paired participant bootstrap samples, stratified by true classes in order neither,PD,CI, seed20261001 using numpy default_rng. On each iteration concatenate independent rng.choice(indices,size=class_n,replace=True) draws in that class order; use the identical sampled participant indices for voice and baseline and every metric. Retain the manifest's participant order. Percentile95% intervals via numpy quantile at .025,.975 with default linear interpolation. Report finite draws; handle zero denominators as NA, never zero.
Compute each procedure's intervals and paired voice-minus-baseline differences; use the same samples for count differences. These conditional intervals fix predictions and do not repeat training, selection, threshold fitting or cohort selection. No new p/q values, hypothesis-testing claims or changes to the existing BH3 family. An interval spanning zero is inconclusive for direction, not proof of no effect. Within-procedure reference Wilson95% intervals are descriptive, separate from paired intervals.
No model refits or additional analysis objectives.

## Reproduction gate and tests
Before new baseline-primary outcomes:
1. Verify all 15 own-fold cached inner/test IDs against manifest; 600 training and150 test per fold; no overlap; coherent labels; finite required scores, structural missing stage2 for neither; 2250 test rows,750 unique people,3 repeats.
2. Verify cached output hashes against fold receipts and relevant sources against archived protected SHA256.
3. Recompute the canonical voice thresholds, primary/original95 participant and repeat decisions, every selected archived confusion cell and operating metric, and baseline original95 cells/metrics. Exact count equality and absolute numeric error <=1e-12. Match voice primary participant decisions rowwise; match pooled source probabilities/AUROCs.
4. Verify supplied counts voice original139/65/29/266 and primary149/84/22/366 (cases referred,PD correct,CI correct,total referrals), baseline original PD56,CI17. Stop and record GATE failure on mismatch; no new results.
5. Tests: ties and largest feasible threshold; missing/NaN rejection; 98% thresholds monotone versus95%; manual voting; full count sums; contrast sign; resampling is participant-paired and retains class counts. Thresholds also independently found by exhaustive candidates. Never display participant-level data in logs.

## Independent verification
The historical study used a separate implementation to verify thresholds, aggregation, metrics and intervals. That independent implementation and its participant files are not included here. A successful public rerun must not be described as independently replicated merely because its built-in checks pass.

## Outputs
results/pdci_a5_matched_policy_20261001/: ANALYSIS_PLAN.md, FROZEN_SPEC.json (versions and all input/script hashes), GATE.json, training_thresholds.csv, operating_points.csv, confusion_matrices.csv, policy_comparison.csv, nominal_bootstrap_intervals.csv, paired_primary_voice_minus_baseline.csv, wilson_reference_intervals.csv, independent verification receipts, REPORT.md, AUDIT.json, COMPLETION.json.
Participant-level decisions stay in local_only/ under the dataset access agreement; they must not be redistributed.
Script: src/pdci_a5_matched_policy_20261001.py. Historical result reporting is separate from this unexecuted public release copy.
