# Public reproduction protocol

This release copy documents the original calculation and the release-only portability changes. It is not the historically frozen protocol; a future rerun records a new hash and timestamp. No results were recomputed when preparing this copy.

# Reviewer-requested post hoc analyses

Post hoc, descriptive analyses originally frozen and run on 2026-10-26. No model is refitted and no new p values are calculated. Nominal 95% intervals use 5,000 paired class-stratified participant bootstrap resamples of fixed saved predictions, without multiplicity adjustment. The implementation uses section seeds 20261026 (country), 20261027 (subtypes) and 20261028 (average precision), continuing the random stream within each section. These section offsets were clarified in the historical reconciliation after the original protocol named the base seed only.

Inputs (frozen run results/pdci_demographic_baseline_20260911/): local_only/participant_oof_predictions.parquet (each participant's three held-out predictions averaged, voice procedure and age/sex/residence-country baseline, the F1 inputs); INPUT_AUDIT.json; the PD and CI diagnosis modules and demographics.tsv through the frozen pipeline's cohort, label and linkage code (src/pdci_tasks.py; src/pdci_demographic_baseline_20260911.py prepare()). Outputs aggregate only.

Reproduction gate (all sections): recompute the F1 PD-versus-CI AUROCs from participant_oof_predictions.parquet (voice 0.8204301, baseline 0.6874552) and the cohort counts 598/90/62 exactly before any new number.

## S1. Within-country PD versus CI (country check)
PD versus CI AUROC of the saved stage-2 predictions for voice and baseline among participants residing in Canada (PD 49, CI 59), with the paired gain and its bootstrap interval. Within the USA (PD 41, CI 3) the CI group is too small; report the counts and no AUROC. The baseline remains the existing age/sex/residence-country model fitted on the full training cohorts; residence country is constant within the evaluated subset. No age/sex-only model is fitted.

## S2. Subtype-restricted PD versus CI (subtype check)
Same statistics among (a) idiopathic PD (53) versus MCI (36); (b) PD excluding DLB, PSP and other or atypical parkinsonism (77) versus all CI (62). Subtype from the recorded module fields used in A8 (diagnosis_parkinsons_disease_subtype; diagnosis_alz_dementia_mci_dt).

## S3. Participants excluded for missing task families (R1.7, R2.7)
Counts only, like A8: among the 829 otherwise eligible participants, the 79 lacking at least one general task family versus the 750 analysed: class (neither, PD, CI), age (mean and SD, numeric ages only, same rule as A8), sex (female, male, unavailable), residence country (USA, Canada); and the number of the 79 missing each task family. No significance tests.

## S4. Class separability (R2.1, optional part)
Average precision (precision weighted by successive recall increments) for PD versus CI (PD as positive and CI as positive) for voice and baseline from the saved predictions, with bootstrap intervals; and a figure of the saved stage-2 score distributions by recorded class (PD, CI) for voice and baseline (density or strip plot; no individual identifiers; no extreme values printed).

## Not included
No refitting, new model, site or recording-system analysis, or reduced-task experiment is part of this protocol. Only the listed analysis inputs are used.

## Implementation details fixed now
- Stage-2 score: the saved averaged q (columns primary_q and agesexcountry_q); PD versus CI AUROC over the true PD (y_true 1) and CI (y_true 2) cases in the subset, PD as positive.
- Bootstrap: 5,000 resamples, paired (the same participants for voice and baseline), stratified by recorded class within the subset (PD and CI resampled separately), the section seeds stated above, percentile 95% intervals; resamples in which a class is empty cannot occur under stratification.
- Residence country, age and sex: canonical padded linkage as in A8 (src/pdci_a8_cohort_recount_20261007.py demographics(); first record per participant; non-numeric age treated as missing).
- Subtypes: raw values of diagnosis_parkinsons_disease_subtype and diagnosis_alz_dementia_mci_dt as mapped in A8 (idiopathic = "Idiopathic Parkinson's Disease (IPD)"; MCI = "Mild Cognitive Impairment (MCI)"; S2(b) keeps idiopathic and "Not Sure / Undetermined" PD and all CI).
- S3 cohort: the 829 = audio participants without ALS and without a PD and CI overlap (src/pdci_tasks.py clean_base_mask); excluded = those not in ids_for_design("general"); task presence from task_presence() over the 11 GENERAL_TASKS.
- S4: average precision (sklearn average_precision_score) with PD as positive and with CI as positive (score 1 - q), voice and baseline, paired bootstrap as above; figure: violin plus box summaries of the saved q by recorded class (PD, CI) for voice and baseline, no individual points, no printed extremes; 300-dpi PNG and SVG.
- Outputs: GATE.json, s1_within_country.csv, s2_subtypes.csv, s3_excluded_vs_analysed.csv, s3_missing_task_families.csv, s4_average_precision.csv, s4_score_distributions.png and .svg, COMPLETION.json, REPORT.md. Aggregates only; cells are counts and summary statistics.

The historical independent implementation agreed exactly on counts and point estimates and within its prespecified 0.01 absolute tolerance on interval endpoints; it is not included in this public copy. The current package has only been checked statically.
