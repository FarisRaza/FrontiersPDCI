# Public reproduction protocol

This release copy documents the original calculation and the release-only portability changes. It is not the historically frozen protocol; a future rerun records a new hash and timestamp. No results were recomputed when preparing this copy.

## Hoehn and Yahr stage counts

Counts only for the 90 PD participants in the 750-participant general-task cohort. Use ids_for_design("general") and labels(ids, "multiclass") in src/pdci_tasks.py. Link the PD module on stripped, six-character zero-padded identifiers, requiring uniqueness.

Use the recorded diagnosis_parkinsons_ds value. A leading integer "Stage 1" through "Stage 5" maps to that stage. Blank is "not recorded". Other values, including intermediate stages such as 1.5 or 2.5, remain their own categories. No CI stage group or model is added.

Freeze protocol, code and inputs; gate on exactly 750 participants, classes [598,90,62], all 90 PD present once, and subtype counts identical to the A8 recount. Then write hy_counts.csv (stage, count, percent of 90) and COMPLETION.json. No identifiers or cross-tabulations are exported. The historical independent check is not included as an automatic step of this public copy.
