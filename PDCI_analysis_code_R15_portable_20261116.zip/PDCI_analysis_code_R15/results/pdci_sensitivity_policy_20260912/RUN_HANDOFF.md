# Sensitivity-policy execution notes

From DATA_ROOT/analysis with the declared Python environment:
python src/pdci_sensitivity_policy_20260912.py freeze
python src/pdci_sensitivity_policy_20260912.py run

The freeze step hashes the source scores, analysis code and public reproduction
protocol before computing policies. The run step verifies the hashes, evaluates
all nine policies and four comparators, audits the outputs, and writes COMPLETE.json
only on success. Do not edit inputs, protocols or code between freeze and run.
Participant-level outputs remain local in local_only/. No model is refitted.
