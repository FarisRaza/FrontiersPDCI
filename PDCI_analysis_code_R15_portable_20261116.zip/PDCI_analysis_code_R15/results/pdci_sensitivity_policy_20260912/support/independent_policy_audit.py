"""Independent reconstruction audit; does not import the policy implementation."""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
ANALYSIS = OUT.parents[1]
SOURCE = ANALYSIS / "results/pdci_demographic_baseline_20260911"
PRIMARY = "separate98_pd95"
SEED = 20260912
checks = {"threshold_rows": 0, "decision_arrays": 0, "metric_values": 0,
          "confusion_cells": 0, "bootstrap_values": 0, "interval_values": 0}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()


def equal(actual, expected, label):
    assert np.allclose(actual, expected, rtol=0, atol=2e-13, equal_nan=True), (label, actual, expected)


def admissible(scores, positive, target):
    # Enumeration is independent of the worker's order-statistic formula.
    good = []
    for cutoff in set(scores):
        if np.count_nonzero(scores[positive] >= cutoff) / np.count_nonzero(positive) + 1e-14 >= target:
            good.append(cutoff)
    return max(good)


def get_cm(y, call):
    return np.bincount(y * 3 + call, minlength=9).reshape(3, 3)


def values(y, call, subtype):
    # Use contingency-table arithmetic instead of the worker's ratio masks.
    m = get_cm(y, call)
    n0, n1, n2 = m.sum(axis=1)
    referred = int(m[:, 1:].sum())
    nt, pt, ct = int(m[0, 0]), int(m[1, 1]), int(m[2, 2])
    true_ref = int(m[1:, 1:].sum())
    pd_ref, ci_ref = int(m[1, 1:].sum()), int(m[2, 1:].sum())
    n_no_ref = int(m[:, 0].sum())
    a = int(np.count_nonzero((y == 1) & subtype))
    b = int(np.count_nonzero((y == 2) & subtype))
    c = int(np.count_nonzero((y == 1) & ~subtype))
    d = int(np.count_nonzero((y == 2) & ~subtype))
    nd = int(m[:, 1].sum())
    result = {
        "screen_sensitivity": (true_ref, n1+n2),
        "screen_PD_sensitivity": (pd_ref, n1),
        "screen_CI_sensitivity": (ci_ref, n2),
        "screen_specificity": (nt, n0),
        "screen_PPV": (true_ref, referred),
        "screen_NPV": (nt, n_no_ref),
        "referral_fraction": (referred, len(y)),
        "conditional_all_PD_sensitivity": (a, a+c),
        "conditional_all_CI_specificity": (d, b+d),
        "conditional_all_PPV": (a, a+b),
        "conditional_all_NPV": (d, c+d),
        "conditional_referred_PD_sensitivity": (pt, pd_ref),
        "conditional_referred_CI_specificity": (ct, ci_ref),
        "conditional_referred_PPV": (pt, pt+int(m[2, 1])),
        "conditional_referred_NPV": (ct, ct+int(m[1, 2])),
        "end_to_end_PD_recall": (pt, n1),
        "end_to_end_CI_recall": (ct, n2),
        "end_to_end_PD_specificity_vs_rest": (int(m[0, [0, 2]].sum()+m[2, [0, 2]].sum()), n0+n2),
        "end_to_end_PD_PPV_vs_rest": (pt, nd),
        "end_to_end_PD_NPV_vs_rest": (int(m[0, [0, 2]].sum()+m[2, [0, 2]].sum()), len(y)-nd),
    }
    counts = dict(n=len(y), n_PD=int(n1), n_CI=int(n2), referrals=referred,
                  PD_to_neither=int(m[1, 0]), PD_to_CI=int(m[1, 2]),
                  CI_to_neither=int(m[2, 0]), CI_to_PD=int(m[2, 1]),
                  neither_referred=int(m[0, 1:].sum()))
    return result, counts, m


def aggregate(screens, subtype, legacy):
    calls = np.where(screens, np.where(subtype, 1, 2), 0)
    decisions = []
    for sr, qr, cr in zip(screens, subtype, calls):
        if legacy:
            votes = [np.count_nonzero(cr == c) for c in range(3)]
            decisions.append(votes.index(max(votes)))
        elif np.count_nonzero(sr) < 2:
            decisions.append(0)
        else:
            chosen = qr[sr]
            decisions.append(1 if np.count_nonzero(chosen) >= np.count_nonzero(~chosen) else 2)
    return np.asarray(decisions), np.count_nonzero(subtype, axis=1) >= 2


def main():
    # Explicit precondition: outcomes may be inspected only after freeze/run completion.
    frozen_path = OUT / "FROZEN_SPEC.json"
    complete_path = OUT / "COMPLETE.json"
    assert frozen_path.is_file() and complete_path.is_file()
    frozen = json.loads(frozen_path.read_text())
    complete = json.loads(complete_path.read_text())
    assert frozen["primary_policy"] == PRIMARY
    assert frozen["new_outer_policy_results_not_yet_computed"] is True
    assert frozen["models_refitted"] is False
    assert frozen["bootstrap_draws"] == 5000 and frozen["seed"] == SEED
    assert frozen["created_utc"] < complete["completed_utc"]
    protected = frozen["protected_sha256"]
    for file, expected in protected.items():
        assert sha(file) == expected, file
    assert complete["audit"] == "PASS" and complete["status"] == "COMPLETE"
    assert sha(OUT / "AUDIT.json") == complete["audit_sha256"]
    assert sha(OUT / "REPORT.md") == complete["report_sha256"]
    manifest = json.loads((SOURCE / "local_only/split_manifest.json").read_text())
    ids = np.asarray(manifest["ids"])
    n = len(ids)
    positions = {pid: i for i, pid in enumerate(ids)}
    inner, outer, receipts = [], [], []
    all_y = np.full(n, -1, dtype=int)
    for j, split in enumerate(manifest["splits"]):
        stem = SOURCE / f"local_only/folds/fold_{j:02d}"
        f = pd.read_parquet(stem.with_suffix(".parquet"))
        g = pd.read_parquet(stem.parent / f"fold_{j:02d}_selected_inner.parquet")
        r = json.loads(stem.with_suffix(".json").read_text())
        assert sha(stem.with_suffix(".parquet")) == r["prediction_sha256"]
        assert f.participant_id.tolist() == ids[split["test"]].tolist()
        assert g.participant_id.tolist() == ids[split["train"]].tolist()
        assert set(f.participant_id).isdisjoint(g.participant_id)
        assert len(f) == 150 and len(g) == 600
        assert f.repeat.eq(j // 5).all() and f.fold.eq(j % 5).all()
        assert g.loc[g.y_true > 0, "stage2"].notna().all()
        assert g.loc[g.y_true == 0, "stage2"].isna().all()
        all_y[split["test"]] = f.y_true.to_numpy(int)
        inner.append(g); outer.append(f); receipts.append(r)
    assert np.array_equal(np.bincount(all_y), [598, 90, 62])
    for j, split in enumerate(manifest["splits"]):
        assert np.array_equal(inner[j].y_true, all_y[split["train"]])
        assert np.array_equal(outer[j].y_true, all_y[split["test"]])
    raw = pd.concat(outer)
    assert raw.groupby("participant_id").size().eq(3).all()
    assert not raw.duplicated(["participant_id", "repeat"]).any()
    thresholds = pd.read_csv(OUT / "training_thresholds.csv")
    ops = pd.read_csv(OUT / "operating_points.csv").set_index(["policy", "scope"])
    cms = pd.read_csv(OUT / "confusion_matrices.csv").set_index(["policy", "scope", "true_class", "predicted_class"])
    saved_part = pd.read_parquet(OUT / "local_only/participant_decisions.parquet")
    saved_repeat = pd.read_parquet(OUT / "local_only/per_repeat_decisions.parquet")
    policies = [(f"separate{int(round(t*100))}_pd{int(round(u*100))}", t, u, "new")
                for t in (.95, .98, 1.) for u in (.90, .95, .98)]
    policies += [(f"{kind}{int(round(t*100))}", t, .5, kind)
                 for t in (.90, .95) for kind in ("legacy", "voting_only")]
    assert set(thresholds.policy) == {p[0] for p in policies}
    assert len(thresholds) == 15 * 13 and len(ops) == 13 * 4
    states = {}
    for name, starget, qtarget, kind in policies:
        sr = np.zeros((n, 3), dtype=bool)
        qr = np.zeros((n, 3), dtype=bool)
        for j, (g, f) in enumerate(zip(inner, outer)):
            y, s, q = (g[k].to_numpy() for k in ("y_true", "screen", "stage2"))
            if kind == "new":
                st = min(admissible(s, y == c, starget) for c in (1, 2))
                qt = admissible(q[y > 0], y[y > 0] == 1, qtarget)
            else:
                st = admissible(s, y > 0, starget)
                qt = .5
                equal(st, receipts[j]["thresholds"]["primary"][f"sens{int(round(starget*100))}"], (name, j, "legacy cutoff"))
            tr = thresholds[(thresholds.policy == name) & (thresholds.outer_fold == j)].iloc[0]
            equal([tr.screen_threshold, tr.pd_threshold], [st, qt], (name, j, "cutoffs"))
            counts = dict(train_PD_n=(y == 1).sum(), train_CI_n=(y == 2).sum(), train_neither_n=(y == 0).sum(),
                          train_PD_referred=((y == 1) & (s >= st)).sum(), train_CI_referred=((y == 2) & (s >= st)).sum(),
                          train_conditional_PD_positive=((y == 1) & (q >= qt)).sum())
            rates = dict(train_screen_PD_sensitivity=np.mean(s[y == 1] >= st),
                         train_screen_CI_sensitivity=np.mean(s[y == 2] >= st),
                         train_screen_specificity=np.mean(s[y == 0] < st),
                         train_conditional_PD_sensitivity=np.mean(q[y == 1] >= qt),
                         train_conditional_CI_specificity=np.mean(q[y == 2] < qt))
            for field, val in {**counts, **rates}.items(): equal(tr[field], val, (name, j, field))
            if kind == "new":
                assert rates["train_screen_PD_sensitivity"] >= starget - 1e-14
                assert rates["train_screen_CI_sensitivity"] >= starget - 1e-14
                assert rates["train_conditional_PD_sensitivity"] >= qtarget - 1e-14
            idx = np.asarray([positions[x] for x in f.participant_id])
            sr[idx, j // 5] = f.primary_screen.to_numpy() >= st
            qr[idx, j // 5] = f.primary_q.to_numpy() >= qt
            sd = saved_repeat[(saved_repeat.policy == name) & saved_repeat.repeat.eq(j//5) & saved_repeat.fold.eq(j%5)].set_index("participant_id").loc[f.participant_id]
            equal(sd.screen_positive, sr[idx, j//5], (name, j, "screen decisions"))
            equal(sd.conditional_PD, qr[idx, j//5], (name, j, "PD decisions"))
            equal(sd.call, np.where(sr[idx, j//5], np.where(qr[idx, j//5], 1, 2), 0), (name, j, "per-repeat calls"))
            checks["threshold_rows"] += 1
        final, subtype = aggregate(sr, qr, kind == "legacy")
        states[name] = (final, subtype)
        sp = saved_part[saved_part.policy == name].set_index("participant_id").loc[ids]
        expected_state = dict(final=final, subtype_all=subtype, screen=final > 0,
                              screen_votes=sr.sum(axis=1), positive_PD_votes=(sr & qr).sum(axis=1),
                              positive_CI_votes=(sr & ~qr).sum(axis=1), all_PD_votes=qr.sum(axis=1))
        for field, val in expected_state.items():
            equal(sp[field].to_numpy(), val, (name, field)); checks["decision_arrays"] += 1
        if kind != "legacy":
            assert not np.any((sr.sum(axis=1) >= 2) & (final == 0))
        calls = np.where(sr, np.where(qr, 1, 2), 0)
        for scope, call, sub in [("participant_majority", final, subtype)] + [(f"repeat_{r}", calls[:, r], qr[:, r]) for r in range(3)]:
            val, count, cm = values(all_y, call, sub)
            row = ops.loc[(name, scope)]
            for field, (num, den) in val.items():
                equal([row[field], row[field+"_numerator"], row[field+"_denominator"]],
                      [num / den if den else np.nan, num, den], (name, scope, field))
                checks["metric_values"] += 3
            for field, v in count.items(): equal(row[field], v, (name, scope, field))
            for a, ca in enumerate(("Neither", "PD", "CI")):
                for b, cb in enumerate(("Neither", "PD", "CI")):
                    equal(cms.loc[(name, scope, ca, cb), "n"], cm[a, b], (name, scope, ca, cb))
                    checks["confusion_cells"] += 1
    # Reproduce source legacy confusion matrices directly, without worker helpers.
    oldcms = pd.read_csv(SOURCE / "confusion_matrices.csv")
    oldops = pd.read_csv(SOURCE / "operating_points.csv")
    for t in (90, 95):
        for scope in ("participant_majority", "repeat_0", "repeat_1", "repeat_2"):
            old = oldcms[oldcms.model.eq("primary") & oldcms.gate.eq(f"sens{t}") & oldcms.scope.eq(scope)]
            a = cms.loc[(f"legacy{t}", scope)].n.to_numpy()
            equal(a, old.n.to_numpy(), (t, scope, "source confusion"))
            a = ops.loc[(f"legacy{t}", scope)]
            b = oldops[oldops.model.eq("primary") & oldops.gate.eq(f"sens{t}") & oldops.scope.eq(scope)].iloc[0]
            for ours, oldkey in (("screen_sensitivity", "sensitivity"), ("screen_specificity", "specificity"), ("screen_PPV", "ppv"), ("screen_NPV", "npv"), ("referrals", "screen_positive"), ("end_to_end_PD_recall", "PD_recall"), ("end_to_end_CI_recall", "cognitive_impairment_recall")):
                equal(a[ours], b[oldkey], (t, scope, oldkey))
    pooled = raw.groupby("participant_id")[["primary_screen", "primary_q", "primary_p0", "primary_p1", "primary_p2"]].mean().reindex(ids)
    aucs = pd.read_csv(OUT / "unchanged_auroc.csv").set_index("endpoint").auc
    current = dict(screen=roc_auc_score(all_y > 0, pooled.primary_screen),
                   stage2=roc_auc_score(all_y[all_y > 0] == 1, pooled.loc[all_y > 0, "primary_q"]),
                   macro=roc_auc_score(all_y, pooled[[f"primary_p{i}" for i in range(3)]], multi_class="ovr", average="macro"))
    for key, value in current.items(): equal(aucs[key], value, key)
    # Reconstruct every bootstrap replicate from explicitly sampled participant rows.
    archive = np.load(OUT / "local_only/bootstrap_draws.npz")
    metrics = archive["metrics"].tolist()
    names = (PRIMARY, "legacy95")
    independent = {name: np.empty((5000, len(metrics))) for name in names}
    rng = np.random.default_rng(SEED)
    groups = [np.flatnonzero(all_y == c) for c in range(3)]
    for b in range(5000):
        ix = np.concatenate([rng.choice(g, len(g), replace=True) for g in groups])
        for name in names:
            final, sub = states[name]
            val, _, _ = values(all_y[ix], final[ix], sub[ix])
            independent[name][b] = [val[key][0] / val[key][1] if val[key][1] else np.nan for key in metrics]
    for name in names:
        equal(independent[name], archive[name], (name, "all bootstrap draws"))
        checks["bootstrap_values"] += independent[name].size
    intervals = pd.read_csv(OUT / "nominal_bootstrap_intervals.csv").set_index(["policy", "metric"])
    wilson = pd.read_csv(OUT / "wilson_binomial_reference_intervals.csv").set_index(["policy", "metric"])
    diff = pd.read_csv(OUT / "paired_primary_minus_legacy95.csv").set_index("metric")
    z = norm.ppf(.975)
    for j, key in enumerate(metrics):
        for name in names:
            val, _, _ = values(all_y, *states[name]); num, den = val[key]
            expected = np.nanquantile(independent[name][:, j], [.025, .975])
            r = intervals.loc[(name, key)]
            equal([r.ci_low, r.ci_high], expected, (name, key, "CI"))
            equal([r.numerator, r.denominator, r.estimate], [num, den, num/den if den else np.nan], (name, key, "point"))
            assert r.finite_draws == np.isfinite(independent[name][:, j]).sum()
            w = wilson.loc[(name, key)]
            if den:
                center = (num + .5*z*z) / (den + z*z)
                half = z * np.sqrt(num*(1-num/den) + .25*z*z) / (den+z*z)
                equal([w.wilson95_low, w.wilson95_high], [center-half, center+half], (name, key, "Wilson"))
            checks["interval_values"] += 7
        delta = independent[PRIMARY][:, j] - independent["legacy95"][:, j]
        expected = np.nanquantile(delta, [.025, .975])
        equal([diff.loc[key].ci_low, diff.loc[key].ci_high], expected, (key, "paired interval"))
        equal(diff.loc[key].difference, intervals.loc[(PRIMARY, key)].estimate - intervals.loc[("legacy95", key)].estimate, (key, "paired point"))
        checks["interval_values"] += 3
    for file, expected in protected.items(): assert sha(file) == expected, file
    receipt = dict(status="PASS", audited_utc=datetime.now(timezone.utc).isoformat(),
                   independent_source_sha256=sha(__file__), worker_source_sha256=sha(ANALYSIS / "src/pdci_sensitivity_policy_20260912.py"),
                   freeze_sha256=sha(frozen_path), protected_files_unchanged=len(protected),
                   threshold_selection_from_own_training_only=True, selected_primary_before_new_outer_results=True,
                   new_policies=9, comparators=4, outer_folds=15, participants=750, resamples=5000,
                   independent_contingency_reconstruction=True, no_worker_module_imported=True,
                   no_models_refitted=True, no_acoustic_payload_loaded=True, checks=checks,
                   unchanged_auc=current)
    path = HERE / "independent_policy_audit_receipt.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
