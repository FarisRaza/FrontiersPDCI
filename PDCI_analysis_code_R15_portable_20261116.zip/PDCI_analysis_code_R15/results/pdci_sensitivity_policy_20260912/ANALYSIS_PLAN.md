# Public reproduction protocol

This release copy documents the original calculation and the release-only portability changes. It is not the historically frozen protocol; a future rerun records a new hash and timestamp. No results were recomputed when preparing this copy.

# PD/CI sensitivity-policy follow-up: frozen specification

## Purpose and status

This follow-up implements the specified priority on sensitivity for both
Parkinson's disease (PD) and cognitive impairment (CI) at screening, and PD
sensitivity during subsequent discrimination. It is an operating-policy analysis
of the completed fully nested model, not a new model search. The plan and code
are frozen and hashed before calculating the new policies' outer-test results.
The study cohort and historical performance have already been examined. This
follow-up therefore is not prospective or independent external validation.

The existing analysis run, predictions, p/q values and reports are read-only. All follow-up output goes into this new directory.

## Fixed source and unchanged models

Use only the primary procedure from
`../pdci_demographic_baseline_20260911/`: the 750 participants (598 neither,
90 PD, 62 CI), the same five outer folds repeated three times, the saved
outer-test scores, and each selected model's own outer-training inner-held-out
scores. ALS and recorded PD+CI overlap remain excluded. Only the 11 general task
families used by the source run are included. Age, sex and country remain the
demographic baseline; duration and frame counts remain optional acoustic inputs.

All fitted models, acoustic feature spaces, inner-CV selections and continuous
scores are unchanged. Architecture selection in the source study maximized
AUROC, not sensitivity at a given specificity. No model is refitted here, and
none is selected using new outer-test performance. The screen, conditional
PD-versus-CI and composed three-class AUROCs consequently remain unchanged.

## Nine policies, with one primary policy declared in advance

For each outer fold, fit decision thresholds using only the selected models'
saved inner-held-out predictions from that fold's training participants:

1. Stage 1: empirical sensitivity target t in {0.95, 0.98, 1.00}. Choose the
   largest common screening cutoff that attains at least t sensitivity among
   training PD participants and at least t among training CI participants,
   separately. A score equal to the cutoff is screen-positive. Equivalently,
   take the smaller of the two class-specific largest admissible cutoffs.
2. Stage 2: PD sensitivity target u in {0.90, 0.95, 0.98}. Choose the largest
   conditional-PD cutoff attaining at least u sensitivity in the training PD
   cases. Use the selected dedicated discriminator's inner-held-out scores for
   all true training PD/CI cases, without gating them on screening. A score
   equal to the cutoff assigns PD; a smaller score assigns CI.

The primary policy is t=0.98, u=0.95. Report every one of the nine combinations;
do not select a winner based on outer-test outcomes. The largest admissible
cutoff maximizes empirical specificity subject to the applicable constraint,
with possible specificity ties. Finite sample sizes make achievable sensitivity
levels discrete. Training targets do not guarantee held-out or future targets,
including when t=1.00.

## Repeated held-out decision aggregation

Each participant receives one held-out screen and discriminator decision in each
of the three repeats, using that repeat's own training-derived thresholds.

* Final screen-positive requires at least two of three positive screens.
* For a final screen-positive participant, vote PD versus CI among the
  screen-positive repeats only. An equal PD/CI vote assigns PD.
* Final screen-negative assigns neither. Disagreement about PD versus CI never
  changes a final positive screen into neither.

Separately, evaluate the conditional discriminator in all 152 true cases using
the majority of its three binary subtype calls, regardless of screening. This
diagnostic measure is distinct from subtype performance among referred cases,
which uses the screen-positive-repeat vote actually used by the pipeline.
Report per-repeat decisions and metrics as well as aggregated results.

## Historical and voting-only comparators

Reproduce both original policies exactly: original pooled-case training
screen-sensitivity target 90% or 95%, conditional cutoff 0.5, majority of three
three-class decisions, three-way ties resolved neither. Match every saved
confusion-matrix cell and operating point for the primary procedure.

Also apply the new stagewise voting rule to the original 90% and 95% screen
thresholds with conditional cutoff 0.5. These two voting-only comparators
distinguish changes in aggregation from changes in sensitivity thresholds.
They are descriptive comparators, not additional candidate winners.

## Outputs and uncertainty

Report exact counts and rates for: overall and PD/CI-specific screen
sensitivity; screen specificity, PPV, NPV and referral counts; conditional
PD sensitivity and CI specificity both in all true cases and among referred
true cases; conditional PPV/NPV; end-to-end PD and CI recall; full PD-versus-rest
specificity/PPV/NPV; and all 3-by-3 confusion matrices. Decompose missed PD into
PD classified neither and PD classified CI, and report the analogous CI errors.
Save fold-level thresholds and empirical training attainment, including
class-specific counts. Participant decisions remain in `local_only`.

For the declared primary policy and exact original 95% comparator, compute
nominal percentile 95% intervals from 5,000 paired participant bootstrap draws
stratified by the three true classes. Reuse each draw across the two policies
and metrics, and report paired differences. The seed is 20260912. These are
fixed-prediction conditional intervals; they do not repeat model development,
fitting, threshold estimation or participant selection. Intervals for
among-referred metrics compare policy-specific referred subsets and are not
same-subgroup causal comparisons. The analysis is descriptive: no new p values,
q values, multiplicity-adjusted significance claims or guarantees of zero
future false negatives are made. A degenerate percentile interval at 100% with
zero observed errors does not establish population sensitivity of 100%.

Also report two-sided 95% Wilson binomial reference intervals for the primary
policy and original 95% comparator's participant-level proportions. These remain
nondegenerate with zero observed errors. They are a descriptive binomial
reference, not an adjustment for cross-validation dependence, model development,
threshold estimation or prior cohort exploration. They are separate from the
prespecified paired fixed-prediction bootstrap, which remains unchanged.

## Required checks before completion

Freeze and verify source/result/protocol SHA-256 hashes; verify all
training/test IDs against the saved split manifest and all training/test sets
are disjoint; require one held-out prediction per participant per repeat;
reproduce source probabilities, AUROCs, original thresholds, original decisions,
and original confusion matrices; independently reconstruct threshold selection
with exhaustive score candidates; verify monotonic thresholds as targets rise;
independently check voting and metric numerators/denominators; check bootstrap
draws and paired intervals; verify that prior protected files remain unchanged.
Write `REPORT.md`, `AUDIT.json`, then `COMPLETE.json` only after checks pass.
