"""Post hoc aggregate audit, C1/T1/D1. Run freeze then run; refuse overwrite."""
from pathlib import Path
import os, sys, json, hashlib, platform, ast, warnings, re, csv
from datetime import datetime, timezone
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
import numpy as np
import pandas as pd
import scipy, sklearn, joblib, pyarrow
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.feature_selection import f_classif
from threadpoolctl import threadpool_limits
OUT=Path(__file__).resolve().parent
ANALYSIS=OUT.parent.parent
ADULT=ANALYSIS.parent
PHENO=ADULT/"phenotype"
CANON=ANALYSIS/"results/pdci_demographic_baseline_20260911"
SOURCE=ANALYSIS/"src/pdci_demographic_baseline_20260911.py"
FAMILY="F10-R13"
MISSING={"","n/a","na","nan","none","null"}
PD="diagnosis/parkinsons_disease"
CI="diagnosis/cognitive_impairment"
TASKS=["questionnaire/productive_vocabulary","task/stroop","task/winograd"]
DEVICE=["task/recording","task/session","task/acoustic_task"]
VERSIONS={k:v for k,v in [("python",platform.python_version()),("numpy",np.__version__),("pandas",pd.__version__),("scipy",scipy.__version__),("scikit-learn",sklearn.__version__),("joblib",joblib.__version__),("pyarrow",pyarrow.__version__)]}
def stamp(): return datetime.now(timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()
def write_json(name,obj):
    p=OUT/name
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("x",encoding="utf-8",newline="\n") as f: json.dump(obj,f,indent=2,ensure_ascii=True,allow_nan=False)
def write_csv(name,rows,columns=None):
    p=OUT/name
    frame = pd.DataFrame(rows, columns=columns)
    # Publication output policy only: retain availability but withhold these categories.
    if name in {"clinical_categories.csv", "clinical_categories_decoded.csv"} and "field" in frame:
        field = frame["field"].astype(str)
        withheld = field.eq("diagnosis_alz_dementia_mci_ds_cdr") | field.str.startswith("vocabulary_item_difficulty_")
        frame = frame.loc[~withheld].copy()
    with p.open("x",encoding="utf-8",newline="") as f: frame.to_csv(f,index=False)
def norm(v): return str(v).strip().zfill(6)
def clean(v):
    if pd.isna(v): return ""
    s=str(v).strip()
    return "" if s.casefold() in MISSING else s
def schema(rel): return json.loads((PHENO/(rel+".json")).read_text(encoding="utf-8"))
def inputs():
    files=[Path(__file__),OUT/"ANALYSIS_PLAN.md",OUT/"AMENDMENT_1.md",SOURCE]
    files += [ANALYSIS/"src"/(n+".py") for n in ["config","pdci_tasks","pdci_linear_harmonics","extract_linear_harmonics"]]
    files += sorted(PHENO.rglob("*.json"))+sorted(PHENO.rglob("*.tsv"))
    files += [CANON/n for n in ["feature_schemas.json","candidate_grid.json","INPUT_AUDIT.json","FROZEN_SPEC.json","auc_intervals.csv","fold_selections.csv","selection_counts.csv","local_only/input_payload.joblib","local_only/participant_oof_predictions.parquet","local_only/split_manifest.json"]]
    files += [CANON/"local_only/folds"/f"fold_{i:02d}.{ext}" for i in range(15) for ext in ["json","parquet"]]
    return sorted(set(files),key=str)
def freeze():
    assert not (OUT/"FROZEN_SPEC_V2.json").exists(),"already frozen"
    write_json("FROZEN_SPEC_V2.json",dict(created_utc=stamp(),family=FAMILY,authority="AR-45",post_hoc=True,versions=VERSIONS,numerical_threads=1,protected_sha256={p.as_posix():sha(p) for p in inputs()}))
    print("FROZEN",flush=True)
def verify_inputs():
    spec=json.loads((OUT/"FROZEN_SPEC_V2.json").read_text())
    wrong=[p for p,h in spec["protected_sha256"].items() if sha(p)!=h]
    assert not wrong,"frozen source/input changed"
    return spec
def original_prep():
    tree=ast.parse(SOURCE.read_text())
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="Prep")
    env={"np":np}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),"exec"),env)
    return env["Prep"]
Prep=original_prep()
def ident(c): return "__".join(f"{k}-{v}" for k,v in c.items())
def tests():
    x=np.array([[0,1,np.nan,np.nan,1],[1,1,1,np.nan,2],[2,1,np.inf,np.nan,3],[3,1,2,np.nan,4]],float)
    obj=Prep();a=obj.fit_transform(x)
    assert obj.available.tolist()==[True,True,True,False,True]
    assert obj.vary.tolist()==[True,False,True,True]
    assert a.shape==(4,3) and np.isfinite(a).all()
    assert np.allclose(a.mean(0),0,atol=1e-10) and np.allclose(a.std(0),1)
    z=np.array([[0.,0.],[1.,1.],[2.,2.],[3.,3.]])
    rank=np.argsort(-f_classif(z,[0,0,1,1])[0],kind="stable")
    assert rank.tolist()==[0,1]
    assert norm(" 12 ")=="000012" and clean("n/a")=="" and clean("No")=="No" and clean("0")=="0"
    assert roc_auc_score([0,0,1,1],[0,0,1,1])==1 and roc_auc_score([0,0,1,1],[1,1,0,0])==0
    write_json("qa/tests.json",dict(status="PASS",checks=["availability_at_half","nonfinite","constant","finite_standardized","stable_F_tie","canonical_ID","blank_not_no","AUROC_sign"]))
def gate(data):
    y=np.asarray(data["y"]); ids=[norm(v) for v in data["ids"]]
    assert len(ids)==750 and len(set(ids))==750 and np.bincount(y).tolist()==[598,90,62]
    p=pd.read_parquet(CANON/"local_only/participant_oof_predictions.parquet")
    if "participant_id" not in p.columns:
        assert p.index.name=="participant_id"
        p=p.reset_index()
    p["participant_id"]=p.participant_id.map(norm)
    assert p.participant_id.is_unique and set(p.participant_id)==set(ids)
    p=p.set_index("participant_id").loc[ids]
    assert np.array_equal(p.y_true.to_numpy(),y)
    ref=pd.read_csv(CANON/"auc_intervals.csv")
    metrics=[]
    for model in ["primary","agesexcountry"]:
        s=p[model+"_screen"].to_numpy();q=p[model+"_q"].to_numpy();pp=p[[model+f"_p{i}" for i in range(3)]].to_numpy()
        assert np.isfinite(np.c_[s,q,pp]).all() and ((np.c_[s,q,pp]>=0)&(np.c_[s,q,pp]<=1)).all()
        assert np.allclose(pp.sum(1),1)
        got={"screen":roc_auc_score(y>0,s),"stage2":roc_auc_score(y[y>0]==1,q[y>0]),"macro":roc_auc_score(y,pp,multi_class="ovr",average="macro")}
        for endpoint,val in got.items():
            target=float(ref[(ref.model==model)&(ref.endpoint==endpoint)].auc.iloc[0])
            assert abs(val-target)<=1e-9
            metrics.append(dict(model=model,endpoint=endpoint,reproduced=val,reference=target,absolute_error=abs(val-target)))
    assert len(data["splits"])==15
    new=list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=20260725).split(np.zeros(len(y)),y))
    seen=np.zeros(len(y),int);choice_rows=[];recs=[]
    choices=pd.read_csv(CANON/"fold_selections.csv")
    for oi,((tr,te),(tr2,te2)) in enumerate(zip(data["splits"],new)):
        assert np.array_equal(tr,tr2) and np.array_equal(te,te2) and set(tr).isdisjoint(te)
        assert len(set(tr))==len(tr) and len(set(te))==len(te) and len(tr)+len(te)==750
        seen[te]+=1
        r=json.loads((CANON/"local_only/folds"/f"fold_{oi:02d}.json").read_text());recs.append(r)
        fp=CANON/"local_only/folds"/f"fold_{oi:02d}.parquet"
        assert sha(fp)==r["prediction_sha256"]
        f=pd.read_parquet(fp,columns=["participant_id","y_true"])
        assert f.participant_id.map(norm).tolist()==[ids[j] for j in te] and np.array_equal(f.y_true.to_numpy(),y[te])
        for proc in ["screen","stage2"]:
            c=r["choices"][proc]
            expected=choices[(choices.repeat==oi//5)&(choices.fold==oi%5)&(choices.procedure==proc)].candidate
            assert len(expected)==1 and expected.iloc[0]==ident(c)
        assert r["train_cases"]==int((y[tr]>0).sum())
        choice_rows.append(dict(outer_fit_zero_based=oi,screen_timing=r["choices"]["screen"]["timing"],stage2_timing=r["choices"]["stage2"]["timing"]))
    assert np.all(seen==3)
    assert sum(r["choices"]["screen"]["timing"]=="on" for r in recs)==0
    assert sum(r["choices"]["stage2"]["timing"]=="on" for r in recs)==4
    write_json("GATE.json",dict(status="PASS",created_utc=stamp(),participants=750,class_counts=[598,90,62],unique_canonical_ids=True,original_partitions_exact=True,train_test_disjoint=True,heldout_per_participant=3,selected_configs_match=True,metrics=metrics,timing_choices=choice_rows))
    return ids,y,recs
def read_selected(rel,fields):
    p=PHENO/(rel+".tsv")
    head=p.open(encoding="utf-8").readline().rstrip("\r\n").split("\t")
    cols=["participant_id"]+[f for f in fields if f in head]
    df=pd.read_csv(p,sep="\t",dtype=str,keep_default_na=False,usecols=cols)
    df["participant_id"]=df.participant_id.map(norm)
    return df,head
def choice_map(v):
    mapping={}
    choices=v.get("choices") or []
    for c in choices:
        label=c.get("name",{}).get("en",str(c.get("value")))
        mapping[str(c.get("value")).strip().casefold()]=label
        mapping[str(label).strip().casefold()]=label
    return mapping
def categorized(s,v,checkbox):
    mapping=choice_map(v)
    if s.casefold() in mapping: return mapping[s.casefold()]
    if checkbox and s.casefold() in {"1","true","checked","yes"}: return "Recorded selected"
    if checkbox and s.casefold() in {"0","false","unchecked","no"}: return "Recorded unselected"
    return "Other populated token (withheld)"
def summarize_field(df,field,v,cohort,group,mode="categorical"):
    n=len(cohort); has=set(df.participant_id)&set(cohort)
    sub=df[df.participant_id.isin(cohort)]
    vals={}
    if field in sub:
        for pid,raw in zip(sub.participant_id,sub[field]):
            s=clean(raw)
            if s: vals.setdefault(pid,set()).add(s)
    observed=len(vals)
    row=dict(family=FAMILY+"-C1",group=group,source=field_source[field],field=field,denominator=n,participants_with_module_row=len(has),observed=observed,missing=n-observed,column_present=field in df,semantics=mode)
    counts={}
    if mode=="categorical":
        for vv in vals.values():
            cats={categorized(s,v,"___" in field) for s in vv}
            lab=next(iter(cats)) if len(cats)==1 else "Multiple recorded categories"
            counts[lab]=counts.get(lab,0)+1
    return row,[dict(family=FAMILY+"-C1",group=group,source=field_source[field],field=field,category=k,n=v,denominator=n) for k,v in sorted(counts.items())]
field_source={}
def clinical(ids,y):
    pdsc=schema(PD);cisc=schema(CI)
    pdflds=[k for k in pdsc if k in {"diagnosis_parkinsons_current_treatment_obtained","diagnosis_parkinsons_ds","diagnosis_parkinsons_ma_uprds","diagnosis_parkinsons_ma___updrs"} or k.startswith(("diagnosis_parkinsons_current_treatment_obtained_yes_medications___","diagnosis_parkinsons_current_treatment_obtained_yes_npi___","diagnosis_parkinsons_treatment_obtained_yes_medications___"))]
    ciflds=[k for k in cisc if k in {"diagnosis_alz_dementia_mci_causes","diagnosis_alz_dementia_mci_ds_cdr","diagnosis_alz_dementia_mci_treatment_obtained","diagnosis_alz_dementia_mci_ds___cdr","diagnosis_alz_dementia_mci_ds___mci","diagnosis_alz_dementia_mci_gold_standard_diagnosis_confirmation_method___cognitive_testing","diagnosis_alz_dementia_mci_gold_standard_diagnosis_confirmation_method___functional_inventory"} or k.startswith("diagnosis_alz_dementia_mci_treatment_obtained_yes_medications___")]
    rows=[];cats=[];semantics=[]
    groups={"PD":[i for i,c in zip(ids,y) if c==1],"CI":[i for i,c in zip(ids,y) if c==2]}
    for rel,fields,group in [(PD,pdflds,"PD"),(CI,ciflds,"CI")]:
        ds=schema(rel);df,head=read_selected(rel,fields)
        assert df.participant_id.is_unique,"duplicate diagnosis rows require amendment"
        assert set(groups[group]).issubset(set(df.participant_id))
        for f in fields:
            field_source[f]=rel
            r,cc=summarize_field(df,f,ds[f],groups[group],group)
            rows.append(r);cats.extend(cc)
            semantics.append(dict(source=rel,field=f,description=ds[f].get("description"),question=ds[f].get("question"),choices=ds[f].get("choices"),deprecated="[DEPRECATED]" in json.dumps(ds[f].get("question")),interpretation="categorical; blank is unrecorded"))
        if group=="PD":
            hy=df.set_index("participant_id").loc[groups[group],"diagnosis_parkinsons_ds"].map(clean)
            expected=[13,20,28,7,5]
            for stage,n in enumerate(expected,1): assert int(hy.str.startswith(f"Stage {stage} ").sum())==n
            assert int((hy=="").sum())==17
    cogn=[]
    for rel in TASKS:
        ds=schema(rel)
        fields=[k for k in ds if k.startswith(("vocabulary_item_correct_","vocabulary_item_difficulty_","stroop_item_correct_")) or k in {"winograd_score","winograd_number_questions"}]
        df,head=read_selected(rel,fields)
        for f in fields:
            field_source[f]=rel
            for g,cohort in groups.items():
                mode="availability_only_scale_ambiguous" if f.startswith("winograd_") else "categorical"
                r,cc=summarize_field(df,f,ds[f],cohort,g,mode);cogn.append(r);cats.extend(cc)
    write_csv("clinical_availability.csv",rows)
    write_csv("clinical_categories.csv",cats)
    write_csv("cognitive_availability.csv",cogn)
    write_json("clinical_semantics.json",dict(fields=semantics,UPDRS="Dictionary description says numeric total but choices are part labels; no numeric score inferred.",CDR="Ordinal categories; no continuous score inferred.",medication="Current/deprecated entries separate; absent checkbox unknown; neither establishes ON/OFF at recording.",numeric_summaries="None: no unambiguous numeric clinical severity score in the selected inventory.",Hoehn_Yahr_existing_count_reconciliation="PASS"))
def timing(data,recs):
    schemas=json.loads((CANON/"feature_schemas.json").read_text())
    inventory=[]
    for key,cols in schemas.items():
        counts=dict(explicit_duration=sum(c.startswith("dur_log__") for c in cols),dynamic_timing=sum(c.startswith("timing__") for c in cols),harmonic_timing=sum(c.startswith("htiming__") for c in cols))
        inventory.append(dict(family=FAMILY+"-T1",schema=key,total_columns=len(cols),**counts,timing_total=sum(counts.values())))
        assert not any(c.endswith(("__ltas_dur_s","__lin_dur_s","__prosody_f0_ppq3_st")) for c in cols)
    rows=[]
    y=np.asarray(data["y"])
    for oi,r in enumerate(recs):
        c=r["choices"]["stage2"];key=c["space"]+"__timing_"+c["timing"]
        cols=np.asarray(schemas[key],dtype=object);tr,te=data["splits"][oi];tr=tr[y[tr]>0]
        matrix=data["matrices"][key];assert matrix.shape==(750,len(cols))
        obj=Prep();a=obj.fit_transform(matrix[tr])
        available=cols[obj.available];survive=available[obj.vary]
        is_pca=c["family"].startswith("pca")
        if is_pca:
            selected=survive
            k=min(c["k"],min(100,len(tr)-2,a.shape[1]))
        else:
            scores=np.nan_to_num(f_classif(a,(y[tr]==1).astype(int))[0],nan=-np.inf,posinf=np.finfo(float).max)
            ranking=np.argsort(-scores,kind="stable")
            k=min(c["k"],a.shape[1],len(tr)-2);selected=survive[ranking[:k]]
        row=dict(family=FAMILY+"-T1",outer_fit_zero_based=oi,repeat_one_based=oi//5+1,fold_one_based=oi%5+1,representation=c["space"],head=c["family"],timing_choice=c["timing"],training_cases=len(tr),input_columns=len(cols),available_columns=len(available),nonconstant_columns=len(survive),requested_dimension=c["k"],used_dimension=k,retention_meaning="input_to_PCA" if is_pca else "F_top_k_input_to_head")
        for label,subset in [("supplied",cols),("available",available),("nonconstant",survive),("retained",selected)]:
            row[label+"_duration"]=sum(str(v).startswith("dur_log__") for v in subset)
            row[label+"_dynamic"]=sum(str(v).startswith("timing__") for v in subset)
            row[label+"_timing"]=row[label+"_duration"]+row[label+"_dynamic"]
        if c["timing"]=="off": assert row["retained_timing"]==0
        rows.append(row)
    write_csv("timing_schema_counts.csv",inventory);write_csv("timing_retained_by_fit.csv",rows)
def metadata_inventory():
    rows=[]
    pat=re.compile(r"mmse|mini.mental|moca|montreal|on/off|off.state|on.state|medication.state|disease.duration|disease.onset|diagnos.{0,15}date",re.I)
    for p in sorted(PHENO.rglob("*.json")):
        rel=p.relative_to(PHENO).with_suffix("").as_posix();ds=schema(rel)
        head=(PHENO/(rel+".tsv")).open(encoding="utf-8").readline().rstrip("\r\n").split("\t")
        for k,v in ds.items():
            text=json.dumps([k,v],ensure_ascii=False)
            if pat.search(text): rows.append(dict(source=rel,field=k,in_dictionary=True,in_tsv=k in head,description=v.get("description",""),matched_terms=";".join(sorted(set(m.group(0).lower() for m in pat.finditer(text))))))
        for k in head:
            if k not in ds and pat.search(k): rows.append(dict(source=rel,field=k,in_dictionary=False,in_tsv=True,description="",matched_terms="header_only"))
    write_csv("schema_keyword_inventory.csv",rows,["source","field","in_dictionary","in_tsv","description","matched_terms"])
def generic_device(f,s,ds):
    low=s.casefold()
    if f=="recording_microphone":
        maps={"built-in microphone":"Built-in/internal microphone","builtin microphone":"Built-in/internal microphone","internal microphone":"Built-in/internal microphone","integrated microphone":"Built-in/internal microphone","external microphone":"External microphone","headset":"Headset","headset microphone":"Headset","usb microphone":"USB microphone","default":"Default (unspecified hardware)","unknown":"Unknown"}
        return maps.get(low,"Other populated text (withheld)")
    return choice_map(ds).get(low,"Other populated text (withheld)")
def device(ids,y):
    inventory=[];rows=[];cats=[]
    groups={"all750":ids,"PD":[i for i,c in zip(ids,y) if c==1],"CI":[i for i,c in zip(ids,y) if c==2]}
    pat=re.compile(r"(^|_)(site|centre|center|clinic|device|microphone|system|hardware)(_|$)",re.I)
    found_site=False
    for rel in DEVICE:
        ds=schema(rel);head=(PHENO/(rel+".tsv")).open(encoding="utf-8").readline().rstrip("\r\n").split("\t")
        fields=sorted({k for k in set(ds)|set(head) if pat.search(k)}|({"recording_input_gain","recording_profile_name","recording_profile_version"} if rel=="task/recording" else set()))
        found_site=found_site or any(re.search(r"(^|_)(site|centre|center|clinic)(_|$)",f,re.I) for f in fields)
        if not fields:
            inventory.append(dict(source=rel,field="[no site/device/system field in dictionary or TSV]",dictionary_present=False,column_present=False))
            continue
        df,_=read_selected(rel,fields)
        for f in fields:
            inventory.append(dict(source=rel,field=f,dictionary_present=f in ds,column_present=f in head))
            for g,cohort in groups.items():
                sub=df[df.participant_id.isin(cohort)]
                observed=[];people=set();by_person={}
                if f in sub:
                    for pid,raw in zip(sub.participant_id,sub[f]):
                        val=clean(raw)
                        if val:
                            observed.append(val);people.add(pid);by_person.setdefault(pid,set()).add(val)
                rows.append(dict(family=FAMILY+"-D1",source=rel,field=f,group=g,denominator=len(cohort),dictionary_present=f in ds,column_present=f in head,rows=len(sub),populated_rows=len(observed),participants_with_rows=sub.participant_id.nunique(),participants_with_value=len(people),participants_no_value=len(cohort)-len(people),distinct_populated_values=len(set(observed)),participants_with_multiple_values=sum(len(v)>1 for v in by_person.values())))
                if f in {"recording_microphone","recording_profile_name","recording_profile_version"}:
                    cc={}
                    for vv in by_person.values():
                        labels={generic_device(f,s,ds.get(f,{})) for s in vv}
                        lab=next(iter(labels)) if len(labels)==1 else "Multiple generic categories"
                        cc[lab]=cc.get(lab,0)+1
                    for lab,n in sorted(cc.items()): cats.append(dict(family=FAMILY+"-D1",source=rel,field=f,group=g,category=lab,participants=n,denominator=len(cohort)))
    write_csv("device_field_inventory.csv",inventory)
    write_csv("device_coverage.csv",rows)
    write_csv("device_categories.csv",cats,["family","source","field","group","category","participants","denominator"])
    write_json("device_semantics.json",dict(site_identifier_field_detected=found_site,scope=DEVICE,no_raw_device_strings_emitted=True,profile_interpretation="Profile name dictionary enumerates Speech/Breathe/Cough; these are task profiles, not device types.",feasibility="Read coverage and within-group generic categories; no device model fitted. Absent or wholly empty fields cannot support a device-aware sensitivity."))
def run():
    assert not (OUT/"COMPLETION.json").exists() and not (OUT/"GATE.json").exists(),"refuse overwrite; diagnose failure before a new amended run"
    started=stamp();spec=verify_inputs()
    with threadpool_limits(1),warnings.catch_warnings():
        warnings.simplefilter("ignore",RuntimeWarning)
        data=joblib.load(CANON/"local_only/input_payload.joblib")
        ids,y,recs=gate(data)
        tests();clinical(ids,y);timing(data,recs);metadata_inventory();device(ids,y)
    verify_inputs()
    outfiles=[p for p in OUT.rglob("*") if p.is_file() and p.name!="COMPLETION.json"]
    write_json("COMPLETION.json",dict(status="COMPLETE_PRIMARY_PENDING_INDEPENDENT_RECOUNT",started_utc=started,completed_utc=stamp(),family=FAMILY,versions=VERSIONS,input_hashes_unchanged=True,gate="PASS",synthetic_tests="PASS",participants=750,PD=90,CI=62,outer_fits=15,no_model_fit=True,no_participant_outputs=True,outputs_sha256={p.relative_to(OUT).as_posix():sha(p) for p in outfiles}))
    print("COMPLETE; independent recount required",flush=True)
if __name__=="__main__":
    {"freeze":freeze,"run":run}[sys.argv[1]]()
