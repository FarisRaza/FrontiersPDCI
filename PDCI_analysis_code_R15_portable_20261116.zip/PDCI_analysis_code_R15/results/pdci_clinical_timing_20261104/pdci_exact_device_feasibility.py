from pathlib import Path
import os,sys,json,hashlib,re,importlib.util,string
for key in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]: os.environ[key]="1"
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location("core",OUT/"pdci_clinical_timing_audit_v2.py")
core=importlib.util.module_from_spec(sp);sp.loader.exec_module(core)
np=core.np;pd=core.pd
def hashes():
    paths=[Path(__file__),OUT/"D2_FEASIBILITY_PLAN.md",OUT/"pdci_clinical_timing_audit_v2.py",core.SOURCE,core.CANON/"local_only/input_payload.joblib",core.PHENO/"task/recording.tsv",core.PHENO/"task/recording.json",OUT/"FROZEN_SPEC_V2.json",OUT/"COMPLETION.json",OUT/"SEMANTIC_FROZEN_SPEC.json",OUT/"SEMANTIC_COMPLETION.json"]
    return {p.as_posix():core.sha(p) for p in paths}
def freeze():
    core.write_json("EXACT_DEVICE_FROZEN_SPEC.json",dict(created_utc=core.stamp(),protected_sha256=hashes(),authority="AR-45",outcomes_used=False))
    print("EXACT DEVICE FEASIBILITY FROZEN",flush=True)
def semantic(s):
    t=re.sub("[^a-z0-9]","",s.casefold())
    sets={
      "Headset microphone":{"headset","headsetmic","headsetmicrophone","wiredheadset","wiredheadsetmic","wiredheadsetmicrophone","microphoneheadset"},
      "Built-in/internal microphone":{"builtin","builtinmic","builtinmicrophone","microphonebuiltin","internalmic","internalmicrophone","integratedmicrophone"},
      "USB microphone":{"usb","usbmic","usbmicrophone","microphoneusb","usbaudiodevice"},
      "External microphone":{"externalmic","externalmicrophone","microphoneexternal"},
      "Bluetooth microphone":{"bluetooth","bluetoothmic","bluetoothmicrophone","bluetoothhfp","bluetoothheadset"},
      "Phone/tablet microphone":{"iphonemicrophone","ipadmicrophone","smartphonemicrophone","phonemicrophone","tabletmicrophone"},
      "Unspecified microphone":{"microphone","mic","default","unknown","unspecified"},
      "Microphone position label":{"front","back","bottom","top"}}
    suspicious=bool(re.search(r"@|https?://|\b(?:\d{1,3}\.){3}\d{1,3}\b|[0-9a-f]{8}-[0-9a-f]{4}-|serial|\d{6,}",s,re.I))
    for label,keys in sets.items():
        if t in keys and not suspicious:
            return dict(safe_generic_label=label,semantic_assessment="Recognized generic microphone-type token",potential_identifier_pattern=False)
    manufacturer=any(t.startswith(x) for x in ["shure","logitech","apple","samsung","sennheiser","jabra","blueyeti","rode","audiotechnica","realtek","bose"])
    if manufacturer and not suspicious:
        return dict(safe_generic_label="Manufacturer/model-style label (withheld)",semantic_assessment="Manufacturer/model naming pattern; exact hardware identity not verified",potential_identifier_pattern=False)
    return dict(safe_generic_label="Unresolved populated label (withheld)",semantic_assessment="Potential identifier pattern" if suspicious else "Unrecognized label; no hardware interpretation assigned",potential_identifier_pattern=suspicious)
def run():
    f=json.loads((OUT/"EXACT_DEVICE_FROZEN_SPEC.json").read_text())
    assert all(core.sha(p)==v for p,v in f["protected_sha256"].items())
    data=core.joblib.load(core.CANON/"local_only/input_payload.joblib")
    ids=[core.norm(i) for i in data["ids"]];y=np.asarray(data["y"]);ct=np.asarray(data["asc"][:,2])
    assert len(ids)==len(set(ids))==750 and np.bincount(y).tolist()==[598,90,62]
    assert set(ct)=={0,1}
    df,_=core.read_selected("task/recording",["recording_microphone"])
    vals={p:set() for p in ids};blanks={p:0 for p in ids}
    for pid,raw in zip(df.participant_id,df.recording_microphone):
        if pid not in vals: continue
        s=core.clean(raw)
        if s: vals[pid].add(s)
        else: blanks[pid]+=1
    tokens=sorted(set().union(*vals.values()),key=lambda s:hashlib.sha256(s.encode("utf-8")).hexdigest())
    labels={s:string.ascii_uppercase[j] if j<26 else "D"+str(j+1) for j,s in enumerate(tokens)}
    assigned={p:next(iter(v)) if len(v)==1 else "[Multiple]" if len(v)>1 else "[Missing]" for p,v in vals.items()}
    rows=[];aud=[]
    for tok in tokens+["[Multiple]","[Missing]"]:
        label=labels.get(tok,tok)
        membership=np.array([assigned[p]==tok for p in ids])
        anymembership=np.array([tok in vals[p] for p in ids]) if tok in labels else membership
        sem=semantic(tok) if tok in labels else dict(safe_generic_label=tok,semantic_assessment="Participant-level category",potential_identifier_pattern=False)
        row=dict(family="F10-R13-D2-feasibility",device_category=label,**sem,
                 exclusive_all=int(membership.sum()),any_all=int(anymembership.sum()),exclusive_with_some_blank_rows=sum(membership[j] and blanks[p]>0 for j,p in enumerate(ids)))
        for group,cls in [("neither",0),("PD",1),("CI",2)]:
            row["exclusive_"+group]=int((membership&(y==cls)).sum())
            row["any_"+group]=int((anymembership&(y==cls)).sum())
            for country,v in [("Canada",0),("USA",1)]:
                row["exclusive_"+group+"_"+country]=int((membership&(y==cls)&(ct==v)).sum())
        for country,v in [("Canada",0),("USA",1)]:
            row["exclusive_all_"+country]=int((membership&(ct==v)).sum())
        row["potential_stratum_ge10_PD_CI"]=tok in labels and row["exclusive_PD"]>=10 and row["exclusive_CI"]>=10 and not sem["potential_identifier_pattern"]
        row["potential_Canada_stratum_ge10_PD_CI"]=row["potential_stratum_ge10_PD_CI"] and row["exclusive_PD_Canada"]>=10 and row["exclusive_CI_Canada"]>=10
        rows.append(row)
        if tok in labels: aud.append(dict(device_category=label,**sem))
    assert sum(r["exclusive_all"] for r in rows)==750
    assert sum(r["exclusive_PD"] for r in rows)==90 and sum(r["exclusive_CI"] for r in rows)==62
    core.write_csv("exact_device_feasibility.csv",rows)
    core.write_json("exact_device_metadata_audit.json",dict(status="PASS",label_rule="Lexicographic SHA256 of trimmed populated exact UTF-8 microphone strings from all canonical recording rows; A onwards; raw strings/hashes not emitted",all_participants_partitioned_once=True,metadata_semantics=aud,device_identity_not_verified=True,site_identity_not_inferred=True,scope="All released recording rows of canonical participants, including recordings outside the 11 model task families",no_model_fit=True,no_outcome_inspection=True))
    assert all(core.sha(p)==v for p,v in f["protected_sha256"].items())
    names=["D2_FEASIBILITY_PLAN.md","pdci_exact_device_feasibility.py","EXACT_DEVICE_FROZEN_SPEC.json","exact_device_feasibility.csv","exact_device_metadata_audit.json"]
    core.write_json("EXACT_DEVICE_COMPLETION.json",dict(status="COMPLETE_PENDING_INDEPENDENT_RECOUNT",completed_utc=core.stamp(),protected_inputs_unchanged=True,outputs_sha256={n:core.sha(OUT/n) for n in names}))
    print("EXACT DEVICE FEASIBILITY COMPLETE",flush=True)
if __name__=="__main__": {"freeze":freeze,"run":run}[sys.argv[1]]()
