# Parquet identifier handling and public prerequisites

The executed v2 gate accepts participant_id as a named parquet index or a column and applies the same canonical-ID/label checks after resetting the index when necessary. This public copy retains that logic. It hashes its current protocol, this note, script and scientific inputs. The failed historical v1 script and its freeze are not public prerequisites. No population, field, preprocessing or ranking setting changes.
