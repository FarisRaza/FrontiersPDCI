from pathlib import Path
import sys, os, json, hashlib, importlib.util, re, math
from datetime import datetime, timezone
for key in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]:
    os.environ[key]="1"
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("primary_audit",OUT/"pdci_clinical_timing_audit_v2.py")
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
pd=core.pd;np=core.np
def hashes():
    frozen=json.loads((OUT/"FROZEN_SPEC_V2.json").read_text())
    paths=[Path(p) for p in frozen["protected_sha256"]]
    paths += [Path(__file__),OUT/"AMENDMENT_2.md",OUT/"FROZEN_SPEC_V2.json"]
    paths += [OUT/n for n in ["clinical_availability.csv","clinical_categories.csv","cognitive_availability.csv","device_coverage.csv","device_categories.csv","COMPLETION.json"]]
    return {p.as_posix():core.sha(p) for p in sorted(set(paths),key=str)}
def freeze():
    core.verify_inputs()
    core.write_json("SEMANTIC_FROZEN_SPEC.json",dict(created_utc=core.stamp(),authority="AR-45",amendment="2",protected_sha256=hashes()))
    print("SEMANTIC FOLLOW-UP FROZEN",flush=True)
def decoded(s,v,checkbox):
    token=s.casefold()
    try:
        x=float(token)
        if math.isfinite(x) and x.is_integer(): token=str(int(x))
    except ValueError: pass
    mapping=core.choice_map(v)
    if token in mapping: return mapping[token]
    if checkbox and token in {"1","true","checked","yes"}: return "Recorded selected"
    if checkbox and token in {"0","false","unchecked","no"}: return "Recorded unselected"
    return "Other populated token (withheld)"
def run():
    frozen=json.loads((OUT/"SEMANTIC_FROZEN_SPEC.json").read_text())
    assert all(core.sha(p)==h for p,h in frozen["protected_sha256"].items())
    data=core.joblib.load(core.CANON/"local_only/input_payload.joblib")
    ids=[core.norm(v) for v in data["ids"]];y=np.asarray(data["y"]);country=data["asc"][:,2]
    groups={"PD":[p for p,c in zip(ids,y) if c==1],"CI":[p for p,c in zip(ids,y) if c==2]}
    core.categorized=decoded
    rows=pd.concat([pd.read_csv(OUT/"clinical_availability.csv"),pd.read_csv(OUT/"cognitive_availability.csv")],ignore_index=True)
    cats=[];matched=0
    for source,part in rows.groupby("source",sort=False):
        fields=part.field.unique().tolist();df,_=core.read_selected(source,fields);ds=core.schema(source)
        for _,r in part.iterrows():
            core.field_source[r.field]=source
            row,cc=core.summarize_field(df,r.field,ds[r.field],groups[r.group],r.group,r.semantics)
            for k,v in row.items(): assert v==r[k],f"availability changed: {source}/{r.field}/{k}"
            matched+=1;cats.extend(cc)
    core.write_csv("clinical_categories_decoded.csv",cats)
    core.write_json("semantic_followup_audit.json",dict(status="PASS",availability_rows_compared=matched,availability_rows_matched=matched,availability_changed=False,no_model_fit=True,no_raw_device_values_emitted=True,decoder_synthetic_checks={"1.0_checkbox":decoded("1.0",{},True)=="Recorded selected","0.0_checkbox":decoded("0.0",{},True)=="Recorded unselected","blank_preserved":core.clean("n/a")=="","difficulty_2.0":decoded("2.0",{"choices":[{"value":2,"name":{"en":"2"}}]},False)=="2"},publication_export_policy="CDR and vocabulary-difficulty category rows withheld; availability unchanged",device_metadata_scope="Superseded broad generic-device branch omitted; use exact-device feasibility script."))
    assert all(core.sha(p)==h for p,h in frozen["protected_sha256"].items())
    files=["AMENDMENT_2.md","pdci_semantic_followup.py","SEMANTIC_FROZEN_SPEC.json","clinical_categories_decoded.csv","semantic_followup_audit.json"]
    core.write_json("SEMANTIC_COMPLETION.json",dict(status="COMPLETE_PENDING_INDEPENDENT_RECOUNT",completed_utc=core.stamp(),protected_inputs_unchanged=True,outputs_sha256={n:core.sha(OUT/n) for n in files}))
    print("SEMANTIC FOLLOW-UP COMPLETE",flush=True)
if __name__=="__main__": {"freeze":freeze,"run":run}[sys.argv[1]]()
