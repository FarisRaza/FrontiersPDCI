# Public reproduction protocol

This release copy documents the original calculation and the release-only portability changes. It is not the historically frozen protocol; a future rerun records a new hash and timestamp. No results were recomputed when preparing this copy.

## Cohort and label recount (counts only)

Reproduce the published cohort flow, class composition and Table 1 descriptives. Unit: participant. No model, inference or new subgroup is fitted. The analysis cohort contains 750 participants (598 neither, 90 PD, 62 CI).

Use src/pdci_tasks.py: audio cohort has n_recordings > 0; remove ALS records and records with both PD and CI labels; require all 11 GENERAL_TASKS. Labels are 0 neither, 1 PD, 2 CI. The recorded categories do not imply a confirmed clinical differential diagnosis or healthy controls.

Read demographics through the canonical stripped, six-character zero-padded identifier. Keep the first demographics record. Convert age to numeric, treating nonnumeric values as missing. Sex is sex_at_birth, falling back to sex_assigned_at_birth; count Female, Male and unavailable. Country is residence country: USA, Canada and unknown. PD subtype uses diagnosis_parkinsons_disease_subtype; CI subtype uses diagnosis_alz_dementia_mci_dt. Report the recorded categories, missing values and absence from the module separately.

## Gate and outputs

Before writing counts, require exact agreement with source INPUT_AUDIT.json: 750 participants; classes [598,90,62]; 4 missing ages; 6 unavailable sexes; no missing country; matching country-by-class counts; 833 participants with audio. Freeze the protocol, script and computational inputs first, then gate, then run.

Write cohort_flow.csv, table1_recount.csv, subtype_recount.csv, RECONCILIATION.csv and COMPLETION.json. Age SD uses ddof=1; also store ddof=0 solely for historical reconciliation. Compare counts exactly and age means/SDs at two decimals against the unchanged published constants in paper_values(). The original private paper and notes are no longer required: the script hash pins these reference constants. Legacy CSV field names paper_tex and paper_tex_line identify the historical reference, not an input dependency. Report discrepancies; do not silently replace published values.

Only aggregates may be shared. The historical independent recount is distinct from this public copy and is not rerun by the three commands.
