"""D2 post hoc nested refit in Canadian cases with one common microphone label."""
import os,sys
sys.dont_write_bytecode=True
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import importlib.util,json,hashlib,time,warnings
from concurrent.futures import ThreadPoolExecutor
import numpy as np,pandas as pd,joblib
from scipy.stats import t
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from threadpoolctl import threadpool_limits
OUT=Path(__file__).resolve().parent;ANALYSIS=OUT.parents[1]
N1=ANALYSIS/'results/pdci_reviewer_extension_20261104'
sp=importlib.util.spec_from_file_location('original_subgroup',N1/'pdci_subgroup_analysis_20261104.py')
n=importlib.util.module_from_spec(sp);sp.loader.exec_module(n)
REC=ANALYSIS.parent/'phenotype/task/recording.tsv'
def write(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def missing(v):return str(v).strip().lower() in ['','n/a','na','nan','none','null']
def freeze():
    assert not (OUT/'FROZEN_SPEC.json').exists()
    paths=set(n.inputs())|{REC,REC.with_suffix('.json'),Path(n.__file__),N1/'GATE.json',Path(__file__),OUT/'ANALYSIS_PLAN.md'}
    write('FROZEN_SPEC.json',dict(time=n.now(),inputs={str(p):n.sha(p) for p in sorted(paths)},
        family='F10-R13-D2',authority='AR-45',seed=20260725,bootstrap_seed=20261106,bootstrap=5000,
        decision='Largest min(PD,CI) Canadian exact-single-microphone stratum with at least10each; tie totaln then SHA256 order',
        original_N1_N2_results_known=True,no_device_performance_examined=True))
    print('D2 frozen before outcomes.',flush=True)
def verify():
    s=json.loads((OUT/'FROZEN_SPEC.json').read_text())
    for p,h in s['inputs'].items():assert n.sha(p)==h,p
    return s
def run():
    verify();assert json.loads((N1/'GATE.json').read_text())['passed'];assert not (OUT/'COMPLETION.json').exists()
    start=n.now();data=joblib.load(n.SOURCE/'local_only/input_payload.joblib')
    ids=pd.Index(data['ids']).astype(str).str.strip().str.zfill(6);labels=n.review.load().reindex(ids)
    assert np.array_equal(labels.y_true.to_numpy(),data['y']) and np.bincount(data['y']).tolist()==[598,90,62]
    raw=pd.read_csv(REC,sep='\t',dtype=str,keep_default_na=False,usecols=['participant_id','recording_microphone'])
    raw['pid']=raw.participant_id.astype(str).str.strip().str.zfill(6);raw=raw[raw.pid.isin(ids)]
    raw['value']=raw.recording_microphone.str.strip();raw=raw[~raw.value.map(missing)]
    values=raw.groupby('pid').value.agg(lambda z:tuple(sorted(set(z))))
    tokens=sorted(raw.value.unique(),key=lambda z:hashlib.sha256(z.encode('utf-8')).hexdigest())
    categories={v:chr(65+i) for i,v in enumerate(tokens)}
    single=values.map(lambda z:z[0] if len(z)==1 else None).reindex(ids)
    eligible=[];audit=[]
    for token in tokens:
        mask=(single==token)&(labels.country=='Canada')&labels.y_true.isin([1,2])
        npd=int((labels.loc[mask,'y_true']==1).sum());nci=int((labels.loc[mask,'y_true']==2).sum())
        audit.append(dict(recorded_category=categories[token],n_PD=npd,n_CI=nci,eligible=min(npd,nci)>=10))
        if min(npd,nci)>=10:eligible.append((min(npd,nci),npd+nci,hashlib.sha256(token.encode('utf-8')).hexdigest(),token))
    assert eligible,'No device stratum supports the frozen analysis'
    eligible.sort(key=lambda z:(-z[0],-z[1],z[2]));chosen=eligible[0][3]
    mask=((single==chosen)&(labels.country=='Canada')&labels.y_true.isin([1,2])).to_numpy()
    assert (int((data['y'][mask]==1).sum()),int((data['y'][mask]==2).sum()))==(38,46)
    pd.DataFrame(audit).to_csv(OUT/'device_subset_gate_counts.csv',index=False)
    # Repeat the six published AUROCs as a gate; no model outcome from D2 yet.
    pr=pd.read_parquet(n.SOURCE/'local_only/participant_oof_predictions.parquet');ref=pd.read_csv(n.SOURCE/'auc_intervals.csv');yy=pr.y_true.to_numpy()
    for model in ['primary','agesexcountry']:
        val=n.core.metrics(yy,pr[model+'_screen'].to_numpy(),pr[model+'_q'].to_numpy(),pr[[model+'_p'+str(i) for i in range(3)]].to_numpy())
        for endpoint in ['screen','stage2','macro']:assert abs(val[endpoint]-float(ref[(ref.model==model)&(ref.endpoint==endpoint)].auc.iloc[0]))<1e-9
    write('GATE.json',dict(passed=True,time=n.now(),canonical_counts=[598,90,62],canonical_six_aurocs_matched=True,
        canonical_selected_refit_gate_source=str(N1/'GATE.json'),chosen_recorded_category=categories[chosen],n_PD=38,n_CI=46,
        country='Canada',one_exact_string_per_person=True,choice_uses_counts_only=True))
    sub=dict(y=(data['y'][mask]==1).astype(int),asc=data['asc'][mask],matrices={k:v[mask] for k,v in data['matrices'].items()});y=sub['y']
    outer=[(i,tr,te) for i,(tr,te) in enumerate(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=20260725).split(np.zeros(len(y)),y))]
    vs=np.full((3,len(y)),np.nan);bs=vs.copy();seen=np.zeros((3,len(y)),int);rows=[]
    with threadpool_limits(1),warnings.catch_warnings():
        warnings.simplefilter('ignore')
        with ThreadPoolExecutor(max_workers=2) as pool:
            for te,v,b,row in pool.map(lambda z:n.fit_one(sub,z,'Canada_single_microphone'),outer):
                r=row['repeat'];vs[r,te]=v;bs[r,te]=b;seen[r,te]+=1;rows.append(row)
    assert (seen==1).all() and np.isfinite(vs).all() and np.isfinite(bs).all()
    pd.DataFrame(rows).to_csv(OUT/'device_fold_metrics.csv',index=False)
    pd.DataFrame(n.summarize(y,vs.mean(0),bs.mean(0),'Canada_single_microphone',20261106)).to_csv(OUT/'device_metrics.csv',index=False)
    reps=[]
    for r in range(3):
        v=roc_auc_score(y,vs[r]);b=roc_auc_score(y,bs[r]);reps.append(dict(analysis='Canada_single_microphone',repeat=r,voice_auc=v,baseline_auc=b,difference=v-b))
    pd.DataFrame(reps).to_csv(OUT/'device_repeat_metrics.csv',index=False)
    frame=pd.DataFrame(rows);d=frame.gain;ratio=(frame.test_n/frame.train_n).mean();se=float(np.sqrt((1/15+ratio)*d.var(ddof=1)));mean=float(d.mean())
    corrected=dict(analysis='Canada_single_microphone',mean_fold_gain=mean,corrected_se=se,test_train_ratio=ratio,
        ci_low=mean-t.ppf(.975,14)*se,ci_high=mean+t.ppf(.975,14)*se,p=float(2*t.sf(abs(mean/se),14)),df=14,
        multiplicity='Unadjusted exploratory additional comparison; outside original BH3 and N1/N2 BH2')
    pd.DataFrame([corrected]).to_csv(OUT/'device_corrected_cv.csv',index=False)
    verify();write('COMPLETION.json',dict(status='COMPLETE_REQUIRES_INDEPENDENT_RECONCILIATION',started=start,ended=n.now(),
        outer_fits=15,participant_rows_written=False,original_input_hashes_unchanged=True,recorded_category=categories[chosen]))
    print('D2 complete; only aggregate outputs written.',flush=True)
if __name__=='__main__':globals()[sys.argv[1]]()
