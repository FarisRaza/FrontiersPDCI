# Common operating point comparison

Family F13-OP. Post hoc Reviewer 1 request 2, authorized by AR-48. Date 16 November 2026 UTC. Original F1/F2/F5/F8-A5 analyses remain unchanged.

## Question and population

Compare the saved voice procedure and age sex country baseline at identical training referral budgets, preserving the canonical 750 participants (598 neither, 90 PD, 62 CI), 15 outer partitions, selected models and inner-held-out scores. No refitting or new feature selection. Unit is the participant; each participant has three outer predictions.

## Frozen design

Evaluate every budget in 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80. This range and reporting of all seven are fixed before calculating new outcomes. The midpoint 0.50 may be used as a compact illustration, with the full grid reported. No claim of optimal budget and no selection by held-out performance.

For each procedure and outer fit, choose the screen cutoff using all 600 outer-training participants' selected inner-held-out screening scores. The allowed referral count is floor(budget times 600). Among unique scores, use the lowest threshold that refers no more than that count under score greater than or equal to threshold; retain ties as one block. If no score group fits, use nextafter(maximum score, positive infinity), referring none. This maximizes the attainable training referrals within budget. The discriminator threshold is the largest q cutoff achieving at least 95% sensitivity among training PD participants, determined without screening gating from its selected inner-held-out scores. Neither threshold uses outer-test scores, ranks or outcomes.

Apply cutoffs to each fit's outer-test predictions. A participant is referred if at least two of three repeats refer. Among referring repeats, a PD vote majority (ties to PD) assigns PD; otherwise CI. Negative screens assign neither. This is the original primary-policy voting rule. Report each repeat separately as well. A common training budget is not an exact constraint on the achieved held-out referral count; repeated voting may also alter referral fraction. Describe this explicitly.

## Outcomes and uncertainty

For each budget and procedure report full three-by-three confusion counts and the following with numerator and denominator: total referral fraction, case screening sensitivity, PD and CI screening sensitivities separately, neither specificity, end-to-end PD and CI sensitivity, PD and CI assignment PPV against all other labels, CI-to-PD and PD-to-CI fractions, correctly assigned cases among all cases. Denominators respectively include all750, all152cases, PD90, CI62, neither598, or the procedure's assignment count. Compare voice minus baseline.

Compute nominal 95% percentile intervals on fixed participant-majority decisions and paired differences using 5000 shared class-stratified participant resamples, numpy default_rng seed20261116, class order0/1/2, concatenated within-class sampled indices and linear quantiles0.025/0.975. Use the same resampling weights for all budgets and procedures. Retain finite-draw counts; undefined zero-denominator draws remain missing, never forced to0. These are exploratory pointwise intervals conditional on saved fitted predictions and thresholds. No hypothesis tests or multiplicity-adjusted claims; original BH3 unchanged. Report all budgets, with no best-budget selection.

## Freeze and canonical gate

Before any new outcome, freeze this plan, script, the split manifest, every selected-inner/test fold file and receipt, saved participant-average predictions, original pooled AUROCs and A5 aggregate reference tables with SHA256 in FROZEN_SPEC.json; record installed runtime versions. Refuse changed files and refuse overwriting completed results. Do not read excluded September14 or stage-prediction results.

Gate: verify exact participant ordering, labels, 600/150 disjoint splits, three outer predictions per participant and saved prediction hashes. Reproduce all six original AUROCs at absolute tolerance1e-12. Recompute the original separate98_pd95 thresholds for both procedures from training data, then match all60 thresholds at1e-12 and all72 A5 confusion cells exactly (participant-majority and three repeats). Stop before new outcomes if any gate fails.

Test hand cases for tied scores, budgets0and1, nonfinite and empty scores, threshold inclusion, two-stage voting and PD tie rule, undefined denominators and paired signs. Independently reimplement the protocol without reading the owner script, reconcile thresholds, aggregate counts, point estimates and bootstrap intervals. Separate code review must audit leakage, ties, denominators and weighting. Record actual comparisons/tolerances and no unverified claims.

## Execution and privacy

Use the project virtual environment and one numerical-library thread, single process, expected under1GiB. Start only under the machine light-job gate and serialize against other PD/CI compute; checkpoint or stop below3GiB commit headroom. Raw inputs remain in place. New participant decisions stay exclusively in this dated result folder/local_only and are excluded from any shared archive. Public tables and reports are aggregates. Capture input/output hashes and times in COMPLETION.json; preserve originals.
