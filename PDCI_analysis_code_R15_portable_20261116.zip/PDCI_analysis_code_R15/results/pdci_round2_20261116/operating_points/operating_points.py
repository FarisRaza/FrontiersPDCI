"""F13-OP post hoc common training referral budgets. Participant data stay local."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ctypes, hashlib, json, math, os, platform
for variable in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[variable]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import numpy as np
import pandas as pd
import scipy, sklearn
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

ANALYSIS=Path(os.environ.get("PDCI_ANALYSIS_ROOT",str(Path(__file__).resolve().parents[3]))).resolve()
SOURCE=ANALYSIS/'results/pdci_demographic_baseline_20260911'
A5=ANALYSIS/'results/pdci_a5_matched_policy_20261001'
OUT=ANALYSIS/'results/pdci_round2_20261116/operating_points'
BUDGETS=(.2,.3,.4,.5,.6,.7,.8)
MODELS={'voice':('primary','screen','stage2'),'baseline':('agesexcountry','asc_screen','asc_stage2')}
NBOOT=5000
SEED=20261116
LABELS=('Neither','PD','CI')

def stamp(): return datetime.now(timezone.utc).isoformat()
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save_json(p,obj): Path(p).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csv(name,rows):
    frame=rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows)
    frame.to_csv(OUT/name,index=False,float_format='%.17g')
def ratio(a,b): return float(a/b) if b else np.nan
def memory_status():
    class Status(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ('total','available','commit_limit','commit_available','virtual_total','virtual_available','extended')]
    s=Status();s.length=ctypes.sizeof(s)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
    return dict(free_RAM_GiB=s.available/2**30,commit_headroom_GiB=s.commit_available/2**30)
def close(a,b):
    assert np.allclose(a,b,rtol=0,atol=1e-12,equal_nan=True),'Numerical disagreement'

def budget_threshold(scores,budget):
    """Maximize referrals <= floor(b*n); tied scores remain together."""
    s=np.asarray(scores,float)
    if s.ndim!=1 or not len(s) or not np.isfinite(s).all() or not 0<=budget<=1:
        raise ValueError('Finite vector and budget in [0,1] required')
    allowed=math.floor(budget*len(s)+1e-12)
    values,counts=np.unique(s,return_counts=True)
    referred=np.cumsum(counts[::-1])
    eligible=np.flatnonzero(referred<=allowed)
    threshold=float(values[::-1][eligible[-1]]) if len(eligible) else float(np.nextafter(values[-1],np.inf))
    assert (s>=threshold).sum()<=allowed
    if len(eligible) and eligible[-1]+1<len(values):
        assert (s>=values[::-1][eligible[-1]+1]).sum()>allowed
    return threshold

def sensitivity_threshold(scores,target):
    s=np.asarray(scores,float)
    if not len(s) or not np.isfinite(s).all(): raise ValueError('Finite positives required')
    required=math.ceil(target*len(s)-1e-12)
    return float(np.sort(s)[len(s)-required])

def vote(screen,pd_call):
    assert screen.shape==pd_call.shape and screen.ndim==2 and screen.shape[1]==3
    referred=screen.sum(axis=1)>=2
    n_pd=(screen&pd_call).sum(axis=1)
    n_ci=(screen&~pd_call).sum(axis=1)
    return np.where(referred,np.where(n_pd>=n_ci,1,2),0)

def masks(y,final):
    pd_,ci,none,case=y==1,y==2,y==0,y>0
    referral=final>0
    return {
        'referral_fraction':(referral,np.ones(len(y),bool)),
        'screen_sensitivity':(case&referral,case),
        'screen_PD_sensitivity':(pd_&referral,pd_),
        'screen_CI_sensitivity':(ci&referral,ci),
        'screen_specificity':(none&~referral,none),
        'end_to_end_PD_recall':(pd_&(final==1),pd_),
        'end_to_end_CI_recall':(ci&(final==2),ci),
        'end_to_end_PD_PPV_vs_rest':(pd_&(final==1),final==1),
        'end_to_end_CI_PPV_vs_rest':(ci&(final==2),final==2),
        'CI_to_PD_rate':(ci&(final==1),ci),
        'PD_to_CI_rate':(pd_&(final==2),pd_),
        'correct_case_assignment':((pd_&(final==1))|(ci&(final==2)),case),
    }

def input_files():
    p=[Path(__file__).resolve(),OUT/'ANALYSIS_PLAN.md',SOURCE/'local_only/split_manifest.json',
       SOURCE/'local_only/participant_oof_predictions.parquet',SOURCE/'pooled_oof_metrics.csv',
       A5/'confusion_matrices.csv',A5/'training_thresholds.csv',A5/'policy_comparison.csv']
    for i in range(15):
        p.extend(SOURCE/f'local_only/folds/fold_{i:02d}{suffix}' for suffix in ('.json','.parquet','_selected_inner.parquet'))
    return sorted(p)

def freeze():
    assert not (OUT/'FROZEN_SPEC.json').exists(),'Already frozen'
    selftests()
    save_json(OUT/'FROZEN_SPEC.json',dict(family='F13-OP',post_hoc=True,author_ruling='AR-48',created_utc=stamp(),
        budgets=BUDGETS,pd_training_sensitivity=.95,threshold_comparison='>=',
        budget_rule='largest attainable count <= floor(budget*n), keep score ties together',
        seed=SEED,n_boot=NBOOT,contrast='voice minus baseline',models_refitted=False,
        scripts_and_inputs_sha256={str(p):sha(p) for p in input_files()},
        versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__)))
    print('F13-OP protocol frozen before new operating outcomes.')

def verify():
    f=json.loads((OUT/'FROZEN_SPEC.json').read_text())
    assert tuple(f['budgets'])==BUDGETS and f['seed']==SEED and f['n_boot']==NBOOT
    for path,h in f['scripts_and_inputs_sha256'].items(): assert sha(path)==h,'Frozen input/script changed'
    return f

def selftests():
    assert budget_threshold([.1,.2,.3,.4],.5)==.3
    assert budget_threshold([.1,.3,.3,.9],.5)==.9
    assert budget_threshold([.2,.2],.5)>.2
    assert budget_threshold([.1,.9],0)>.9
    assert budget_threshold([.1,.9],1)==.1
    assert sensitivity_threshold([.1,.1,.4,.7],.75)==.1
    for x in ([],[np.nan],[np.inf]):
        try: budget_threshold(x,.5)
        except ValueError: pass
        else: raise AssertionError('Nonfinite/empty scores accepted')
    s=np.array([[1,1,0],[1,0,0],[1,1,1],[1,0,1]],bool)
    q=np.array([[1,0,0],[1,0,0],[0,0,1],[0,0,0]],bool)
    assert vote(s,q).tolist()==[1,0,2,2]
    y=np.array([0,1,2]); m=masks(y,np.array([0,1,1]))
    assert tuple(map(lambda a:int(a.sum()),m['end_to_end_PD_PPV_vs_rest']))==(1,2)
    assert np.isnan(ratio(0,0))
    return {'threshold_ties':True,'budget_extremes':True,'missing_rejected':True,'voting_ties':True,'ratio_denominators':True}

def load():
    manifest=json.loads((SOURCE/'local_only/split_manifest.json').read_text())
    ids=np.asarray(manifest['ids']); assert len(ids)==750 and len(set(ids))==750
    y=np.full(750,-1,int); raw=[]; inner=[]
    for i,split in enumerate(manifest['splits']):
        rec=json.loads((SOURCE/f'local_only/folds/fold_{i:02d}.json').read_text())
        tpath=SOURCE/f'local_only/folds/fold_{i:02d}.parquet'
        assert sha(tpath)==rec['prediction_sha256'] and rec['status']=='COMPLETE'
        test=pd.read_parquet(tpath)
        train=pd.read_parquet(SOURCE/f'local_only/folds/fold_{i:02d}_selected_inner.parquet')
        ti,vi=np.asarray(split['train']),np.asarray(split['test'])
        assert len(ti)==600 and len(vi)==150 and not set(ti)&set(vi)
        assert train.participant_id.tolist()==ids[ti].tolist() and test.participant_id.tolist()==ids[vi].tolist()
        assert (test.repeat==i//5).all() and (test.fold==i%5).all()
        assert all(x['disjoint'] for x in rec['inner_partition_audit'])
        if i<5: y[vi]=test.y_true.to_numpy(int)
        else: assert np.array_equal(y[vi],test.y_true.to_numpy(int))
        for model,(prefix,sc,qc) in MODELS.items():
            assert np.isfinite(train[sc]).all() and train[sc].between(0,1).all()
            cases=train.y_true>0
            assert np.isfinite(train.loc[cases,qc]).all() and train.loc[cases,qc].between(0,1).all()
            assert train.loc[~cases,qc].isna().all()
            assert np.isfinite(test[[prefix+'_screen',prefix+'_q']]).all().all()
        raw.append(test); inner.append(train)
    assert np.array_equal(np.bincount(y),[598,90,62])
    for split,train in zip(manifest['splits'],inner): assert np.array_equal(train.y_true,y[split['train']])
    raw=pd.concat(raw,ignore_index=True)
    assert len(raw)==2250 and not raw.duplicated(['participant_id','repeat']).any()
    return ids,y,raw,inner

def evaluate(ids,y,raw,inner,model,budget=None,gate_policy=False):
    prefix,sc,qc=MODELS[model]; thresholds=[]
    for i,train in enumerate(inner):
        yy=train.y_true.to_numpy(int); s=train[sc].to_numpy(float); q=train[qc].to_numpy(float)
        if gate_policy: st=min(sensitivity_threshold(s[yy==c],.98) for c in (1,2))
        else: st=budget_threshold(s,budget)
        qt=sensitivity_threshold(q[yy==1],.95)
        thresholds.append(dict(model=model,budget='primary98' if gate_policy else budget,outer_fold=i,repeat=i//5,fold=i%5,
            screen_threshold=st,pd_threshold=qt,n_training=len(s),training_referrals=int((s>=st).sum()),
            training_referral_fraction=float((s>=st).mean()),training_PD_screen_sensitivity=float((s[yy==1]>=st).mean()),
            training_CI_screen_sensitivity=float((s[yy==2]>=st).mean()),training_PD_discrimination_sensitivity=float((q[yy==1]>=qt).mean())))
    th=pd.DataFrame(thresholds)
    data=raw[['participant_id','repeat','fold','y_true',prefix+'_screen',prefix+'_q']].merge(th[['repeat','fold','screen_threshold','pd_threshold']],on=['repeat','fold'],validate='many_to_one')
    data['screen']=data[prefix+'_screen']>=data.screen_threshold
    data['pd_call']=data[prefix+'_q']>=data.pd_threshold
    s=data.pivot(index='participant_id',columns='repeat',values='screen').reindex(ids).to_numpy(bool)
    q=data.pivot(index='participant_id',columns='repeat',values='pd_call').reindex(ids).to_numpy(bool)
    final=vote(s,q)
    scopes={'participant_majority':final}
    scopes.update({f'repeat_{r}':np.where(s[:,r],np.where(q[:,r],1,2),0) for r in range(3)})
    return th,scopes

def gate():
    verify(); tests=selftests(); ids,y,raw,inner=load()
    pooled=raw.groupby('participant_id').mean(numeric_only=True).reindex(ids)
    saved=pd.read_parquet(SOURCE/'local_only/participant_oof_predictions.parquet').reindex(ids)
    source_aucs=pd.read_csv(SOURCE/'pooled_oof_metrics.csv',float_precision='round_trip').set_index('model')
    auc_rows=[]
    for model,(prefix,_,__) in MODELS.items():
        cols=[prefix+'_screen',prefix+'_q']+[prefix+'_p'+str(i) for i in range(3)]
        close(pooled[cols].to_numpy(),saved[cols].to_numpy())
        values={'screen':roc_auc_score(y>0,pooled[cols[0]]),'stage2':roc_auc_score(y[y>0]==1,pooled.loc[y>0,cols[1]]),
                'macro':roc_auc_score(y,pooled[cols[2:]],multi_class='ovr',average='macro')}
        for endpoint,value in values.items():
            close(value,source_aucs.loc[prefix,endpoint]);auc_rows.append(dict(model=model,endpoint=endpoint,value=value))
    refcm=pd.read_csv(A5/'confusion_matrices.csv'); refth=pd.read_csv(A5/'training_thresholds.csv',float_precision='round_trip')
    checks=0
    for model in MODELS:
        th,scopes=evaluate(ids,y,raw,inner,model,gate_policy=True)
        rt=refth[(refth.model==model)&(refth.policy=='separate98_pd95')].sort_values('outer_fold')
        close(th[['screen_threshold','pd_threshold']].to_numpy(),rt[['screen_threshold','pd_threshold']].to_numpy())
        for scope,final in scopes.items():
            rc=refcm[(refcm.model==model)&(refcm.policy=='separate98_pd95')&(refcm.scope==scope)]
            for c in range(3):
                for p in range(3):
                    actual=int(((y==c)&(final==p)).sum())
                    expected=int(rc[(rc.true_class==LABELS[c])&(rc.predicted_class==LABELS[p])].n.iloc[0])
                    assert actual==expected; checks+=1
    save_json(OUT/'GATE.json',dict(status='PASS',time=stamp(),tests=tests,n_participants=750,outer_folds=15,split_and_label_linkage_verified=True,
        historical_auroc_rows=auc_rows,A5_confusion_cells_matched=checks,A5_threshold_cells_matched=60,no_models_refitted=True))
    print('Canonical gate PASS: six AUROCs, 72 A5 confusion cells and 60 thresholds reproduced.')

def run():
    verify(); assert json.loads((OUT/'GATE.json').read_text())['status']=='PASS'
    assert not (OUT/'COMPLETION.json').exists(),'Run already complete'
    start_memory=memory_status()
    assert start_memory['commit_headroom_GiB']>=5 and start_memory['free_RAM_GiB']>=.4,'Light-job memory gate not met; no new results'
    started=stamp(); ids,y,raw,inner=load()
    rng=np.random.default_rng(SEED); groups=[np.flatnonzero(y==c) for c in range(3)]
    weights=np.empty((NBOOT,len(y)),np.float64)
    for b in range(NBOOT):
        selected=np.concatenate([rng.choice(g,len(g),replace=True) for g in groups]);weights[b]=np.bincount(selected,minlength=len(y))
    thresholds=[];points=[];cms=[];intervals=[];deltas=[];decisions=[]
    for budget in BUDGETS:
        assert memory_status()['commit_headroom_GiB']>=3,'Low commit headroom; stop before writing results'
        estimates={}; draws={}
        for model in MODELS:
            th,scopes=evaluate(ids,y,raw,inner,model,budget)
            thresholds.append(th)
            for scope,final in scopes.items():
                mm=masks(y,final)
                for metric,(num,den) in mm.items():
                    points.append(dict(family='F13-OP',budget=budget,model=model,scope=scope,metric=metric,numerator=int(num.sum()),denominator=int(den.sum()),estimate=ratio(num.sum(),den.sum())))
                for c in range(3):
                    for p in range(3): cms.append(dict(family='F13-OP',budget=budget,model=model,scope=scope,true_class=LABELS[c],predicted_class=LABELS[p],n=int(((y==c)&(final==p)).sum())))
            final=scopes['participant_majority']; mm=masks(y,final)
            nums=np.column_stack([v[0] for v in mm.values()]).astype(float);dens=np.column_stack([v[1] for v in mm.values()]).astype(float)
            nn=weights@nums;dd=weights@dens
            bs=np.divide(nn,dd,out=np.full_like(nn,np.nan),where=dd>0)
            estimates[model]=np.array([ratio(num.sum(),den.sum()) for num,den in mm.values()]);draws[model]=bs
            for j,(metric,(num,den)) in enumerate(mm.items()):
                valid=bs[np.isfinite(bs[:,j]),j];lo,hi=np.quantile(valid,[.025,.975]) if len(valid) else (np.nan,np.nan)
                intervals.append(dict(family='F13-OP',budget=budget,model=model,metric=metric,numerator=int(num.sum()),denominator=int(den.sum()),estimate=estimates[model][j],ci_low=lo,ci_high=hi,n_boot=NBOOT,finite_draws=len(valid)))
                for b in range(10):
                    ix=np.repeat(np.arange(len(y)),weights[b].astype(int));close(bs[b,j],ratio(num[ix].sum(),den[ix].sum()))
            decisions.append(pd.DataFrame(dict(participant_id=ids,y_true=y,budget=budget,model=model,final=final)))
        for j,metric in enumerate(mm):
            values=draws['voice'][:,j]-draws['baseline'][:,j];valid=values[np.isfinite(values)]
            lo,hi=np.quantile(valid,[.025,.975]) if len(valid) else (np.nan,np.nan)
            deltas.append(dict(family='F13-OP',budget=budget,metric=metric,difference=estimates['voice'][j]-estimates['baseline'][j],ci_low=lo,ci_high=hi,n_boot=NBOOT,finite_draws=len(valid)))
    csv('training_thresholds.csv',pd.concat(thresholds,ignore_index=True));csv('operating_points.csv',points);csv('confusion_matrices.csv',cms)
    csv('nominal_bootstrap_intervals.csv',intervals);csv('paired_voice_minus_baseline.csv',deltas)
    (OUT/'local_only').mkdir(exist_ok=True)
    pd.concat(decisions,ignore_index=True).to_parquet(OUT/'local_only/participant_decisions.parquet',index=False)
    verify()
    save_json(OUT/'COMPLETION.json',dict(status='AWAITING_INDEPENDENT_VERIFICATION',family='F13-OP',started_utc=started,completed_utc=stamp(),n_participants=750,
        models_refitted=False,start_memory=start_memory,end_memory=memory_status(),threshold_rows=210,operating_rows=len(points),confusion_cells=len(cms),bootstrap_rows=len(intervals),paired_rows=len(deltas),
        output_sha256={str(p.relative_to(OUT)):sha(p) for p in list(OUT.glob('*.csv'))+[OUT/'local_only/participant_decisions.parquet']}))
    (OUT/'REPORT.md').write_text('# Common training referral budgets\n\nPost hoc F13-OP under AR-48. Seven budgets (20% to 80% by 10 percentage points) were frozen before their held-out outcomes. Both procedures use the same budget in each outer training set, with thresholds estimated from their own selected inner-held-out scores. Ties are kept together without exceeding the training budget. The PD discrimination target remains 95% in training. Results are aggregate, participant-majority decisions and per-repeat decisions. Held-out and voted referral fractions need not equal the training budget. All budgets are reported; no winner is selected. Intervals condition on saved scores and training-derived thresholds, use paired class-stratified participant resampling and are pointwise exploratory, not multiplicity adjusted. There is no model refitting or clinical utility validation.\n\nSee CSVs for complete numerator/denominator results; independent verification pending.\n',encoding='utf-8')
    print('F13-OP completed; awaiting independent verification. Aggregate files only outside local_only.')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['freeze','gate','run','verify','selftest']);a=ap.parse_args()
    with threadpool_limits(1): globals()[a.action if a.action!='selftest' else 'selftests']()
if __name__=='__main__':main()
