# Pre-outcome implementation clarification 1
Recorded 2026-11-16 UTC in response to the independent verifier's request. This clarifies the already-frozen implementation without changing any calculation, input, model, contrast, or inference rule. No new matched-model outcome existed when this note was written. ANALYSIS_PLAN.md and matched_models.py remain unchanged under FROZEN_SPEC.json.

## Concatenation and numerical types
Use the order in the canonical feature_schemas.json lists throughout. A is the order of individual__timing_off after removing the three ASC names. T is the order of individual__timing_on after removing every name in individual__timing_off. ASC is age, sex_male, residence_country_USA.

- D: [ASC].
- DA: [ASC, A].
- DMT: [ASC, gain_mean, gain_sample_SD, T, microphone_one_hot].
- DMTA: [ASC, gain_mean, gain_sample_SD, T, microphone_one_hot, A].

The saved ASC, A and T blocks are retained as float32 before assembly. Gain summaries and one-hot columns are float64. Consequently D and DA are assembled as float32; DMT and DMTA are assembled as float64 by NumPy promotion. In all cases the initial Prep step explicitly copies the assembled matrix to float64. Preprocessing and logistic fitting thereafter use float64. The canonical standardization is followed by StandardScaler on the resulting training matrix, matching the demographic baseline's second standardization.

## Microphone mode and vocabulary
Trim populated microphone strings without lower-casing them; treat case-insensitive empty, n/a, na, nan, none and null tokens as missing. Within each task use the nonmissing exact-string mode, breaking count ties by ascending SHA256 hexadecimal digest of the UTF-8 string, then ascending exact string in the hypothetical hash-collision case. Apply the same mode/tie rule to the eleven task modes with equal task weight. Do not add a mixed-label or tie indicator.

For every inner fit and outer refit, estimate the missing-category fill from the modal participant-level category among that fitting sample. Learn the vocabulary from that fitting sample after applying its fill. Vocabulary/one-hot column order is ascending (SHA256 hexadecimal digest of UTF-8 exact string, exact string). Omit an empty token from the vocabulary. If the fitting sample has no populated category, the metadata categorical block has zero columns. Unseen held-out categories map to all-zero rows.

## Numeric gain and bootstrap order
Convert gain with pandas.to_numeric(errors='coerce'), nonfinite values to NaN. Within participant/task take the mean of finite recordings. In the canonical eleven-task order take numpy.nanmean and numpy.nanstd(ddof=1). Their columns are mean, then SD. No counts enter the design.

Bootstrap uses numpy.default_rng(20261116), draws each class in order 0/1/2 with rng.choice(class_indices,size=class_size,replace=True), concatenates the draws, and obtains weights with numpy.bincount(minlength=750). Every arm and endpoint uses that same draw. Class indices are ascending canonical-row positions.
