"""R15 post hoc matched ridge arms. Local data only; never edits canonical inputs."""
from __future__ import annotations
import argparse
import ast
from collections import Counter
import ctypes
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time
import warnings

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                 "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[variable] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
import joblib
import numpy as np
import pandas as pd
import scipy
from scipy.stats import t as student_t
import sklearn
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

OUT = Path(__file__).resolve().parent
ANALYSIS = Path(os.environ.get("PDCI_ANALYSIS_ROOT", str(OUT.parents[2]))).resolve()
CANON = ANALYSIS / "results/pdci_demographic_baseline_20260911"
RECORDING = Path(os.environ.get("PDCI_DATA_ROOT", str(ANALYSIS.parent))).resolve() / "phenotype/task/recording.tsv"
SOURCE = ANALYSIS / "src/pdci_demographic_baseline_20260911.py"
CONFIG = ANALYSIS / "src/config.py"
LOCAL = OUT / "local_only"
SEED, BOOT_SEED, B = 20260725, 20261116, 5000
ARMS = ("D", "DA", "DMT", "DMTA")
ENDPOINTS = ("screen", "stage2", "macro")
CONTRASTS = (("DA", "D"), ("DMTA", "DMT"))
GRID = [dict(c=c, weight=w) for c in (.01, .1, 1., 10.)
        for w in ("empirical", "balanced")]
TASKS = ("prolonged_vowel", "maximum_phonation_time", "loudness", "glides",
         "free_speech", "diadochokinesis", "picture_description", "breathing",
         "cough_respiration", "story_recall", "rainbow_passage")
ASC = ["age", "sex_male", "residence_country_USA"]
EXPECTED = {"primary": [.9549705157542685, .8204301075268817, .9144897690395921],
            "agesexcountry": [.94655430381975, .6874551971326165, .9166056511489344]}
MISSING = {"", "n/a", "na", "nan", "none", "null"}
PEAK_PRIVATE_BYTES = 0

def stamp():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()

def write_json(name, data, exclusive=False):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive and path.exists():
        raise RuntimeError("Refusing to overwrite existing immutable receipt: " + name)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False, default=str),
                   encoding="utf-8")
    os.replace(tmp, path)

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def versions():
    return dict(python=platform.python_version(), numpy=np.__version__,
                pandas=pd.__version__, scipy=scipy.__version__,
                scikit_learn=sklearn.__version__, joblib=joblib.__version__)

class MemoryStatus(ctypes.Structure):
    _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
        (k, ctypes.c_ulonglong) for k in ("total_phys", "avail_phys",
        "total_page", "avail_page", "total_virtual", "avail_virtual", "avail_ext")]

class ProcessMemory(ctypes.Structure):
    _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong)] + [
        (k, ctypes.c_size_t) for k in ("PeakWorkingSetSize", "WorkingSetSize",
        "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
        "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]

def memory():
    global PEAK_PRIVATE_BYTES
    m = MemoryStatus()
    m.length = ctypes.sizeof(m)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    p = ProcessMemory()
    p.cb = ctypes.sizeof(p)
    ctypes.windll.kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    get_memory = ctypes.windll.psapi.GetProcessMemoryInfo
    get_memory.argtypes = [ctypes.c_void_p, ctypes.POINTER(ProcessMemory), ctypes.c_ulong]
    get_memory.restype = ctypes.c_int
    assert get_memory(ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(p), p.cb)
    PEAK_PRIVATE_BYTES = max(PEAK_PRIVATE_BYTES, int(p.PrivateUsage))
    return dict(commit_headroom_GiB=m.avail_page/2**30,
                free_RAM_GiB=m.avail_phys/2**30,
                private_GiB=p.PrivateUsage/2**30,
                observed_peak_private_GiB=PEAK_PRIVATE_BYTES/2**30)

def memory_gate(start=False):
    m = memory()
    if m["private_GiB"] >= 1:
        raise RuntimeError("Private memory reached 1 GiB; preserve checkpoints and stop.")
    blocked = (m["commit_headroom_GiB"] < (5 if start else 3) or
               (start and m["free_RAM_GiB"] < .4))
    if blocked:
        print("PAUSE: memory gate; completed-fold checkpoints preserved.", flush=True)
    while blocked:
        write_json("RUN_STATUS.json", dict(status="PAUSED_MEMORY", at=stamp(), memory=m))
        time.sleep(15)
        m = memory()
        blocked = m["commit_headroom_GiB"] < 5 or m["free_RAM_GiB"] < .4
    return m

def ident(c):
    return "__".join(f"{key}-{value}" for key, value in c.items())

def norm_id(value):
    return str(value).strip().zfill(6)

def token(value):
    v = str(value).strip()
    return "" if v.casefold() in MISSING else v

def mode(values):
    counts = Counter(v for v in values if v)
    if not counts:
        return ""
    top = max(counts.values())
    return min((v for v in counts if counts[v] == top),
               key=lambda v: (hashlib.sha256(v.encode("utf-8")).hexdigest(), v))

def taxonomy():
    tree = ast.parse(CONFIG.read_text(encoding="utf-8-sig"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
                isinstance(x, ast.Name) and x.id == "TASK_GROUP_RULES" for x in node.targets):
            return [(re.compile(pattern), group) for pattern, group in ast.literal_eval(node.value)]
    raise AssertionError("Canonical task taxonomy not found.")

def task_group(name, rules):
    name = str(name).strip().lower().replace(" ", "-")
    for pattern, group in rules:
        if pattern.match(name):
            return group
    return "other"

class Prep:
    """Numerically match the original training-only ASC preprocessing."""
    def fit_transform(self, x):
        x = np.asarray(x, dtype=float).copy()
        x[~np.isfinite(x)] = np.nan
        self.available = np.mean(np.isfinite(x), axis=0) >= .5
        z = x[:, self.available]
        self.lo, self.hi = np.nanquantile(z, [.005, .995], axis=0)
        same = self.hi <= self.lo
        self.lo[same], self.hi[same] = -np.inf, np.inf
        z = np.clip(z, self.lo, self.hi)
        self.med = np.nanmedian(z, axis=0)
        z = np.where(np.isfinite(z), z, self.med)
        self.mean, self.sd = z.mean(axis=0), z.std(axis=0)
        self.vary = self.sd > 1e-8
        if not self.vary.any():
            raise ValueError("No nonconstant training predictors.")
        return (z-self.mean)[:, self.vary] / self.sd[self.vary]

    def transform(self, x):
        z = np.asarray(x, dtype=float)[:, self.available]
        z = np.where(np.isfinite(z), z, np.nan)
        z = np.clip(z, self.lo, self.hi)
        z = np.where(np.isfinite(z), z, self.med)
        return (z-self.mean)[:, self.vary] / self.sd[self.vary]

class Category:
    """Training-only imputation and vocabulary; unseen test labels become zero."""
    def fit(self, labels):
        self.fill = mode(labels)
        filled = [v or self.fill for v in labels]
        self.categories = sorted({v for v in filled if v},
                key=lambda v: (hashlib.sha256(v.encode("utf-8")).hexdigest(), v))
        return self

    def transform(self, labels):
        filled = np.asarray([v or self.fill for v in labels], dtype=object)
        return np.column_stack([filled == v for v in self.categories]).astype(float) \
               if self.categories else np.empty((len(filled), 0))

def metadata(ids):
    use = ["participant_id", "recording_name", "recording_microphone", "recording_input_gain"]
    rec = pd.read_csv(RECORDING, sep="\t", dtype=str, keep_default_na=False, usecols=use)
    rec["pid"] = rec.participant_id.map(norm_id)
    rec = rec[rec.pid.isin(ids)].copy()
    rules = taxonomy()
    rec["task"] = rec.recording_name.map(lambda n: task_group(n, rules))
    rec = rec[rec.task.isin(TASKS)].copy()
    rec["mic"] = rec.recording_microphone.map(token)
    rec["gain"] = pd.to_numeric(rec.recording_input_gain, errors="coerce")
    rec.loc[~np.isfinite(rec.gain), "gain"] = np.nan
    grouped = rec.groupby(["pid", "task"], sort=True)
    per_mic = grouped.mic.agg(lambda v: mode(v.tolist()))
    per_gain = grouped.gain.mean()
    index = pd.MultiIndex.from_product([ids, TASKS], names=["pid", "task"])
    assert set(per_mic.index) == set(index), "Metadata must cover the same 11 task families."
    per_mic = per_mic.reindex(index).to_numpy().reshape(len(ids), 11)
    per_gain = per_gain.reindex(index).to_numpy().reshape(len(ids), 11)
    cats = np.asarray([mode(row) for row in per_mic], dtype=object)
    nums = np.column_stack([np.nanmean(per_gain, axis=1), np.nanstd(per_gain, axis=1, ddof=1)])
    audit = dict(participants=len(ids), task_families=11, participant_task_pairs=len(index),
                 general_recording_rows=len(rec),
                 all_pairs_present=True, numeric_metadata_columns=2,
                 microphone_summary="mode within task; equal-task mode; SHA256 ties",
                 missing_numeric_cells=int(np.isnan(nums).sum()),
                 missing_microphone_summaries=int(sum(not v for v in cats)),
                 distinct_summary_categories=int(len(set(cats)-{""})),
                 raw_labels_or_identifiers_emitted=False)
    return nums, cats, audit

def load_data():
    payload = joblib.load(CANON/"local_only/input_payload.joblib")
    schema = read_json(CANON/"feature_schemas.json")
    ids = np.asarray([norm_id(v) for v in payload["ids"]])
    y = np.asarray(payload["y"], dtype=int)
    assert len(ids) == len(set(ids)) == 750
    assert np.bincount(y, minlength=3).tolist() == [598, 90, 62]
    assert schema["demographic_baseline"] == ASC
    off_names, on_names = schema["individual__timing_off"], schema["individual__timing_on"]
    assert len(off_names) == 5558 and len(on_names) == 5638
    a_names = [c for c in off_names if c not in ASC]
    t_names = [c for c in on_names if c not in off_names]
    assert len(a_names) == 5555 and len(t_names) == 80
    assert len(set(a_names)) == 5555 and not set(a_names) & set(t_names)
    assert all(c.startswith("task__") for c in a_names)
    assert all(c.startswith(("timing__", "dur_log__")) for c in t_names)
    prohibited = re.compile(r"participant|recording_id|session_id|diagnosis|cohort|n_recordings|task_presence|completion")
    assert not any(prohibited.search(c) for c in a_names+t_names+ASC)
    assert not any(c.startswith(("timing__", "dur_log__")) for c in a_names)
    ai = [off_names.index(c) for c in a_names]
    ti = [on_names.index(c) for c in t_names]
    xasc = np.array(payload["asc"], dtype=np.float32, copy=True)
    assert np.array_equal(xasc, payload["matrices"]["individual__timing_off"][:, -3:],
                          equal_nan=True)
    a = np.array(payload["matrices"]["individual__timing_off"][:, ai],
                 dtype=np.float32, copy=True)
    t = np.array(payload["matrices"]["individual__timing_on"][:, ti],
                 dtype=np.float32, copy=True)
    splits = [(np.array(tr, dtype=int), np.array(te, dtype=int)) for tr, te in payload["splits"]]
    del payload
    gc.collect()
    nums, cats, maudit = metadata(ids)
    return dict(ids=ids, y=y, asc=xasc, acoustic=a, timing=t, splits=splits,
                metadata_numeric=nums, microphone=cats, metadata_audit=maudit,
                a_names=a_names, t_names=t_names)

def design_pair(data, arm, tr, te):
    train, test = [data["asc"][tr]], [data["asc"][te]]
    category_width = 0
    if arm in ("DMT", "DMTA"):
        encoder = Category().fit(data["microphone"][tr])
        ca, cb = encoder.transform(data["microphone"][tr]), encoder.transform(data["microphone"][te])
        category_width = ca.shape[1]
        train += [data["metadata_numeric"][tr], data["timing"][tr], ca]
        test += [data["metadata_numeric"][te], data["timing"][te], cb]
    if arm in ("DA", "DMTA"):
        train.append(data["acoustic"][tr])
        test.append(data["acoustic"][te])
    x, z = np.column_stack(train), np.column_stack(test)
    prep = Prep()
    aa, bb = prep.fit_transform(x), prep.transform(z)
    scaler = StandardScaler()
    aa, bb = scaler.fit_transform(aa), scaler.transform(bb)
    assert np.isfinite(aa).all() and np.isfinite(bb).all()
    return aa, bb, dict(supplied_columns=x.shape[1],
                       retained_columns=aa.shape[1], category_columns=category_width)

def compose(s, q):
    s, q = np.clip(s, 1e-8, 1-1e-8), np.clip(q, 1e-8, 1-1e-8)
    return np.column_stack((1-s, s*q, s*(1-q)))

def metrics(y, s, q, p):
    cases = y > 0
    assert np.isfinite(s).all() and np.isfinite(q).all() and np.isfinite(p).all()
    assert np.allclose(p.sum(axis=1), 1, rtol=0, atol=1e-12)
    return dict(screen=float(roc_auc_score(cases, s)),
                stage2=float(roc_auc_score(y[cases] == 1, q[cases])),
                macro=float(roc_auc_score(y, p, multi_class="ovr", average="macro")))

def weighted_auc(y, score):
    order = np.argsort(score, kind="stable")
    starts = np.r_[0, np.flatnonzero(np.diff(np.asarray(score)[order]))+1]
    pos = np.asarray(y, dtype=bool)[order]
    def score_weights(weights):
        w = np.asarray(weights)[order]
        wp = np.add.reduceat(w*pos, starts)
        wn = np.add.reduceat(w*(~pos), starts)
        return float(np.dot(wp, np.cumsum(wn)-.5*wn)/(wp.sum()*wn.sum()))
    return score_weights

def bh(p):
    p = np.asarray(p, dtype=float)
    order = np.argsort(p, kind="stable")
    ranked = np.minimum.accumulate((p[order]*len(p)/np.arange(1, len(p)+1))[::-1])[::-1]
    ans = np.empty(len(p))
    ans[order] = np.minimum(1, ranked)
    return ans

def corrected(delta, ratio):
    delta = np.asarray(delta, dtype=float)
    mean = float(np.mean(delta))
    se = float(np.sqrt((1/len(delta)+np.mean(ratio))*np.var(delta, ddof=1)))
    p = float(2*student_t.sf(abs(mean/se), len(delta)-1)) if se else (0. if mean else 1.)
    radius = float(student_t.ppf(.975, len(delta)-1)*se)
    return dict(mean_fold_gain=mean, corrected_cv_se=se,
                corrected_cv95_low=mean-radius, corrected_cv95_high=mean+radius,
                corrected_cv_p=p, mean_test_train_ratio=float(np.mean(ratio)),
                df=len(delta)-1)

def tests():
    a = np.array([[1,np.nan,7,np.nan],[2,4,7,np.nan],
                  [3,6,7,np.nan],[4,8,7,np.nan]], dtype=float)
    prep = Prep()
    z = prep.fit_transform(a)
    assert z.shape == (4,2)
    before = (prep.med.copy(), prep.mean.copy(), prep.lo.copy(), prep.hi.copy())
    v = prep.transform(np.array([[np.nan, 1000, 7, 999], [-1000, 5, 7, np.nan]]))
    assert np.isfinite(v).all()
    assert all(np.array_equal(x,y) for x,y in zip(before, (prep.med,prep.mean,prep.lo,prep.hi)))
    assert np.allclose(v[0,0], (prep.med[0]-prep.mean[0])/prep.sd[0])
    assert mode(["b","a"]) == mode(["a","b"])
    assert mode(["b","b","a"]) == "b" and mode(["",""]) == ""
    cat = Category().fit(["a","a","b",""])
    assert cat.fill == "a" and cat.transform(["never-seen"]).sum() == 0
    assert np.array_equal(cat.transform([""])[0], cat.transform(["a"])[0])
    assert Category().fit(["",""]).transform([""]).shape == (1,0)
    yy = np.array([0,1,0,1,0,1])
    ss = np.array([.2,.4,.4,.8,.8,.9])
    ww = np.array([1,2,3,1,4,2])
    assert abs(weighted_auc(yy,ss)(ww)-roc_auc_score(yy,ss,sample_weight=ww)) < 1e-14
    assert abs(weighted_auc(yy,ss)(np.ones(6))-roc_auc_score(yy,ss)) < 1e-14
    assert np.allclose(bh([.01,.04,.03]), [.03,.04,.04])
    assert corrected(np.zeros(15), np.full(15,.25))["corrected_cv_p"] == 1
    assert corrected(np.full(15,.1), np.full(15,.25))["mean_fold_gain"] > 0
    p = compose(np.array([.1,.8,.9]),np.array([.2,.9,.1]))
    assert np.allclose(p.sum(axis=1),1)
    assert metrics(np.array([0,1,2]),p[:,1]+p[:,2],
                   np.array([.2,.9,.1]),p)["macro"] == 1
    return dict(status="PASS", training_only_preprocessing=True, missingness=True,
                stable_mode=True, fold_category_encoding=True, unseen_categories=True,
                weighted_auc_ties_and_weights=True, contrast_sign=True,
                composition_and_macro=True, BH_known_case=True, zero_difference_cv=True,
                tests_fit_no_classifiers=True)

def input_paths():
    files = [Path(__file__), OUT/"ANALYSIS_PLAN.md", SOURCE, CONFIG,
             CANON/"local_only/input_payload.joblib", CANON/"local_only/split_manifest.json",
             CANON/"local_only/participant_oof_predictions.parquet",
             CANON/"feature_schemas.json", CANON/"candidate_grid.json",
             CANON/"INPUT_AUDIT.json", CANON/"AUDIT.json", CANON/"COMPLETION.json",
             CANON/"FROZEN_SPEC.json", CANON/"pooled_oof_metrics.csv",
             RECORDING, RECORDING.with_suffix(".json")]
    for i in range(15):
        files += [CANON/f"local_only/folds/fold_{i:02d}.parquet",
                  CANON/f"local_only/folds/fold_{i:02d}.json"]
    return files

def freeze():
    assert not (OUT/"FROZEN_SPEC.json").exists(), "Already frozen; do not overwrite."
    assert not list(LOCAL.glob("*/fold_*.npz")), "Results exist before freeze."
    spec = dict(status="FROZEN_BEFORE_NEW_MODEL_FITS", created_utc=stamp(),
        family="F12-MM", authorization=["AR-46","AR-48"], seed=SEED, bootstrap_seed=BOOT_SEED,
        bootstrap_draws=B, arms=list(ARMS), endpoints=list(ENDPOINTS),
        contrasts=[dict(augmented=a,comparator=b) for a,b in CONTRASTS],
        grid=GRID, inner_margin=.005, multiplicity="exploratory_BH6",
        baseline_reproduction_tolerance=1e-9, canonical_pooled_metric_tolerance=1e-9,
        acoustic_columns=5555,timing_columns=80,demographic_columns=3,
        metadata_numeric_columns=2,metadata_vocabulary="fit within each training partition",
        expected_classifier_fits=3000, versions=versions(),
        memory_policy=dict(processes=1,BLAS_threads=1,start_headroom_GiB=5,
                           start_free_RAM_GiB=.4,pause_headroom_GiB=3,private_limit_GiB=1),
        private_checkpoints="Derived held-out scores without IDs; local_only, excluded from exports",
        inputs_sha256={str(p):sha(p) for p in input_paths()})
    write_json("FROZEN_SPEC.json", spec, exclusive=True)
    print("Frozen protocol, script, input hashes and versions; no new model fit.",flush=True)

def check_frozen():
    spec = read_json(OUT/"FROZEN_SPEC.json")
    for path, expected in spec["inputs_sha256"].items():
        assert sha(path) == expected, "Frozen file changed: "+path
    assert versions() == spec["versions"], "Software environment changed since freeze."
    assert GRID == spec["grid"]
    return spec

def preflight():
    check_frozen()
    memory_gate(start=True)
    test_receipt = tests()
    data = load_data()
    y, ids = data["y"], data["ids"]
    manifest = read_json(CANON/"local_only/split_manifest.json")
    assert [norm_id(v) for v in manifest["ids"]] == ids.tolist()
    regenerated = list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,
                       random_state=SEED).split(np.zeros(len(y)),y))
    assert len(data["splits"]) == 15
    cover = np.zeros((3,len(y)),dtype=int)
    inner_verified = 0
    for i, ((tr,te),(rr,ee)) in enumerate(zip(data["splits"],regenerated)):
        assert np.array_equal(tr,rr) and np.array_equal(te,ee)
        assert np.array_equal(tr,manifest["splits"][i]["train"])
        assert np.array_equal(te,manifest["splits"][i]["test"])
        assert len(set(tr)&set(te)) == 0 and len(tr)==600 and len(te)==150
        cover[i//5,te] += 1
        inner = list(StratifiedKFold(3,shuffle=True,random_state=SEED+1009*i)
                     .split(np.zeros(len(tr)), y[tr]))
        seen = np.zeros(len(tr),dtype=int)
        for it,iv in inner:
            train,valid = tr[it],tr[iv]
            assert set(train).isdisjoint(valid) and set(train).isdisjoint(te)
            assert set(valid).isdisjoint(te)
            seen[iv] += 1
            assert set(np.unique(y[train][y[train]>0])) == {1,2}
            assert set(np.unique(y[valid][y[valid]>0])) == {1,2}
            inner_verified += 1
        assert np.all(seen == 1)
        saved = pd.read_parquet(CANON/f"local_only/folds/fold_{i:02d}.parquet")
        assert [norm_id(v) for v in saved.participant_id] == ids[te].tolist()
        assert np.array_equal(saved.y_true.to_numpy(int), y[te])
    assert np.all(cover == 1)
    pooled = pd.read_parquet(CANON/"local_only/participant_oof_predictions.parquet")
    if "participant_id" in pooled.columns:
        pooled = pooled.set_index("participant_id")
    pooled.index = pooled.index.map(norm_id)
    assert pooled.index.is_unique and set(pooled.index) == set(ids)
    pooled = pooled.reindex(ids)
    assert np.array_equal(pooled.y_true.to_numpy(int),y)
    aggregate = pd.read_csv(CANON/"pooled_oof_metrics.csv").set_index("model")
    reproduced = []
    for arm in ("primary","agesexcountry"):
        actual = metrics(y,pooled[arm+"_screen"].to_numpy(),pooled[arm+"_q"].to_numpy(),
                         pooled[[arm+"_p"+str(c) for c in range(3)]].to_numpy())
        for j,ep in enumerate(ENDPOINTS):
            expected = float(aggregate.loc[arm,ep])
            assert abs(expected-EXPECTED[arm][j]) < 1e-12
            assert abs(actual[ep]-expected) <= 1e-9
            reproduced.append(dict(model=arm,endpoint=ep,observed=actual[ep],
                                   expected=expected,absolute_difference=abs(actual[ep]-expected)))
    assert read_json(CANON/"candidate_grid.json")["baseline"] == GRID
    test_receipt.update(exact_outer_partitions=15,exact_inner_partitions=inner_verified,
                        participant_grouping=True,feature_block_disjointness=True,
                        prohibited_features_absent=True)
    write_json("TESTS.json",test_receipt,exclusive=True)
    write_json("DATA_AUDIT.json",dict(status="PASS",n=750,class_counts=[598,90,62],
        acoustic_columns=5555,timing_columns=80,demographic_columns=ASC,
        metadata=data["metadata_audit"],
        retained_design_bytes=int(sum(data[k].nbytes for k in
            ("asc","acoustic","timing","metadata_numeric"))),
        no_new_feature_extraction=True,no_new_results=True,memory=memory()),exclusive=True)
    write_json("GATE.json",dict(status="PASS",created_utc=stamp(),
        frozen_spec_sha256=sha(OUT/"FROZEN_SPEC.json"),class_counts=[598,90,62],
        outer_partitions=15,inner_partitions=45,test_appearances_per_repeat=1,
        all_task_pairs_present=True,six_canonical_pooled_AUROCs=reproduced,
        no_classifiers_fit=True,baseline_refit_gate_still_required=True),exclusive=True)
    print("PASS: prefit canonical gate, six original AUROCs, all splits and leakage guards.",flush=True)

def select(y,bank):
    scores = {ident(c):float(roc_auc_score(y,bank[ident(c)])) for c in GRID}
    best = max(scores.values())
    eligible = [c for c in GRID if scores[ident(c)] >= best-.005]
    pick = min(eligible,key=lambda c:(c["c"],int(c["weight"]!="empirical"),ident(c)))
    return dict(pick),scores

def ridge_pair(a,y,b,cfg):
    memory_gate()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        estimator = LogisticRegression(C=cfg["c"],penalty="l2",solver="lbfgs",
            max_iter=5000,tol=1e-4,class_weight="balanced" if cfg["weight"]=="balanced" else None,
            random_state=SEED)
        estimator.fit(a,y)
    if any(issubclass(w.category,ConvergenceWarning) for w in caught):
        raise RuntimeError("Convergence failure; frozen grid not altered.")
    assert estimator.classes_.tolist() == [0,1]
    return np.clip(estimator.predict_proba(b)[:,1],1e-8,1-1e-8), int(estimator.n_iter_.max())

def fit_fold(data,arm,outer):
    prefix = f"local_only/{arm}/fold_{outer:02d}"
    npz_path, json_path = OUT/(prefix+".npz"), OUT/(prefix+".json")
    spec_hash = sha(OUT/"FROZEN_SPEC.json")
    if json_path.exists():
        receipt = read_json(json_path)
        assert receipt["frozen_spec_sha256"] == spec_hash
        assert sha(npz_path) == receipt["checkpoint_sha256"]
        return receipt
    if npz_path.exists():
        raise RuntimeError("Uncommitted checkpoint requires explicit recovery: "+prefix)
    started = time.monotonic()
    y = data["y"]
    tr,te = data["splits"][outer]
    inner = list(StratifiedKFold(3,shuffle=True,random_state=SEED+1009*outer)
                 .split(np.zeros(len(tr)),y[tr]))
    bank = {stage:{ident(c):np.full(len(tr),np.nan) for c in GRID}
            for stage in ("screen","stage2")}
    max_iter_seen = 0
    width_audit = []
    for ii,(it,iv) in enumerate(inner):
        for stage in ("screen","stage2"):
            train,valid,local_valid = tr[it],tr[iv],iv
            if stage == "stage2":
                train = train[y[train]>0]
                keep = y[valid]>0
                valid,local_valid = valid[keep],local_valid[keep]
            assert set(train).isdisjoint(valid) and set(train).isdisjoint(te)
            target = (y[train]>0).astype(int) if stage=="screen" else (y[train]==1).astype(int)
            a,b,width = design_pair(data,arm,train,valid)
            for cfg in GRID:
                probs,niter = ridge_pair(a,target,b,cfg)
                bank[stage][ident(cfg)][local_valid] = probs
                max_iter_seen = max(max_iter_seen,niter)
            width_audit.append(dict(inner_fold=ii,stage=stage,**width))
            del a,b
    choices,scores,outer_width,predictions = {},{},{},{}
    for stage in ("screen","stage2"):
        choose_rows = np.ones(len(tr),dtype=bool) if stage=="screen" else y[tr]>0
        target = (y[tr][choose_rows]>0).astype(int) if stage=="screen" else (y[tr][choose_rows]==1).astype(int)
        used = {k:v[choose_rows] for k,v in bank[stage].items()}
        assert all(np.isfinite(v).all() for v in used.values())
        cfg,score = select(target,used)
        choices[stage],scores[stage] = cfg,score
        train = tr if stage=="screen" else tr[y[tr]>0]
        target = (y[train]>0).astype(int) if stage=="screen" else (y[train]==1).astype(int)
        a,b,width = design_pair(data,arm,train,te)
        preds,niter = ridge_pair(a,target,b,cfg)
        max_iter_seen = max(max_iter_seen,niter)
        predictions[stage],outer_width[stage] = preds,width
        del a,b
    s,q = predictions["screen"],predictions["stage2"]
    p = compose(s,q)
    assert len(s)==len(q)==len(te)
    npz_path.parent.mkdir(parents=True,exist_ok=True)
    tmp = npz_path.with_suffix(".tmp")
    with tmp.open("wb") as handle:
        np.savez_compressed(handle,s=s,q=q,p=p)
    os.replace(tmp,npz_path)
    receipt = dict(status="COMPLETE",arm=arm,outer_fold=outer,repeat=outer//5,
        fold=outer%5,frozen_spec_sha256=spec_hash,checkpoint_sha256=sha(npz_path),
        choices=choices,inner_scores=scores,inner_widths=width_audit,outer_widths=outer_width,
        train_n=len(tr),test_n=len(te),train_cases=int(sum(y[tr]>0)),
        test_cases=int(sum(y[te]>0)),max_logistic_iterations=max_iter_seen,
        classifier_fits=50,elapsed_seconds=time.monotonic()-started,
        completed_utc=stamp(),memory=memory(),checkpoint_contains_identifiers=False)
    write_json(prefix+".json",receipt,exclusive=True)
    write_json("RUN_STATUS.json",dict(status="RUNNING",last_completed_arm=arm,
        last_completed_outer_fold=outer,at=stamp(),memory=memory()))
    print(f"COMPLETE {arm} outer {outer+1}/15 ({receipt['elapsed_seconds']:.1f}s)",flush=True)
    return receipt

def baseline_gate(data):
    errors,choice_checks = [],0
    for outer,(tr,te) in enumerate(data["splits"]):
        fit_fold(data,"D",outer)
        expected = pd.read_parquet(CANON/f"local_only/folds/fold_{outer:02d}.parquet")
        old = read_json(CANON/f"local_only/folds/fold_{outer:02d}.json")
        rec = read_json(LOCAL/f"D/fold_{outer:02d}.json")
        with np.load(LOCAL/f"D/fold_{outer:02d}.npz") as got:
            for key,cols in (("s",["agesexcountry_screen"]),("q",["agesexcountry_q"]),
                             ("p",[f"agesexcountry_p{i}" for i in range(3)])):
                wanted = expected[cols].to_numpy()
                if len(cols)==1:
                    wanted = wanted[:,0]
                error = float(np.max(np.abs(got[key]-wanted)))
                errors.append(error)
                assert error <= 1e-9, f"Canonical baseline reproduction failed: fold {outer}, score {key}."
        for stage in ("screen","stage2"):
            assert rec["choices"][stage] == old["choices"]["asc_"+stage]
            choice_checks += 1
    result = dict(status="PASS",created_utc=stamp(),max_absolute_prediction_difference=max(errors),
        probability_arrays_compared=45,selected_candidates_matched=choice_checks,
        outer_folds=15,classifier_fits=750,tolerance=1e-9,
        frozen_spec_sha256=sha(OUT/"FROZEN_SPEC.json"),
        new_augmented_models_not_started=True)
    if (OUT/"BASELINE_REPRODUCTION_GATE.json").exists():
        prior=read_json(OUT/"BASELINE_REPRODUCTION_GATE.json")
        assert prior["status"]=="PASS" and prior["frozen_spec_sha256"]==result["frozen_spec_sha256"]
    else:
        write_json("BASELINE_REPRODUCTION_GATE.json",result,exclusive=True)
    print(f"PASS: baseline reproduced; maximum score difference {max(errors):.3g}.",flush=True)

def collect(data):
    y=data["y"]
    all_predictions,fold_rows,repeat_rows,selections = {},[],[],[]
    for arm in ARMS:
        s=np.full((3,750),np.nan)
        q=np.full((3,750),np.nan)
        p=np.full((3,750,3),np.nan)
        for outer,(tr,te) in enumerate(data["splits"]):
            receipt=read_json(LOCAL/f"{arm}/fold_{outer:02d}.json")
            checkpoint=LOCAL/f"{arm}/fold_{outer:02d}.npz"
            assert sha(checkpoint)==receipt["checkpoint_sha256"]
            with np.load(checkpoint) as z:
                s[outer//5,te],q[outer//5,te],p[outer//5,te] = z["s"],z["q"],z["p"]
                mm=metrics(y[te],z["s"],z["q"],z["p"])
            fold_rows.append(dict(arm=arm,outer_fold=outer,repeat=outer//5,fold=outer%5,
                train_n=len(tr),test_n=len(te),train_cases=int(sum(y[tr]>0)),
                test_cases=int(sum(y[te]>0)),**mm))
            for stage in ("screen","stage2"):
                cfg=receipt["choices"][stage]
                selections.append(dict(arm=arm,outer_fold=outer,stage=stage,**cfg,
                    selected_inner_auc=receipt["inner_scores"][stage][ident(cfg)],
                    **receipt["outer_widths"][stage]))
        assert np.isfinite(s).all() and np.isfinite(q).all() and np.isfinite(p).all()
        for repeat in range(3):
            repeat_rows.append(dict(arm=arm,repeat=repeat,**metrics(y,s[repeat],q[repeat],p[repeat])))
        all_predictions[arm]=dict(s=s.mean(axis=0),q=q.mean(axis=0),p=p.mean(axis=0))
    return all_predictions,pd.DataFrame(fold_rows),pd.DataFrame(repeat_rows),pd.DataFrame(selections)

def summarize(data):
    predictions,folds,repeats,selections=collect(data)
    y=data["y"]
    point={a:metrics(y,**predictions[a]) for a in ARMS}
    case=y>0
    funcs={}
    for arm,pr in predictions.items():
        funcs[arm]=dict(screen=weighted_auc(y>0,pr["s"]),
                       stage2=weighted_auc(y[case]==1,pr["q"][case]),
                       macro=[weighted_auc(y==c,pr["p"][:,c]) for c in range(3)])
    indices=[np.flatnonzero(y==c) for c in range(3)]
    rng=np.random.default_rng(BOOT_SEED)
    dist=np.empty((B,len(ARMS),3))
    for draw in range(B):
        if draw%250==0:
            memory_gate()
        sampled=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in indices])
        weights=np.bincount(sampled,minlength=len(y))
        for ai,arm in enumerate(ARMS):
            f=funcs[arm]
            dist[draw,ai,0]=f["screen"](weights)
            dist[draw,ai,1]=f["stage2"](weights[case])
            dist[draw,ai,2]=np.mean([g(weights) for g in f["macro"]])
    arm_rows=[]
    for ai,arm in enumerate(ARMS):
        for ei,endpoint in enumerate(ENDPOINTS):
            lo,hi=np.quantile(dist[:,ai,ei],[.025,.975])
            arm_rows.append(dict(family="F12-MM",arm=arm,endpoint=endpoint,
                n=152 if endpoint=="stage2" else 750,AUROC=point[arm][endpoint],
                nominal_fixed_prediction95_low=float(lo),nominal_fixed_prediction95_high=float(hi)))
    comparisons=[]
    for augmented,comparator in CONTRASTS:
        aa=folds[folds.arm==augmented].sort_values("outer_fold")
        bb=folds[folds.arm==comparator].sort_values("outer_fold")
        assert aa.outer_fold.tolist()==bb.outer_fold.tolist()==list(range(15))
        for ei,endpoint in enumerate(ENDPOINTS):
            delta=dist[:,ARMS.index(augmented),ei]-dist[:,ARMS.index(comparator),ei]
            lo,hi=np.quantile(delta,[.025,.975])
            ratio=(aa.test_cases/aa.train_cases).to_numpy() if endpoint=="stage2" else (aa.test_n/aa.train_n).to_numpy()
            cv=corrected(aa[endpoint].to_numpy()-bb[endpoint].to_numpy(),ratio)
            comparisons.append(dict(family="F12-MM",augmented=augmented,comparator=comparator,
                endpoint=endpoint,augmented_AUROC=point[augmented][endpoint],
                comparator_AUROC=point[comparator][endpoint],
                pooled_AUROC_gain=point[augmented][endpoint]-point[comparator][endpoint],
                nominal_fixed_prediction95_low=float(lo),nominal_fixed_prediction95_high=float(hi),
                bootstrap_draws=B,bootstrap_seed=BOOT_SEED,**cv))
    comparisons=pd.DataFrame(comparisons)
    comparisons["exploratory_BH6_q"]=bh(comparisons.corrected_cv_p)
    pd.DataFrame(arm_rows).to_csv(OUT/"arm_metrics.csv",index=False)
    comparisons.to_csv(OUT/"paired_comparisons.csv",index=False)
    folds.to_csv(OUT/"fold_metrics.csv",index=False)
    repeats.to_csv(OUT/"repeat_metrics.csv",index=False)
    selections.to_csv(OUT/"selected_candidates.csv",index=False)
    lines=["# R15 matched-model incremental acoustics",
        "Post hoc reviewer-requested family F12-MM; authority AR-46/AR-48.",
        "",
        "The 750-participant cohort and all 15 original outer folds were retained. All four arms used the same eight ridge candidates, preprocessing and inner partitions. The lead endpoint is conditional PD-versus-CI discrimination in 152 cases. Added-model results are separate from the original primary procedure and BH3.",
        "",
        "| Contrast | Endpoint | Augmented AUROC | Comparator AUROC | Pooled gain (nominal 95% interval) | Mean-fold gain | Corrected-CV p | Exploratory BH6 q |",
        "|---|---|---:|---:|---|---:|---:|---:|"]
    for _,r in comparisons.iterrows():
        lines.append(f"| {r.augmented} minus {r.comparator} | {r.endpoint} | {r.augmented_AUROC:.4f} | {r.comparator_AUROC:.4f} | {r.pooled_AUROC_gain:+.4f} ({r.nominal_fixed_prediction95_low:+.4f}, {r.nominal_fixed_prediction95_high:+.4f}) | {r.mean_fold_gain:+.4f} | {r.corrected_cv_p:.4f} | {r.exploratory_BH6_q:.4f} |")
    lines += ["","D = age/sex/country; A = 5,555 fixed task-specific acoustic columns excluding the explicit duration/frame-count block; M = training-encoded microphone summary and two gain summaries; T = 80 explicit timing columns.",
        "",
        "The 5,000 paired class-stratified participant bootstrap intervals hold predictions fixed and are not adjusted for multiplicity. Corrected repeated-CV intervals and exploratory BH6 values address separate mean-fold estimands. The original BH3 values are unchanged. A null or imprecise contrast is not an equivalence result.",
        "",
        "Canonical pooled metrics, cohort and partitions passed the prefit gate. Refitted D predictions and all 30 selected baseline candidates passed the canonical reproduction gate before any augmented fit. Numerical results await the parent's independent protocol-based reimplementation and scientific interpretation.",
        "",
        "No clinical fields, counts, completion indicators or missingness indicators were predictors. Recorded microphone labels and gain settings are metadata summaries, not verification of common physical hardware or a controlled acquisition setting. Source fields not available in the audited metadata were not imputed from diagnoses or country.",
        "",
        "Private score checkpoints under local_only are new restricted derived files, contain no IDs, and must never enter Library, code-release or publication archives. All manuscript-facing tables and receipts contain aggregates only. No data were uploaded and no original result, manuscript or source file was modified.",
        "",
        "Material qualifiers for author review (AR-05): this comparison was specified after historical results were known; it evaluates a single fixed ridge family; bootstrap intervals omit retraining uncertainty; corrected-CV inference is approximate; metadata modes summarize mixed recorded labels; this is internal evaluation, not causal or external validation.",
        "",
        "Independent verification status: pending. See FROZEN_SPEC.json, TESTS.json, DATA_AUDIT.json, GATE.json, BASELINE_REPRODUCTION_GATE.json, and COMPLETION.json."]
    (OUT/"REPORT.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return comparisons

def run():
    started=stamp()
    wall=time.monotonic()
    check_frozen()
    assert not (OUT/"COMPLETION.json").exists(),"Already complete; do not overwrite."
    gate=read_json(OUT/"GATE.json")
    assert gate["status"]=="PASS" and gate["frozen_spec_sha256"]==sha(OUT/"FROZEN_SPEC.json")
    memory_gate(start=True)
    data=load_data()
    with threadpool_limits(1):
        baseline_gate(data)
        for arm in ARMS[1:]:
            for outer in range(15):
                fit_fold(data,arm,outer)
        summarize(data)
    check_frozen()
    aggregate=["arm_metrics.csv","paired_comparisons.csv","fold_metrics.csv",
               "repeat_metrics.csv","selected_candidates.csv","REPORT.md",
               "GATE.json","BASELINE_REPRODUCTION_GATE.json","TESTS.json","DATA_AUDIT.json"]
    checkpoints=sorted(LOCAL.glob("*/fold_*.npz"))
    receipt=dict(status="COMPLETE_AWAITING_INDEPENDENT_REPLICATION",family="F12-MM",
        started_utc=started,completed_utc=stamp(),elapsed_seconds=time.monotonic()-wall,
        participants=750,class_counts=[598,90,62],outer_partitions=15,arms=4,
        stage_fits_per_arm_fold=2,classifier_fits=3000,bootstrap_draws=B,
        comparisons=6,original_BH3_unchanged=True,canonical_baseline_gate="PASS",
        no_original_writes=True,all_frozen_input_hashes_unchanged=True,
        public_outputs_aggregate_only=True,private_checkpoints_export_prohibited=True,
        versions=versions(),memory=memory(),frozen_spec_sha256=sha(OUT/"FROZEN_SPEC.json"),
        aggregate_outputs_sha256={p:sha(OUT/p) for p in aggregate},
        local_checkpoint_sha256={str(p.relative_to(OUT)):sha(p) for p in checkpoints})
    write_json("COMPLETION.json",receipt,exclusive=True)
    write_json("RUN_STATUS.json",dict(status=receipt["status"],at=stamp(),memory=memory()))
    print("COMPLETE: 60 arm-folds, six contrasts, aggregate tables; independent replication pending.",flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=["freeze","preflight","run","selftest"])
    args=parser.parse_args()
    if args.command=="freeze":
        freeze()
    elif args.command=="preflight":
        preflight()
    elif args.command=="selftest":
        print(json.dumps(tests(),indent=2))
    else:
        run()

if __name__=="__main__":
    try:
        main()
    except Exception as error:
        # No raw data, label strings or participant values enter console or failure receipts.
        write_json("FAILURE.json",dict(status="STOPPED",at=stamp(),
            error_type=type(error).__name__,message=str(error),
            completed_checkpoints=len(list(LOCAL.glob("*/fold_*.json")))))
        raise
