"""Independent F13-OP reconstruction from frozen protocol, no owner imports."""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import time
from datetime import datetime,timezone

for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[k]="1"
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold

OUT=Path(__file__).resolve().parent
ROUND=OUT.parents[1]
ANALYSIS=Path(os.environ.get("PDCI_ANALYSIS_ROOT",str(ROUND.parents[1]))).resolve()
OWNER=ROUND/"operating_points"
CANON=ANALYSIS/"results/pdci_demographic_baseline_20260911"
A5=ANALYSIS/"results/pdci_a5_matched_policy_20261001"
BUDGETS=[.2,.3,.4,.5,.6,.7,.8]
MODELS=["voice","baseline"]
NBOOT=5000
SEED=20261116
CLASS={"Neither":0,"PD":1,"CI":2}
METRICS=["referral_fraction","case_screening_sensitivity","PD_screening_sensitivity",
         "CI_screening_sensitivity","neither_specificity","PD_end_to_end_sensitivity",
         "CI_end_to_end_sensitivity","PD_assignment_PPV","CI_assignment_PPV",
         "CI_to_PD","PD_to_CI","correct_case_assignment"]
COLS={"voice":("primary_screen","primary_q","screen","stage2"),
      "baseline":("agesexcountry_screen","agesexcountry_q","asc_screen","asc_stage2")}

def digest(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def js(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def save_json(name,data):
    path=OUT/name
    if path.exists():
        raise RuntimeError("Refusing overwrite: "+name)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,allow_nan=False),encoding="utf-8")

def now():
    return datetime.now(timezone.utc).isoformat()

def version_info():
    return dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                scipy=scipy.__version__,sklearn=sklearn.__version__)

class Status(ctypes.Structure):
    _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[
        (k,ctypes.c_ulonglong) for k in ("total","available","limit","headroom",
        "total_virtual","available_virtual","reserved")]

def check_memory(initial=False):
    value=Status()
    value.length=ctypes.sizeof(value)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value))
    threshold=5 if initial else 3
    while value.headroom/2**30<threshold or (initial and value.available/2**30<.4):
        print("PAUSED at memory gate; no new numerical batch.",flush=True)
        time.sleep(15)
        assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value))
        threshold=5
        initial=True
    return dict(commit_headroom_GiB=value.headroom/2**30,free_RAM_GiB=value.available/2**30)

def normalize(value):
    return str(value).strip().zfill(6)

def budget_cutoff(scores,budget):
    scores=np.asarray(scores,float)
    if scores.ndim!=1 or not len(scores) or not np.isfinite(scores).all():
        raise ValueError("Budget cutoff requires a nonempty finite vector.")
    if not 0<=budget<=1:
        raise ValueError("Budget outside zero to one.")
    limit=math.floor(budget*len(scores))
    values,counts=np.unique(scores,return_counts=True)
    referred=np.cumsum(counts[::-1])[::-1]
    usable=np.flatnonzero(referred<=limit)
    if len(usable):
        cut=float(values[usable[0]])
    else:
        cut=float(np.nextafter(values[-1],np.inf))
    attained=int(np.sum(scores>=cut))
    assert attained<=limit
    return cut,limit,attained

def sensitivity_cutoff(scores,target):
    positive=np.asarray(scores,float)
    if positive.ndim!=1 or not len(positive) or not np.isfinite(positive).all():
        raise ValueError("Sensitivity cutoff requires populated finite positive scores.")
    if not 0<target<=1:
        raise ValueError("Sensitivity target outside zero to one.")
    values=np.unique(positive)
    satisfying=[v for v in values if np.sum(positive>=v)/len(positive)>=target]
    return float(max(satisfying))

def majority(refers,pd_votes):
    refers=np.asarray(refers,bool)
    pd_votes=np.asarray(pd_votes,bool)
    assert refers.shape==pd_votes.shape and refers.shape[0]==3
    referred=refers.sum(axis=0)
    pd=(refers&pd_votes).sum(axis=0)
    return np.where(referred>=2,np.where(2*pd>=referred,1,2),0).astype(np.int8)

def cmatrix(y,calls,weights=None):
    if weights is None:
        weights=np.ones(len(y),dtype=int)
    return np.bincount(3*np.asarray(y,int)+np.asarray(calls,int),
                       weights=weights,minlength=9).reshape(3,3)

def quantities(cm):
    actual=cm.sum(axis=1)
    assigned=cm.sum(axis=0)
    total=actual.sum()
    case=actual[1]+actual[2]
    num=np.asarray([assigned[1]+assigned[2],
        cm[1:,1:].sum(),cm[1,1:].sum(),cm[2,1:].sum(),
        cm[0,0],cm[1,1],cm[2,2],cm[1,1],cm[2,2],
        cm[2,1],cm[1,2],cm[1,1]+cm[2,2]],float)
    den=np.asarray([total,case,actual[1],actual[2],actual[0],
        actual[1],actual[2],assigned[1],assigned[2],actual[2],actual[1],case],float)
    value=np.divide(num,den,out=np.full(len(METRICS),np.nan),where=den>0)
    return num,den,value

def hand_tests():
    cut,cap,n=budget_cutoff([.1,.4,.4,.9],.5)
    assert cut==.9 and cap==2 and n==1
    cut,_,n=budget_cutoff([.1,.4,.4,.9],1)
    assert cut==.1 and n==4
    cut,_,n=budget_cutoff([.1,.4,.4,.9],0)
    assert cut>.9 and n==0
    assert np.sum(np.array([.1,.4,.4,.9])>=.4)==3
    assert sensitivity_cutoff([.1,.2,.2,.9],.75)==.2
    for bad in ([],[.1,np.nan],[np.inf]):
        try:
            budget_cutoff(bad,.5)
        except ValueError:
            pass
        else:
            raise AssertionError("Nonfinite/empty guard failed.")
    refs=np.array([[1,1,1,0],[1,1,1,1],[0,1,0,0]],bool)
    pv=np.array([[1,1,0,0],[0,0,0,1],[1,1,1,0]],bool)
    assert majority(refs,pv).tolist()==[1,1,2,0]
    y=np.array([0,1,2])
    base=quantities(cmatrix(y,[0,0,0]))[2]
    voice=quantities(cmatrix(y,[0,1,2]))[2]
    idx=METRICS.index("correct_case_assignment")
    assert voice[idx]-base[idx]==1 and base[idx]-voice[idx]==-1
    assert np.isnan(base[METRICS.index("PD_assignment_PPV")])
    assert voice[METRICS.index("PD_assignment_PPV")]==1
    return dict(status="PASS",tied_budget=True,budget_boundaries=True,threshold_inclusion=True,
        empty_and_nonfinite_guard=True,vote_and_PD_tie=True,undefined_denominator=True,
        positive_and_negative_paired_sign=True)

def frozen():
    spec=js(OUT/"FROZEN_SPEC.json")
    for path,sha in spec["inputs_sha256"].items():
        assert digest(path)==sha,"Frozen input changed."
    assert version_info()==spec["versions"]
    return spec

def load_inputs():
    manifest=js(CANON/"local_only/split_manifest.json")
    ids=[normalize(x) for x in manifest["ids"]]
    assert len(ids)==len(set(ids))==750
    splits=[(np.asarray(x["train"],int),np.asarray(x["test"],int)) for x in manifest["splits"]]
    assert len(splits)==15
    outer=[]
    y=np.full(750,-1,dtype=int)
    seen=np.zeros((3,750),dtype=int)
    for i,(tr,te) in enumerate(splits):
        assert len(tr)==600 and len(te)==150 and set(tr).isdisjoint(te)
        frame=pd.read_parquet(CANON/f"local_only/folds/fold_{i:02d}.parquet")
        assert [normalize(x) for x in frame.participant_id]==[ids[j] for j in te]
        yy=frame.y_true.to_numpy(int)
        known=y[te]>=0
        assert np.array_equal(y[te][known],yy[known])
        y[te]=yy
        seen[i//5,te]+=1
        original=js(CANON/f"local_only/folds/fold_{i:02d}.json")
        assert digest(CANON/f"local_only/folds/fold_{i:02d}.parquet")==original["prediction_sha256"]
        outer.append(frame)
    assert np.all(seen==1) and np.bincount(y).tolist()==[598,90,62]
    canonical=list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=20260725)
                   .split(np.zeros(750),y))
    for got,expected in zip(splits,canonical):
        assert all(np.array_equal(a,b) for a,b in zip(got,expected))
    inner=[]
    for i,(tr,te) in enumerate(splits):
        frame=pd.read_parquet(CANON/f"local_only/folds/fold_{i:02d}_selected_inner.parquet")
        assert [normalize(x) for x in frame.participant_id]==[ids[j] for j in tr]
        assert np.array_equal(frame.y_true.to_numpy(int),y[tr])
        inner.append(frame)
    return dict(ids=ids,y=y,splits=splits,outer=outer,inner=inner)

def original_gate(data):
    y=data["y"]
    nmatch=0
    point=js(OWNER/"FROZEN_SPEC.json")
    assert point["budgets"]==BUDGETS and point["seed"]==SEED and point["n_boot"]==NBOOT
    saved=pd.read_parquet(CANON/"local_only/participant_oof_predictions.parquet")
    if "participant_id" in saved.columns:
        saved=saved.set_index("participant_id")
    saved.index=saved.index.map(normalize)
    saved=saved.reindex(data["ids"])
    assert np.array_equal(saved.y_true.to_numpy(int),y)
    published=pd.read_csv(CANON/"pooled_oof_metrics.csv").set_index("model")
    auc_differences=[]
    for prefix in ("primary","agesexcountry"):
        s=saved[prefix+"_screen"].to_numpy()
        q=saved[prefix+"_q"].to_numpy()
        p=saved[[prefix+"_p"+str(j) for j in range(3)]].to_numpy()
        computed=[roc_auc_score(y>0,s),roc_auc_score(y[y>0]==1,q[y>0]),
                  roc_auc_score(y,p,multi_class="ovr",average="macro")]
        for ep,value in zip(("screen","stage2","macro"),computed):
            d=abs(float(value)-float(published.loc[prefix,ep]))
            assert d<=1e-12
            auc_differences.append(d)
    references=pd.read_csv(A5/"training_thresholds.csv")
    references=references[references.policy=="separate98_pd95"]
    oldcalls={}
    differences=[]
    for model in MODELS:
        out_s,out_q,in_s,in_q=COLS[model]
        ref=np.zeros((3,750),bool)
        votes=np.zeros((3,750),bool)
        repeated=np.zeros((3,750),np.int8)
        for i,(tr,te) in enumerate(data["splits"]):
            inner,outer=data["inner"][i],data["outer"][i]
            yy=y[tr]
            scut=min(sensitivity_cutoff(inner.loc[yy==1,in_s],.98),
                     sensitivity_cutoff(inner.loc[yy==2,in_s],.98))
            qcut=sensitivity_cutoff(inner.loc[yy==1,in_q],.95)
            row=references[(references.model==model)&(references.outer_fold==i)]
            assert len(row)==1
            for column,value in (("screen_threshold",scut),("pd_threshold",qcut)):
                difference=abs(float(row.iloc[0][column])-value)
                assert difference<=1e-12
                differences.append(difference)
            rr=outer[out_s].to_numpy()>=scut
            pp=outer[out_q].to_numpy()>=qcut
            ref[i//5,te],votes[i//5,te]=rr,pp
            repeated[i//5,te]=np.where(rr,np.where(pp,1,2),0)
        oldcalls[model]={"participant_majority":majority(ref,votes),
                        **{f"repeat_{r}":repeated[r] for r in range(3)}}
    matrices=pd.read_csv(A5/"confusion_matrices.csv")
    matrices=matrices[matrices.policy=="separate98_pd95"]
    for row in matrices.itertuples():
        matrix=cmatrix(y,oldcalls[row.model][row.scope])
        assert matrix[CLASS[row.true_class],CLASS[row.predicted_class]]==row.n
        nmatch+=1
    assert len(differences)==60 and nmatch==72
    result=dict(status="PASS",at=now(),cohort=[598,90,62],outer_partitions=15,
        test_appearances_per_participant=3,canonical_AUROCs=6,
        maximum_AUROC_difference=max(auc_differences),matched_thresholds=60,
        maximum_threshold_difference=max(differences),matched_confusion_cells=nmatch,
        no_new_budget_outcomes_before_gate=True,owner_code_read=False)
    save_json("GATE.json",result)

def calculate_calls(data):
    y=data["y"]
    calls=np.zeros((len(BUDGETS),2,3,750),np.int8)
    pooled=np.zeros((len(BUDGETS),2,750),np.int8)
    threshold_rows=[]
    for bi,budget in enumerate(BUDGETS):
        for mi,model in enumerate(MODELS):
            out_s,out_q,in_s,in_q=COLS[model]
            refs=np.zeros((3,750),bool)
            pdvotes=np.zeros((3,750),bool)
            for i,(tr,te) in enumerate(data["splits"]):
                inner,outer=data["inner"][i],data["outer"][i]
                yy=y[tr]
                scut,allowed,attained=budget_cutoff(inner[in_s].to_numpy(),budget)
                qcut=sensitivity_cutoff(inner.loc[yy==1,in_q].to_numpy(),.95)
                rr=outer[out_s].to_numpy()>=scut
                vv=outer[out_q].to_numpy()>=qcut
                refs[i//5,te]=rr
                pdvotes[i//5,te]=vv
                calls[bi,mi,i//5,te]=np.where(rr,np.where(vv,1,2),0)
                threshold_rows.append(dict(budget=budget,model=model,outer_fold=i,
                    screen_threshold=scut,pd_threshold=qcut,
                    allowed_training_referrals=allowed,attained_training_referrals=attained,
                    training_n=len(tr),training_PD=int(np.sum(yy==1)),
                    training_PD_above_q=int(np.sum(inner.loc[yy==1,in_q].to_numpy()>=qcut))))
            pooled[bi,mi]=majority(refs,pdvotes)
    return calls,pooled,pd.DataFrame(threshold_rows)

def confusions_and_metrics(data,repeated,pooled):
    y=data["y"]
    confusions=[]
    metrics=[]
    for bi,budget in enumerate(BUDGETS):
        for mi,model in enumerate(MODELS):
            scopes={"participant_majority":pooled[bi,mi],
                    **{f"repeat_{r}":repeated[bi,mi,r] for r in range(3)}}
            for scope,pred in scopes.items():
                c=cmatrix(y,pred)
                for truth in range(3):
                    for call in range(3):
                        confusions.append(dict(budget=budget,model=model,scope=scope,
                            true_class=truth,predicted_class=call,n=int(c[truth,call])))
                num,den,val=quantities(c)
                for k,name in enumerate(METRICS):
                    metrics.append(dict(budget=budget,model=model,scope=scope,metric=name,
                        numerator=int(num[k]),denominator=int(den[k]),estimate=float(val[k])))
    return pd.DataFrame(confusions),pd.DataFrame(metrics)

def finite_interval(values):
    values=np.asarray(values,float)
    values=values[np.isfinite(values)]
    if not len(values):
        return np.nan,np.nan,0
    lower,upper=np.quantile(values,[.025,.975],method="linear")
    return float(lower),float(upper),len(values)

def bootstrap(data,pooled):
    y=data["y"]
    rng=np.random.default_rng(SEED)
    groups=[np.flatnonzero(y==i) for i in range(3)]
    cells=np.asarray([[3*y+pooled[b,m] for m in range(2)] for b in range(len(BUDGETS))])
    values=np.full((NBOOT,len(BUDGETS),2,len(METRICS)),np.nan)
    for draw in range(NBOOT):
        if draw%500==0:
            check_memory()
        sampled=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in groups])
        weights=np.bincount(sampled,minlength=750)
        for b in range(len(BUDGETS)):
            for m in range(2):
                matrix=np.bincount(cells[b,m],weights=weights,minlength=9).reshape(3,3)
                values[draw,b,m]=quantities(matrix)[2]
    intervals=[]
    deltas=[]
    for b,budget in enumerate(BUDGETS):
        point=[]
        for m,model in enumerate(MODELS):
            estimates=quantities(cmatrix(y,pooled[b,m]))[2]
            point.append(estimates)
            for k,metric in enumerate(METRICS):
                low,high,n=finite_interval(values[:,b,m,k])
                intervals.append(dict(budget=budget,model=model,metric=metric,
                    estimate=float(estimates[k]),nominal95_low=low,nominal95_high=high,
                    finite_draws=n,bootstrap_draws=NBOOT))
        for k,metric in enumerate(METRICS):
            low,high,n=finite_interval(values[:,b,0,k]-values[:,b,1,k])
            deltas.append(dict(budget=budget,metric=metric,
                voice_minus_baseline=float(point[0][k]-point[1][k]),
                nominal95_low=low,nominal95_high=high,finite_draws=n,bootstrap_draws=NBOOT))
    return pd.DataFrame(intervals),pd.DataFrame(deltas)

def run():
    start=now()
    t=time.monotonic()
    frozen()
    assert not (OUT/"COMPLETION.json").exists()
    start_memory=check_memory(initial=True)
    save_json("TESTS.json",hand_tests())
    data=load_inputs()
    original_gate(data)
    repeats,pool,thresholds=calculate_calls(data)
    confusions,metrics=confusions_and_metrics(data,repeats,pool)
    intervals,differences=bootstrap(data,pool)
    local=OUT/"local_only"
    local.mkdir(exist_ok=True)
    np.savez_compressed(local/"independent_calls.npz",repeat_calls=repeats,majority_calls=pool)
    tables={"thresholds.csv":thresholds,"confusion_matrices.csv":confusions,
            "metrics.csv":metrics,"intervals.csv":intervals,"paired_differences.csv":differences}
    for name,table in tables.items():
        table.to_csv(OUT/name,index=False)
    frozen()
    outputs={name:digest(OUT/name) for name in list(tables)+["GATE.json","TESTS.json"]}
    save_json("COMPLETION.json",dict(status="INDEPENDENT_RESULTS_FROZEN_BEFORE_COMPARISON",
        started_utc=start,completed_utc=now(),seconds=time.monotonic()-t,
        owner_code_read=False,owner_new_results_read=False,models_refitted=False,
        participants=750,outer_folds=15,budgets=7,procedures=2,metrics_per_scope=12,
        threshold_rows=len(thresholds),confusion_rows=len(confusions),metric_rows=len(metrics),
        interval_rows=len(intervals),paired_difference_rows=len(differences),
        versions=version_info(),start_memory=start_memory,end_memory=check_memory(),
        inputs_unchanged=True,outputs_sha256=outputs,
        private_checkpoint_sha256=digest(local/"independent_calls.npz"),
        checkpoint_export_prohibited=True))
    print("Independent F13 results frozen; reconciliation with owner still pending.",flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("command",choices=["run","selftest"])
    args=p.parse_args()
    if args.command=="selftest":
        print(json.dumps(hand_tests(),indent=2))
    else:
        run()
