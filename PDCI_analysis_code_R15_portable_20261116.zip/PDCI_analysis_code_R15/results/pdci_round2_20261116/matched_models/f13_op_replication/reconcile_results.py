"""Compare frozen independent F13 aggregate outputs with owner tables only."""
import csv,hashlib,json,math
from pathlib import Path
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent
OWNER=OUT.parents[1]/"operating_points"
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
def read(p):
 with p.open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def value(x):
 try:return float(x)
 except (ValueError,TypeError):return float("nan")
completion=json.loads((OUT/"COMPLETION.json").read_text())
assert completion["owner_code_read"] is False and completion["owner_new_results_read"] is False
for name,digest in completion["outputs_sha256"].items():assert sha(OUT/name)==digest
metric_map=dict(zip(
["referral_fraction","case_screening_sensitivity","PD_screening_sensitivity","CI_screening_sensitivity","neither_specificity","PD_end_to_end_sensitivity","CI_end_to_end_sensitivity","PD_assignment_PPV","CI_assignment_PPV","CI_to_PD","PD_to_CI","correct_case_assignment"],
["referral_fraction","screen_sensitivity","screen_PD_sensitivity","screen_CI_sensitivity","screen_specificity","end_to_end_PD_recall","end_to_end_CI_recall","end_to_end_PD_PPV_vs_rest","end_to_end_CI_PPV_vs_rest","CI_to_PD_rate","PD_to_CI_rate","correct_case_assignment"]))
rows=[]
mismatches=[]
def test_table(name,left,right,key,cols):
 a={key(r):r for r in left};b={key(r):r for r in right}
 assert len(a)==len(left) and len(b)==len(right) and set(a)==set(b),name+" row keys differ"
 maximum=0.; matched=0;missing_pairs=0
 for k in a:
  for col in cols:
   x,y=value(a[k][col]),value(b[k][col])
   if math.isnan(x) and math.isnan(y):matched+=1;missing_pairs+=1;continue
   delta=abs(x-y)
   if math.isfinite(delta):maximum=max(maximum,delta)
   if math.isfinite(delta) and delta<=1e-12:matched+=1
   else:mismatches.append(dict(table=name,key=list(k),column=col,independent=x if math.isfinite(x) else None,owner=y if math.isfinite(y) else None))
 rows.append(dict(table=name,rows=len(a),numeric_cells=len(a)*len(cols),matched_cells=matched,equal_missing_cells=missing_pairs,max_absolute_difference=maximum,columns=cols))
key=lambda r:(float(r["budget"]),r["model"],int(r["outer_fold"]))
a=read(OUT/"thresholds.csv")
for r in a:
 r["n_training"]=r["training_n"];r["training_referrals"]=r["attained_training_referrals"]
 r["training_referral_fraction"]=str(float(r["attained_training_referrals"])/float(r["training_n"]))
 r["training_PD_discrimination_sensitivity"]=str(float(r["training_PD_above_q"])/float(r["training_PD"]))
test_table("training_thresholds",a,read(OWNER/"training_thresholds.csv"),key,["screen_threshold","pd_threshold","n_training","training_referrals","training_referral_fraction","training_PD_discrimination_sensitivity"])
a=read(OUT/"confusion_matrices.csv");b=read(OWNER/"confusion_matrices.csv")
lookup={"Neither":"0","PD":"1","CI":"2"}
for r in b:r["true_class"]=lookup[r["true_class"]];r["predicted_class"]=lookup[r["predicted_class"]]
key=lambda r:(float(r["budget"]),r["model"],r["scope"],int(r["true_class"]),int(r["predicted_class"]))
test_table("confusion_matrices",a,b,key,["n"])
a=read(OUT/"metrics.csv")
for r in a:r["metric"]=metric_map[r["metric"]]
key=lambda r:(float(r["budget"]),r["model"],r["scope"],r["metric"])
test_table("operating_points",a,read(OWNER/"operating_points.csv"),key,["numerator","denominator","estimate"])
majority={(float(r["budget"]),r["model"],r["metric"]):r for r in a if r["scope"]=="participant_majority"}
a=read(OUT/"intervals.csv")
for r in a:
 r["metric"]=metric_map[r["metric"]];r["ci_low"]=r["nominal95_low"];r["ci_high"]=r["nominal95_high"];r["n_boot"]=r["bootstrap_draws"]
 m=majority[(float(r["budget"]),r["model"],r["metric"])]
 r["numerator"]=m["numerator"];r["denominator"]=m["denominator"]
key=lambda r:(float(r["budget"]),r["model"],r["metric"])
test_table("nominal_bootstrap_intervals",a,read(OWNER/"nominal_bootstrap_intervals.csv"),key,["numerator","denominator","estimate","ci_low","ci_high","n_boot","finite_draws"])
a=read(OUT/"paired_differences.csv")
for r in a:
 r["metric"]=metric_map[r["metric"]];r["ci_low"]=r["nominal95_low"];r["ci_high"]=r["nominal95_high"];r["n_boot"]=r["bootstrap_draws"];r["difference"]=r["voice_minus_baseline"]
key=lambda r:(float(r["budget"]),r["metric"])
test_table("paired_voice_minus_baseline",a,read(OWNER/"paired_voice_minus_baseline.csv"),key,["difference","ci_low","ci_high","n_boot","finite_draws"])
owner_files=["training_thresholds.csv","confusion_matrices.csv","operating_points.csv","nominal_bootstrap_intervals.csv","paired_voice_minus_baseline.csv"]
report=dict(status="PASS" if not mismatches else "FAIL",at=datetime.now(timezone.utc).isoformat(),independent_frozen_before_owner_results_read=True,owner_source_read=False,
 tolerance=1e-12,tables=rows,rows_compared=sum(r["rows"] for r in rows),cells_compared=sum(r["numeric_cells"] for r in rows),
 cells_matched=sum(r["matched_cells"] for r in rows),max_absolute_difference=max(r["max_absolute_difference"] for r in rows),
 mismatches=mismatches,script_sha256=sha(Path(__file__)),independent_completion_sha256=sha(OUT/"COMPLETION.json"),
 owner_outputs_sha256={name:sha(OWNER/name) for name in owner_files})
target=OUT/"RECONCILIATION.json"
assert not target.exists()
target.write_text(json.dumps(report,indent=2,allow_nan=False),encoding="utf-8")
print(json.dumps({k:report[k] for k in ["status","rows_compared","cells_compared","cells_matched","max_absolute_difference"]},indent=2))
if mismatches:raise SystemExit(2)
