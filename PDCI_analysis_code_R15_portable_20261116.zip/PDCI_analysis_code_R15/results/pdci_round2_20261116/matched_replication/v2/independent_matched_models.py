"""Independent F12-MM reimplementation from frozen protocol, without owner code."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,ast,ctypes,hashlib,json,math,os,platform,re,time,warnings
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import joblib,numpy as np,pandas as pd,scipy,sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold,RepeatedStratifiedKFold
from sklearn.metrics import roc_auc_score
from sklearn.exceptions import ConvergenceWarning
from scipy.stats import t as student_t
from threadpoolctl import threadpool_limits

ROOT=Path(os.environ.get("PDCI_ANALYSIS_ROOT",str(Path(__file__).resolve().parents[4]))).resolve()
CAN=ROOT/'results/pdci_demographic_baseline_20260911'
OWNER=ROOT/'results/pdci_round2_20261116/matched_models'
OUT=ROOT/'results/pdci_round2_20261116/matched_replication/v2'
ARMS=('D','DA','DMT','DMTA');ENDS=('screen','stage2','macro')
GRID=[(c,w) for c in (.01,.1,1.,10.) for w in ('empirical','balanced')]
SEED=20260725;B=5000;BOOT_SEED=20261116
RECORDING=Path(os.environ.get("PDCI_DATA_ROOT",str(ROOT.parent))).resolve()/"phenotype/task/recording.tsv"

def now():return datetime.now(timezone.utc).isoformat()
def hashfile(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save_json(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def memory():
    class M(ctypes.Structure):
        _fields_=[('n',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('phys','free','limit','head','v','vf','e')]
    s=M();s.n=ctypes.sizeof(s);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
    return {'free_GiB':s.free/2**30,'headroom_GiB':s.head/2**30}
def memory_wait(start=False):
    while True:
        m=memory()
        if m['headroom_GiB']>=(5 if start else 3) and (not start or m['free_GiB']>=.4):return m
        save_json('WAIT_STATUS.json',{'status':'WAITING_MEMORY','time':now(),**m})
        time.sleep(15);start=True
def label_key(x):return (hashlib.sha256(x.encode('utf-8')).hexdigest(),x)
def microphone_label(x):
    if pd.isna(x):return None
    value=str(x).strip()
    return None if value.lower() in ('','n/a','na','nan','none','null') else value
def mode(values):
    values=[x for x in values if x is not None]
    if not values:return None
    counts={x:values.count(x) for x in set(values)}
    return min(counts,key=lambda x:(-counts[x],*label_key(x)))

class NumericFit:
    def fit(self,arr):
        a=np.array(arr,dtype=np.float64,copy=True);a[~np.isfinite(a)]=np.nan
        self.use=np.isfinite(a).mean(0)>=.5;z=a[:,self.use]
        bounds=np.nanquantile(z,[.005,.995],axis=0)
        bad=bounds[1]<=bounds[0];bounds[0,bad]=-np.inf;bounds[1,bad]=np.inf
        self.low,self.high=bounds
        z=np.clip(z,self.low,self.high);self.median=np.nanmedian(z,axis=0)
        z=np.where(np.isfinite(z),z,self.median)
        self.center=z.mean(0);self.scale=z.std(0);self.variable=self.scale>1e-8
        assert self.variable.any()
        return (z-self.center)[:,self.variable]/self.scale[self.variable]
    def apply(self,arr):
        z=np.asarray(arr,np.float64)[:,self.use];z=np.where(np.isfinite(z),z,np.nan)
        z=np.clip(z,self.low,self.high);z=np.where(np.isfinite(z),z,self.median)
        return (z-self.center)[:,self.variable]/self.scale[self.variable]

def metadata(ids,tasks):
    source=pd.read_csv(RECORDING,sep='\t',usecols=['participant_id','recording_name','recording_microphone','recording_input_gain'],dtype=str)
    source['id']=source.participant_id.str.strip().str.zfill(6)
    tree=ast.parse((ROOT/'src/config.py').read_text(encoding='utf-8'))
    rules=None
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TASK_GROUP_RULES' for t in node.targets):rules=ast.literal_eval(node.value)
    assert rules is not None
    def task_name(s):
        s=str(s).strip().lower().replace(' ','-')
        for pat,name in rules:
            if re.match(pat,s):return name
        return 'other'
    source['task']=source.recording_name.map(task_name)
    source=source[source.id.isin(ids)&source.task.isin(tasks)].copy()
    source['mic']=source.recording_microphone.map(microphone_label)
    source['gain']=pd.to_numeric(source.recording_input_gain,errors='coerce')
    source.loc[~np.isfinite(source.gain),'gain']=np.nan
    grouped=source.groupby(['id','task'],sort=True)
    microphone=grouped.mic.agg(lambda col:mode(col.tolist()))
    gain=grouped.gain.mean()
    index=pd.MultiIndex.from_product([ids,tasks],names=['id','task'])
    assert len(grouped)==750*11 and set(index).issubset(set(grouped.groups))
    mm=microphone.reindex(index).to_numpy(object).reshape(len(ids),len(tasks))
    gg=gain.reindex(index).to_numpy(float).reshape(len(ids),len(tasks))
    # Explicitly ignore missing task values; there are no missingness indicator predictors.
    cats=np.array([mode([v if isinstance(v,str) else None for v in row]) for row in mm],dtype=object)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        numeric=np.column_stack([np.nanmean(gg,axis=1),np.nanstd(gg,axis=1,ddof=1)])
    return numeric,cats

def read_inputs():
    d=joblib.load(CAN/'local_only/input_payload.joblib')
    schema=json.loads((CAN/'feature_schemas.json').read_text())
    ids=np.asarray(d['ids']).astype(str);y=np.asarray(d['y'],int)
    assert len(set(ids))==750 and np.array_equal(np.bincount(y),[598,90,62])
    names=schema['individual__timing_off'];on_names=schema['individual__timing_on']
    ai=[i for i,k in enumerate(names) if k not in schema['demographic_baseline']]
    ti=[i for i,k in enumerate(on_names) if k not in names]
    arrays={'D':np.asarray(d['asc'],np.float32),'A':np.asarray(d['matrices']['individual__timing_off'][:,ai],np.float32),
            'T':np.asarray(d['matrices']['individual__timing_on'][:,ti],np.float32)}
    splits=d['splits'];del d
    assert arrays['D'].shape==(750,3) and arrays['A'].shape==(750,5555) and arrays['T'].shape==(750,80)
    assert not (set(names[i] for i in ai)&set(on_names[i] for i in ti))
    expected=list(RepeatedStratifiedKFold(n_splits=5,n_repeats=3,random_state=SEED).split(np.zeros(750),y))
    assert len(splits)==15 and schema['demographic_baseline']==['age','sex_male','residence_country_USA']
    coverage=np.zeros((3,750),int)
    for fold,((tr,te),(rtr,rte)) in enumerate(zip(splits,expected)):
        assert np.array_equal(tr,rtr) and np.array_equal(te,rte) and not set(tr)&set(te)
        coverage[fold//5,te]+=1
    assert np.all(coverage==1)
    tasks=json.loads((CAN/'INPUT_AUDIT.json').read_text())['general_tasks']
    arrays['M'],cats=metadata(ids,tasks)
    saved=pd.read_parquet(CAN/'local_only/participant_oof_predictions.parquet').reindex(ids)
    reference=pd.read_csv(CAN/'pooled_oof_metrics.csv',float_precision='round_trip').set_index('model')
    checks=[]
    assert np.array_equal(saved.y_true.to_numpy(int),y)
    for model in ('primary','agesexcountry'):
        s=saved[model+'_screen'].to_numpy();q=saved[model+'_q'].to_numpy()
        p=saved[[model+'_p'+str(c) for c in range(3)]].to_numpy()
        metrics=aucs(y,s,q,p)
        for endpoint,value in zip(ENDS,metrics):
            error=abs(float(value)-float(reference.loc[model,endpoint]));assert error<=1e-9
            checks.append(dict(model=model,endpoint=endpoint,absolute_difference=error))
    save_json('GATE.json',{'status':'PASS','time':now(),'participants':750,'class_counts':[598,90,62],
        'outer_partitions_exact':15,'test_coverage_per_repeat':1,'metadata_task_pairs':8250,
        'A_columns':5555,'T_columns':80,'canonical_auroc_checks':checks})
    return ids,y,arrays,cats,splits

def assemble(arrays,categories,train,test,arm):
    if arm=='D':return arrays['D'][train],arrays['D'][test]
    if arm=='DA':return np.column_stack([arrays['D'][train],arrays['A'][train]]),np.column_stack([arrays['D'][test],arrays['A'][test]])
    fill=mode(categories[train].tolist())
    trcat=np.array([fill if c is None else c for c in categories[train]],object)
    tecat=np.array([fill if c is None else c for c in categories[test]],object)
    vocab=np.array(sorted({v for v in trcat if v is not None},key=label_key),object)
    trhot=(trcat[:,None]==vocab[None,:]).astype(np.float64)
    tehot=(tecat[:,None]==vocab[None,:]).astype(np.float64)
    trparts=[arrays['D'][train],arrays['M'][train],arrays['T'][train],trhot]
    teparts=[arrays['D'][test],arrays['M'][test],arrays['T'][test],tehot]
    if arm=='DMTA':trparts.append(arrays['A'][train]);teparts.append(arrays['A'][test])
    return np.column_stack(trparts),np.column_stack(teparts)

def train_predict(x,z,target,c,w):
    processor=NumericFit();xx=processor.fit(x);zz=processor.apply(z)
    scaler=StandardScaler();xx=scaler.fit_transform(xx);zz=scaler.transform(zz)
    model=LogisticRegression(C=c,penalty='l2',solver='lbfgs',max_iter=5000,tol=1e-4,
          random_state=SEED,class_weight=None if w=='empirical' else 'balanced')
    with warnings.catch_warnings():
        warnings.simplefilter('error',ConvergenceWarning);warnings.simplefilter('ignore',FutureWarning)
        model.fit(xx,target)
    assert model.classes_.tolist()==[0,1]
    return np.clip(model.predict_proba(zz)[:,1],1e-8,1-1e-8)

def compose(s,q):return np.column_stack([1-s,s*q,s*(1-q)])
def aucs(y,s,q,p):return np.array([roc_auc_score(y>0,s),roc_auc_score(y[y>0]==1,q[y>0]),roc_auc_score(y,p,average='macro',multi_class='ovr')])
def weighted_auc(y,p,w):
    # Independent pairwise rank definition; each tied pair contributes one half.
    yes=np.flatnonzero(y);no=np.flatnonzero(~y)
    comparisons=(p[yes,None]>p[None,no]).astype(float)+.5*(p[yes,None]==p[None,no])
    denominator=w[:,yes].sum(1)*w[:,no].sum(1)
    numerator=np.sum((w[:,yes]@comparisons)*w[:,no],axis=1)
    return numerator/denominator
def bh(values):
    p=np.asarray(values,float);order=np.argsort(p,kind='stable');n=len(p)
    ranked=np.minimum.accumulate((p[order]*n/np.arange(1,n+1))[::-1])[::-1]
    q=np.empty(n);q[order]=np.minimum(ranked,1);return q
def difference(augmented,comparator):return np.asarray(augmented)-np.asarray(comparator)
def corrected_interval(diff,ratio):
    mean=float(np.mean(diff));se=math.sqrt((1/len(diff)+ratio)*np.var(diff,ddof=1))
    critical=float(student_t.ppf(.975,len(diff)-1))
    p=float(2*student_t.sf(abs(mean/se),len(diff)-1)) if se>0 else (1. if mean==0 else 0.)
    return mean,se,mean-critical*se,mean+critical*se,p

def selftests():
    x=np.array([[0,0,np.nan],[1,0,2],[2,0,3],[3,0,4]],float)
    prep=NumericFit();z=prep.fit(x);out=prep.apply([[1,999,np.nan]])
    assert z.shape==(4,2) and np.isfinite(out).all()
    y=np.array([0,1,0,1],bool);p=np.array([.1,.5,.5,.9]);w=np.array([[1,1,1,1],[1,2,2,1]])
    actual=weighted_auc(y,p,w)
    for j,row in enumerate(w):
        ix=np.repeat(np.arange(4),row);assert abs(actual[j]-roc_auc_score(y[ix],p[ix]))<1e-14
    assert np.allclose(bh([.01,.04,.03]),[.03,.04,.04])
    assert np.allclose(compose(np.array([.2,.8]),np.array([.3,.7])).sum(1),1)
    assert mode([None,'a','a','b'])=='a' and mode([None]) is None
    assert microphone_label(' n/A ') is None and microphone_label('DeviceA')=='DeviceA'
    assert np.allclose(difference(np.array([.9,.8]),np.array([.7,.6])),[.2,.2])
    assert corrected_interval(np.zeros(15),.25)==(0.,0.,0.,0.,1.)
    fake={'D':np.ones((4,3),np.float32),'M':np.ones((4,2)), 'T':np.ones((4,80),np.float32)}
    x,z=assemble(fake,np.array([None,None,'unseen',None],object),np.array([0,1]),np.array([2,3]),'DMT')
    assert x.shape==(2,85) and z.shape==(2,85)
    x,z=assemble(fake,np.array(['known','known','unseen',None],object),np.array([0,1]),np.array([2,3]),'DMT')
    assert x.shape==(2,86) and np.array_equal(z[:,-1],[0,1])
    return {'preprocessing':True,'pairwise_weighted_auc_ties':True,'BH':True,'composition':True,'modes':True,
        'contrast_sign':True,'all_missing_and_unseen_categories':True,'zero_difference_corrected_CV':True}

def inputs():
    paths=[Path(__file__),OUT/'ANALYSIS_PLAN.md',OWNER/'ANALYSIS_PLAN.md',OWNER/'AMENDMENT_1_IMPLEMENTATION_DETAILS.md',OWNER/'FROZEN_SPEC.json',
           CAN/'local_only/input_payload.joblib',CAN/'feature_schemas.json',CAN/'INPUT_AUDIT.json',CAN/'local_only/split_manifest.json',
           CAN/'local_only/participant_oof_predictions.parquet',CAN/'pooled_oof_metrics.csv',RECORDING,ROOT/'src/config.py']
    for i in range(15):paths.extend([CAN/f'local_only/folds/fold_{i:02d}.json',CAN/f'local_only/folds/fold_{i:02d}.parquet'])
    return paths
def freeze():
    assert not (OUT/'FROZEN_SPEC.json').exists()
    save_json('TESTS.json',selftests())
    save_json('FROZEN_SPEC.json',{'created_utc':now(),'family':'F12-MM independent reimplementation','owner_code_read_before_freeze':False,
       'implementation_basis':'owner protocol and amendment, canonical baseline source inspected as common method reference; owner matched-model code unread',
       'sha256':{str(p):hashfile(p) for p in inputs()},'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__},
       'tolerances':{'canonical_baseline_max_abs':1e-9,'independent_predictions_max_abs':1e-7,'aggregate_metrics_max_abs':1e-9,'exact_selections':True}})
def verify():
    spec=json.loads((OUT/'FROZEN_SPEC.json').read_text())
    for p,h in spec['sha256'].items():assert hashfile(p)==h,'Protected file changed'
    return spec

def canonical_baseline_check(outer,choice_rows,fold):
    canon=pd.read_parquet(CAN/f'local_only/folds/fold_{fold:02d}.parquet')
    error=float(np.max(np.abs(outer-canon[['agesexcountry_screen','agesexcountry_q']].to_numpy())))
    assert error<=1e-9,f'Canonical baseline gate failed at fold {fold}, max difference {error}'
    cjson=json.loads((CAN/f'local_only/folds/fold_{fold:02d}.json').read_text())
    for j,name in enumerate(('asc_screen','asc_stage2')):
        cc=cjson['choices'][name];assert cc['c']==choice_rows[j]['c'] and cc['weight']==choice_rows[j]['weight']

def run():
    assert not (OUT/'COMPLETION.json').exists(),'Completed run is immutable'
    verify();selftests();memory_wait(start=True)
    ids,y,arrays,cats,splits=read_inputs();(OUT/'local_only').mkdir(exist_ok=True)
    # Canonical baseline integrated gate is completed before augmented-arm replication.
    choices=[];inner_rows=[];pred=np.full((4,3,750,2),np.nan)
    for a,arm in enumerate(ARMS):
        for fold,(tr,te) in enumerate(splits):
            memory_wait();checkpoint=OUT/f'local_only/{arm}_{fold:02d}.npz'
            receipt=OUT/f'local_only/{arm}_{fold:02d}.json'
            if checkpoint.exists() and receipt.exists():
                rec=json.loads(receipt.read_text());assert hashfile(checkpoint)==rec['checkpoint_sha256']
                assert rec['arm']==arm and rec['outer_fold']==fold
                with np.load(checkpoint,allow_pickle=False) as saved:
                    assert set(saved.files)=={'outer','inner','test_indices'}
                    assert np.array_equal(saved['test_indices'],te)
                    assert saved['outer'].shape==(len(te),2) and saved['inner'].shape==(len(tr),2)
                    assert np.isfinite(saved['outer']).all()
                    assert np.isfinite(saved['inner'][:,0]).all() and np.isfinite(saved['inner'][y[tr]>0,1]).all()
                    assert all(c['arm']==arm and c['outer_fold']==fold for c in rec['choices'])
                    assert len(rec['choices'])==2 and len(rec['inner_scores'])==16
                    if arm=='D':canonical_baseline_check(saved['outer'],rec['choices'],fold)
                    pred[a,fold//5,te,:]=saved['outer']
                choices.extend(rec['choices']);inner_rows.extend(rec['inner_scores']);continue
            split3=list(StratifiedKFold(3,shuffle=True,random_state=SEED+1009*fold).split(np.zeros(len(tr)),y[tr]))
            outer=np.zeros((len(te),2));oofs=np.full((len(tr),2),np.nan);choice_rows=[];score_rows=[]
            for stage in (0,1):
                candidate=np.full((len(tr),8),np.nan)
                for it,iv in split3:
                    train=tr[it];valid=tr[iv]
                    if stage:
                        train=train[y[train]>0];iv=iv[y[valid]>0];valid=tr[iv]
                    x,z=assemble(arrays,cats,train,valid,arm)
                    target=(y[train]==1 if stage else y[train]>0).astype(int)
                    for cidx,(c,w) in enumerate(GRID):candidate[iv,cidx]=train_predict(x,z,target,c,w)
                mask=y[tr]>0 if stage else np.ones(len(tr),bool)
                truth=(y[tr][mask]==1 if stage else y[tr][mask]>0).astype(int)
                scores=np.array([roc_auc_score(truth,candidate[mask,k]) for k in range(8)])
                selected=np.flatnonzero(scores>=scores.max()-.005)[0];c,w=GRID[selected]
                train=tr[y[tr]>0] if stage else tr
                x,z=assemble(arrays,cats,train,te,arm);target=(y[train]==1 if stage else y[train]>0).astype(int)
                outer[:,stage]=train_predict(x,z,target,c,w);oofs[:,stage]=candidate[:,selected]
                choice_rows.append(dict(arm=arm,outer_fold=fold,stage=ENDS[stage],c=c,weight=w,inner_auroc=float(scores[selected])))
                score_rows.extend(dict(arm=arm,outer_fold=fold,stage=ENDS[stage],c=cc,weight=ww,inner_auroc=float(scores[k])) for k,(cc,ww) in enumerate(GRID))
            if arm=='D':canonical_baseline_check(outer,choice_rows,fold)
            pred[a,fold//5,te,:]=outer
            np.savez_compressed(checkpoint,outer=outer,inner=oofs,test_indices=te)
            save_json(str(receipt.relative_to(OUT)),{'arm':arm,'outer_fold':fold,'time':now(),'choices':choice_rows,'inner_scores':score_rows,'checkpoint_sha256':hashfile(checkpoint)})
            choices.extend(choice_rows);inner_rows.extend(score_rows)
            save_json('RUN_STATUS.json',{'status':'FITTING','arm':arm,'outer_fold_completed':fold,'time':now(),'memory':memory()})
        if arm=='D':save_json('BASELINE_REPRODUCTION_GATE.json',{'status':'PASS','folds':15,'choices':30,'prediction_tolerance':1e-9,'time':now()})
    assert np.isfinite(pred).all()
    pd.DataFrame(choices).to_csv(OUT/'selected_candidates.csv',index=False,float_format='%.17g')
    pd.DataFrame(inner_rows).to_csv(OUT/'candidate_inner_aurocs.csv',index=False,float_format='%.17g')
    np.savez_compressed(OUT/'local_only/predictions.npz',predictions=pred)
    summarize(y,pred,splits)
    verify();save_json('COMPLETION.json',{'status':'AWAITING_RECONCILIATION','time':now(),'family':'F12-MM replica','folds':60,'model_fits':3000,
        'output_sha256':{p.name:hashfile(p) for p in OUT.glob('*.csv')}})

def summarize(y,pred,splits):
    arm_points={};fold_points={};mean_scores={};arm_rows=[];fold_rows=[]
    for ai,arm in enumerate(ARMS):
        s=pred[ai,:,:,0].mean(0);q=pred[ai,:,:,1].mean(0)
        pp=np.mean([compose(pred[ai,r,:,0],pred[ai,r,:,1]) for r in range(3)],axis=0)
        mean_scores[arm]=(s,q,pp);arm_points[arm]=aucs(y,s,q,pp)
        arm_rows.extend(dict(arm=arm,endpoint=e,auroc=float(v)) for e,v in zip(ENDS,arm_points[arm]))
        folds=[]
        for oi,(tr,te) in enumerate(splits):
            s1=pred[ai,oi//5,te,0];q1=pred[ai,oi//5,te,1]
            vals=aucs(y[te],s1,q1,compose(s1,q1));folds.append(vals)
            fold_rows.extend(dict(arm=arm,outer_fold=oi,endpoint=e,auroc=float(v)) for e,v in zip(ENDS,vals))
        fold_points[arm]=np.asarray(folds)
    rng=np.random.default_rng(BOOT_SEED);groups=[np.flatnonzero(y==c) for c in range(3)]
    weights=np.zeros((B,len(y)),np.float64)
    for b in range(B):
        ix=np.concatenate([rng.choice(g,len(g),replace=True) for g in groups]);weights[b]=np.bincount(ix,minlength=len(y))
    draws={}
    for arm in ARMS:
        memory_wait();s,q,pp=mean_scores[arm];case=y>0
        draws[arm]=np.column_stack([weighted_auc(case,s,weights),weighted_auc(y[case]==1,q[case],weights[:,case]),
                  np.mean([weighted_auc(y==c,pp[:,c],weights) for c in range(3)],axis=0)])
    rows=[]
    for aug,base in (('DA','D'),('DMTA','DMT')):
        for ei,endpoint in enumerate(ENDS):
            diff=difference(fold_points[aug][:,ei],fold_points[base][:,ei])
            ratio=np.mean([np.sum(y[te]>0)/np.sum(y[tr]>0) if endpoint=='stage2' else len(te)/len(tr) for tr,te in splits])
            mean,se,clow,chigh,p=corrected_interval(diff,ratio)
            pooled=difference(arm_points[aug][ei],arm_points[base][ei])
            lower,upper=np.quantile(difference(draws[aug][:,ei],draws[base][:,ei]),[.025,.975])
            rows.append(dict(augmented=aug,comparator=base,endpoint=endpoint,pooled_gain=float(pooled),bootstrap_low=float(lower),bootstrap_high=float(upper),
                mean_fold_gain=mean,corrected_se=se,corrected_low=clow,corrected_high=chigh,corrected_p=p,test_train_ratio=float(ratio)))
    q=bh([r['corrected_p'] for r in rows])
    for r,qq in zip(rows,q):r['BH6_p']=float(qq)
    pd.DataFrame(arm_rows).to_csv(OUT/'arm_metrics.csv',index=False,float_format='%.17g')
    pd.DataFrame(fold_rows).to_csv(OUT/'fold_metrics.csv',index=False,float_format='%.17g')
    pd.DataFrame(rows).to_csv(OUT/'paired_comparisons.csv',index=False,float_format='%.17g')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['freeze','run','verify','selftests']);args=ap.parse_args()
    with threadpool_limits(1):globals()[args.action]()
